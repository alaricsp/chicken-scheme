/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:24
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: chicken-syntax.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file chicken-syntax.c
   unit: chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[239];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,97,49,53,56,52,32,102,111,114,109,49,52,48,54,32,114,49,52,48,55,32,99,49,52,48,56,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,97,49,53,57,52,32,120,49,51,57,55,32,114,49,51,57,56,32,99,49,51,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,97,49,54,49,57,32,102,111,114,109,49,51,54,55,32,114,49,51,54,56,32,99,49,51,54,57,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,97,49,55,50,55,32,102,111,114,109,49,51,53,49,32,114,49,51,53,50,32,99,49,51,53,51,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,115,49,51,48,48,32,100,49,51,48,49,32,99,115,49,51,48,50,32,101,120,112,111,114,116,115,49,51,48,51,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,97,49,56,51,49,32,102,111,114,109,49,50,56,56,32,114,49,50,56,57,32,99,49,50,57,48,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,50,53,54,32,118,97,114,115,49,50,53,55,32,98,115,49,50,53,56,32,118,97,108,115,49,50,53,57,32,114,101,115,116,49,50,54,48,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,97,50,49,48,56,32,102,111,114,109,49,50,52,52,32,114,49,50,52,53,32,99,49,50,52,54,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,50,49,53,32,118,97,114,115,49,50,49,54,32,118,97,108,115,49,50,49,55,32,114,101,115,116,49,50,49,56,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,97,50,51,50,55,32,102,111,114,109,49,50,48,51,32,114,49,50,48,52,32,99,49,50,48,53,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,49,54,57,32,105,49,49,55,48,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,97,50,56,55,51,32,115,110,97,109,101,49,49,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,28),40,97,50,53,49,53,32,102,111,114,109,49,49,51,49,32,114,49,49,51,50,32,99,49,49,51,51,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,51,48,51,56,32,107,49,49,49,53,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,48,56,55,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,28),40,97,50,56,57,48,32,102,111,114,109,49,48,55,49,32,114,49,48,55,50,32,99,49,48,55,51,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,28),40,97,51,50,49,55,32,102,111,114,109,49,48,53,56,32,114,49,48,53,57,32,99,49,48,54,48,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,28),40,97,51,52,49,49,32,102,111,114,109,49,48,51,51,32,114,49,48,51,52,32,99,49,48,51,53,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,57,51,56,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,14),40,103,101,110,118,97,114,115,32,110,57,51,52,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,51,54,53,48,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,98,117,105,108,100,32,118,97,114,115,50,57,57,56,32,118,114,101,115,116,57,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,97,51,54,54,48,32,118,97,114,115,49,57,57,50,32,118,97,114,115,50,57,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,31),40,97,51,54,49,56,32,118,97,114,115,57,55,49,32,97,114,103,99,57,55,50,32,114,101,115,116,57,55,51,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,20),40,97,51,54,48,56,32,99,57,54,56,32,98,111,100,121,57,54,57,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,97,51,57,49,57,32,118,97,114,115,57,52,54,32,97,114,103,99,57,52,55,32,114,101,115,116,57,52,56,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,51,57,48,57,32,99,57,52,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,25),40,97,51,53,48,57,32,102,111,114,109,57,50,56,32,114,57,50,57,32,99,57,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,97,114,103,115,57,48,54,32,118,97,114,100,101,102,115,57,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,25),40,97,51,57,51,48,32,102,111,114,109,56,56,53,32,114,56,56,54,32,99,56,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,25),40,97,52,50,51,50,32,102,111,114,109,56,54,51,32,114,56,54,52,32,99,56,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,54),40,114,101,99,117,114,32,118,97,114,115,55,57,48,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,55,57,49,32,100,101,102,115,55,57,50,32,110,101,120,116,45,103,117,121,55,57,51,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,100,101,102,97,117,108,116,45,112,114,111,99,115,32,118,97,114,115,55,56,50,32,98,111,100,121,45,112,114,111,99,55,56,51,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,55,56,52,32,100,101,102,115,55,56,53,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,45),40,114,101,99,117,114,32,118,97,114,115,56,49,49,32,100,101,102,97,117,108,116,101,114,115,56,49,50,32,110,111,110,45,100,101,102,97,117,108,116,115,56,49,51,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,57),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,56,48,51,32,100,101,102,97,117,108,116,101,114,115,56,48,52,32,98,111,100,121,45,112,114,111,99,56,48,53,32,114,101,115,116,56,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,29),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,56,51,49,32,115,121,109,56,51,50,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,52,56,50,52,32,118,97,114,56,52,54,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,97,52,56,51,52,32,118,56,51,54,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,25),40,97,52,52,49,54,32,102,111,114,109,55,54,54,32,114,55,54,55,32,99,55,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,97,52,57,55,57,32,120,55,53,54,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,19),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,55,52,51,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,25),40,97,52,56,52,56,32,102,111,114,109,55,50,52,32,114,55,50,53,32,99,55,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,102,111,108,100,32,98,115,54,57,49,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,25),40,97,53,48,49,55,32,102,111,114,109,54,56,48,32,114,54,56,49,32,99,54,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,26),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,54,52,57,32,105,100,54,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,25),40,97,53,49,56,48,32,102,111,114,109,54,52,49,32,114,54,52,50,32,99,54,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,25),40,97,53,50,56,49,32,102,111,114,109,54,50,56,32,114,54,50,57,32,99,54,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,54,48,53,41,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,97,53,52,52,57,32,118,54,50,49,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,97,53,52,49,49,32,118,98,54,49,53,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,12),40,97,53,52,56,55,32,118,54,49,51,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,97,53,52,57,51,32,118,54,48,49,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,12),40,97,53,53,49,49,32,120,53,57,55,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,25),40,97,53,51,53,53,32,102,111,114,109,53,56,54,32,114,53,56,55,32,99,53,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,19),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,53,55,51,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,25),40,97,53,53,50,49,32,102,111,114,109,53,54,50,32,114,53,54,51,32,99,53,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,52,53,54,32,108,52,53,55,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,52,53,57,32,108,52,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,53,48,48,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,12),40,97,53,55,51,53,32,118,53,52,51,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,53,50,56,32,101,120,112,115,53,50,57,32,108,108,105,115,116,115,50,53,51,48,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,97,53,56,55,49,32,120,53,53,55,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,53,48,54,32,97,99,99,53,48,55,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,12),40,97,53,57,50,51,32,118,52,57,54,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,52,55,54,32,97,99,99,52,55,55,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,25),40,97,53,53,57,51,32,102,111,114,109,52,52,52,32,114,52,52,53,32,99,52,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,97,54,48,48,53,32,103,52,51,52,52,51,53,52,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,25),40,97,53,57,56,49,32,102,111,114,109,52,50,53,32,114,52,50,54,32,99,52,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,17),40,97,54,49,51,56,32,118,52,49,55,32,97,52,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,25),40,97,54,48,50,51,32,102,111,114,109,51,56,56,32,114,51,56,57,32,99,51,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,97,54,49,54,56,32,102,111,114,109,51,55,57,32,114,51,56,48,32,99,51,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,25),40,97,54,50,50,49,32,102,111,114,109,51,55,48,32,114,51,55,49,32,99,51,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,97,54,51,56,50,32,97,51,54,50,32,97,50,51,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,12),40,97,54,52,52,52,32,122,51,53,52,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,12),40,97,54,52,53,52,32,122,51,53,48,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,97,54,50,54,54,32,102,111,114,109,51,51,48,32,114,51,51,49,32,99,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,50,57,55,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,25),40,97,54,52,54,56,32,102,111,114,109,50,54,55,32,114,50,54,56,32,99,50,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,19),40,97,54,54,56,55,32,105,100,50,53,57,32,111,116,50,54,48,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,19),40,97,54,55,48,49,32,110,116,50,53,50,32,105,100,50,53,51,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,19),40,97,54,55,53,49,32,105,100,50,52,53,32,110,116,50,52,54,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,19),40,97,54,55,54,53,32,111,116,50,51,56,32,105,100,50,51,57,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,50,51,52,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,12),40,97,54,56,50,51,32,120,50,50,48,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,12),40,97,54,56,51,51,32,120,50,49,54,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,25),40,97,54,53,56,57,32,102,111,114,109,50,48,52,32,114,50,48,53,32,99,50,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,25),40,97,54,56,52,55,32,102,111,114,109,49,56,52,32,114,49,56,53,32,99,49,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,97,54,57,56,52,32,102,111,114,109,49,53,57,32,114,49,54,48,32,99,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,7),40,97,55,49,50,55,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,22),40,100,111,108,111,111,112,49,52,50,32,120,49,52,57,32,120,115,49,53,48,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,7),40,97,55,49,51,50,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,55,49,54,53,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,7),40,97,55,49,50,49,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,25),40,97,55,48,57,53,32,102,111,114,109,49,49,54,32,114,49,49,55,32,99,49,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,25),40,97,55,49,56,52,32,102,111,114,109,49,48,56,32,114,49,48,57,32,99,49,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,97,55,50,48,50,32,102,111,114,109,57,54,32,114,57,55,32,99,57,56,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,22),40,97,55,51,48,49,32,102,111,114,109,54,50,32,114,54,51,32,99,54,52,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,51,54,32,105,51,55,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,17),40,97,55,52,52,52,32,120,56,32,114,57,32,99,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_chicken_syntax_toplevel)
C_externexport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_fcall f_7502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_fcall f_7565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7312)
static void C_ccall f_7312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7363)
static void C_fcall f_7363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7210)
static void C_ccall f_7210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7201)
static void C_ccall f_7201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_ccall f_7183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_fcall f_7143(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_ccall f_6985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6998)
static void C_ccall f_6998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_fcall f_7004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6983)
static void C_ccall f_6983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_fcall f_6921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_ccall f_6603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_fcall f_6800(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_fcall f_6531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6445)
static void C_ccall f_6445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6226)
static void C_ccall f_6226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_fcall f_5938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5918)
static void C_ccall f_5918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_fcall f_5894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_fcall f_5712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_fcall f_5750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5643)
static void C_fcall f_5643(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_fcall f_5612(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_fcall f_5543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_fcall f_5187(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_fcall f_5200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_fcall f_5212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_fcall f_5039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_fcall f_4902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_fcall f_4743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_fcall f_4547(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4553)
static void C_fcall f_4553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_fcall f_4450(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_fcall f_3983(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_fcall f_3637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3688)
static void C_fcall f_3688(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_fcall f_3516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3522)
static void C_fcall f_3522(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_fcall f_2991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_fcall f_2942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_fcall f_2585(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2611)
static void C_fcall f_2611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_fcall f_2651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_fcall f_2353(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2006)
static void C_fcall f_2006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_fcall f_1870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_fcall f_1639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7502)
static void C_fcall trf_7502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7502(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7502(t0,t1,t2,t3);}

C_noret_decl(trf_7565)
static void C_fcall trf_7565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7565(t0,t1);}

C_noret_decl(trf_7363)
static void C_fcall trf_7363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7363(t0,t1);}

C_noret_decl(trf_7143)
static void C_fcall trf_7143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7143(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7143(t0,t1,t2,t3);}

C_noret_decl(trf_7004)
static void C_fcall trf_7004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7004(t0,t1);}

C_noret_decl(trf_6921)
static void C_fcall trf_6921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6921(t0,t1);}

C_noret_decl(trf_6800)
static void C_fcall trf_6800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6800(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6800(t0,t1,t2);}

C_noret_decl(trf_6531)
static void C_fcall trf_6531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6531(t0,t1,t2);}

C_noret_decl(trf_5938)
static void C_fcall trf_5938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5938(t0,t1,t2,t3);}

C_noret_decl(trf_5878)
static void C_fcall trf_5878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5878(t0,t1,t2,t3);}

C_noret_decl(trf_5894)
static void C_fcall trf_5894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5894(t0,t1);}

C_noret_decl(trf_5712)
static void C_fcall trf_5712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5712(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5712(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5750)
static void C_fcall trf_5750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5750(t0,t1);}

C_noret_decl(trf_5643)
static void C_fcall trf_5643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5643(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5643(t0,t1,t2,t3);}

C_noret_decl(trf_5612)
static void C_fcall trf_5612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5612(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5612(t0,t1,t2,t3);}

C_noret_decl(trf_5543)
static void C_fcall trf_5543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5543(t0,t1,t2);}

C_noret_decl(trf_5187)
static void C_fcall trf_5187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5187(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5187(t0,t1,t2,t3);}

C_noret_decl(trf_5200)
static void C_fcall trf_5200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5200(t0,t1);}

C_noret_decl(trf_5212)
static void C_fcall trf_5212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5212(t0,t1);}

C_noret_decl(trf_5039)
static void C_fcall trf_5039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5039(t0,t1,t2);}

C_noret_decl(trf_4902)
static void C_fcall trf_4902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4902(t0,t1,t2);}

C_noret_decl(trf_4743)
static void C_fcall trf_4743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4743(t0,t1,t2);}

C_noret_decl(trf_4547)
static void C_fcall trf_4547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4547(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4547(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4553)
static void C_fcall trf_4553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4553(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4553(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4450)
static void C_fcall trf_4450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4450(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4450(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4468)
static void C_fcall trf_4468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4468(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4468(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3983)
static void C_fcall trf_3983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3983(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3983(t0,t1,t2,t3);}

C_noret_decl(trf_3637)
static void C_fcall trf_3637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3637(t0,t1);}

C_noret_decl(trf_3688)
static void C_fcall trf_3688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3688(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3688(t0,t1,t2,t3);}

C_noret_decl(trf_3516)
static void C_fcall trf_3516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3516(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3516(t0,t1,t2);}

C_noret_decl(trf_3522)
static void C_fcall trf_3522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3522(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3522(t0,t1,t2);}

C_noret_decl(trf_2991)
static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2991(t0,t1);}

C_noret_decl(trf_2942)
static void C_fcall trf_2942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2942(t0,t1);}

C_noret_decl(trf_2585)
static void C_fcall trf_2585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2585(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2585(t0,t1,t2,t3);}

C_noret_decl(trf_2611)
static void C_fcall trf_2611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2611(t0,t1);}

C_noret_decl(trf_2651)
static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2651(t0,t1);}

C_noret_decl(trf_2353)
static void C_fcall trf_2353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2353(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2353(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2134)
static void C_fcall trf_2134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2134(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2134(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1860)
static void C_fcall trf_1860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1860(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1860(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2006)
static void C_fcall trf_2006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2006(t0,t1);}

C_noret_decl(trf_1870)
static void C_fcall trf_1870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1870(t0,t1);}

C_noret_decl(trf_1639)
static void C_fcall trf_1639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1639(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3119)){
C_save(t1);
C_rereclaim2(3119*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,239);
lf[0]=C_h_intern(&lf[0],29,"\003syschicken-macro-environment");
lf[1]=C_h_intern(&lf[1],17,"register-feature!");
lf[2]=C_h_intern(&lf[2],6,"srfi-8");
lf[3]=C_h_intern(&lf[3],7,"srfi-16");
lf[4]=C_h_intern(&lf[4],7,"srfi-26");
lf[5]=C_h_intern(&lf[5],7,"srfi-31");
lf[6]=C_h_intern(&lf[6],7,"srfi-15");
lf[7]=C_h_intern(&lf[7],7,"srfi-11");
lf[8]=C_h_intern(&lf[8],16,"\003sysmacro-subset");
lf[9]=C_h_intern(&lf[9],28,"\003sysextend-macro-environment");
lf[10]=C_h_intern(&lf[10],12,"define-macro");
lf[11]=C_h_intern(&lf[11],12,"syntax-error");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[13]=C_h_intern(&lf[13],18,"\003syser-transformer");
lf[14]=C_h_intern(&lf[14],3,"use");
lf[15]=C_h_intern(&lf[15],22,"\004corerequire-extension");
lf[16]=C_h_intern(&lf[16],16,"\003syscheck-syntax");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[18]=C_h_intern(&lf[18],17,"define-for-syntax");
lf[19]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[20]=C_h_intern(&lf[20],25,"\003sysenable-runtime-macros");
lf[21]=C_h_intern(&lf[21],6,"define");
lf[22]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[23]=C_h_intern(&lf[23],28,"\003sysregister-meta-expression");
lf[24]=C_h_intern(&lf[24],4,"eval");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[26]=C_h_intern(&lf[26],10,"\003sysappend");
lf[27]=C_h_intern(&lf[27],6,"lambda");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[29]=C_h_intern(&lf[29],3,"rec");
lf[30]=C_h_intern(&lf[30],6,"letrec");
lf[31]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[32]=C_h_intern(&lf[32],16,"define-extension");
lf[33]=C_h_intern(&lf[33],22,"chicken-compile-shared");
lf[34]=C_h_intern(&lf[34],9,"compiling");
lf[35]=C_h_intern(&lf[35],4,"name");
lf[36]=C_h_intern(&lf[36],4,"unit");
lf[37]=C_h_intern(&lf[37],5,"quote");
lf[38]=C_h_intern(&lf[38],7,"provide");
lf[39]=C_h_intern(&lf[39],4,"else");
lf[40]=C_h_intern(&lf[40],3,"not");
lf[41]=C_h_intern(&lf[41],11,"cond-expand");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[43]=C_h_intern(&lf[43],4,"cdar");
lf[44]=C_h_intern(&lf[44],6,"append");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[46]=C_h_intern(&lf[46],4,"caar");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[48]=C_h_intern(&lf[48],6,"export");
lf[49]=C_h_intern(&lf[49],7,"dynamic");
lf[50]=C_h_intern(&lf[50],6,"static");
lf[51]=C_h_intern(&lf[51],5,"begin");
lf[52]=C_h_intern(&lf[52],7,"declare");
lf[53]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[54]=C_h_intern(&lf[54],4,"cute");
lf[55]=C_h_intern(&lf[55],6,"gensym");
lf[56]=C_h_intern(&lf[56],7,"reverse");
lf[57]=C_h_intern(&lf[57],5,"apply");
lf[58]=C_h_intern(&lf[58],5,"<...>");
lf[59]=C_h_intern(&lf[59],2,"<>");
lf[60]=C_h_intern(&lf[60],3,"let");
lf[61]=C_h_intern(&lf[61],3,"cut");
lf[62]=C_h_intern(&lf[62],18,"define-record-type");
lf[63]=C_h_intern(&lf[63],18,"\003sysmake-structure");
lf[64]=C_h_intern(&lf[64],14,"\003sysstructure\077");
lf[65]=C_h_intern(&lf[65],15,"\000record-setters");
lf[66]=C_h_intern(&lf[66],12,"\003sysfeatures");
lf[67]=C_h_intern(&lf[67],19,"\003syscheck-structure");
lf[68]=C_h_intern(&lf[68],10,"\004corecheck");
lf[69]=C_h_intern(&lf[69],13,"\003sysblock-ref");
lf[70]=C_h_intern(&lf[70],14,"\003sysblock-set!");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[72]=C_h_intern(&lf[72],7,"\003sysmap");
lf[73]=C_h_intern(&lf[73],3,"car");
lf[74]=C_h_intern(&lf[74],18,"getter-with-setter");
lf[75]=C_h_intern(&lf[75],1,"y");
lf[76]=C_h_intern(&lf[76],1,"x");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[78]=C_h_intern(&lf[78],14,"condition-case");
lf[79]=C_h_intern(&lf[79],9,"condition");
lf[80]=C_h_intern(&lf[80],8,"\003sysslot");
lf[81]=C_h_intern(&lf[81],10,"\003syssignal");
lf[82]=C_h_intern(&lf[82],4,"cond");
lf[83]=C_h_intern(&lf[83],17,"handle-exceptions");
lf[84]=C_h_intern(&lf[84],4,"memv");
lf[85]=C_h_intern(&lf[85],3,"and");
lf[86]=C_h_intern(&lf[86],4,"kvar");
lf[87]=C_h_intern(&lf[87],5,"exvar");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[89]=C_h_intern(&lf[89],10,"\003sysvalues");
lf[90]=C_h_intern(&lf[90],9,"\003sysapply");
lf[91]=C_h_intern(&lf[91],20,"\003syscall-with-values");
lf[92]=C_h_intern(&lf[92],22,"with-exception-handler");
lf[93]=C_h_intern(&lf[93],30,"call-with-current-continuation");
lf[94]=C_h_intern(&lf[94],4,"args");
lf[95]=C_h_intern(&lf[95],1,"k");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[97]=C_h_intern(&lf[97],21,"define-record-printer");
lf[98]=C_h_intern(&lf[98],27,"\003sysregister-record-printer");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[100]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[102]=C_h_intern(&lf[102],11,"case-lambda");
lf[103]=C_h_intern(&lf[103],6,"length");
lf[104]=C_h_intern(&lf[104],9,"split-at!");
lf[105]=C_h_intern(&lf[105],4,"take");
lf[106]=C_h_intern(&lf[106],3,"map");
lf[107]=C_h_intern(&lf[107],4,"list");
lf[108]=C_h_intern(&lf[108],3,"cdr");
lf[109]=C_h_intern(&lf[109],4,"fx>=");
lf[110]=C_h_intern(&lf[110],3,"fx=");
lf[111]=C_h_intern(&lf[111],11,"lambda-list");
lf[112]=C_h_intern(&lf[112],25,"\003sysdecompose-lambda-list");
lf[113]=C_h_intern(&lf[113],10,"fold-right");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[115]=C_h_intern(&lf[115],2,"if");
lf[116]=C_h_intern(&lf[116],4,"lvar");
lf[117]=C_h_intern(&lf[117],4,"rvar");
lf[118]=C_h_intern(&lf[118],3,"min");
lf[119]=C_h_intern(&lf[119],7,"require");
lf[120]=C_h_intern(&lf[120],6,"srfi-1");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[122]=C_h_intern(&lf[122],14,"let-optionals*");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[124]=C_h_intern(&lf[124],14,"\004coreimmutable");
lf[125]=C_h_intern(&lf[125],9,"\003syserror");
lf[126]=C_h_intern(&lf[126],4,"tmp2");
lf[127]=C_h_intern(&lf[127],3,"tmp");
lf[128]=C_h_intern(&lf[128],5,"null\077");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[130]=C_h_intern(&lf[130],8,"optional");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[134]=C_h_intern(&lf[134],13,"let-optionals");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[136]=C_h_intern(&lf[136],14,"string->symbol");
lf[137]=C_h_intern(&lf[137],13,"string-append");
lf[138]=C_h_intern(&lf[138],14,"symbol->string");
lf[139]=C_h_intern(&lf[139],4,"let*");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[141]=C_h_intern(&lf[141],5,"%rest");
lf[142]=C_h_intern(&lf[142],4,"body");
lf[143]=C_h_intern(&lf[143],4,"cadr");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[145]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[146]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[148]=C_h_intern(&lf[148],6,"select");
lf[149]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[151]=C_h_intern(&lf[151],4,"eqv\077");
lf[152]=C_h_intern(&lf[152],2,"or");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[154]=C_h_intern(&lf[154],8,"and-let*");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[156]=C_h_intern(&lf[156],13,"define-inline");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[158]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[159]=C_h_intern(&lf[159],18,"\004coredefine-inline");
lf[160]=C_h_intern(&lf[160],9,"nth-value");
lf[161]=C_h_intern(&lf[161],8,"list-ref");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[163]=C_h_intern(&lf[163],13,"letrec-values");
lf[164]=C_h_intern(&lf[164],9,"\004coreset!");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[167]=C_h_intern(&lf[167],11,"let*-values");
lf[168]=C_h_intern(&lf[168],10,"let-values");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[171]=C_h_intern(&lf[171],13,"define-values");
lf[172]=C_h_intern(&lf[172],11,"set!-values");
lf[173]=C_h_intern(&lf[173],19,"\003sysregister-export");
lf[174]=C_h_intern(&lf[174],18,"\003syscurrent-module");
lf[175]=C_h_intern(&lf[175],12,"\003sysfor-each");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[177]=C_h_intern(&lf[177],14,"\004coreundefined");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[179]=C_h_intern(&lf[179],6,"unless");
lf[180]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[181]=C_h_intern(&lf[181],4,"when");
lf[182]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[183]=C_h_intern(&lf[183],12,"parameterize");
lf[184]=C_h_intern(&lf[184],16,"\003sysdynamic-wind");
lf[185]=C_h_intern(&lf[185],1,"t");
lf[186]=C_h_intern(&lf[186],8,"\003syslist");
lf[187]=C_h_intern(&lf[187],4,"swap");
lf[188]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[189]=C_h_intern(&lf[189],9,"eval-when");
lf[190]=C_h_intern(&lf[190],10,"\000compiling");
lf[191]=C_h_intern(&lf[191],19,"\004corecompiletimetoo");
lf[192]=C_h_intern(&lf[192],20,"\004corecompiletimeonly");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[194]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[196]=C_h_intern(&lf[196],4,"load");
lf[197]=C_h_intern(&lf[197],7,"compile");
lf[198]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[199]=C_h_intern(&lf[199],9,"fluid-let");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[201]=C_h_intern(&lf[201],6,"ensure");
lf[202]=C_h_intern(&lf[202],11,"\000type-error");
lf[203]=C_h_intern(&lf[203],15,"\003syssignal-hook");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[205]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[206]=C_h_intern(&lf[206],6,"assert");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[208]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[209]=C_h_intern(&lf[209],7,"include");
lf[210]=C_h_intern(&lf[210],27,"\003syscurrent-source-filename");
lf[211]=C_h_intern(&lf[211],4,"read");
lf[212]=C_h_intern(&lf[212],20,"with-input-from-file");
lf[213]=C_h_intern(&lf[213],5,"print");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[216]=C_h_intern(&lf[216],12,"load-verbose");
lf[217]=C_h_intern(&lf[217],28,"\003sysresolve-include-filename");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[219]=C_h_intern(&lf[219],12,"\004coredeclare");
lf[220]=C_h_intern(&lf[220],4,"time");
lf[221]=C_h_intern(&lf[221],15,"\003sysstart-timer");
lf[222]=C_h_intern(&lf[222],14,"\003sysstop-timer");
lf[223]=C_h_intern(&lf[223],17,"\003sysdisplay-times");
lf[224]=C_h_intern(&lf[224],7,"receive");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[227]=C_h_intern(&lf[227],13,"define-record");
lf[228]=C_h_intern(&lf[228],3,"val");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[234]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[235]=C_h_intern(&lf[235],21,"\003sysmacro-environment");
lf[236]=C_h_intern(&lf[236],11,"\003sysprovide");
lf[237]=C_h_intern(&lf[237],19,"chicken-more-macros");
lf[238]=C_h_intern(&lf[238],14,"chicken-syntax");
C_register_lf2(lf,239,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1461,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 35   ##sys#provide */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[237],lf[238]);}

/* k1459 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 41   ##sys#macro-environment */
t3=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1463 in k1459 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7443,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7445,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 45   ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7444 in k1463 in k1459 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7445,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7449,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 47   ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[227],t2,lf[234]);}

/* k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7449,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 50   symbol->string */
t5=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7458,2,t0,t1);}
t2=(C_word)C_i_memq(lf[65],*((C_word*)lf[66]+1));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7464,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 52   r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[51]);}

/* k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 53   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 54   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[74]);}

/* k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 55   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 58   string-append */
t4=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[233],((C_word*)t0)[2]);}

/* k7881 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 58   string->symbol */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7843,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[37],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[63],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t9,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7835,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 61   string-append */
t12=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],lf[232]);}

/* k7833 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 61   string->symbol */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[76],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[37],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[76],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[64],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7496,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7500,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word)li97),tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_7502(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_fcall f_7502(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7502,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken-syntax.scm: 66   symbol->string */
t7=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7515,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 67   string-append */
t4=*((C_word*)lf[137]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],lf[230],t1,lf[231]);}

/* k7777 in k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 67   string->symbol */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7513 in k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7518,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7775,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 68   string-append */
t4=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[229],((C_word*)t0)[2]);}

/* k7773 in k7513 in k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 68   string->symbol */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7516 in k7513 in k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[124],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7518,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[228],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[76],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[37],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[76],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[67],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[68],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[228],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[76],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[70],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7565,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[76],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[37],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[76],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[67],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[68],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[76],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[69],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_7565(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[76],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[37],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[76],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[67],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[68],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[76],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[69],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_7565(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k7563 in k7516 in k7513 in k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_fcall f_7565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7565,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7529,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 87   mapslots */
t11=((C_word*)((C_word*)t0)[2])[1];
f_7502(t11,t8,t9,t10);}

/* k7527 in k7563 in k7516 in k7513 in k7510 in mapslots in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7529,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7498 in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7494 in k7789 in k7873 in k7841 in k7471 in k7468 in k7465 in k7462 in k7456 in k7447 in a7444 in k1463 in k1459 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k7441 in k1463 in k1459 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 43   ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[227],C_SCHEME_END_OF_LIST,t1);}

/* k1466 in k1463 in k1459 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7300,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7302,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 92   ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7302,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7306,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 94   r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[27]);}

/* k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7309,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 95   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7312,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 96   ##sys#check-syntax */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[224],((C_word*)t0)[4],lf[226]);}

/* k7310 in k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7312,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7348,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 100  ##sys#check-syntax */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[224],((C_word*)t0)[5],lf[225]);}}

/* k7346 in k7310 in k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7348,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7363,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_7363(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_7363(t6,C_SCHEME_FALSE);}}

/* k7361 in k7346 in k7310 in k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_fcall f_7363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7363,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7417,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k7415 in k7361 in k7346 in k7310 in k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7417,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[91],t5));}

/* k7376 in k7361 in k7346 in k7310 in k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7378,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7339 in k7310 in k7307 in k7304 in a7301 in k1466 in k1463 in k1459 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[186],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[91],t5));}

/* k7298 in k1466 in k1463 in k1459 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 89   ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[224],C_SCHEME_END_OF_LIST,t1);}

/* k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7203,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 112  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7202 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7203,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7207,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 114  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[185]);}

/* k7205 in a7202 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 115  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[51]);}

/* k7208 in k7205 in a7202 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7213,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 116  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k7211 in k7208 in k7205 in a7202 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7213,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[221],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k7290 in k7211 in k7208 in k7205 in a7202 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[222],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[223],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[89],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[90],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[91],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k7199 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 110  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7183,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7185,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 127  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7184 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7185,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7193,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k7191 in a7184 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7193,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[219],t1));}

/* k7181 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 125  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[52],C_SCHEME_END_OF_LIST,t1);}

/* k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7096,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 133  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7096,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7100,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 135  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[209],t2,lf[218]);}

/* k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 136  ##sys#resolve-include-filename */
t4=*((C_word*)lf[217]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7106,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 137  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[51]);}

/* k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7109,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7172,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 138  load-verbose */
t4=*((C_word*)lf[216]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7170 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 138  print */
t2=*((C_word*)lf[213]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[214],((C_word*)t0)[2],lf[215]);}
else{
t2=((C_word*)t0)[3];
f_7109(2,t2,C_SCHEME_UNDEFINED);}}

/* k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7122,a[2]=((C_word*)t0)[2],a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 140  with-input-from-file */
t5=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7122,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7128,a[2]=t3,a[3]=t5,a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7133,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7166,a[2]=t5,a[3]=t3,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[184]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a7165 in a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7166,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[210]+1));
t3=C_mutate((C_word*)lf[210]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a7132 in a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 143  read */
t3=*((C_word*)lf[211]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7139 in a7132 in a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7143,a[2]=t3,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7143(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop142 in k7139 in a7132 in a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_7143(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7143,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken-syntax.scm: 146  reverse */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7160,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 143  read */
t5=*((C_word*)lf[211]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k7158 in doloop142 in k7139 in a7132 in a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_7143(t3,((C_word*)t0)[2],t1,t2);}

/* a7127 in a7121 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[210]+1));
t3=C_mutate((C_word*)lf[210]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k7118 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7114 in k7107 in k7104 in k7101 in k7098 in a7095 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7092 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 131  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[209],C_SCHEME_END_OF_LIST,t1);}

/* k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6983,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6985,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 150  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6984 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6985,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6989,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 152  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[206],t2,lf[208]);}

/* k6987 in a6984 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6989,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6998,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 155  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[115]);}

/* k6996 in k6987 in a6984 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7001,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 156  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[37]);}

/* k6999 in k6996 in k6987 in a6984 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[207],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[37],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_7004(t7,(C_word)C_a_i_cons(&a,2,lf[124],t6));}
else{
t4=t2;
f_7004(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k7002 in k6999 in k6996 in k6987 in a6984 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_7004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7004,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[68],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[177],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_length(((C_word*)t0)[2]);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
/* ##sys#append */
t11=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_SCHEME_END_OF_LIST);}

/* k7045 in k7002 in k6999 in k6996 in k6987 in a6984 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7047,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[125],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6981 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 148  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[206],C_SCHEME_END_OF_LIST,t1);}

/* k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6848,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 172  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6848,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 174  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[201],t2,lf[205]);}

/* k6850 in a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6864,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 178  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[127]);}

/* k6862 in k6850 in a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 179  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k6865 in k6862 in k6850 in a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 180  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k6868 in k6865 in k6862 in k6850 in a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[68],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6921,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_6921(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[204],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[37],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[124],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[37],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_6921(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k6919 in k6868 in k6865 in k6862 in k6850 in a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_6921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6915 in k6868 in k6865 in k6862 in k6850 in a6847 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6917,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[202],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[203],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k6844 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 169  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[201],C_SCHEME_END_OF_LIST,t1);}

/* k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6588,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6590,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 193  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6590,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6594,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 195  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[199],t2,lf[200]);}

/* k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6594,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6603,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 198  ##sys#map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[73]+1),t2);}

/* k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 199  ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6833 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6834,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6842,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 199  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6840 in a6833 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 199  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6824,a[2]=((C_word*)t0)[2],a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 200  ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6823 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6824,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6832,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 200  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6830 in a6823 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 200  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 201  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 202  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6822,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 203  ##sys#map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[143]+1),((C_word*)t0)[2]);}

/* k6820 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 203  map */
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[186]+1),((C_word*)t0)[2],t1);}

/* k6780 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6786,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6790,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6794,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6800,a[2]=t7,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6800(t9,t4,t5);}

/* loop in k6780 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_6800(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6800,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6814,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm: 208  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6812 in loop in k6780 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6792 in k6780 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 204  map */
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[186]+1),((C_word*)t0)[2],t1);}

/* k6788 in k6780 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6784 in k6780 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6766,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 211  map */
t5=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a6765 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6766,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k6732 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6738,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6752,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 213  map */
t5=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6751 in k6732 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6752,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k6740 in k6732 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[177],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6736 in k6732 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6666,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6702,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 218  map */
t7=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6701 in k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6702,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k6668 in k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6674,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6688,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 220  map */
t5=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6687 in k6668 in k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6688,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k6676 in k6668 in k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[177],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6672 in k6668 in k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6664 in k6720 in k6728 in k6624 in k6613 in k6610 in k6607 in k6604 in k6601 in k6592 in a6589 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6666,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[184],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k6586 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 191  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[199],C_SCHEME_END_OF_LIST,t1);}

/* k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6467,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6469,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 226  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6469,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6473,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 228  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[189],t2,lf[198]);}

/* k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6479,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 230  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[51]);}

/* k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 232  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[24]);}

/* k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 233  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[197]);}

/* k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 234  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[196]);}

/* k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6494,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_6531(t12,t8,((C_word*)t0)[2]);}

/* loop in k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_6531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6531,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6544,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 241  c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6552 in loop in k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6554,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_6544(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 242  c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6559 in k6552 in loop in k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_6544(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 243  c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k6566 in k6559 in k6552 in loop in k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_6544(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm: 244  ##sys#error */
t3=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[195],t2);}}

/* k6542 in loop in k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm: 245  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6531(t3,((C_word*)t0)[2],t2);}

/* k6492 in k6489 in k6486 in k6483 in k6578 in k6477 in k6471 in a6468 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[190],*((C_word*)lf[66]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[191],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[192],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[193]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[194]));}}

/* k6465 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 224  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[189],C_SCHEME_END_OF_LIST,t1);}

/* k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6265,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6267,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 257  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6267,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6271,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 259  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[183],t2,lf[188]);}

/* k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6280,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 262  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[187]);}

/* k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 263  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 264  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 265  ##sys#map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[73]+1),((C_word*)t0)[2]);}

/* k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 266  ##sys#map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[143]+1),((C_word*)t0)[2]);}

/* k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[2],a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 267  ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6454 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6463,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 267  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6461 in a6454 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 267  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6445,a[2]=((C_word*)t0)[2],a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 268  ##sys#map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6444 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6445,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6453,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 268  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6451 in a6444 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 268  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6309,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 269  map */
t4=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[186]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6437 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6443,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 269  map */
t3=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[186]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6441 in k6437 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 269  ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6307 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6381,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[6],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 271  map */
t5=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6382 in k6307 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6383,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[185],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[185],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[164],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k6379 in k6307 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6375 in k6307 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t8=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6355 in k6375 in k6307 in k6296 in k6293 in k6290 in k6287 in k6284 in k6281 in k6278 in k6269 in a6266 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[184],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k6263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 255  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[183],C_SCHEME_END_OF_LIST,t1);}

/* k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6220,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6222,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 282  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6221 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6222,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6226,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 284  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[181],t2,lf[182]);}

/* k6224 in a6221 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 285  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k6231 in k6224 in a6221 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6233,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 286  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[51]);}

/* k6251 in k6231 in k6224 in a6221 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6255 in k6251 in k6231 in k6224 in a6221 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6218 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 280  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[181],C_SCHEME_END_OF_LIST,t1);}

/* k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6167,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6169,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 290  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6168 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6169,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6173,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 292  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[179],t2,lf[180]);}

/* k6171 in a6168 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 293  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k6178 in k6171 in a6168 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[177],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 295  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[51]);}

/* k6206 in k6178 in k6171 in a6168 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6210 in k6206 in k6178 in k6171 in a6168 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k6165 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 288  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[179],C_SCHEME_END_OF_LIST,t1);}

/* k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6024,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 299  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6024,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6028,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 301  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[172],t2,lf[178]);}

/* k6026 in a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6037,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 304  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[27]);}

/* k6035 in k6026 in a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6037,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[177],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[91],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[55]+1),((C_word*)t0)[4]);}}}

/* k6104 in k6035 in k6026 in a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6137,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6139,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 317  map */
t8=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a6138 in k6104 in k6035 in k6026 in a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6139,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[164],t5));}

/* k6135 in k6104 in k6035 in k6026 in a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6131 in k6104 in k6035 in k6026 in a6023 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[91],t5));}

/* k6020 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 297  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[172],C_SCHEME_END_OF_LIST,t1);}

/* k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5980,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5982,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 323  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5982,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5986,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 325  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[171],t2,lf[176]);}

/* k5984 in a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6006,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a6005 in k5984 in a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6006,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6014,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 326  ##sys#current-module */
t4=*((C_word*)lf[174]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6012 in a6005 in k5984 in a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#register-export */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5987 in k5984 in a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 327  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[172]);}

/* k5994 in k5987 in k5984 in a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6000,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5998 in k5994 in k5987 in k5984 in a5981 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5978 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 321  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[171],C_SCHEME_END_OF_LIST,t1);}

/* k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5594,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 331  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5594,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5598,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 333  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[168],t2,lf[170]);}

/* k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 336  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[60]);}

/* k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 337  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5610,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=t3,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5643,a[2]=t5,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5685,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[73]+1),((C_word*)t0)[3]);}

/* k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5938,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5938(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5938,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5951,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken-syntax.scm: 353  append */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken-syntax.scm: 354  append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5612(t6,t5,t4,t3);}
else{
t6=t5;
f_5951(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k5949 in loop in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 356  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5938(t3,((C_word*)t0)[2],t2,t1);}

/* k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[2],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5923 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5924,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5932,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5936,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 357  gensym */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5934 in a5923 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 357  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5930 in a5923 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5932,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5692,a[2]=t1,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5878,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5878(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5878,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-syntax.scm: 361  reverse */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5894,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5918,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 365  map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5643(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5911,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 364  lookup */
t7=((C_word*)t0)[2];
f_5692(3,t7,t6,t4);}}}

/* k5909 in loop in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5911,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5894(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5916 in loop in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5918,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5894(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5892 in loop in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 366  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5878(t3,((C_word*)t0)[2],t2,t1);}

/* k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5710,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5872,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5871 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5872,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word)li60),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5712(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5712(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5712,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[5],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5866,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 372  cdar */
t8=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t7=t5;
f_5750(t7,C_SCHEME_FALSE);}}}

/* k5864 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5750(t2,(C_word)C_i_nullp(t1));}

/* k5748 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5750,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 373  caar */
t3=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5832,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 378  fold */
t11=((C_word*)((C_word*)t0)[3])[1];
f_5712(t11,t7,t8,t9,t10);}}

/* k5830 in k5748 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5832,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[91],t6));}

/* k5787 in k5748 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5769,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 374  fold */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5712(t10,t6,t7,t8,t9);}

/* k5767 in k5787 in k5748 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5769,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5735 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5736,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5744,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 371  lookup */
t4=((C_word*)t0)[2];
f_5692(3,t4,t3,t2);}

/* k5742 in a5735 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5728 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5732 in k5728 in fold in k5708 in k5701 in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5734,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5689 in k5686 in k5683 in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5692,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5643(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5643,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5666,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken-syntax.scm: 346  proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm: 345  proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k5664 in map* in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5670,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 346  map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5643(t4,t2,((C_word*)t0)[2],t3);}

/* k5668 in k5664 in map* in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5612(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5612,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5633,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 342  append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5631 in append* in k5608 in k5605 in k5596 in a5593 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5633,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5590 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 329  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[168],C_SCHEME_END_OF_LIST,t1);}

/* k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5520,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5522,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 382  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5522,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5526,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 384  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[167],t2,lf[169]);}

/* k5524 in a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 387  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[60]);}

/* k5533 in k5524 in a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 388  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[168]);}

/* k5536 in k5533 in k5524 in a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5543,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5543(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k5536 in k5533 in k5524 in a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5543,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5561,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5580,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 393  fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5578 in fold in k5536 in k5533 in k5524 in a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5559 in fold in k5536 in k5533 in k5524 in a5521 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5518 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 380  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[167],C_SCHEME_END_OF_LIST,t1);}

/* k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5356,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 397  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5356,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5360,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 399  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[163],t2,lf[166]);}

/* k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5369,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 402  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[60]);}

/* k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 403  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5512,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a5511 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5512,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5508 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[26]+1),t1);}

/* k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5378,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[2],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5493 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5494,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5502,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5506,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 405  gensym */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5504 in a5493 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 405  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5500 in a5493 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5502,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5379,a[2]=t1,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5488,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5487 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5488,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[165]));}

/* k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5411 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5412,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5440,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* map */
t9=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k5438 in a5411 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[3],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5449 in k5438 in a5411 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5450,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5466,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 412  lookup */
t4=((C_word*)t0)[2];
f_5379(3,t4,t3,t2);}

/* k5464 in a5449 in k5438 in a5411 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[164],t3));}

/* k5446 in k5438 in a5411 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5442 in k5438 in a5411 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[91],t5));}

/* k5404 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5410,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5408 in k5404 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5400 in k5396 in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5376 in k5373 in k5370 in k5367 in k5358 in a5355 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5379,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k5352 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 395  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[163],C_SCHEME_END_OF_LIST,t1);}

/* k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5280,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5282,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 418  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5281 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5282,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5286,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 420  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[160],t2,lf[162]);}

/* k5284 in a5281 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 421  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k5287 in k5284 in a5281 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 422  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[161]);}

/* k5290 in k5287 in k5284 in a5281 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5295,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 423  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k5293 in k5290 in k5287 in k5284 in a5281 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5295,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t5,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k5278 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 416  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[160],C_SCHEME_END_OF_LIST,t1);}

/* k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5179,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5181,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 430  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5181,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5185,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 432  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[27]);}

/* k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5187,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5272,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 446  quotify-proc */
t6=t2;
f_5187(t6,t4,t5,lf[156]);}

/* k5270 in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5266 in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[159],t1));}

/* quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5187(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5187,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 435  ##sys#check-syntax */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[158]);}

/* k5189 in quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5191,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_5200(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k5246 in k5189 in quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5248,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5200(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5198 in k5189 in quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5200,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5203,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_5212(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5222,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
/* chicken-syntax.scm: 441  c */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k5220 in k5198 in k5189 in quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5212(t2,(C_word)C_i_not(t1));}

/* k5210 in k5198 in k5189 in quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 442  syntax-error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[156],lf[157],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5203(2,t2,C_SCHEME_UNDEFINED);}}

/* k5201 in k5198 in k5189 in quotify-proc in k5183 in a5180 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5203,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k5177 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 428  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[156],C_SCHEME_END_OF_LIST,t1);}

/* k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5016,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5018,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 450  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5018,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5022,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 452  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t2,lf[155]);}

/* k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5031,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 455  r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[115]);}

/* k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 456  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5039,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li42),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5039(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_5039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5039,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 459  r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[51]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 463  fold */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5151,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 467  fold */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 462  fold */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k5082 in fold in k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5149 in fold in k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k5111 in fold in k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5051 in fold in k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5057,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5055 in k5051 in fold in k5032 in k5029 in k5020 in a5017 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5057,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5014 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 448  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[154],C_SCHEME_END_OF_LIST,t1);}

/* k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4849,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 471  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4849,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4853,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 473  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[148],t2,lf[153]);}

/* k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 476  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[127]);}

/* k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 477  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 478  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[39]);}

/* k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 479  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[152]);}

/* k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 480  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[151]);}

/* k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 481  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[51]);}

/* k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 482  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4884,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4900,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li40),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_4902(t9,t5,((C_word*)t0)[2]);}

/* expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_4902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4902,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 488  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[148],t3,lf[149]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[150]);}}

/* k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 489  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4978,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a4979 in k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4980,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4976 in k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4972 in k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k4964 in k4972 in k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 494  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4902(t4,t3,((C_word*)t0)[2]);}

/* k4960 in k4964 in k4972 in k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4929 in k4922 in k4916 in expand in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4898 in k4882 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in k4851 in a4848 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4845 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 469  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[148],C_SCHEME_END_OF_LIST,t1);}

/* k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 575  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4417,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4421,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 577  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[134],t2,lf[147]);}

/* k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4433,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 581  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[128]);}

/* k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 582  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 583  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 584  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[73]);}

/* k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 585  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 586  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4450,a[2]=t1,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word)li34),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 624  ##sys#check-syntax */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[134],((C_word*)t0)[2],lf[146]);}

/* k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 625  ##sys#check-syntax */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[134],((C_word*)t0)[8],lf[145]);}

/* k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[73]+1),((C_word*)t0)[2]);}

/* k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4743,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4835,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4834 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4835,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4843,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 633  prefix-sym */
f_4743(t3,lf[144],t2);}

/* k4841 in a4834 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 633  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[143]+1),((C_word*)t0)[2]);}

/* k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 637  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[142]);}

/* k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 640  r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[141]);}

/* k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a4824 in k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4825,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 642  prefix-sym */
f_4743(t3,lf[140],t2);}

/* k4831 in a4824 in k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 642  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4768 in k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4773,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 645  make-default-procs */
t3=((C_word*)t0)[3];
f_4450(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k4771 in k4768 in k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 647  make-if-tree */
t3=((C_word*)t0)[4];
f_4547(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k4774 in k4771 in k4768 in k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 650  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[139]);}

/* k4781 in k4774 in k4771 in k4768 in k4765 in k4762 in k4759 in k4756 in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_4743(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4743,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 628  symbol->string */
t6=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k4753 in prefix-sym in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 628  string-append */
t2=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4749 in prefix-sym in k4740 in k4737 in k4734 in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 628  string->symbol */
t2=*((C_word*)lf[136]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_4547(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4547,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4553,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,a[10]=((C_word)li33),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_4553(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_4553(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4553,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[68],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 613  reverse */
t10=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[128],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t7,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t5,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t8,tmp=(C_word)a,a+=15,tmp);
/* chicken-syntax.scm: 617  reverse */
t10=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}}

/* k4727 in recur in make-if-tree in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4729,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[5]);
t15=(C_word)C_i_cdr(((C_word*)t0)[4]);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[3]);
/* chicken-syntax.scm: 620  recur */
t17=((C_word*)((C_word*)t0)[2])[1];
f_4553(t17,t13,t14,t15,t16);}

/* k4671 in k4727 in recur in make-if-tree in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4673,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k4613 in recur in make-if-tree in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[135],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[37],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[124],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[125],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_4450(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4450,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4458,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 592  reverse */
t7=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 593  reverse */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 594  reverse */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4464 in k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4466,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4468,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4468(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k4464 in k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4468,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4521,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 599  reverse */
t9=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k4519 in recur in k4464 in k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 600  reverse */
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4535 in k4519 in recur in k4464 in k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k4531 in k4519 in recur in k4464 in k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4489,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 601  recur */
t12=((C_word*)((C_word*)t0)[3])[1];
f_4468(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k4487 in k4531 in k4519 in recur in k4464 in k4460 in k4456 in make-default-procs in k4446 in k4443 in k4440 in k4437 in k4434 in k4431 in k4419 in a4416 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4413 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 573  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[134],C_SCHEME_END_OF_LIST,t1);}

/* k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4231,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4233,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 670  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4233,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 672  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[130],t2,lf[133]);}

/* k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 673  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 674  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[128]);}

/* k4241 in k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 675  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k4244 in k4241 in k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 676  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k4251 in k4244 in k4241 in k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_i_cddr(((C_word*)t0)[7]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
t10=t9;
f_4288(2,t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4288(2,t11,(C_word)C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[132],t8);}}}

/* k4286 in k4251 in k4244 in k4241 in k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 679  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k4370 in k4286 in k4251 in k4244 in k4241 in k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 680  r */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[73]);}

/* k4346 in k4370 in k4286 in k4251 in k4244 in k4241 in k4238 in k4235 in a4232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[131],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[37],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[124],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[125],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k4229 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 668  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[130],C_SCHEME_END_OF_LIST,t1);}

/* k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 703  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3931,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3935,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 705  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[122],t2,lf[129]);}

/* k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3947,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 709  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[60]);}

/* k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 710  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 711  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[128]);}

/* k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 712  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[73]);}

/* k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 713  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[108]);}

/* k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 714  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],a[10]=((C_word)li28),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_3983(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_3983(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3983,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[68],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t9=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 725  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[126]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k4209 in loop in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4211,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4071 in loop in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[37],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 732  loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_3983(t30,t28,t1,t29);}

/* k4090 in k4071 in loop in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4047 in loop in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[123],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[37],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[124],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[125],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k3979 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3933 in a3930 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3927 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 701  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[122],C_SCHEME_END_OF_LIST,t1);}

/* k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3510,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 740  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3510,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3514,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 742  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[102],t2,lf[121]);}

/* k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[4],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3551,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 748  require */
t4=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[120]);}

/* k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3908,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3910,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3909 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3910,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3920,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 750  ##sys#decompose-lambda-list */
t5=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a3919 in a3909 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3920,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k3906 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[118]+1),t1);}

/* k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 754  genvars */
t3=((C_word*)t0)[2];
f_3516(t3,t2,t1);}

/* k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 755  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[117]);}

/* k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 756  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[116]);}

/* k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 757  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 758  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 759  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 760  append */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[10]);}

/* k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[103],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li24),tmp=(C_word)a,a+=10,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 762  fold-right */
t10=*((C_word*)lf[113]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,lf[114],t9);}

/* a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3609,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=((C_word)li23),tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 764  ##sys#decompose-lambda-list */
t6=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3619,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 767  ##sys#check-syntax */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[102],t6,lf[111]);}

/* k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[14],((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_3637(t5,C_SCHEME_TRUE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3857,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 772  r */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[109]);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3872,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 773  r */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[110]);}}

/* k3870 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_3637(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3855 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_3637(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_3637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3637,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3661,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_3688(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_3688(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3688,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3713,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t9=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[4]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3745,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3844,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 782  gensym */
t6=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3842 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 782  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3754 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 783  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[73]);}

/* k3834 in k3754 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 784  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[108]);}

/* k3814 in k3834 in k3754 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3816,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 786  build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_3688(t11,t8,t10,((C_word*)t0)[7]);}
else{
/* chicken-syntax.scm: 787  build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_3688(t10,t8,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}}

/* k3773 in k3814 in k3834 in k3754 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3743 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3745,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3711 in build in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3663 in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 790  map */
t3=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[107]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3680 in k3663 in a3660 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a3650 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3659,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 775  take */
t3=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3657 in a3650 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 775  split-at! */
t2=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3643 in k3635 in k3621 in a3618 in a3608 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3605 in k3581 in k3570 in k3567 in k3564 in k3561 in k3558 in k3555 in k3552 in k3549 in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_3516(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3516,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3522(t6,t1,C_fix(0));}

/* loop in genvars in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_3522(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3522,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 747  gensym */
t5=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3546 in loop in genvars in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 747  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3534 in loop in genvars in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3540,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 747  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3522(t4,t2,t3);}

/* k3538 in k3534 in loop in genvars in k3512 in a3509 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3506 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 738  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[102],C_SCHEME_END_OF_LIST,t1);}

/* k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 800  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3412,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 802  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[97],t2,lf[101]);}

/* k3414 in a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 806  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[97],t5,lf[99]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3481,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 813  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[97],t5,lf[100]);}}

/* k3479 in k3414 in a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[37],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3494 in k3479 in k3414 in a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[98],t2));}

/* k3429 in k3414 in a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[37],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 811  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[27]);}

/* k3452 in k3429 in k3414 in a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3464 in k3452 in k3429 in k3414 in a3411 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[98],t5));}

/* k3408 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 798  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[97],C_SCHEME_END_OF_LIST,t1);}

/* k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3216,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 821  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3218,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3222,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 823  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[83],t2,lf[96]);}

/* k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 824  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[95]);}

/* k3223 in k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 825  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[94]);}

/* k3226 in k3223 in k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 826  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k3229 in k3226 in k3223 in k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 827  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[93]);}

/* k3240 in k3229 in k3226 in k3223 in k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 829  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[92]);}

/* k3268 in k3240 in k3229 in k3226 in k3223 in k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
/* ##sys#append */
t15=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k3360 in k3268 in k3240 in k3229 in k3226 in k3223 in k3220 in a3217 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[89],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[90],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[27],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[91],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k3214 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 819  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[83],C_SCHEME_END_OF_LIST,t1);}

/* k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2889,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2891,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 840  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2891,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2895,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 842  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[78],t2,lf[88]);}

/* k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 843  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[87]);}

/* k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 844  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[86]);}

/* k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 845  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[85]);}

/* k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 846  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[60]);}

/* k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 847  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[84]);}

/* k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 848  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[39]);}

/* k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,a[8]=((C_word)li14),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 862  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[83]);}

/* k3086 in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3088,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[79],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[37],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[64],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[80],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 865  r */
t17=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[82]);}

/* k3126 in k3086 in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3136,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k3134 in k3126 in k3086 in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k3130 in k3126 in k3086 in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2915,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t13=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t10=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3033,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* map */
t11=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a3038 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3039,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[37],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k3035 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3031 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k3023 in k3031 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_2991(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3004 in k3031 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_2991(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2989 in k3031 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2974 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_2942(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2955 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_2942(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2940 in parse-clause in k2911 in k2908 in k2905 in k2902 in k2899 in k2896 in k2893 in a2890 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2942,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2887 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 838  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[78],C_SCHEME_END_OF_LIST,t1);}

/* k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 874  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2516,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2520,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 876  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[62],t2,lf[77]);}

/* k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 881  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[51]);}

/* k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 882  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 883  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 885  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[76]);}

/* k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 886  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[75]);}

/* k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 887  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[74]);}

/* k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* map */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[73]+1),((C_word*)t0)[3]);}

/* k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[37],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2872,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a2873 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2874,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[71]));}

/* k2870 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[63],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[37],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[64],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],a[9]=((C_word)li10),tmp=(C_word)a,a+=10,tmp));
t22=((C_word*)t20)[1];
f_2585(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2585(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2585,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[65],*((C_word*)lf[66]+1));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[37],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[67],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[68],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[69],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,lf[37],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[67],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[68],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[70],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_2611(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_2611(t24,C_SCHEME_END_OF_LIST);}}}

/* k2609 in loop in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2611,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_2651(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_2651(t5,((C_word*)t0)[3]);}}

/* k2649 in k2609 in loop in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2651,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2627,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken-syntax.scm: 917  loop */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2585(t9,t6,t7,t8);}

/* k2625 in k2649 in k2609 in loop in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2621 in k2649 in k2609 in loop in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2581 in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2577 in k2866 in k2554 in k2551 in k2548 in k2545 in k2539 in k2536 in k2533 in k2518 in a2515 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2512 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 872  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[62],C_SCHEME_END_OF_LIST,t1);}

/* k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2328,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 924  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2328,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2332,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 926  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[59]);}

/* k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 927  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[58]);}

/* k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 928  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 929  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[51]);}

/* k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 930  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word)li8),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2353(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2353(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2353,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2363,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 933  reverse */
t7=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 940  c */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2454 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2456,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2459,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 941  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 943  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2482 in k2454 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 943  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2353(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-syntax.scm: 944  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2353(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k2476 in k2454 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 941  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2457 in k2454 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm: 942  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2353(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 934  reverse */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2364 in k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 936  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k2436 in k2364 in k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k2413 in k2364 in k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 936  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2370 in k2364 in k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2381 in k2370 in k2364 in k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2401 in k2381 in k2370 in k2364 in k2361 in loop in k2342 in k2339 in k2336 in k2333 in k2330 in a2327 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2324 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 922  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[61],C_SCHEME_END_OF_LIST,t1);}

/* k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2107,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 948  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2109,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2113,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 950  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[60]);}

/* k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 951  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 952  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[59]);}

/* k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 953  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[58]);}

/* k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 954  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word)li6),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2134(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2134(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2134,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2144,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 957  reverse */
t8=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 967  c */
t9=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k2251 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 968  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 970  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2279 in k2251 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 970  loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2134(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2314,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 972  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2312 in k2279 in k2251 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 972  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2285 in k2279 in k2251 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2287,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 973  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2134(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k2273 in k2251 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 968  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2254 in k2251 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 969  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2134(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 958  reverse */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2145 in k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2147,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2208,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 960  gensym */
t4=*((C_word*)lf[55]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2241 in k2145 in k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k2206 in k2145 in k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 960  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2151 in k2145 in k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2176,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2174 in k2151 in k2145 in k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2194 in k2174 in k2151 in k2145 in k2142 in loop in k2123 in k2120 in k2117 in k2114 in k2111 in a2108 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k2105 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 946  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[54],C_SCHEME_END_OF_LIST,t1);}

/* k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 983  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1832,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1836,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 985  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[32],t2,lf[53]);}

/* k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 986  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[52]);}

/* k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 987  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[51]);}

/* k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 988  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[50]);}

/* k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 989  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[49]);}

/* k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 990  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[48]);}

/* k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li4),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_1860(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_1860(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1860,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1870,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_1870(t7,lf[42]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_2006(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_2006(t7,C_SCHEME_FALSE);}}}

/* k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_2006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2006,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1005 caar */
t3=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
/* chicken-syntax.scm: 1016 syntax-error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[32],lf[47],((C_word*)t0)[12]);}}

/* k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 1007 c */
t4=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2037,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1008 cdar */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1009 c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1010 cdar */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 1011 c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2066 in k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1012 cdar */
t6=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1014 caar */
t3=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2088 in k2066 in k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1014 syntax-error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[32],lf[45],t1);}

/* k2081 in k2066 in k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1012 append */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2073 in k2066 in k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1012 loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1860(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2060 in k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2056 in k2041 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1010 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1860(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2035 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2031 in k2016 in k2007 in k2004 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1008 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1860(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1998 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_1870(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_1870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1870,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 996  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[41]);}

/* k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[33],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 998  r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[40]);}

/* k1971 in k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[34],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1967 in k1971 in k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 999  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[39]);}

/* k1903 in k1967 in k1971 in k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[35]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[36],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1002 r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[38]);}

/* k1931 in k1903 in k1967 in k1971 in k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1002 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[37]);}

/* k1943 in k1931 in k1903 in k1967 in k1971 in k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[35]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1927 in k1943 in k1931 in k1903 in k1967 in k1971 in k1983 in k1875 in k1868 in loop in k1849 in k1846 in k1843 in k1840 in k1837 in k1834 in a1831 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k1828 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 981  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[32],C_SCHEME_END_OF_LIST,t1);}

/* k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1726,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1025 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1727 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1728,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1732,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1027 ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[29],t2,lf[31]);}

/* k1730 in a1727 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1029 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[30]);}

/* k1736 in k1730 in a1727 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 1032 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[27]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1822,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k1820 in k1736 in k1730 in a1727 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k1781 in k1736 in k1730 in a1727 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k1793 in k1781 in k1736 in k1730 in a1727 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k1724 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1023 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[29],C_SCHEME_END_OF_LIST,t1);}

/* k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1042 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1620,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1624,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1044 ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[18],t2,lf[28]);}

/* k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[19]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1698,a[2]=t5,a[3]=t8,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1050 r */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[27]);}
else{
t9=t8;
f_1639(t9,(C_word)C_i_car(t5));}}

/* k1696 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1710,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1708 in k1696 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_1639(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k1637 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_fcall f_1639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1639,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1053 eval */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
/* chicken-syntax.scm: 1054 syntax-error */
t3=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[18],lf[25],((C_word*)t0)[4]);}}

/* k1683 in k1637 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1642(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k1640 in k1637 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[21],t4);
/* chicken-syntax.scm: 1055 ##sys#register-meta-expression */
t6=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t2,t5);}

/* k1643 in k1640 in k1637 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
if(C_truep(*((C_word*)lf[20]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1057 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[22]);}}

/* k1653 in k1643 in k1640 in k1637 in k1622 in a1619 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k1616 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1040 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[18],C_SCHEME_END_OF_LIST,t1);}

/* k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1595,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1065 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1594 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1595,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1599,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1067 ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[14],t2,lf[17]);}

/* k1597 in a1594 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[15],t4));}

/* k1591 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1063 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],C_SCHEME_END_OF_LIST,t1);}

/* k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1583,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1585,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1078 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1584 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1585,5,t0,t1,t2,t3,t4);}
/* chicken-syntax.scm: 1080 syntax-error */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[10],lf[12]);}

/* k1581 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1076 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[10],C_SCHEME_END_OF_LIST,t1);}

/* k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1083 ##sys#macro-subset */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1086 register-feature! */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[2],lf[3],lf[4],lf[5],lf[6],lf[7]);}

/* k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1459 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[588] = {
{"toplevel:chicken_syntax_scm",(void*)C_chicken_syntax_toplevel},
{"f_1461:chicken_syntax_scm",(void*)f_1461},
{"f_1465:chicken_syntax_scm",(void*)f_1465},
{"f_7445:chicken_syntax_scm",(void*)f_7445},
{"f_7449:chicken_syntax_scm",(void*)f_7449},
{"f_7458:chicken_syntax_scm",(void*)f_7458},
{"f_7464:chicken_syntax_scm",(void*)f_7464},
{"f_7467:chicken_syntax_scm",(void*)f_7467},
{"f_7470:chicken_syntax_scm",(void*)f_7470},
{"f_7473:chicken_syntax_scm",(void*)f_7473},
{"f_7883:chicken_syntax_scm",(void*)f_7883},
{"f_7843:chicken_syntax_scm",(void*)f_7843},
{"f_7875:chicken_syntax_scm",(void*)f_7875},
{"f_7835:chicken_syntax_scm",(void*)f_7835},
{"f_7791:chicken_syntax_scm",(void*)f_7791},
{"f_7502:chicken_syntax_scm",(void*)f_7502},
{"f_7512:chicken_syntax_scm",(void*)f_7512},
{"f_7779:chicken_syntax_scm",(void*)f_7779},
{"f_7515:chicken_syntax_scm",(void*)f_7515},
{"f_7775:chicken_syntax_scm",(void*)f_7775},
{"f_7518:chicken_syntax_scm",(void*)f_7518},
{"f_7565:chicken_syntax_scm",(void*)f_7565},
{"f_7529:chicken_syntax_scm",(void*)f_7529},
{"f_7500:chicken_syntax_scm",(void*)f_7500},
{"f_7496:chicken_syntax_scm",(void*)f_7496},
{"f_7443:chicken_syntax_scm",(void*)f_7443},
{"f_1468:chicken_syntax_scm",(void*)f_1468},
{"f_7302:chicken_syntax_scm",(void*)f_7302},
{"f_7306:chicken_syntax_scm",(void*)f_7306},
{"f_7309:chicken_syntax_scm",(void*)f_7309},
{"f_7312:chicken_syntax_scm",(void*)f_7312},
{"f_7348:chicken_syntax_scm",(void*)f_7348},
{"f_7363:chicken_syntax_scm",(void*)f_7363},
{"f_7417:chicken_syntax_scm",(void*)f_7417},
{"f_7378:chicken_syntax_scm",(void*)f_7378},
{"f_7341:chicken_syntax_scm",(void*)f_7341},
{"f_7300:chicken_syntax_scm",(void*)f_7300},
{"f_1471:chicken_syntax_scm",(void*)f_1471},
{"f_7203:chicken_syntax_scm",(void*)f_7203},
{"f_7207:chicken_syntax_scm",(void*)f_7207},
{"f_7210:chicken_syntax_scm",(void*)f_7210},
{"f_7213:chicken_syntax_scm",(void*)f_7213},
{"f_7292:chicken_syntax_scm",(void*)f_7292},
{"f_7201:chicken_syntax_scm",(void*)f_7201},
{"f_1474:chicken_syntax_scm",(void*)f_1474},
{"f_7185:chicken_syntax_scm",(void*)f_7185},
{"f_7193:chicken_syntax_scm",(void*)f_7193},
{"f_7183:chicken_syntax_scm",(void*)f_7183},
{"f_1477:chicken_syntax_scm",(void*)f_1477},
{"f_7096:chicken_syntax_scm",(void*)f_7096},
{"f_7100:chicken_syntax_scm",(void*)f_7100},
{"f_7103:chicken_syntax_scm",(void*)f_7103},
{"f_7106:chicken_syntax_scm",(void*)f_7106},
{"f_7172:chicken_syntax_scm",(void*)f_7172},
{"f_7109:chicken_syntax_scm",(void*)f_7109},
{"f_7122:chicken_syntax_scm",(void*)f_7122},
{"f_7166:chicken_syntax_scm",(void*)f_7166},
{"f_7133:chicken_syntax_scm",(void*)f_7133},
{"f_7141:chicken_syntax_scm",(void*)f_7141},
{"f_7143:chicken_syntax_scm",(void*)f_7143},
{"f_7160:chicken_syntax_scm",(void*)f_7160},
{"f_7128:chicken_syntax_scm",(void*)f_7128},
{"f_7120:chicken_syntax_scm",(void*)f_7120},
{"f_7116:chicken_syntax_scm",(void*)f_7116},
{"f_7094:chicken_syntax_scm",(void*)f_7094},
{"f_1480:chicken_syntax_scm",(void*)f_1480},
{"f_6985:chicken_syntax_scm",(void*)f_6985},
{"f_6989:chicken_syntax_scm",(void*)f_6989},
{"f_6998:chicken_syntax_scm",(void*)f_6998},
{"f_7001:chicken_syntax_scm",(void*)f_7001},
{"f_7004:chicken_syntax_scm",(void*)f_7004},
{"f_7047:chicken_syntax_scm",(void*)f_7047},
{"f_6983:chicken_syntax_scm",(void*)f_6983},
{"f_1483:chicken_syntax_scm",(void*)f_1483},
{"f_6848:chicken_syntax_scm",(void*)f_6848},
{"f_6852:chicken_syntax_scm",(void*)f_6852},
{"f_6864:chicken_syntax_scm",(void*)f_6864},
{"f_6867:chicken_syntax_scm",(void*)f_6867},
{"f_6870:chicken_syntax_scm",(void*)f_6870},
{"f_6921:chicken_syntax_scm",(void*)f_6921},
{"f_6917:chicken_syntax_scm",(void*)f_6917},
{"f_6846:chicken_syntax_scm",(void*)f_6846},
{"f_1486:chicken_syntax_scm",(void*)f_1486},
{"f_6590:chicken_syntax_scm",(void*)f_6590},
{"f_6594:chicken_syntax_scm",(void*)f_6594},
{"f_6603:chicken_syntax_scm",(void*)f_6603},
{"f_6834:chicken_syntax_scm",(void*)f_6834},
{"f_6842:chicken_syntax_scm",(void*)f_6842},
{"f_6606:chicken_syntax_scm",(void*)f_6606},
{"f_6824:chicken_syntax_scm",(void*)f_6824},
{"f_6832:chicken_syntax_scm",(void*)f_6832},
{"f_6609:chicken_syntax_scm",(void*)f_6609},
{"f_6612:chicken_syntax_scm",(void*)f_6612},
{"f_6615:chicken_syntax_scm",(void*)f_6615},
{"f_6822:chicken_syntax_scm",(void*)f_6822},
{"f_6782:chicken_syntax_scm",(void*)f_6782},
{"f_6800:chicken_syntax_scm",(void*)f_6800},
{"f_6814:chicken_syntax_scm",(void*)f_6814},
{"f_6794:chicken_syntax_scm",(void*)f_6794},
{"f_6790:chicken_syntax_scm",(void*)f_6790},
{"f_6786:chicken_syntax_scm",(void*)f_6786},
{"f_6626:chicken_syntax_scm",(void*)f_6626},
{"f_6766:chicken_syntax_scm",(void*)f_6766},
{"f_6734:chicken_syntax_scm",(void*)f_6734},
{"f_6752:chicken_syntax_scm",(void*)f_6752},
{"f_6742:chicken_syntax_scm",(void*)f_6742},
{"f_6738:chicken_syntax_scm",(void*)f_6738},
{"f_6730:chicken_syntax_scm",(void*)f_6730},
{"f_6722:chicken_syntax_scm",(void*)f_6722},
{"f_6702:chicken_syntax_scm",(void*)f_6702},
{"f_6670:chicken_syntax_scm",(void*)f_6670},
{"f_6688:chicken_syntax_scm",(void*)f_6688},
{"f_6678:chicken_syntax_scm",(void*)f_6678},
{"f_6674:chicken_syntax_scm",(void*)f_6674},
{"f_6666:chicken_syntax_scm",(void*)f_6666},
{"f_6588:chicken_syntax_scm",(void*)f_6588},
{"f_1489:chicken_syntax_scm",(void*)f_1489},
{"f_6469:chicken_syntax_scm",(void*)f_6469},
{"f_6473:chicken_syntax_scm",(void*)f_6473},
{"f_6479:chicken_syntax_scm",(void*)f_6479},
{"f_6580:chicken_syntax_scm",(void*)f_6580},
{"f_6485:chicken_syntax_scm",(void*)f_6485},
{"f_6488:chicken_syntax_scm",(void*)f_6488},
{"f_6491:chicken_syntax_scm",(void*)f_6491},
{"f_6531:chicken_syntax_scm",(void*)f_6531},
{"f_6554:chicken_syntax_scm",(void*)f_6554},
{"f_6561:chicken_syntax_scm",(void*)f_6561},
{"f_6568:chicken_syntax_scm",(void*)f_6568},
{"f_6544:chicken_syntax_scm",(void*)f_6544},
{"f_6494:chicken_syntax_scm",(void*)f_6494},
{"f_6467:chicken_syntax_scm",(void*)f_6467},
{"f_1492:chicken_syntax_scm",(void*)f_1492},
{"f_6267:chicken_syntax_scm",(void*)f_6267},
{"f_6271:chicken_syntax_scm",(void*)f_6271},
{"f_6280:chicken_syntax_scm",(void*)f_6280},
{"f_6283:chicken_syntax_scm",(void*)f_6283},
{"f_6286:chicken_syntax_scm",(void*)f_6286},
{"f_6289:chicken_syntax_scm",(void*)f_6289},
{"f_6292:chicken_syntax_scm",(void*)f_6292},
{"f_6455:chicken_syntax_scm",(void*)f_6455},
{"f_6463:chicken_syntax_scm",(void*)f_6463},
{"f_6295:chicken_syntax_scm",(void*)f_6295},
{"f_6445:chicken_syntax_scm",(void*)f_6445},
{"f_6453:chicken_syntax_scm",(void*)f_6453},
{"f_6298:chicken_syntax_scm",(void*)f_6298},
{"f_6439:chicken_syntax_scm",(void*)f_6439},
{"f_6443:chicken_syntax_scm",(void*)f_6443},
{"f_6309:chicken_syntax_scm",(void*)f_6309},
{"f_6383:chicken_syntax_scm",(void*)f_6383},
{"f_6381:chicken_syntax_scm",(void*)f_6381},
{"f_6377:chicken_syntax_scm",(void*)f_6377},
{"f_6357:chicken_syntax_scm",(void*)f_6357},
{"f_6265:chicken_syntax_scm",(void*)f_6265},
{"f_1495:chicken_syntax_scm",(void*)f_1495},
{"f_6222:chicken_syntax_scm",(void*)f_6222},
{"f_6226:chicken_syntax_scm",(void*)f_6226},
{"f_6233:chicken_syntax_scm",(void*)f_6233},
{"f_6253:chicken_syntax_scm",(void*)f_6253},
{"f_6257:chicken_syntax_scm",(void*)f_6257},
{"f_6220:chicken_syntax_scm",(void*)f_6220},
{"f_1498:chicken_syntax_scm",(void*)f_1498},
{"f_6169:chicken_syntax_scm",(void*)f_6169},
{"f_6173:chicken_syntax_scm",(void*)f_6173},
{"f_6180:chicken_syntax_scm",(void*)f_6180},
{"f_6208:chicken_syntax_scm",(void*)f_6208},
{"f_6212:chicken_syntax_scm",(void*)f_6212},
{"f_6167:chicken_syntax_scm",(void*)f_6167},
{"f_1501:chicken_syntax_scm",(void*)f_1501},
{"f_6024:chicken_syntax_scm",(void*)f_6024},
{"f_6028:chicken_syntax_scm",(void*)f_6028},
{"f_6037:chicken_syntax_scm",(void*)f_6037},
{"f_6106:chicken_syntax_scm",(void*)f_6106},
{"f_6139:chicken_syntax_scm",(void*)f_6139},
{"f_6137:chicken_syntax_scm",(void*)f_6137},
{"f_6133:chicken_syntax_scm",(void*)f_6133},
{"f_6022:chicken_syntax_scm",(void*)f_6022},
{"f_1504:chicken_syntax_scm",(void*)f_1504},
{"f_5982:chicken_syntax_scm",(void*)f_5982},
{"f_5986:chicken_syntax_scm",(void*)f_5986},
{"f_6006:chicken_syntax_scm",(void*)f_6006},
{"f_6014:chicken_syntax_scm",(void*)f_6014},
{"f_5989:chicken_syntax_scm",(void*)f_5989},
{"f_5996:chicken_syntax_scm",(void*)f_5996},
{"f_6000:chicken_syntax_scm",(void*)f_6000},
{"f_5980:chicken_syntax_scm",(void*)f_5980},
{"f_1507:chicken_syntax_scm",(void*)f_1507},
{"f_5594:chicken_syntax_scm",(void*)f_5594},
{"f_5598:chicken_syntax_scm",(void*)f_5598},
{"f_5607:chicken_syntax_scm",(void*)f_5607},
{"f_5610:chicken_syntax_scm",(void*)f_5610},
{"f_5685:chicken_syntax_scm",(void*)f_5685},
{"f_5938:chicken_syntax_scm",(void*)f_5938},
{"f_5951:chicken_syntax_scm",(void*)f_5951},
{"f_5688:chicken_syntax_scm",(void*)f_5688},
{"f_5924:chicken_syntax_scm",(void*)f_5924},
{"f_5936:chicken_syntax_scm",(void*)f_5936},
{"f_5932:chicken_syntax_scm",(void*)f_5932},
{"f_5691:chicken_syntax_scm",(void*)f_5691},
{"f_5878:chicken_syntax_scm",(void*)f_5878},
{"f_5911:chicken_syntax_scm",(void*)f_5911},
{"f_5918:chicken_syntax_scm",(void*)f_5918},
{"f_5894:chicken_syntax_scm",(void*)f_5894},
{"f_5703:chicken_syntax_scm",(void*)f_5703},
{"f_5872:chicken_syntax_scm",(void*)f_5872},
{"f_5710:chicken_syntax_scm",(void*)f_5710},
{"f_5712:chicken_syntax_scm",(void*)f_5712},
{"f_5866:chicken_syntax_scm",(void*)f_5866},
{"f_5750:chicken_syntax_scm",(void*)f_5750},
{"f_5832:chicken_syntax_scm",(void*)f_5832},
{"f_5789:chicken_syntax_scm",(void*)f_5789},
{"f_5769:chicken_syntax_scm",(void*)f_5769},
{"f_5736:chicken_syntax_scm",(void*)f_5736},
{"f_5744:chicken_syntax_scm",(void*)f_5744},
{"f_5730:chicken_syntax_scm",(void*)f_5730},
{"f_5734:chicken_syntax_scm",(void*)f_5734},
{"f_5692:chicken_syntax_scm",(void*)f_5692},
{"f_5643:chicken_syntax_scm",(void*)f_5643},
{"f_5666:chicken_syntax_scm",(void*)f_5666},
{"f_5670:chicken_syntax_scm",(void*)f_5670},
{"f_5612:chicken_syntax_scm",(void*)f_5612},
{"f_5633:chicken_syntax_scm",(void*)f_5633},
{"f_5592:chicken_syntax_scm",(void*)f_5592},
{"f_1510:chicken_syntax_scm",(void*)f_1510},
{"f_5522:chicken_syntax_scm",(void*)f_5522},
{"f_5526:chicken_syntax_scm",(void*)f_5526},
{"f_5535:chicken_syntax_scm",(void*)f_5535},
{"f_5538:chicken_syntax_scm",(void*)f_5538},
{"f_5543:chicken_syntax_scm",(void*)f_5543},
{"f_5580:chicken_syntax_scm",(void*)f_5580},
{"f_5561:chicken_syntax_scm",(void*)f_5561},
{"f_5520:chicken_syntax_scm",(void*)f_5520},
{"f_1513:chicken_syntax_scm",(void*)f_1513},
{"f_5356:chicken_syntax_scm",(void*)f_5356},
{"f_5360:chicken_syntax_scm",(void*)f_5360},
{"f_5369:chicken_syntax_scm",(void*)f_5369},
{"f_5372:chicken_syntax_scm",(void*)f_5372},
{"f_5512:chicken_syntax_scm",(void*)f_5512},
{"f_5510:chicken_syntax_scm",(void*)f_5510},
{"f_5375:chicken_syntax_scm",(void*)f_5375},
{"f_5494:chicken_syntax_scm",(void*)f_5494},
{"f_5506:chicken_syntax_scm",(void*)f_5506},
{"f_5502:chicken_syntax_scm",(void*)f_5502},
{"f_5378:chicken_syntax_scm",(void*)f_5378},
{"f_5488:chicken_syntax_scm",(void*)f_5488},
{"f_5398:chicken_syntax_scm",(void*)f_5398},
{"f_5412:chicken_syntax_scm",(void*)f_5412},
{"f_5440:chicken_syntax_scm",(void*)f_5440},
{"f_5450:chicken_syntax_scm",(void*)f_5450},
{"f_5466:chicken_syntax_scm",(void*)f_5466},
{"f_5448:chicken_syntax_scm",(void*)f_5448},
{"f_5444:chicken_syntax_scm",(void*)f_5444},
{"f_5406:chicken_syntax_scm",(void*)f_5406},
{"f_5410:chicken_syntax_scm",(void*)f_5410},
{"f_5402:chicken_syntax_scm",(void*)f_5402},
{"f_5379:chicken_syntax_scm",(void*)f_5379},
{"f_5354:chicken_syntax_scm",(void*)f_5354},
{"f_1516:chicken_syntax_scm",(void*)f_1516},
{"f_5282:chicken_syntax_scm",(void*)f_5282},
{"f_5286:chicken_syntax_scm",(void*)f_5286},
{"f_5289:chicken_syntax_scm",(void*)f_5289},
{"f_5292:chicken_syntax_scm",(void*)f_5292},
{"f_5295:chicken_syntax_scm",(void*)f_5295},
{"f_5280:chicken_syntax_scm",(void*)f_5280},
{"f_1519:chicken_syntax_scm",(void*)f_1519},
{"f_5181:chicken_syntax_scm",(void*)f_5181},
{"f_5185:chicken_syntax_scm",(void*)f_5185},
{"f_5272:chicken_syntax_scm",(void*)f_5272},
{"f_5268:chicken_syntax_scm",(void*)f_5268},
{"f_5187:chicken_syntax_scm",(void*)f_5187},
{"f_5191:chicken_syntax_scm",(void*)f_5191},
{"f_5248:chicken_syntax_scm",(void*)f_5248},
{"f_5200:chicken_syntax_scm",(void*)f_5200},
{"f_5222:chicken_syntax_scm",(void*)f_5222},
{"f_5212:chicken_syntax_scm",(void*)f_5212},
{"f_5203:chicken_syntax_scm",(void*)f_5203},
{"f_5179:chicken_syntax_scm",(void*)f_5179},
{"f_1522:chicken_syntax_scm",(void*)f_1522},
{"f_5018:chicken_syntax_scm",(void*)f_5018},
{"f_5022:chicken_syntax_scm",(void*)f_5022},
{"f_5031:chicken_syntax_scm",(void*)f_5031},
{"f_5034:chicken_syntax_scm",(void*)f_5034},
{"f_5039:chicken_syntax_scm",(void*)f_5039},
{"f_5084:chicken_syntax_scm",(void*)f_5084},
{"f_5151:chicken_syntax_scm",(void*)f_5151},
{"f_5113:chicken_syntax_scm",(void*)f_5113},
{"f_5053:chicken_syntax_scm",(void*)f_5053},
{"f_5057:chicken_syntax_scm",(void*)f_5057},
{"f_5016:chicken_syntax_scm",(void*)f_5016},
{"f_1525:chicken_syntax_scm",(void*)f_1525},
{"f_4849:chicken_syntax_scm",(void*)f_4849},
{"f_4853:chicken_syntax_scm",(void*)f_4853},
{"f_4862:chicken_syntax_scm",(void*)f_4862},
{"f_4865:chicken_syntax_scm",(void*)f_4865},
{"f_4868:chicken_syntax_scm",(void*)f_4868},
{"f_4871:chicken_syntax_scm",(void*)f_4871},
{"f_4874:chicken_syntax_scm",(void*)f_4874},
{"f_4877:chicken_syntax_scm",(void*)f_4877},
{"f_4884:chicken_syntax_scm",(void*)f_4884},
{"f_4902:chicken_syntax_scm",(void*)f_4902},
{"f_4918:chicken_syntax_scm",(void*)f_4918},
{"f_4924:chicken_syntax_scm",(void*)f_4924},
{"f_4980:chicken_syntax_scm",(void*)f_4980},
{"f_4978:chicken_syntax_scm",(void*)f_4978},
{"f_4974:chicken_syntax_scm",(void*)f_4974},
{"f_4966:chicken_syntax_scm",(void*)f_4966},
{"f_4962:chicken_syntax_scm",(void*)f_4962},
{"f_4931:chicken_syntax_scm",(void*)f_4931},
{"f_4900:chicken_syntax_scm",(void*)f_4900},
{"f_4847:chicken_syntax_scm",(void*)f_4847},
{"f_1528:chicken_syntax_scm",(void*)f_1528},
{"f_4417:chicken_syntax_scm",(void*)f_4417},
{"f_4421:chicken_syntax_scm",(void*)f_4421},
{"f_4433:chicken_syntax_scm",(void*)f_4433},
{"f_4436:chicken_syntax_scm",(void*)f_4436},
{"f_4439:chicken_syntax_scm",(void*)f_4439},
{"f_4442:chicken_syntax_scm",(void*)f_4442},
{"f_4445:chicken_syntax_scm",(void*)f_4445},
{"f_4448:chicken_syntax_scm",(void*)f_4448},
{"f_4736:chicken_syntax_scm",(void*)f_4736},
{"f_4739:chicken_syntax_scm",(void*)f_4739},
{"f_4742:chicken_syntax_scm",(void*)f_4742},
{"f_4835:chicken_syntax_scm",(void*)f_4835},
{"f_4843:chicken_syntax_scm",(void*)f_4843},
{"f_4758:chicken_syntax_scm",(void*)f_4758},
{"f_4761:chicken_syntax_scm",(void*)f_4761},
{"f_4764:chicken_syntax_scm",(void*)f_4764},
{"f_4767:chicken_syntax_scm",(void*)f_4767},
{"f_4825:chicken_syntax_scm",(void*)f_4825},
{"f_4833:chicken_syntax_scm",(void*)f_4833},
{"f_4770:chicken_syntax_scm",(void*)f_4770},
{"f_4773:chicken_syntax_scm",(void*)f_4773},
{"f_4776:chicken_syntax_scm",(void*)f_4776},
{"f_4783:chicken_syntax_scm",(void*)f_4783},
{"f_4743:chicken_syntax_scm",(void*)f_4743},
{"f_4755:chicken_syntax_scm",(void*)f_4755},
{"f_4751:chicken_syntax_scm",(void*)f_4751},
{"f_4547:chicken_syntax_scm",(void*)f_4547},
{"f_4553:chicken_syntax_scm",(void*)f_4553},
{"f_4729:chicken_syntax_scm",(void*)f_4729},
{"f_4673:chicken_syntax_scm",(void*)f_4673},
{"f_4615:chicken_syntax_scm",(void*)f_4615},
{"f_4450:chicken_syntax_scm",(void*)f_4450},
{"f_4458:chicken_syntax_scm",(void*)f_4458},
{"f_4462:chicken_syntax_scm",(void*)f_4462},
{"f_4466:chicken_syntax_scm",(void*)f_4466},
{"f_4468:chicken_syntax_scm",(void*)f_4468},
{"f_4521:chicken_syntax_scm",(void*)f_4521},
{"f_4537:chicken_syntax_scm",(void*)f_4537},
{"f_4533:chicken_syntax_scm",(void*)f_4533},
{"f_4489:chicken_syntax_scm",(void*)f_4489},
{"f_4415:chicken_syntax_scm",(void*)f_4415},
{"f_1531:chicken_syntax_scm",(void*)f_1531},
{"f_4233:chicken_syntax_scm",(void*)f_4233},
{"f_4237:chicken_syntax_scm",(void*)f_4237},
{"f_4240:chicken_syntax_scm",(void*)f_4240},
{"f_4243:chicken_syntax_scm",(void*)f_4243},
{"f_4246:chicken_syntax_scm",(void*)f_4246},
{"f_4253:chicken_syntax_scm",(void*)f_4253},
{"f_4288:chicken_syntax_scm",(void*)f_4288},
{"f_4372:chicken_syntax_scm",(void*)f_4372},
{"f_4348:chicken_syntax_scm",(void*)f_4348},
{"f_4231:chicken_syntax_scm",(void*)f_4231},
{"f_1534:chicken_syntax_scm",(void*)f_1534},
{"f_3931:chicken_syntax_scm",(void*)f_3931},
{"f_3935:chicken_syntax_scm",(void*)f_3935},
{"f_3947:chicken_syntax_scm",(void*)f_3947},
{"f_3950:chicken_syntax_scm",(void*)f_3950},
{"f_3953:chicken_syntax_scm",(void*)f_3953},
{"f_3956:chicken_syntax_scm",(void*)f_3956},
{"f_3959:chicken_syntax_scm",(void*)f_3959},
{"f_3962:chicken_syntax_scm",(void*)f_3962},
{"f_3983:chicken_syntax_scm",(void*)f_3983},
{"f_4211:chicken_syntax_scm",(void*)f_4211},
{"f_4073:chicken_syntax_scm",(void*)f_4073},
{"f_4092:chicken_syntax_scm",(void*)f_4092},
{"f_4049:chicken_syntax_scm",(void*)f_4049},
{"f_3981:chicken_syntax_scm",(void*)f_3981},
{"f_3929:chicken_syntax_scm",(void*)f_3929},
{"f_1537:chicken_syntax_scm",(void*)f_1537},
{"f_3510:chicken_syntax_scm",(void*)f_3510},
{"f_3514:chicken_syntax_scm",(void*)f_3514},
{"f_3551:chicken_syntax_scm",(void*)f_3551},
{"f_3910:chicken_syntax_scm",(void*)f_3910},
{"f_3920:chicken_syntax_scm",(void*)f_3920},
{"f_3908:chicken_syntax_scm",(void*)f_3908},
{"f_3554:chicken_syntax_scm",(void*)f_3554},
{"f_3557:chicken_syntax_scm",(void*)f_3557},
{"f_3560:chicken_syntax_scm",(void*)f_3560},
{"f_3563:chicken_syntax_scm",(void*)f_3563},
{"f_3566:chicken_syntax_scm",(void*)f_3566},
{"f_3569:chicken_syntax_scm",(void*)f_3569},
{"f_3572:chicken_syntax_scm",(void*)f_3572},
{"f_3583:chicken_syntax_scm",(void*)f_3583},
{"f_3609:chicken_syntax_scm",(void*)f_3609},
{"f_3619:chicken_syntax_scm",(void*)f_3619},
{"f_3623:chicken_syntax_scm",(void*)f_3623},
{"f_3872:chicken_syntax_scm",(void*)f_3872},
{"f_3857:chicken_syntax_scm",(void*)f_3857},
{"f_3637:chicken_syntax_scm",(void*)f_3637},
{"f_3661:chicken_syntax_scm",(void*)f_3661},
{"f_3688:chicken_syntax_scm",(void*)f_3688},
{"f_3844:chicken_syntax_scm",(void*)f_3844},
{"f_3756:chicken_syntax_scm",(void*)f_3756},
{"f_3836:chicken_syntax_scm",(void*)f_3836},
{"f_3816:chicken_syntax_scm",(void*)f_3816},
{"f_3775:chicken_syntax_scm",(void*)f_3775},
{"f_3745:chicken_syntax_scm",(void*)f_3745},
{"f_3713:chicken_syntax_scm",(void*)f_3713},
{"f_3665:chicken_syntax_scm",(void*)f_3665},
{"f_3682:chicken_syntax_scm",(void*)f_3682},
{"f_3651:chicken_syntax_scm",(void*)f_3651},
{"f_3659:chicken_syntax_scm",(void*)f_3659},
{"f_3645:chicken_syntax_scm",(void*)f_3645},
{"f_3607:chicken_syntax_scm",(void*)f_3607},
{"f_3516:chicken_syntax_scm",(void*)f_3516},
{"f_3522:chicken_syntax_scm",(void*)f_3522},
{"f_3548:chicken_syntax_scm",(void*)f_3548},
{"f_3536:chicken_syntax_scm",(void*)f_3536},
{"f_3540:chicken_syntax_scm",(void*)f_3540},
{"f_3508:chicken_syntax_scm",(void*)f_3508},
{"f_1540:chicken_syntax_scm",(void*)f_1540},
{"f_3412:chicken_syntax_scm",(void*)f_3412},
{"f_3416:chicken_syntax_scm",(void*)f_3416},
{"f_3481:chicken_syntax_scm",(void*)f_3481},
{"f_3496:chicken_syntax_scm",(void*)f_3496},
{"f_3431:chicken_syntax_scm",(void*)f_3431},
{"f_3454:chicken_syntax_scm",(void*)f_3454},
{"f_3466:chicken_syntax_scm",(void*)f_3466},
{"f_3410:chicken_syntax_scm",(void*)f_3410},
{"f_1543:chicken_syntax_scm",(void*)f_1543},
{"f_3218:chicken_syntax_scm",(void*)f_3218},
{"f_3222:chicken_syntax_scm",(void*)f_3222},
{"f_3225:chicken_syntax_scm",(void*)f_3225},
{"f_3228:chicken_syntax_scm",(void*)f_3228},
{"f_3231:chicken_syntax_scm",(void*)f_3231},
{"f_3242:chicken_syntax_scm",(void*)f_3242},
{"f_3270:chicken_syntax_scm",(void*)f_3270},
{"f_3362:chicken_syntax_scm",(void*)f_3362},
{"f_3216:chicken_syntax_scm",(void*)f_3216},
{"f_1546:chicken_syntax_scm",(void*)f_1546},
{"f_2891:chicken_syntax_scm",(void*)f_2891},
{"f_2895:chicken_syntax_scm",(void*)f_2895},
{"f_2898:chicken_syntax_scm",(void*)f_2898},
{"f_2901:chicken_syntax_scm",(void*)f_2901},
{"f_2904:chicken_syntax_scm",(void*)f_2904},
{"f_2907:chicken_syntax_scm",(void*)f_2907},
{"f_2910:chicken_syntax_scm",(void*)f_2910},
{"f_2913:chicken_syntax_scm",(void*)f_2913},
{"f_3088:chicken_syntax_scm",(void*)f_3088},
{"f_3128:chicken_syntax_scm",(void*)f_3128},
{"f_3136:chicken_syntax_scm",(void*)f_3136},
{"f_3132:chicken_syntax_scm",(void*)f_3132},
{"f_2915:chicken_syntax_scm",(void*)f_2915},
{"f_3039:chicken_syntax_scm",(void*)f_3039},
{"f_3037:chicken_syntax_scm",(void*)f_3037},
{"f_3033:chicken_syntax_scm",(void*)f_3033},
{"f_3025:chicken_syntax_scm",(void*)f_3025},
{"f_3006:chicken_syntax_scm",(void*)f_3006},
{"f_2991:chicken_syntax_scm",(void*)f_2991},
{"f_2976:chicken_syntax_scm",(void*)f_2976},
{"f_2957:chicken_syntax_scm",(void*)f_2957},
{"f_2942:chicken_syntax_scm",(void*)f_2942},
{"f_2889:chicken_syntax_scm",(void*)f_2889},
{"f_1549:chicken_syntax_scm",(void*)f_1549},
{"f_2516:chicken_syntax_scm",(void*)f_2516},
{"f_2520:chicken_syntax_scm",(void*)f_2520},
{"f_2535:chicken_syntax_scm",(void*)f_2535},
{"f_2538:chicken_syntax_scm",(void*)f_2538},
{"f_2541:chicken_syntax_scm",(void*)f_2541},
{"f_2547:chicken_syntax_scm",(void*)f_2547},
{"f_2550:chicken_syntax_scm",(void*)f_2550},
{"f_2553:chicken_syntax_scm",(void*)f_2553},
{"f_2556:chicken_syntax_scm",(void*)f_2556},
{"f_2874:chicken_syntax_scm",(void*)f_2874},
{"f_2872:chicken_syntax_scm",(void*)f_2872},
{"f_2868:chicken_syntax_scm",(void*)f_2868},
{"f_2585:chicken_syntax_scm",(void*)f_2585},
{"f_2611:chicken_syntax_scm",(void*)f_2611},
{"f_2651:chicken_syntax_scm",(void*)f_2651},
{"f_2627:chicken_syntax_scm",(void*)f_2627},
{"f_2623:chicken_syntax_scm",(void*)f_2623},
{"f_2583:chicken_syntax_scm",(void*)f_2583},
{"f_2579:chicken_syntax_scm",(void*)f_2579},
{"f_2514:chicken_syntax_scm",(void*)f_2514},
{"f_1552:chicken_syntax_scm",(void*)f_1552},
{"f_2328:chicken_syntax_scm",(void*)f_2328},
{"f_2332:chicken_syntax_scm",(void*)f_2332},
{"f_2335:chicken_syntax_scm",(void*)f_2335},
{"f_2338:chicken_syntax_scm",(void*)f_2338},
{"f_2341:chicken_syntax_scm",(void*)f_2341},
{"f_2344:chicken_syntax_scm",(void*)f_2344},
{"f_2353:chicken_syntax_scm",(void*)f_2353},
{"f_2456:chicken_syntax_scm",(void*)f_2456},
{"f_2484:chicken_syntax_scm",(void*)f_2484},
{"f_2478:chicken_syntax_scm",(void*)f_2478},
{"f_2459:chicken_syntax_scm",(void*)f_2459},
{"f_2363:chicken_syntax_scm",(void*)f_2363},
{"f_2366:chicken_syntax_scm",(void*)f_2366},
{"f_2438:chicken_syntax_scm",(void*)f_2438},
{"f_2415:chicken_syntax_scm",(void*)f_2415},
{"f_2372:chicken_syntax_scm",(void*)f_2372},
{"f_2383:chicken_syntax_scm",(void*)f_2383},
{"f_2403:chicken_syntax_scm",(void*)f_2403},
{"f_2326:chicken_syntax_scm",(void*)f_2326},
{"f_1555:chicken_syntax_scm",(void*)f_1555},
{"f_2109:chicken_syntax_scm",(void*)f_2109},
{"f_2113:chicken_syntax_scm",(void*)f_2113},
{"f_2116:chicken_syntax_scm",(void*)f_2116},
{"f_2119:chicken_syntax_scm",(void*)f_2119},
{"f_2122:chicken_syntax_scm",(void*)f_2122},
{"f_2125:chicken_syntax_scm",(void*)f_2125},
{"f_2134:chicken_syntax_scm",(void*)f_2134},
{"f_2253:chicken_syntax_scm",(void*)f_2253},
{"f_2281:chicken_syntax_scm",(void*)f_2281},
{"f_2314:chicken_syntax_scm",(void*)f_2314},
{"f_2287:chicken_syntax_scm",(void*)f_2287},
{"f_2275:chicken_syntax_scm",(void*)f_2275},
{"f_2256:chicken_syntax_scm",(void*)f_2256},
{"f_2144:chicken_syntax_scm",(void*)f_2144},
{"f_2147:chicken_syntax_scm",(void*)f_2147},
{"f_2243:chicken_syntax_scm",(void*)f_2243},
{"f_2208:chicken_syntax_scm",(void*)f_2208},
{"f_2153:chicken_syntax_scm",(void*)f_2153},
{"f_2176:chicken_syntax_scm",(void*)f_2176},
{"f_2196:chicken_syntax_scm",(void*)f_2196},
{"f_2107:chicken_syntax_scm",(void*)f_2107},
{"f_1558:chicken_syntax_scm",(void*)f_1558},
{"f_1832:chicken_syntax_scm",(void*)f_1832},
{"f_1836:chicken_syntax_scm",(void*)f_1836},
{"f_1839:chicken_syntax_scm",(void*)f_1839},
{"f_1842:chicken_syntax_scm",(void*)f_1842},
{"f_1845:chicken_syntax_scm",(void*)f_1845},
{"f_1848:chicken_syntax_scm",(void*)f_1848},
{"f_1851:chicken_syntax_scm",(void*)f_1851},
{"f_1860:chicken_syntax_scm",(void*)f_1860},
{"f_2006:chicken_syntax_scm",(void*)f_2006},
{"f_2009:chicken_syntax_scm",(void*)f_2009},
{"f_2018:chicken_syntax_scm",(void*)f_2018},
{"f_2043:chicken_syntax_scm",(void*)f_2043},
{"f_2068:chicken_syntax_scm",(void*)f_2068},
{"f_2090:chicken_syntax_scm",(void*)f_2090},
{"f_2083:chicken_syntax_scm",(void*)f_2083},
{"f_2075:chicken_syntax_scm",(void*)f_2075},
{"f_2062:chicken_syntax_scm",(void*)f_2062},
{"f_2058:chicken_syntax_scm",(void*)f_2058},
{"f_2037:chicken_syntax_scm",(void*)f_2037},
{"f_2033:chicken_syntax_scm",(void*)f_2033},
{"f_2000:chicken_syntax_scm",(void*)f_2000},
{"f_1870:chicken_syntax_scm",(void*)f_1870},
{"f_1877:chicken_syntax_scm",(void*)f_1877},
{"f_1985:chicken_syntax_scm",(void*)f_1985},
{"f_1973:chicken_syntax_scm",(void*)f_1973},
{"f_1969:chicken_syntax_scm",(void*)f_1969},
{"f_1905:chicken_syntax_scm",(void*)f_1905},
{"f_1933:chicken_syntax_scm",(void*)f_1933},
{"f_1945:chicken_syntax_scm",(void*)f_1945},
{"f_1929:chicken_syntax_scm",(void*)f_1929},
{"f_1830:chicken_syntax_scm",(void*)f_1830},
{"f_1561:chicken_syntax_scm",(void*)f_1561},
{"f_1728:chicken_syntax_scm",(void*)f_1728},
{"f_1732:chicken_syntax_scm",(void*)f_1732},
{"f_1738:chicken_syntax_scm",(void*)f_1738},
{"f_1822:chicken_syntax_scm",(void*)f_1822},
{"f_1783:chicken_syntax_scm",(void*)f_1783},
{"f_1795:chicken_syntax_scm",(void*)f_1795},
{"f_1726:chicken_syntax_scm",(void*)f_1726},
{"f_1564:chicken_syntax_scm",(void*)f_1564},
{"f_1620:chicken_syntax_scm",(void*)f_1620},
{"f_1624:chicken_syntax_scm",(void*)f_1624},
{"f_1698:chicken_syntax_scm",(void*)f_1698},
{"f_1710:chicken_syntax_scm",(void*)f_1710},
{"f_1639:chicken_syntax_scm",(void*)f_1639},
{"f_1685:chicken_syntax_scm",(void*)f_1685},
{"f_1642:chicken_syntax_scm",(void*)f_1642},
{"f_1645:chicken_syntax_scm",(void*)f_1645},
{"f_1655:chicken_syntax_scm",(void*)f_1655},
{"f_1618:chicken_syntax_scm",(void*)f_1618},
{"f_1567:chicken_syntax_scm",(void*)f_1567},
{"f_1595:chicken_syntax_scm",(void*)f_1595},
{"f_1599:chicken_syntax_scm",(void*)f_1599},
{"f_1593:chicken_syntax_scm",(void*)f_1593},
{"f_1570:chicken_syntax_scm",(void*)f_1570},
{"f_1585:chicken_syntax_scm",(void*)f_1585},
{"f_1583:chicken_syntax_scm",(void*)f_1583},
{"f_1573:chicken_syntax_scm",(void*)f_1573},
{"f_1576:chicken_syntax_scm",(void*)f_1576},
{"f_1579:chicken_syntax_scm",(void*)f_1579},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
