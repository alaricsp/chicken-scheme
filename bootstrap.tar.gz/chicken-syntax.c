/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-04-15 09:10
   Version 4.0.1 - SVN rev. 14255
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-04-15 on lenovo-1 (MINGW32_NT-6.0)
   command line: chicken-syntax.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file chicken-syntax.c
   unit: chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[235];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,97,49,53,54,51,32,102,111,114,109,49,51,56,53,32,114,49,51,56,54,32,99,49,51,56,55,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,97,49,53,55,51,32,120,49,51,55,54,32,114,49,51,55,55,32,99,49,51,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,97,49,53,57,56,32,102,111,114,109,49,51,54,55,32,114,49,51,54,56,32,99,49,51,54,57,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,97,49,54,51,53,32,102,111,114,109,49,51,53,49,32,114,49,51,53,50,32,99,49,51,53,51,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,115,49,51,48,48,32,100,49,51,48,49,32,99,115,49,51,48,50,32,101,120,112,111,114,116,115,49,51,48,51,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,97,49,55,51,57,32,102,111,114,109,49,50,56,56,32,114,49,50,56,57,32,99,49,50,57,48,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,50,53,54,32,118,97,114,115,49,50,53,55,32,98,115,49,50,53,56,32,118,97,108,115,49,50,53,57,32,114,101,115,116,49,50,54,48,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,97,50,48,49,54,32,102,111,114,109,49,50,52,52,32,114,49,50,52,53,32,99,49,50,52,54,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,50,49,53,32,118,97,114,115,49,50,49,54,32,118,97,108,115,49,50,49,55,32,114,101,115,116,49,50,49,56,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,97,50,50,51,53,32,102,111,114,109,49,50,48,51,32,114,49,50,48,52,32,99,49,50,48,53,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,49,54,57,32,105,49,49,55,48,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,97,50,55,56,49,32,115,110,97,109,101,49,49,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,28),40,97,50,52,50,51,32,102,111,114,109,49,49,51,49,32,114,49,49,51,50,32,99,49,49,51,51,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,50,57,52,54,32,107,49,49,49,53,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,48,56,55,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,28),40,97,50,55,57,56,32,102,111,114,109,49,48,55,49,32,114,49,48,55,50,32,99,49,48,55,51,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,28),40,97,51,49,50,53,32,102,111,114,109,49,48,53,56,32,114,49,48,53,57,32,99,49,48,54,48,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,28),40,97,51,51,49,57,32,102,111,114,109,49,48,51,51,32,114,49,48,51,52,32,99,49,48,51,53,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,57,51,56,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,14),40,103,101,110,118,97,114,115,32,110,57,51,52,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,51,53,53,56,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,98,117,105,108,100,32,118,97,114,115,50,57,57,56,32,118,114,101,115,116,57,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,97,51,53,54,56,32,118,97,114,115,49,57,57,50,32,118,97,114,115,50,57,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,31),40,97,51,53,50,54,32,118,97,114,115,57,55,49,32,97,114,103,99,57,55,50,32,114,101,115,116,57,55,51,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,20),40,97,51,53,49,54,32,99,57,54,56,32,98,111,100,121,57,54,57,41,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,97,51,56,50,55,32,118,97,114,115,57,52,54,32,97,114,103,99,57,52,55,32,114,101,115,116,57,52,56,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,51,56,49,55,32,99,57,52,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,25),40,97,51,52,49,55,32,102,111,114,109,57,50,56,32,114,57,50,57,32,99,57,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,97,114,103,115,57,48,54,32,118,97,114,100,101,102,115,57,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,25),40,97,51,56,51,56,32,102,111,114,109,56,56,53,32,114,56,56,54,32,99,56,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,25),40,97,52,49,52,48,32,102,111,114,109,56,54,51,32,114,56,54,52,32,99,56,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,54),40,114,101,99,117,114,32,118,97,114,115,55,57,48,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,55,57,49,32,100,101,102,115,55,57,50,32,110,101,120,116,45,103,117,121,55,57,51,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,100,101,102,97,117,108,116,45,112,114,111,99,115,32,118,97,114,115,55,56,50,32,98,111,100,121,45,112,114,111,99,55,56,51,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,55,56,52,32,100,101,102,115,55,56,53,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,45),40,114,101,99,117,114,32,118,97,114,115,56,49,49,32,100,101,102,97,117,108,116,101,114,115,56,49,50,32,110,111,110,45,100,101,102,97,117,108,116,115,56,49,51,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,57),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,56,48,51,32,100,101,102,97,117,108,116,101,114,115,56,48,52,32,98,111,100,121,45,112,114,111,99,56,48,53,32,114,101,115,116,56,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,29),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,56,51,49,32,115,121,109,56,51,50,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,52,55,51,50,32,118,97,114,56,52,54,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,97,52,55,52,50,32,118,56,51,54,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,25),40,97,52,51,50,52,32,102,111,114,109,55,54,54,32,114,55,54,55,32,99,55,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,97,52,56,56,55,32,120,55,53,54,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,19),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,55,52,51,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,25),40,97,52,55,53,54,32,102,111,114,109,55,50,52,32,114,55,50,53,32,99,55,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,102,111,108,100,32,98,115,54,57,49,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,25),40,97,52,57,50,53,32,102,111,114,109,54,56,48,32,114,54,56,49,32,99,54,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,26),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,54,52,57,32,105,100,54,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,25),40,97,53,48,56,56,32,102,111,114,109,54,52,49,32,114,54,52,50,32,99,54,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,25),40,97,53,49,56,57,32,102,111,114,109,54,50,56,32,114,54,50,57,32,99,54,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,54,48,53,41,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,97,53,51,53,55,32,118,54,50,49,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,97,53,51,49,57,32,118,98,54,49,53,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,12),40,97,53,51,57,53,32,118,54,49,51,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,97,53,52,48,49,32,118,54,48,49,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,12),40,97,53,52,49,57,32,120,53,57,55,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,25),40,97,53,50,54,51,32,102,111,114,109,53,56,54,32,114,53,56,55,32,99,53,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,19),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,53,55,51,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,25),40,97,53,52,50,57,32,102,111,114,109,53,54,50,32,114,53,54,51,32,99,53,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,52,53,54,32,108,52,53,55,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,52,53,57,32,108,52,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,53,48,48,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,12),40,97,53,54,52,51,32,118,53,52,51,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,53,50,56,32,101,120,112,115,53,50,57,32,108,108,105,115,116,115,50,53,51,48,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,97,53,55,55,57,32,120,53,53,55,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,53,48,54,32,97,99,99,53,48,55,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,12),40,97,53,56,51,49,32,118,52,57,54,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,52,55,54,32,97,99,99,52,55,55,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,25),40,97,53,53,48,49,32,102,111,114,109,52,52,52,32,114,52,52,53,32,99,52,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,97,53,57,49,51,32,103,52,51,52,52,51,53,52,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,25),40,97,53,56,56,57,32,102,111,114,109,52,50,53,32,114,52,50,54,32,99,52,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,17),40,97,54,48,52,54,32,118,52,49,55,32,97,52,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,25),40,97,53,57,51,49,32,102,111,114,109,51,56,56,32,114,51,56,57,32,99,51,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,97,54,48,55,54,32,102,111,114,109,51,55,57,32,114,51,56,48,32,99,51,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,25),40,97,54,49,50,57,32,102,111,114,109,51,55,48,32,114,51,55,49,32,99,51,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,97,54,50,57,48,32,97,51,54,50,32,97,50,51,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,12),40,97,54,51,53,50,32,122,51,53,52,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,12),40,97,54,51,54,50,32,122,51,53,48,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,97,54,49,55,52,32,102,111,114,109,51,51,48,32,114,51,51,49,32,99,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,50,57,55,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,25),40,97,54,51,55,54,32,102,111,114,109,50,54,55,32,114,50,54,56,32,99,50,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,19),40,97,54,53,57,53,32,105,100,50,53,57,32,111,116,50,54,48,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,19),40,97,54,54,48,57,32,110,116,50,53,50,32,105,100,50,53,51,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,19),40,97,54,54,53,57,32,105,100,50,52,53,32,110,116,50,52,54,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,19),40,97,54,54,55,51,32,111,116,50,51,56,32,105,100,50,51,57,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,50,51,52,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,12),40,97,54,55,51,49,32,120,50,50,48,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,12),40,97,54,55,52,49,32,120,50,49,54,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,25),40,97,54,52,57,55,32,102,111,114,109,50,48,52,32,114,50,48,53,32,99,50,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,25),40,97,54,55,53,53,32,102,111,114,109,49,56,52,32,114,49,56,53,32,99,49,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,97,54,56,57,50,32,102,111,114,109,49,53,57,32,114,49,54,48,32,99,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,7),40,97,55,48,51,53,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,22),40,100,111,108,111,111,112,49,52,50,32,120,49,52,57,32,120,115,49,53,48,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,7),40,97,55,48,52,48,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,55,48,55,51,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,7),40,97,55,48,50,57,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,25),40,97,55,48,48,51,32,102,111,114,109,49,49,54,32,114,49,49,55,32,99,49,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,25),40,97,55,48,57,50,32,102,111,114,109,49,48,56,32,114,49,48,57,32,99,49,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,97,55,49,49,48,32,102,111,114,109,57,54,32,114,57,55,32,99,57,56,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,22),40,97,55,50,48,57,32,102,111,114,109,54,50,32,114,54,51,32,99,54,52,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,51,54,32,105,51,55,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,17),40,97,55,51,53,50,32,120,56,32,114,57,32,99,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_chicken_syntax_toplevel)
C_externexport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7366)
static void C_ccall f_7366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_ccall f_7372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_fcall f_7410(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_fcall f_7473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7210)
static void C_ccall f_7210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7256)
static void C_ccall f_7256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7271)
static void C_fcall f_7271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_fcall f_7051(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7068)
static void C_ccall f_7068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7002)
static void C_ccall f_7002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_fcall f_6912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6829)
static void C_fcall f_6829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6502)
static void C_ccall f_6502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_fcall f_6708(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6534)
static void C_ccall f_6534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6642)
static void C_ccall f_6642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6646)
static void C_ccall f_6646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6476)
static void C_ccall f_6476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6075)
static void C_ccall f_6075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_fcall f_5846(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5844)
static void C_ccall f_5844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_fcall f_5786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_fcall f_5802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_fcall f_5620(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_fcall f_5658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5551)
static void C_fcall f_5551(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_fcall f_5520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_fcall f_5451(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_fcall f_5108(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_fcall f_5120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_fcall f_4947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_fcall f_4810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_fcall f_4455(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4461)
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_fcall f_4358(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_fcall f_4376(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_fcall f_3891(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_fcall f_3545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3596)
static void C_fcall f_3596(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_fcall f_3424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3430)
static void C_fcall f_3430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_fcall f_2899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_fcall f_2850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_fcall f_2493(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2519)
static void C_fcall f_2519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_fcall f_2559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_fcall f_2261(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_fcall f_2042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_fcall f_1768(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1914)
static void C_fcall f_1914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_fcall f_1778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7410)
static void C_fcall trf_7410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7410(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7410(t0,t1,t2,t3);}

C_noret_decl(trf_7473)
static void C_fcall trf_7473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7473(t0,t1);}

C_noret_decl(trf_7271)
static void C_fcall trf_7271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7271(t0,t1);}

C_noret_decl(trf_7051)
static void C_fcall trf_7051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7051(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7051(t0,t1,t2,t3);}

C_noret_decl(trf_6912)
static void C_fcall trf_6912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6912(t0,t1);}

C_noret_decl(trf_6829)
static void C_fcall trf_6829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6829(t0,t1);}

C_noret_decl(trf_6708)
static void C_fcall trf_6708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6708(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6708(t0,t1,t2);}

C_noret_decl(trf_6439)
static void C_fcall trf_6439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6439(t0,t1,t2);}

C_noret_decl(trf_5846)
static void C_fcall trf_5846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5846(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5846(t0,t1,t2,t3);}

C_noret_decl(trf_5786)
static void C_fcall trf_5786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5786(t0,t1,t2,t3);}

C_noret_decl(trf_5802)
static void C_fcall trf_5802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5802(t0,t1);}

C_noret_decl(trf_5620)
static void C_fcall trf_5620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5620(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5620(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5658)
static void C_fcall trf_5658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5658(t0,t1);}

C_noret_decl(trf_5551)
static void C_fcall trf_5551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5551(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5551(t0,t1,t2,t3);}

C_noret_decl(trf_5520)
static void C_fcall trf_5520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5520(t0,t1,t2,t3);}

C_noret_decl(trf_5451)
static void C_fcall trf_5451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5451(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5451(t0,t1,t2);}

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5095(t0,t1,t2,t3);}

C_noret_decl(trf_5108)
static void C_fcall trf_5108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5108(t0,t1);}

C_noret_decl(trf_5120)
static void C_fcall trf_5120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5120(t0,t1);}

C_noret_decl(trf_4947)
static void C_fcall trf_4947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4947(t0,t1,t2);}

C_noret_decl(trf_4810)
static void C_fcall trf_4810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4810(t0,t1,t2);}

C_noret_decl(trf_4651)
static void C_fcall trf_4651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4651(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4651(t0,t1,t2);}

C_noret_decl(trf_4455)
static void C_fcall trf_4455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4455(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4455(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4461)
static void C_fcall trf_4461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4461(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4461(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4358)
static void C_fcall trf_4358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4358(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4358(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4376)
static void C_fcall trf_4376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4376(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4376(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3891)
static void C_fcall trf_3891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3891(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3891(t0,t1,t2,t3);}

C_noret_decl(trf_3545)
static void C_fcall trf_3545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3545(t0,t1);}

C_noret_decl(trf_3596)
static void C_fcall trf_3596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3596(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3596(t0,t1,t2,t3);}

C_noret_decl(trf_3424)
static void C_fcall trf_3424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3424(t0,t1,t2);}

C_noret_decl(trf_3430)
static void C_fcall trf_3430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3430(t0,t1,t2);}

C_noret_decl(trf_2899)
static void C_fcall trf_2899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2899(t0,t1);}

C_noret_decl(trf_2850)
static void C_fcall trf_2850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2850(t0,t1);}

C_noret_decl(trf_2493)
static void C_fcall trf_2493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2493(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2493(t0,t1,t2,t3);}

C_noret_decl(trf_2519)
static void C_fcall trf_2519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2519(t0,t1);}

C_noret_decl(trf_2559)
static void C_fcall trf_2559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2559(t0,t1);}

C_noret_decl(trf_2261)
static void C_fcall trf_2261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2261(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2261(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2042)
static void C_fcall trf_2042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2042(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2042(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1768)
static void C_fcall trf_1768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1768(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1768(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1914)
static void C_fcall trf_1914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1914(t0,t1);}

C_noret_decl(trf_1778)
static void C_fcall trf_1778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1778(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3080)){
C_save(t1);
C_rereclaim2(3080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,235);
lf[0]=C_h_intern(&lf[0],29,"\003syschicken-macro-environment");
lf[1]=C_h_intern(&lf[1],17,"register-feature!");
lf[2]=C_h_intern(&lf[2],6,"srfi-8");
lf[3]=C_h_intern(&lf[3],7,"srfi-16");
lf[4]=C_h_intern(&lf[4],7,"srfi-26");
lf[5]=C_h_intern(&lf[5],7,"srfi-31");
lf[6]=C_h_intern(&lf[6],7,"srfi-15");
lf[7]=C_h_intern(&lf[7],7,"srfi-11");
lf[8]=C_h_intern(&lf[8],16,"\003sysmacro-subset");
lf[9]=C_h_intern(&lf[9],28,"\003sysextend-macro-environment");
lf[10]=C_h_intern(&lf[10],12,"define-macro");
lf[11]=C_h_intern(&lf[11],12,"syntax-error");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[13]=C_h_intern(&lf[13],18,"\003syser-transformer");
lf[14]=C_h_intern(&lf[14],3,"use");
lf[15]=C_h_intern(&lf[15],22,"\004corerequire-extension");
lf[16]=C_h_intern(&lf[16],16,"\003syscheck-syntax");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[18]=C_h_intern(&lf[18],17,"define-for-syntax");
lf[19]=C_h_intern(&lf[19],10,"\003sysappend");
lf[20]=C_h_intern(&lf[20],6,"define");
lf[21]=C_h_intern(&lf[21],16,"begin-for-syntax");
lf[22]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[23]=C_h_intern(&lf[23],3,"rec");
lf[24]=C_h_intern(&lf[24],6,"lambda");
lf[25]=C_h_intern(&lf[25],6,"letrec");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[27]=C_h_intern(&lf[27],16,"define-extension");
lf[28]=C_h_intern(&lf[28],22,"chicken-compile-shared");
lf[29]=C_h_intern(&lf[29],9,"compiling");
lf[30]=C_h_intern(&lf[30],4,"name");
lf[31]=C_h_intern(&lf[31],4,"unit");
lf[32]=C_h_intern(&lf[32],5,"quote");
lf[33]=C_h_intern(&lf[33],7,"provide");
lf[34]=C_h_intern(&lf[34],4,"else");
lf[35]=C_h_intern(&lf[35],3,"not");
lf[36]=C_h_intern(&lf[36],11,"cond-expand");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\006%begin\376\377\016\376\377\016");
lf[38]=C_h_intern(&lf[38],4,"cdar");
lf[39]=C_h_intern(&lf[39],6,"append");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[41]=C_h_intern(&lf[41],4,"caar");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[43]=C_h_intern(&lf[43],6,"export");
lf[44]=C_h_intern(&lf[44],7,"dynamic");
lf[45]=C_h_intern(&lf[45],6,"static");
lf[46]=C_h_intern(&lf[46],5,"begin");
lf[47]=C_h_intern(&lf[47],7,"declare");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[49]=C_h_intern(&lf[49],4,"cute");
lf[50]=C_h_intern(&lf[50],6,"gensym");
lf[51]=C_h_intern(&lf[51],7,"reverse");
lf[52]=C_h_intern(&lf[52],5,"apply");
lf[53]=C_h_intern(&lf[53],5,"<...>");
lf[54]=C_h_intern(&lf[54],2,"<>");
lf[55]=C_h_intern(&lf[55],3,"let");
lf[56]=C_h_intern(&lf[56],3,"cut");
lf[57]=C_h_intern(&lf[57],18,"define-record-type");
lf[58]=C_h_intern(&lf[58],18,"\003sysmake-structure");
lf[59]=C_h_intern(&lf[59],14,"\003sysstructure\077");
lf[60]=C_h_intern(&lf[60],15,"\000record-setters");
lf[61]=C_h_intern(&lf[61],12,"\003sysfeatures");
lf[62]=C_h_intern(&lf[62],19,"\003syscheck-structure");
lf[63]=C_h_intern(&lf[63],10,"\004corecheck");
lf[64]=C_h_intern(&lf[64],13,"\003sysblock-ref");
lf[65]=C_h_intern(&lf[65],14,"\003sysblock-set!");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[67]=C_h_intern(&lf[67],7,"\003sysmap");
lf[68]=C_h_intern(&lf[68],3,"car");
lf[69]=C_h_intern(&lf[69],18,"getter-with-setter");
lf[70]=C_h_intern(&lf[70],1,"y");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[73]=C_h_intern(&lf[73],14,"condition-case");
lf[74]=C_h_intern(&lf[74],9,"condition");
lf[75]=C_h_intern(&lf[75],8,"\003sysslot");
lf[76]=C_h_intern(&lf[76],10,"\003syssignal");
lf[77]=C_h_intern(&lf[77],4,"cond");
lf[78]=C_h_intern(&lf[78],17,"handle-exceptions");
lf[79]=C_h_intern(&lf[79],4,"memv");
lf[80]=C_h_intern(&lf[80],3,"and");
lf[81]=C_h_intern(&lf[81],4,"kvar");
lf[82]=C_h_intern(&lf[82],5,"exvar");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[84]=C_h_intern(&lf[84],10,"\003sysvalues");
lf[85]=C_h_intern(&lf[85],9,"\003sysapply");
lf[86]=C_h_intern(&lf[86],20,"\003syscall-with-values");
lf[87]=C_h_intern(&lf[87],22,"with-exception-handler");
lf[88]=C_h_intern(&lf[88],30,"call-with-current-continuation");
lf[89]=C_h_intern(&lf[89],4,"args");
lf[90]=C_h_intern(&lf[90],1,"k");
lf[91]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[92]=C_h_intern(&lf[92],21,"define-record-printer");
lf[93]=C_h_intern(&lf[93],27,"\003sysregister-record-printer");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[97]=C_h_intern(&lf[97],11,"case-lambda");
lf[98]=C_h_intern(&lf[98],6,"length");
lf[99]=C_h_intern(&lf[99],9,"split-at!");
lf[100]=C_h_intern(&lf[100],4,"take");
lf[101]=C_h_intern(&lf[101],3,"map");
lf[102]=C_h_intern(&lf[102],4,"list");
lf[103]=C_h_intern(&lf[103],3,"cdr");
lf[104]=C_h_intern(&lf[104],2,">=");
lf[105]=C_h_intern(&lf[105],1,"=");
lf[106]=C_h_intern(&lf[106],11,"lambda-list");
lf[107]=C_h_intern(&lf[107],25,"\003sysdecompose-lambda-list");
lf[108]=C_h_intern(&lf[108],10,"fold-right");
lf[109]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[110]=C_h_intern(&lf[110],2,"if");
lf[111]=C_h_intern(&lf[111],4,"lvar");
lf[112]=C_h_intern(&lf[112],4,"rvar");
lf[113]=C_h_intern(&lf[113],3,"min");
lf[114]=C_h_intern(&lf[114],7,"require");
lf[115]=C_h_intern(&lf[115],6,"srfi-1");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[117]=C_h_intern(&lf[117],14,"let-optionals*");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[119]=C_h_intern(&lf[119],14,"\004coreimmutable");
lf[120]=C_h_intern(&lf[120],9,"\003syserror");
lf[121]=C_h_intern(&lf[121],4,"tmp2");
lf[122]=C_h_intern(&lf[122],3,"tmp");
lf[123]=C_h_intern(&lf[123],5,"null\077");
lf[124]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[125]=C_h_intern(&lf[125],8,"optional");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[129]=C_h_intern(&lf[129],13,"let-optionals");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[131]=C_h_intern(&lf[131],14,"string->symbol");
lf[132]=C_h_intern(&lf[132],13,"string-append");
lf[133]=C_h_intern(&lf[133],14,"symbol->string");
lf[134]=C_h_intern(&lf[134],4,"let*");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[136]=C_h_intern(&lf[136],5,"%rest");
lf[137]=C_h_intern(&lf[137],4,"body");
lf[138]=C_h_intern(&lf[138],4,"cadr");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[140]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[141]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[143]=C_h_intern(&lf[143],6,"select");
lf[144]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[146]=C_h_intern(&lf[146],4,"eqv\077");
lf[147]=C_h_intern(&lf[147],2,"or");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[149]=C_h_intern(&lf[149],8,"and-let*");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[151]=C_h_intern(&lf[151],13,"define-inline");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[153]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[154]=C_h_intern(&lf[154],18,"\004coredefine-inline");
lf[155]=C_h_intern(&lf[155],9,"nth-value");
lf[156]=C_h_intern(&lf[156],8,"list-ref");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[158]=C_h_intern(&lf[158],13,"letrec-values");
lf[159]=C_h_intern(&lf[159],9,"\004coreset!");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[162]=C_h_intern(&lf[162],11,"let*-values");
lf[163]=C_h_intern(&lf[163],10,"let-values");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[166]=C_h_intern(&lf[166],13,"define-values");
lf[167]=C_h_intern(&lf[167],11,"set!-values");
lf[168]=C_h_intern(&lf[168],19,"\003sysregister-export");
lf[169]=C_h_intern(&lf[169],18,"\003syscurrent-module");
lf[170]=C_h_intern(&lf[170],12,"\003sysfor-each");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[172]=C_h_intern(&lf[172],14,"\004coreundefined");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[174]=C_h_intern(&lf[174],6,"unless");
lf[175]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[176]=C_h_intern(&lf[176],4,"when");
lf[177]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[178]=C_h_intern(&lf[178],12,"parameterize");
lf[179]=C_h_intern(&lf[179],16,"\003sysdynamic-wind");
lf[180]=C_h_intern(&lf[180],1,"t");
lf[181]=C_h_intern(&lf[181],8,"\003syslist");
lf[182]=C_h_intern(&lf[182],4,"swap");
lf[183]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[184]=C_h_intern(&lf[184],9,"eval-when");
lf[185]=C_h_intern(&lf[185],10,"\000compiling");
lf[186]=C_h_intern(&lf[186],19,"\004corecompiletimetoo");
lf[187]=C_h_intern(&lf[187],20,"\004corecompiletimeonly");
lf[188]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[191]=C_h_intern(&lf[191],4,"load");
lf[192]=C_h_intern(&lf[192],7,"compile");
lf[193]=C_h_intern(&lf[193],4,"eval");
lf[194]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[195]=C_h_intern(&lf[195],9,"fluid-let");
lf[196]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[197]=C_h_intern(&lf[197],6,"ensure");
lf[198]=C_h_intern(&lf[198],11,"\000type-error");
lf[199]=C_h_intern(&lf[199],15,"\003syssignal-hook");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[201]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[202]=C_h_intern(&lf[202],6,"assert");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[204]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[205]=C_h_intern(&lf[205],7,"include");
lf[206]=C_h_intern(&lf[206],27,"\003syscurrent-source-filename");
lf[207]=C_h_intern(&lf[207],4,"read");
lf[208]=C_h_intern(&lf[208],20,"with-input-from-file");
lf[209]=C_h_intern(&lf[209],5,"print");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[212]=C_h_intern(&lf[212],12,"load-verbose");
lf[213]=C_h_intern(&lf[213],28,"\003sysresolve-include-filename");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[215]=C_h_intern(&lf[215],12,"\004coredeclare");
lf[216]=C_h_intern(&lf[216],4,"time");
lf[217]=C_h_intern(&lf[217],15,"\003sysstart-timer");
lf[218]=C_h_intern(&lf[218],14,"\003sysstop-timer");
lf[219]=C_h_intern(&lf[219],17,"\003sysdisplay-times");
lf[220]=C_h_intern(&lf[220],7,"receive");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[222]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[223]=C_h_intern(&lf[223],13,"define-record");
lf[224]=C_h_intern(&lf[224],3,"val");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[230]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[231]=C_h_intern(&lf[231],21,"\003sysmacro-environment");
lf[232]=C_h_intern(&lf[232],11,"\003sysprovide");
lf[233]=C_h_intern(&lf[233],19,"chicken-more-macros");
lf[234]=C_h_intern(&lf[234],14,"chicken-syntax");
C_register_lf2(lf,235,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 35   ##sys#provide */
t3=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[233],lf[234]);}

/* k1438 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 41   ##sys#macro-environment */
t3=*((C_word*)lf[231]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1442 in k1438 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1447,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7351,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7353,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 45   ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7352 in k1442 in k1438 */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7353,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7357,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 47   ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[223],t2,lf[230]);}

/* k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7357,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 50   symbol->string */
t5=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7366,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],*((C_word*)lf[61]+1));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7372,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 52   r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[46]);}

/* k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 53   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[20]);}

/* k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 54   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7381,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 55   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 58   string-append */
t4=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[229],((C_word*)t0)[2]);}

/* k7789 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 58   string->symbol */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);}

/* k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7699,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t9,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7743,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 61   string-append */
t12=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],lf[228]);}

/* k7741 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 61   string->symbol */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7699,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[71],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[32],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[71],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[59],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t12);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7408,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word)li97),tmp=(C_word)a,a+=11,tmp));
t19=((C_word*)t17)[1];
f_7410(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_fcall f_7410(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7410,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* chicken-syntax.scm: 66   symbol->string */
t7=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7423,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7687,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 67   string-append */
t4=*((C_word*)lf[132]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],lf[226],t1,lf[227]);}

/* k7685 in k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 67   string->symbol */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7421 in k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7426,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7683,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 68   string-append */
t4=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[225],((C_word*)t0)[2]);}

/* k7681 in k7421 in k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 68   string->symbol */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7424 in k7421 in k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[124],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7426,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[224],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[71],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[32],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[71],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[62],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[63],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[224],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[71],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[65],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t10,t15);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t20);
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t21,a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=(C_word)C_a_i_cons(&a,2,lf[71],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[32],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[71],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[62],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[63],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[71],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[64],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36);
t38=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_7473(t40,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=(C_word)C_a_i_cons(&a,2,lf[71],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[32],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[71],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[62],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,lf[63],t29);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[71],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[64],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t30,t34);
t36=(C_word)C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_7473(t37,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t36));}}

/* k7471 in k7424 in k7421 in k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_fcall f_7473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7473,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7437,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 87   mapslots */
t11=((C_word*)((C_word*)t0)[2])[1];
f_7410(t11,t8,t9,t10);}

/* k7435 in k7471 in k7424 in k7421 in k7418 in mapslots in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7437,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7406 in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7402 in k7697 in k7781 in k7749 in k7379 in k7376 in k7373 in k7370 in k7364 in k7355 in a7352 in k1442 in k1438 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7404,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k7349 in k1442 in k1438 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 43   ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[223],C_SCHEME_END_OF_LIST,t1);}

/* k1445 in k1442 in k1438 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7210,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 92   ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7210,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7214,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 94   r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}

/* k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 95   r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7220,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 96   ##sys#check-syntax */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[220],((C_word*)t0)[4],lf[222]);}

/* k7218 in k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7220,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7256,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 100  ##sys#check-syntax */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[220],((C_word*)t0)[5],lf[221]);}}

/* k7254 in k7218 in k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7256,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7271,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=t5;
f_7271(t7,(C_word)C_i_nullp(t6));}
else{
t6=t5;
f_7271(t6,C_SCHEME_FALSE);}}

/* k7269 in k7254 in k7218 in k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_fcall f_7271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7271,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7286,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7325,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t6=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k7323 in k7269 in k7254 in k7218 in k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7325,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[86],t5));}

/* k7284 in k7269 in k7254 in k7218 in k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7286,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k7247 in k7218 in k7215 in k7212 in a7209 in k1445 in k1442 in k1438 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[181],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[86],t5));}

/* k7206 in k1445 in k1442 in k1438 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 89   ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7111,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 112  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7110 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7111,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7115,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 114  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[180]);}

/* k7113 in a7110 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 115  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[46]);}

/* k7116 in k7113 in a7110 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 116  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k7119 in k7116 in k7113 in a7110 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[217],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k7198 in k7119 in k7116 in k7113 in a7110 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7200,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[84],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[85],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=(C_word)C_a_i_cons(&a,2,lf[86],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t17);
t19=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t18));}

/* k7107 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 110  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[216],C_SCHEME_END_OF_LIST,t1);}

/* k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7093,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 127  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7092 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7093,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7101,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k7099 in a7092 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[215],t1));}

/* k7089 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 125  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[47],C_SCHEME_END_OF_LIST,t1);}

/* k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7002,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7004,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 133  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7004,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7008,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 135  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[205],t2,lf[214]);}

/* k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 136  ##sys#resolve-include-filename */
t4=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7014,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 137  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[46]);}

/* k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7080,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 138  load-verbose */
t4=*((C_word*)lf[212]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7078 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 138  print */
t2=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[210],((C_word*)t0)[2],lf[211]);}
else{
t2=((C_word*)t0)[3];
f_7017(2,t2,C_SCHEME_UNDEFINED);}}

/* k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[2],a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 140  with-input-from-file */
t5=*((C_word*)lf[208]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7036,a[2]=t3,a[3]=t5,a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7041,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7074,a[2]=t5,a[3]=t3,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[179]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a7073 in a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[206]+1));
t3=C_mutate((C_word*)lf[206]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a7040 in a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 143  read */
t3=*((C_word*)lf[207]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7047 in a7040 in a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7049,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7051,a[2]=t3,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7051(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop142 in k7047 in a7040 in a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_7051(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7051,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* chicken-syntax.scm: 146  reverse */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7068,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 143  read */
t5=*((C_word*)lf[207]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k7066 in doloop142 in k7047 in a7040 in a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7068,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_7051(t3,((C_word*)t0)[2],t1,t2);}

/* a7035 in a7029 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[206]+1));
t3=C_mutate((C_word*)lf[206]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k7026 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7022 in k7015 in k7012 in k7009 in k7006 in a7003 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7000 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_7002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 131  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[205],C_SCHEME_END_OF_LIST,t1);}

/* k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6893,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 150  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6892 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6893,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6897,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 152  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[202],t2,lf[204]);}

/* k6895 in a6892 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6897,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6906,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 155  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[110]);}

/* k6904 in k6895 in a6892 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6909,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 156  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[32]);}

/* k6907 in k6904 in k6895 in a6892 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,lf[203],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[32],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t2;
f_6912(t7,(C_word)C_a_i_cons(&a,2,lf[119],t6));}
else{
t4=t2;
f_6912(t4,(C_word)C_i_car(((C_word*)t0)[2]));}}

/* k6910 in k6907 in k6904 in k6895 in a6892 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_6912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6912,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[63],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[172],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t4,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_length(((C_word*)t0)[2]);
t9=(C_word)C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?(C_word)C_i_cdr(((C_word*)t0)[2]):C_SCHEME_END_OF_LIST);
/* ##sys#append */
t11=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t7,t10,C_SCHEME_END_OF_LIST);}

/* k6953 in k6910 in k6907 in k6904 in k6895 in a6892 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[120],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k6889 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 148  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[202],C_SCHEME_END_OF_LIST,t1);}

/* k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6754,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6756,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 172  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6756,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6760,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 174  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[197],t2,lf[201]);}

/* k6758 in a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6760,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6772,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 178  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[122]);}

/* k6770 in k6758 in a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 179  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k6773 in k6770 in k6758 in a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6778,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 180  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k6776 in k6773 in k6770 in k6758 in a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6778,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[63],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t8,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6829,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t11=t10;
f_6829(t11,((C_word*)t0)[2]);}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[200],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[32],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[119],t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[32],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=t10;
f_6829(t19,(C_word)C_a_i_cons(&a,2,t14,t18));}}

/* k6827 in k6776 in k6773 in k6770 in k6758 in a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_6829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6823 in k6776 in k6773 in k6770 in k6758 in a6755 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[198],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[199],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k6752 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 169  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[197],C_SCHEME_END_OF_LIST,t1);}

/* k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6498,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 193  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6498,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6502,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 195  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[195],t2,lf[196]);}

/* k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6502,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 198  ##sys#map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[68]+1),t2);}

/* k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6742,a[2]=((C_word*)t0)[2],a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 199  ##sys#map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6741 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6750,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 199  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6748 in a6741 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 199  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=((C_word*)t0)[2],a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 200  ##sys#map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6731 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 200  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6738 in a6731 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 200  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 201  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 202  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 203  ##sys#map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[138]+1),((C_word*)t0)[2]);}

/* k6728 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 203  map */
t2=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[181]+1),((C_word*)t0)[2],t1);}

/* k6688 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6694,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6698,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6702,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6708,a[2]=t7,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6708(t9,t4,t5);}

/* loop in k6688 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_6708(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6708,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm: 208  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k6720 in loop in k6688 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k6700 in k6688 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 204  map */
t2=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[181]+1),((C_word*)t0)[2],t1);}

/* k6696 in k6688 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6692 in k6688 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6674,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 211  map */
t5=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* a6673 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6674,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[159],t5));}

/* k6640 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6646,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6650,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6660,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 213  map */
t5=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6659 in k6640 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6660,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[159],t5));}

/* k6648 in k6640 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6650,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[172],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6644 in k6640 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6630,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6574,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6610,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 218  map */
t7=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6609 in k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6610,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[159],t5));}

/* k6576 in k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6582,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6586,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6596,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 220  map */
t5=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6595 in k6576 in k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6596,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[159],t5));}

/* k6584 in k6576 in k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[172],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6580 in k6576 in k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6572 in k6628 in k6636 in k6532 in k6521 in k6518 in k6515 in k6512 in k6509 in k6500 in a6497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[179],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k6494 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 191  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[195],C_SCHEME_END_OF_LIST,t1);}

/* k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6377,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 226  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6377,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6381,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 228  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[184],t2,lf[194]);}

/* k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 230  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[46]);}

/* k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6488,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 232  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[193]);}

/* k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 233  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[192]);}

/* k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 234  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[191]);}

/* k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6402,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_6439(t12,t8,((C_word*)t0)[2]);}

/* loop in k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6439,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 241  c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6460 in loop in k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6462,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
f_6452(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 242  c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6467 in k6460 in loop in k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6469,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[7];
f_6452(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6476,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 243  c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k6474 in k6467 in k6460 in loop in k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
f_6452(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm: 244  ##sys#error */
t3=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],lf[190],t2);}}

/* k6450 in loop in k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm: 245  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6439(t3,((C_word*)t0)[2],t2);}

/* k6400 in k6397 in k6394 in k6391 in k6486 in k6385 in k6379 in a6376 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[185],*((C_word*)lf[61]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[186],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[187],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[188]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[189]));}}

/* k6373 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 224  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[184],C_SCHEME_END_OF_LIST,t1);}

/* k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6173,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6175,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 257  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6175,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6179,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 259  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[178],t2,lf[183]);}

/* k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6188,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 262  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[182]);}

/* k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 263  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 264  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 265  ##sys#map */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[68]+1),((C_word*)t0)[2]);}

/* k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6200,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 266  ##sys#map */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[138]+1),((C_word*)t0)[2]);}

/* k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[2],a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 267  ##sys#map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6362 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6371,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 267  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6369 in a6362 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 267  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 268  ##sys#map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a6352 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6353,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6361,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 268  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6359 in a6352 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 268  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6217,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 269  map */
t4=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[181]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k6345 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6351,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 269  map */
t3=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[181]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6349 in k6345 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 269  ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6215 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6289,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[6],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 271  map */
t5=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6290 in k6215 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6291,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[180],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[159],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_cons(&a,2,t7,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t15));}

/* k6287 in k6215 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6283 in k6215 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t8=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6263 in k6283 in k6215 in k6204 in k6201 in k6198 in k6195 in k6192 in k6189 in k6186 in k6177 in a6174 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[179],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12));}

/* k6171 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 255  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[178],C_SCHEME_END_OF_LIST,t1);}

/* k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6128,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6130,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 282  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6129 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6130,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6134,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 284  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[176],t2,lf[177]);}

/* k6132 in a6129 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 285  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k6139 in k6132 in a6129 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6161,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 286  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[46]);}

/* k6159 in k6139 in k6132 in a6129 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6163 in k6159 in k6139 in k6132 in a6129 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k6126 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 280  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[176],C_SCHEME_END_OF_LIST,t1);}

/* k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6075,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6077,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 290  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6076 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6077,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6081,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 292  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[174],t2,lf[175]);}

/* k6079 in a6076 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 293  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k6086 in k6079 in a6076 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6088,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[172],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 295  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[46]);}

/* k6114 in k6086 in k6079 in a6076 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6118 in k6114 in k6086 in k6079 in a6076 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k6073 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 288  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[174],C_SCHEME_END_OF_LIST,t1);}

/* k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5932,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 299  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5932,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5936,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 301  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[167],t2,lf[173]);}

/* k5934 in a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5936,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 304  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[24]);}

/* k5943 in k5934 in a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[172],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[86],t10));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[159],t5));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[50]+1),((C_word*)t0)[4]);}}}

/* k6012 in k5943 in k5934 in a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6041,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6045,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6047,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 317  map */
t8=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a6046 in k6012 in k5943 in k5934 in a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6047,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[159],t5));}

/* k6043 in k6012 in k5943 in k5934 in a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6039 in k6012 in k5943 in k5934 in a5931 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[86],t5));}

/* k5928 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 297  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[167],C_SCHEME_END_OF_LIST,t1);}

/* k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5888,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5890,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 323  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5890,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5894,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 325  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[166],t2,lf[171]);}

/* k5892 in a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5914,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5913 in k5892 in a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5914,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5922,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 326  ##sys#current-module */
t4=*((C_word*)lf[169]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5920 in a5913 in k5892 in a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#register-export */
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5895 in k5892 in a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 327  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[167]);}

/* k5902 in k5895 in k5892 in a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5908,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5906 in k5902 in k5895 in k5892 in a5889 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5908,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5886 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 321  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[166],C_SCHEME_END_OF_LIST,t1);}

/* k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5502,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 331  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5502,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5506,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 333  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[163],t2,lf[165]);}

/* k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 336  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[55]);}

/* k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 337  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5520,a[2]=t3,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5551,a[2]=t5,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5593,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* map */
t9=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[68]+1),((C_word*)t0)[3]);}

/* k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5846(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5846(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5846,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5859,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* chicken-syntax.scm: 353  append */
t6=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* chicken-syntax.scm: 354  append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5520(t6,t5,t4,t3);}
else{
t6=t5;
f_5859(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k5857 in loop in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 356  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5846(t3,((C_word*)t0)[2],t2,t1);}

/* k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5832,a[2]=((C_word*)t0)[2],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5831 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5832,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5840,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5844,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 357  gensym */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5842 in a5831 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 357  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5838 in a5831 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5840,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5600,a[2]=t1,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5786,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5786(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5786,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-syntax.scm: 361  reverse */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5802,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5826,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 365  map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5551(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5819,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 364  lookup */
t7=((C_word*)t0)[2];
f_5600(3,t7,t6,t4);}}}

/* k5817 in loop in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5802(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5824 in loop in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5826,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5802(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5800 in loop in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 366  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5786(t3,((C_word*)t0)[2],t2,t1);}

/* k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5618,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5780,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5779 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5780,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word)li60),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5620(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5620(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5620,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5644,a[2]=((C_word*)t0)[5],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5774,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 372  cdar */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t7=t5;
f_5658(t7,C_SCHEME_FALSE);}}}

/* k5772 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5658(t2,(C_word)C_i_nullp(t1));}

/* k5656 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5658,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 373  caar */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=(C_word)C_i_cdr(((C_word*)t0)[8]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 378  fold */
t11=((C_word*)((C_word*)t0)[3])[1];
f_5620(t11,t7,t8,t9,t10);}}

/* k5738 in k5656 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[86],t6));}

/* k5695 in k5656 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_cdr(((C_word*)t0)[7]);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 374  fold */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5620(t10,t6,t7,t8,t9);}

/* k5675 in k5695 in k5656 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a5643 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5644,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5652,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 371  lookup */
t4=((C_word*)t0)[2];
f_5600(3,t4,t3,t2);}

/* k5650 in a5643 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5652,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k5636 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5640 in k5636 in fold in k5616 in k5609 in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5642,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5597 in k5594 in k5591 in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5600,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5551(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5551,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5574,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* chicken-syntax.scm: 346  proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm: 345  proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k5572 in map* in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5578,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm: 346  map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5551(t4,t2,((C_word*)t0)[2],t3);}

/* k5576 in k5572 in map* in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5520,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5541,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 342  append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k5539 in append* in k5516 in k5513 in k5504 in a5501 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5498 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 329  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[163],C_SCHEME_END_OF_LIST,t1);}

/* k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 382  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5430,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5434,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 384  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[162],t2,lf[164]);}

/* k5432 in a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5434,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5443,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 387  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[55]);}

/* k5441 in k5432 in a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 388  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[163]);}

/* k5444 in k5441 in k5432 in a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5451,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5451(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k5444 in k5441 in k5432 in a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5451,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5488,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
/* chicken-syntax.scm: 393  fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k5486 in fold in k5444 in k5441 in k5432 in a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k5467 in fold in k5444 in k5441 in k5432 in a5429 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5469,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5426 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 380  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[162],C_SCHEME_END_OF_LIST,t1);}

/* k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5262,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5264,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 397  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5264,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5268,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 399  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[158],t2,lf[161]);}

/* k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 402  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[55]);}

/* k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 403  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5420,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* a5419 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5420,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k5416 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[19]+1),t1);}

/* k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5286,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a5401 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5410,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 405  gensym */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5412 in a5401 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 405  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5408 in a5401 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5287,a[2]=t1,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5396,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5395 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5396,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[160]));}

/* k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a5319 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5320,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5348,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* map */
t9=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}

/* k5346 in a5319 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5356,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5358,a[2]=((C_word*)t0)[3],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5357 in k5346 in a5319 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5358,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5374,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 412  lookup */
t4=((C_word*)t0)[2];
f_5287(3,t4,t3,t2);}

/* k5372 in a5357 in k5346 in a5319 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[159],t3));}

/* k5354 in k5346 in a5319 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5350 in k5346 in a5319 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[86],t5));}

/* k5312 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5318,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5316 in k5312 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5308 in k5304 in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5310,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* lookup in k5284 in k5281 in k5278 in k5275 in k5266 in a5263 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5287,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k5260 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 395  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[158],C_SCHEME_END_OF_LIST,t1);}

/* k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5188,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5190,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 418  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5189 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5190,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5194,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 420  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[155],t2,lf[157]);}

/* k5192 in a5189 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 421  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[122]);}

/* k5195 in k5192 in a5189 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 422  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[156]);}

/* k5198 in k5195 in k5192 in a5189 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 423  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k5201 in k5198 in k5195 in k5192 in a5189 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5203,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=(C_word)C_a_i_cons(&a,2,t1,t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t5,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[86],t14));}

/* k5186 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 416  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[155],C_SCHEME_END_OF_LIST,t1);}

/* k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5089,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 430  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5089,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5093,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 432  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}

/* k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5095,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5176,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5180,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 446  quotify-proc */
t6=t2;
f_5095(t6,t4,t5,lf[151]);}

/* k5178 in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5174 in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5176,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[154],t1));}

/* quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 435  ##sys#check-syntax */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[153]);}

/* k5097 in quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5099,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_5108(t6,(C_word)C_i_cadr(((C_word*)t0)[5]));}}

/* k5154 in k5097 in quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5108(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5106 in k5097 in quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5108,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5111,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_5120(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5130,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(t1);
/* chicken-syntax.scm: 441  c */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k5128 in k5106 in k5097 in quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5120(t2,(C_word)C_i_not(t1));}

/* k5118 in k5106 in k5097 in quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_5120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-syntax.scm: 442  syntax-error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[151],lf[152],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5111(2,t2,C_SCHEME_UNDEFINED);}}

/* k5109 in k5106 in k5097 in quotify-proc in k5091 in a5088 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5111,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k5085 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 428  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[151],C_SCHEME_END_OF_LIST,t1);}

/* k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4926,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 450  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4926,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4930,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 452  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[149],t2,lf[150]);}

/* k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4939,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 455  r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[110]);}

/* k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 456  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4947,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li42),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4947(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4947,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 459  r */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[46]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 463  fold */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 467  fold */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 462  fold */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k4990 in fold in k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k5057 in fold in k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k5019 in fold in k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4959 in fold in k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4965,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4963 in k4959 in fold in k4940 in k4937 in k4928 in a4925 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4922 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 448  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[149],C_SCHEME_END_OF_LIST,t1);}

/* k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4757,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 471  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4757,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4761,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 473  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[143],t2,lf[148]);}

/* k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 476  r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[122]);}

/* k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 477  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 478  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[34]);}

/* k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 479  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[147]);}

/* k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 480  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[146]);}

/* k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 481  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[46]);}

/* k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 482  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4792,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4808,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li40),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_4810(t9,t5,((C_word*)t0)[2]);}

/* expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4810,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 488  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[143],t3,lf[144]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[145]);}}

/* k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 489  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4886,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
/* map */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a4887 in k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4888,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4884 in k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4880 in k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k4872 in k4880 in k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 494  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4810(t4,t3,((C_word*)t0)[2]);}

/* k4868 in k4872 in k4880 in k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k4837 in k4830 in k4824 in expand in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4806 in k4790 in k4783 in k4780 in k4777 in k4774 in k4771 in k4768 in k4759 in a4756 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4808,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k4753 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 469  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[143],C_SCHEME_END_OF_LIST,t1);}

/* k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4323,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 575  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4325,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4329,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 577  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[129],t2,lf[142]);}

/* k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4341,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 581  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[123]);}

/* k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 582  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 583  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 584  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[68]);}

/* k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 585  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[103]);}

/* k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 586  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4358,a[2]=t1,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word)li34),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 624  ##sys#check-syntax */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[129],((C_word*)t0)[2],lf[141]);}

/* k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 625  ##sys#check-syntax */
t3=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[129],((C_word*)t0)[8],lf[140]);}

/* k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* map */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[68]+1),((C_word*)t0)[2]);}

/* k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4651,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4743,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a4742 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4743,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 633  prefix-sym */
f_4651(t3,lf[139],t2);}

/* k4749 in a4742 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 633  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[138]+1),((C_word*)t0)[2]);}

/* k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 637  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[137]);}

/* k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 640  r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[136]);}

/* k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[12]);}

/* a4732 in k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4733,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4741,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 642  prefix-sym */
f_4651(t3,lf[135],t2);}

/* k4739 in a4732 in k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 642  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4676 in k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4681,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 645  make-default-procs */
t3=((C_word*)t0)[3];
f_4358(t3,t2,((C_word*)t0)[4],((C_word*)t0)[8],t1,((C_word*)t0)[2]);}

/* k4679 in k4676 in k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 647  make-if-tree */
t3=((C_word*)t0)[4];
f_4455(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 650  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}

/* k4689 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=(C_word)C_a_i_cons(&a,2,t3,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4651(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4651,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 628  symbol->string */
t6=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k4661 in prefix-sym in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 628  string-append */
t2=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4657 in prefix-sym in k4648 in k4645 in k4642 in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 628  string->symbol */
t2=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4455(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4455,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4461,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,a[10]=((C_word)li33),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_4461(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4461,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[63],t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 613  reverse */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[123],t6);
t8=(C_word)C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t7,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t5,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t8,tmp=(C_word)a,a+=15,tmp);
/* chicken-syntax.scm: 617  reverse */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}}

/* k4635 in recur in make-if-tree in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,a[6]=((C_word*)t0)[9],a[7]=t12,tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[5]);
t15=(C_word)C_i_cdr(((C_word*)t0)[4]);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[3]);
/* chicken-syntax.scm: 620  recur */
t17=((C_word*)((C_word*)t0)[2])[1];
f_4461(t17,t13,t14,t15,t16);}

/* k4579 in k4635 in recur in make-if-tree in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k4521 in recur in make-if-tree in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[130],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[32],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[120],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t2,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t12));}

/* make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4358(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4358,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4366,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 592  reverse */
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 593  reverse */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4374,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 594  reverse */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4372 in k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4374,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4376,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4376(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k4372 in k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_4376(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4376,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4429,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=((C_word*)t0)[3],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 599  reverse */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k4427 in recur in k4372 in k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4445,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 600  reverse */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4443 in k4427 in recur in k4372 in k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k4439 in k4427 in recur in k4372 in k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4397,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 601  recur */
t12=((C_word*)((C_word*)t0)[3])[1];
f_4376(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k4395 in k4439 in k4427 in recur in k4372 in k4368 in k4364 in make-default-procs in k4354 in k4351 in k4348 in k4345 in k4342 in k4339 in k4327 in a4324 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4321 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 573  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[129],C_SCHEME_END_OF_LIST,t1);}

/* k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4141,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 670  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4141,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4145,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 672  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[125],t2,lf[128]);}

/* k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 673  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[122]);}

/* k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 674  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[123]);}

/* k4149 in k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 675  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k4152 in k4149 in k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 676  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k4159 in k4152 in k4149 in k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_i_cddr(((C_word*)t0)[7]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
t10=t9;
f_4196(2,t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_4196(2,t11,(C_word)C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[127],t8);}}}

/* k4194 in k4159 in k4152 in k4149 in k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 679  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[103]);}

/* k4278 in k4194 in k4159 in k4152 in k4149 in k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[63],t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t7,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 680  r */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[68]);}

/* k4254 in k4278 in k4194 in k4159 in k4152 in k4149 in k4146 in k4143 in a4140 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[126],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[32],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[119],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[120],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t15);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t19);
t21=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t20));}

/* k4137 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 668  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[125],C_SCHEME_END_OF_LIST,t1);}

/* k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 703  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3839,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3843,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 705  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[117],t2,lf[124]);}

/* k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3855,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 709  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[55]);}

/* k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 710  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 711  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[123]);}

/* k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 712  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[68]);}

/* k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 713  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[103]);}

/* k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 714  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[122]);}

/* k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],a[10]=((C_word)li28),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_3891(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_3891(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3891,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[63],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t9=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 725  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[121]);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k4117 in loop in k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3979 in loop in k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[77],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=(C_word)C_a_i_cons(&a,2,t4,t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t2,t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t14);
t16=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[32],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t17,t20);
t22=(C_word)C_a_i_cons(&a,2,t15,t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t1,t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t27,tmp=(C_word)a,a+=5,tmp);
t29=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 732  loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_3891(t30,t28,t1,t29);}

/* k3998 in k3979 in loop in k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3955 in loop in k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[118],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[32],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[119],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[120],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t3,t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k3887 in k3868 in k3865 in k3862 in k3859 in k3856 in k3853 in k3841 in a3838 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3835 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 701  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 740  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3418,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3422,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 742  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[97],t2,lf[116]);}

/* k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[4],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3459,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 748  require */
t4=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[115]);}

/* k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3816,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* map */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a3817 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3818,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3828,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 750  ##sys#decompose-lambda-list */
t5=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a3827 in a3817 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3828,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k3814 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[113]+1),t1);}

/* k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 754  genvars */
t3=((C_word*)t0)[2];
f_3424(t3,t2,t1);}

/* k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 755  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[112]);}

/* k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 756  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[111]);}

/* k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 757  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 758  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 759  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 760  append */
t3=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[10]);}

/* k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[98],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li24),tmp=(C_word)a,a+=10,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm: 762  fold-right */
t10=*((C_word*)lf[108]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,lf[109],t9);}

/* a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3517,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=((C_word)li23),tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 764  ##sys#decompose-lambda-list */
t6=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3527,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t1,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm: 767  ##sys#check-syntax */
t7=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[97],t6,lf[106]);}

/* k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[14],((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_3545(t5,C_SCHEME_TRUE);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3765,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 772  r */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[104]);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3780,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 773  r */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[105]);}}

/* k3778 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3780,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_3545(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3763 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_3545(t4,(C_word)C_a_i_cons(&a,2,t1,t3));}

/* k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_3545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3545,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t1,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3569,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_3596(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_3596(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3596,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[6])){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t9=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[4]));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3752,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 782  gensym */
t6=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3750 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 782  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3662 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 783  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[68]);}

/* k3742 in k3662 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 784  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[103]);}

/* k3722 in k3742 in k3662 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm: 786  build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_3596(t11,t8,t10,((C_word*)t0)[7]);}
else{
/* chicken-syntax.scm: 787  build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_3596(t10,t8,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}}

/* k3681 in k3722 in k3742 in k3662 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k3651 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3619 in build in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k3571 in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 790  map */
t3=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[102]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3588 in k3571 in a3568 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a3558 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 775  take */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3565 in a3558 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 775  split-at! */
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3551 in k3543 in k3529 in a3526 in a3516 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3513 in k3489 in k3478 in k3475 in k3472 in k3469 in k3466 in k3463 in k3460 in k3457 in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* genvars in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_3424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3424,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3430(t6,t1,C_fix(0));}

/* loop in genvars in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_3430(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3430,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 747  gensym */
t5=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3454 in loop in genvars in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 747  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3442 in loop in genvars in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3448,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm: 747  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3430(t4,t2,t3);}

/* k3446 in k3442 in loop in genvars in k3420 in a3417 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3414 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 738  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[97],C_SCHEME_END_OF_LIST,t1);}

/* k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 800  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3320,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3324,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 802  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[92],t2,lf[96]);}

/* k3322 in a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 806  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[92],t5,lf[94]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3389,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm: 813  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[92],t5,lf[95]);}}

/* k3387 in k3322 in a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3402 in k3387 in k3322 in a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[93],t2));}

/* k3337 in k3322 in a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[32],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 811  r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[24]);}

/* k3360 in k3337 in k3322 in a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3372 in k3360 in k3337 in k3322 in a3319 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[93],t5));}

/* k3316 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 798  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[92],C_SCHEME_END_OF_LIST,t1);}

/* k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3126,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 821  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3126,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3130,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 823  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[78],t2,lf[91]);}

/* k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 824  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[90]);}

/* k3131 in k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 825  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[89]);}

/* k3134 in k3131 in k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 826  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k3137 in k3134 in k3131 in k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 827  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k3148 in k3137 in k3134 in k3131 in k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3150,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3178,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 829  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[87]);}

/* k3176 in k3148 in k3137 in k3134 in k3131 in k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3178,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t14=(C_word)C_i_cdddr(((C_word*)t0)[8]);
/* ##sys#append */
t15=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k3268 in k3176 in k3148 in k3137 in k3134 in k3131 in k3128 in a3125 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[84],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[85],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[24],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[86],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t19);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k3122 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 819  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[78],C_SCHEME_END_OF_LIST,t1);}

/* k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2797,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2799,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 840  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2799,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2803,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 842  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[73],t2,lf[83]);}

/* k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 843  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[82]);}

/* k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 844  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[81]);}

/* k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 845  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[80]);}

/* k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 846  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[55]);}

/* k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 847  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[79]);}

/* k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 848  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[34]);}

/* k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,a[8]=((C_word)li14),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 862  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[78]);}

/* k2994 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[74],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[32],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[59],t5);
t7=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[75],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t6,t10);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t15,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 865  r */
t17=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[77]);}

/* k3034 in k2994 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3044,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* map */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k3042 in k3034 in k2994 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[76],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k3038 in k3034 in k2994 in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2823,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[5],a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t13=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,t7,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[5],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t10=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2941,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* map */
t11=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t6);}}

/* a2946 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2947,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[32],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k2943 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2939 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k2931 in k2939 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_2899(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2912 in k2939 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_2899(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2897 in k2939 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2899,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2882 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_2850(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2863 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_2850(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2848 in parse-clause in k2819 in k2816 in k2813 in k2810 in k2807 in k2804 in k2801 in a2798 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2850,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k2795 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 838  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[73],C_SCHEME_END_OF_LIST,t1);}

/* k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 874  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2424,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2428,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 876  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[57],t2,lf[72]);}

/* k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddddr(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 881  r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[46]);}

/* k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 882  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 883  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[20]);}

/* k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm: 885  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[71]);}

/* k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 886  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[70]);}

/* k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 887  r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* map */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[68]+1),((C_word*)t0)[3]);}

/* k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}

/* a2781 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2782,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[66]));}

/* k2778 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[32],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[59],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t8,t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],t15);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t20,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],a[9]=((C_word)li10),tmp=(C_word)a,a+=10,tmp));
t22=((C_word*)t20)[1];
f_2493(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2493(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2493,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[60],*((C_word*)lf[61]+1));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[32],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[62],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[63],t14);
t16=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[64],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t15,t19);
t21=(C_word)C_a_i_cons(&a,2,t8,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[3],a[3]=t22,a[4]=t5,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t24=(C_word)C_i_caddr(t4);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t26=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t25);
t27=(C_word)C_a_i_cons(&a,2,t24,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t29=(C_word)C_a_i_cons(&a,2,lf[32],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t30);
t32=(C_word)C_a_i_cons(&a,2,lf[62],t31);
t33=(C_word)C_a_i_cons(&a,2,t32,C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[63],t33);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,t3,t35);
t37=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t36);
t38=(C_word)C_a_i_cons(&a,2,lf[65],t37);
t39=(C_word)C_a_i_cons(&a,2,t38,C_SCHEME_END_OF_LIST);
t40=(C_word)C_a_i_cons(&a,2,t34,t39);
t41=(C_word)C_a_i_cons(&a,2,t27,t40);
t42=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t41);
t43=t23;
f_2519(t43,(C_word)C_a_i_cons(&a,2,t42,C_SCHEME_END_OF_LIST));}
else{
t24=t23;
f_2519(t24,C_SCHEME_END_OF_LIST);}}}

/* k2517 in loop in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2519,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t3;
f_2559(t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}
else{
t5=t3;
f_2559(t5,((C_word*)t0)[3]);}}

/* k2557 in k2517 in loop in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2559,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2535,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* chicken-syntax.scm: 917  loop */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2493(t9,t6,t7,t8);}

/* k2533 in k2557 in k2517 in loop in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2529 in k2557 in k2517 in loop in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2489 in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2485 in k2774 in k2462 in k2459 in k2456 in k2453 in k2447 in k2444 in k2441 in k2426 in a2423 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2420 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 872  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[57],C_SCHEME_END_OF_LIST,t1);}

/* k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2234,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 924  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2236,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2240,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 926  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[54]);}

/* k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 927  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 928  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[52]);}

/* k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 929  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[46]);}

/* k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 930  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word)li8),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2261(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2261(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2261,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2271,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 933  reverse */
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 940  c */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2362 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 941  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm: 943  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2390 in k2362 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 943  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2261(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-syntax.scm: 944  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2261(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k2384 in k2362 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 941  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2365 in k2362 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm: 942  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2261(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 934  reverse */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2272 in k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2323,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 936  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k2344 in k2272 in k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k2321 in k2272 in k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 936  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2278 in k2272 in k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2291,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2289 in k2278 in k2272 in k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2309 in k2289 in k2278 in k2272 in k2269 in loop in k2250 in k2247 in k2244 in k2241 in k2238 in a2235 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2232 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 922  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[56],C_SCHEME_END_OF_LIST,t1);}

/* k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 948  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2017,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2021,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 950  r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[55]);}

/* k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 951  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 952  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[54]);}

/* k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 953  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 954  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[52]);}

/* k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word)li6),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2042(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_2042(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2042,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2052,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t6,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 957  reverse */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-syntax.scm: 967  c */
t9=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k2159 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2183,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 968  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm: 970  c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2187 in k2159 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm: 970  loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2042(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2222,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 972  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2220 in k2187 in k2159 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 972  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2193 in k2187 in k2159 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 973  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2042(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k2181 in k2159 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 968  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2162 in k2159 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm: 969  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2042(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 958  reverse */
t3=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2053 in k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2116,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 960  gensym */
t4=*((C_word*)lf[50]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2149 in k2053 in k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k2114 in k2053 in k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 960  r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2059 in k2053 in k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2084,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2082 in k2059 in k2053 in k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2102 in k2082 in k2059 in k2053 in k2050 in loop in k2031 in k2028 in k2025 in k2022 in k2019 in a2016 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k2013 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 946  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[49],C_SCHEME_END_OF_LIST,t1);}

/* k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1738,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 983  ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1740,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1744,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 985  ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[27],t2,lf[48]);}

/* k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 986  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[47]);}

/* k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 987  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[46]);}

/* k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 988  r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 989  r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[44]);}

/* k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 990  r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[43]);}

/* k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li4),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_1768(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2,C_SCHEME_FALSE);}

/* loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_1768(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1768,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1778,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,C_SCHEME_END_OF_LIST);}
else{
t7=t6;
f_1778(t7,lf[37]);}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[5],a[10]=t2,a[11]=((C_word*)t0)[6],a[12]=t4,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_1914(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_1914(t7,C_SCHEME_FALSE);}}}

/* k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_1914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1005 caar */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
/* chicken-syntax.scm: 1016 syntax-error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[27],lf[42],((C_word*)t0)[12]);}}

/* k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm: 1007 c */
t4=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t1);}

/* k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1008 cdar */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm: 1009 c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1010 cdar */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm: 1011 c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1974 in k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1012 cdar */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1014 caar */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k1996 in k1974 in k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1014 syntax-error */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[27],lf[40],t1);}

/* k1989 in k1974 in k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1012 append */
t2=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1981 in k1974 in k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1012 loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1768(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1968 in k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1964 in k1949 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1010 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1768(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1943 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1939 in k1924 in k1915 in k1912 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* chicken-syntax.scm: 1008 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1768(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1906 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
f_1778(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_fcall f_1778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1778,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm: 996  r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[36]);}

/* k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t3=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[28],t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 998  r */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[35]);}

/* k1879 in k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1875 in k1879 in k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm: 999  r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[34]);}

/* k1811 in k1875 in k1879 in k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[30]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[31],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t5,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1002 r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[33]);}

/* k1839 in k1811 in k1875 in k1879 in k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm: 1002 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[32]);}

/* k1851 in k1839 in k1811 in k1875 in k1879 in k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1853,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[30]+1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
/* ##sys#append */
t7=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1835 in k1851 in k1839 in k1811 in k1875 in k1879 in k1891 in k1783 in k1776 in loop in k1757 in k1754 in k1751 in k1748 in k1745 in k1742 in a1739 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k1736 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 981  ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[27],C_SCHEME_END_OF_LIST,t1);}

/* k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1025 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1635 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1636,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1640,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1027 ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[23],t2,lf[26]);}

/* k1638 in a1635 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm: 1029 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[25]);}

/* k1644 in k1638 in a1635 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1691,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm: 1032 r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[24]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1730,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k1728 in k1644 in k1638 in a1635 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k1689 in k1644 in k1638 in a1635 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1691,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k1701 in k1689 in k1644 in k1638 in a1635 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1703,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k1632 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1023 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[23],C_SCHEME_END_OF_LIST,t1);}

/* k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1042 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1598 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1599,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1603,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1044 ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[18],t2,lf[22]);}

/* k1601 in a1598 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1045 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k1608 in k1601 in a1598 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm: 1046 r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[20]);}

/* k1620 in k1608 in k1601 in a1598 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1624 in k1620 in k1608 in k1601 in a1598 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1595 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1040 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[18],C_SCHEME_END_OF_LIST,t1);}

/* k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1572,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1574,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1053 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1573 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1574,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1578,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm: 1055 ##sys#check-syntax */
t6=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[14],t2,lf[17]);}

/* k1576 in a1573 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[15],t4));}

/* k1570 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1051 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],C_SCHEME_END_OF_LIST,t1);}

/* k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1562,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1564,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1066 ##sys#er-transformer */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1563 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1564,5,t0,t1,t2,t3,t4);}
/* chicken-syntax.scm: 1068 syntax-error */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[10],lf[12]);}

/* k1560 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm: 1064 ##sys#extend-macro-environment */
t2=*((C_word*)lf[9]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[10],C_SCHEME_END_OF_LIST,t1);}

/* k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1071 ##sys#macro-subset */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm: 1074 register-feature! */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[2],lf[3],lf[4],lf[5],lf[6],lf[7]);}

/* k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1529 in k1526 in k1523 in k1520 in k1517 in k1514 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1484 in k1481 in k1478 in k1475 in k1472 in k1469 in k1466 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1442 in k1438 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[584] = {
{"toplevel:chicken_syntax_scm",(void*)C_chicken_syntax_toplevel},
{"f_1440:chicken_syntax_scm",(void*)f_1440},
{"f_1444:chicken_syntax_scm",(void*)f_1444},
{"f_7353:chicken_syntax_scm",(void*)f_7353},
{"f_7357:chicken_syntax_scm",(void*)f_7357},
{"f_7366:chicken_syntax_scm",(void*)f_7366},
{"f_7372:chicken_syntax_scm",(void*)f_7372},
{"f_7375:chicken_syntax_scm",(void*)f_7375},
{"f_7378:chicken_syntax_scm",(void*)f_7378},
{"f_7381:chicken_syntax_scm",(void*)f_7381},
{"f_7791:chicken_syntax_scm",(void*)f_7791},
{"f_7751:chicken_syntax_scm",(void*)f_7751},
{"f_7783:chicken_syntax_scm",(void*)f_7783},
{"f_7743:chicken_syntax_scm",(void*)f_7743},
{"f_7699:chicken_syntax_scm",(void*)f_7699},
{"f_7410:chicken_syntax_scm",(void*)f_7410},
{"f_7420:chicken_syntax_scm",(void*)f_7420},
{"f_7687:chicken_syntax_scm",(void*)f_7687},
{"f_7423:chicken_syntax_scm",(void*)f_7423},
{"f_7683:chicken_syntax_scm",(void*)f_7683},
{"f_7426:chicken_syntax_scm",(void*)f_7426},
{"f_7473:chicken_syntax_scm",(void*)f_7473},
{"f_7437:chicken_syntax_scm",(void*)f_7437},
{"f_7408:chicken_syntax_scm",(void*)f_7408},
{"f_7404:chicken_syntax_scm",(void*)f_7404},
{"f_7351:chicken_syntax_scm",(void*)f_7351},
{"f_1447:chicken_syntax_scm",(void*)f_1447},
{"f_7210:chicken_syntax_scm",(void*)f_7210},
{"f_7214:chicken_syntax_scm",(void*)f_7214},
{"f_7217:chicken_syntax_scm",(void*)f_7217},
{"f_7220:chicken_syntax_scm",(void*)f_7220},
{"f_7256:chicken_syntax_scm",(void*)f_7256},
{"f_7271:chicken_syntax_scm",(void*)f_7271},
{"f_7325:chicken_syntax_scm",(void*)f_7325},
{"f_7286:chicken_syntax_scm",(void*)f_7286},
{"f_7249:chicken_syntax_scm",(void*)f_7249},
{"f_7208:chicken_syntax_scm",(void*)f_7208},
{"f_1450:chicken_syntax_scm",(void*)f_1450},
{"f_7111:chicken_syntax_scm",(void*)f_7111},
{"f_7115:chicken_syntax_scm",(void*)f_7115},
{"f_7118:chicken_syntax_scm",(void*)f_7118},
{"f_7121:chicken_syntax_scm",(void*)f_7121},
{"f_7200:chicken_syntax_scm",(void*)f_7200},
{"f_7109:chicken_syntax_scm",(void*)f_7109},
{"f_1453:chicken_syntax_scm",(void*)f_1453},
{"f_7093:chicken_syntax_scm",(void*)f_7093},
{"f_7101:chicken_syntax_scm",(void*)f_7101},
{"f_7091:chicken_syntax_scm",(void*)f_7091},
{"f_1456:chicken_syntax_scm",(void*)f_1456},
{"f_7004:chicken_syntax_scm",(void*)f_7004},
{"f_7008:chicken_syntax_scm",(void*)f_7008},
{"f_7011:chicken_syntax_scm",(void*)f_7011},
{"f_7014:chicken_syntax_scm",(void*)f_7014},
{"f_7080:chicken_syntax_scm",(void*)f_7080},
{"f_7017:chicken_syntax_scm",(void*)f_7017},
{"f_7030:chicken_syntax_scm",(void*)f_7030},
{"f_7074:chicken_syntax_scm",(void*)f_7074},
{"f_7041:chicken_syntax_scm",(void*)f_7041},
{"f_7049:chicken_syntax_scm",(void*)f_7049},
{"f_7051:chicken_syntax_scm",(void*)f_7051},
{"f_7068:chicken_syntax_scm",(void*)f_7068},
{"f_7036:chicken_syntax_scm",(void*)f_7036},
{"f_7028:chicken_syntax_scm",(void*)f_7028},
{"f_7024:chicken_syntax_scm",(void*)f_7024},
{"f_7002:chicken_syntax_scm",(void*)f_7002},
{"f_1459:chicken_syntax_scm",(void*)f_1459},
{"f_6893:chicken_syntax_scm",(void*)f_6893},
{"f_6897:chicken_syntax_scm",(void*)f_6897},
{"f_6906:chicken_syntax_scm",(void*)f_6906},
{"f_6909:chicken_syntax_scm",(void*)f_6909},
{"f_6912:chicken_syntax_scm",(void*)f_6912},
{"f_6955:chicken_syntax_scm",(void*)f_6955},
{"f_6891:chicken_syntax_scm",(void*)f_6891},
{"f_1462:chicken_syntax_scm",(void*)f_1462},
{"f_6756:chicken_syntax_scm",(void*)f_6756},
{"f_6760:chicken_syntax_scm",(void*)f_6760},
{"f_6772:chicken_syntax_scm",(void*)f_6772},
{"f_6775:chicken_syntax_scm",(void*)f_6775},
{"f_6778:chicken_syntax_scm",(void*)f_6778},
{"f_6829:chicken_syntax_scm",(void*)f_6829},
{"f_6825:chicken_syntax_scm",(void*)f_6825},
{"f_6754:chicken_syntax_scm",(void*)f_6754},
{"f_1465:chicken_syntax_scm",(void*)f_1465},
{"f_6498:chicken_syntax_scm",(void*)f_6498},
{"f_6502:chicken_syntax_scm",(void*)f_6502},
{"f_6511:chicken_syntax_scm",(void*)f_6511},
{"f_6742:chicken_syntax_scm",(void*)f_6742},
{"f_6750:chicken_syntax_scm",(void*)f_6750},
{"f_6514:chicken_syntax_scm",(void*)f_6514},
{"f_6732:chicken_syntax_scm",(void*)f_6732},
{"f_6740:chicken_syntax_scm",(void*)f_6740},
{"f_6517:chicken_syntax_scm",(void*)f_6517},
{"f_6520:chicken_syntax_scm",(void*)f_6520},
{"f_6523:chicken_syntax_scm",(void*)f_6523},
{"f_6730:chicken_syntax_scm",(void*)f_6730},
{"f_6690:chicken_syntax_scm",(void*)f_6690},
{"f_6708:chicken_syntax_scm",(void*)f_6708},
{"f_6722:chicken_syntax_scm",(void*)f_6722},
{"f_6702:chicken_syntax_scm",(void*)f_6702},
{"f_6698:chicken_syntax_scm",(void*)f_6698},
{"f_6694:chicken_syntax_scm",(void*)f_6694},
{"f_6534:chicken_syntax_scm",(void*)f_6534},
{"f_6674:chicken_syntax_scm",(void*)f_6674},
{"f_6642:chicken_syntax_scm",(void*)f_6642},
{"f_6660:chicken_syntax_scm",(void*)f_6660},
{"f_6650:chicken_syntax_scm",(void*)f_6650},
{"f_6646:chicken_syntax_scm",(void*)f_6646},
{"f_6638:chicken_syntax_scm",(void*)f_6638},
{"f_6630:chicken_syntax_scm",(void*)f_6630},
{"f_6610:chicken_syntax_scm",(void*)f_6610},
{"f_6578:chicken_syntax_scm",(void*)f_6578},
{"f_6596:chicken_syntax_scm",(void*)f_6596},
{"f_6586:chicken_syntax_scm",(void*)f_6586},
{"f_6582:chicken_syntax_scm",(void*)f_6582},
{"f_6574:chicken_syntax_scm",(void*)f_6574},
{"f_6496:chicken_syntax_scm",(void*)f_6496},
{"f_1468:chicken_syntax_scm",(void*)f_1468},
{"f_6377:chicken_syntax_scm",(void*)f_6377},
{"f_6381:chicken_syntax_scm",(void*)f_6381},
{"f_6387:chicken_syntax_scm",(void*)f_6387},
{"f_6488:chicken_syntax_scm",(void*)f_6488},
{"f_6393:chicken_syntax_scm",(void*)f_6393},
{"f_6396:chicken_syntax_scm",(void*)f_6396},
{"f_6399:chicken_syntax_scm",(void*)f_6399},
{"f_6439:chicken_syntax_scm",(void*)f_6439},
{"f_6462:chicken_syntax_scm",(void*)f_6462},
{"f_6469:chicken_syntax_scm",(void*)f_6469},
{"f_6476:chicken_syntax_scm",(void*)f_6476},
{"f_6452:chicken_syntax_scm",(void*)f_6452},
{"f_6402:chicken_syntax_scm",(void*)f_6402},
{"f_6375:chicken_syntax_scm",(void*)f_6375},
{"f_1471:chicken_syntax_scm",(void*)f_1471},
{"f_6175:chicken_syntax_scm",(void*)f_6175},
{"f_6179:chicken_syntax_scm",(void*)f_6179},
{"f_6188:chicken_syntax_scm",(void*)f_6188},
{"f_6191:chicken_syntax_scm",(void*)f_6191},
{"f_6194:chicken_syntax_scm",(void*)f_6194},
{"f_6197:chicken_syntax_scm",(void*)f_6197},
{"f_6200:chicken_syntax_scm",(void*)f_6200},
{"f_6363:chicken_syntax_scm",(void*)f_6363},
{"f_6371:chicken_syntax_scm",(void*)f_6371},
{"f_6203:chicken_syntax_scm",(void*)f_6203},
{"f_6353:chicken_syntax_scm",(void*)f_6353},
{"f_6361:chicken_syntax_scm",(void*)f_6361},
{"f_6206:chicken_syntax_scm",(void*)f_6206},
{"f_6347:chicken_syntax_scm",(void*)f_6347},
{"f_6351:chicken_syntax_scm",(void*)f_6351},
{"f_6217:chicken_syntax_scm",(void*)f_6217},
{"f_6291:chicken_syntax_scm",(void*)f_6291},
{"f_6289:chicken_syntax_scm",(void*)f_6289},
{"f_6285:chicken_syntax_scm",(void*)f_6285},
{"f_6265:chicken_syntax_scm",(void*)f_6265},
{"f_6173:chicken_syntax_scm",(void*)f_6173},
{"f_1474:chicken_syntax_scm",(void*)f_1474},
{"f_6130:chicken_syntax_scm",(void*)f_6130},
{"f_6134:chicken_syntax_scm",(void*)f_6134},
{"f_6141:chicken_syntax_scm",(void*)f_6141},
{"f_6161:chicken_syntax_scm",(void*)f_6161},
{"f_6165:chicken_syntax_scm",(void*)f_6165},
{"f_6128:chicken_syntax_scm",(void*)f_6128},
{"f_1477:chicken_syntax_scm",(void*)f_1477},
{"f_6077:chicken_syntax_scm",(void*)f_6077},
{"f_6081:chicken_syntax_scm",(void*)f_6081},
{"f_6088:chicken_syntax_scm",(void*)f_6088},
{"f_6116:chicken_syntax_scm",(void*)f_6116},
{"f_6120:chicken_syntax_scm",(void*)f_6120},
{"f_6075:chicken_syntax_scm",(void*)f_6075},
{"f_1480:chicken_syntax_scm",(void*)f_1480},
{"f_5932:chicken_syntax_scm",(void*)f_5932},
{"f_5936:chicken_syntax_scm",(void*)f_5936},
{"f_5945:chicken_syntax_scm",(void*)f_5945},
{"f_6014:chicken_syntax_scm",(void*)f_6014},
{"f_6047:chicken_syntax_scm",(void*)f_6047},
{"f_6045:chicken_syntax_scm",(void*)f_6045},
{"f_6041:chicken_syntax_scm",(void*)f_6041},
{"f_5930:chicken_syntax_scm",(void*)f_5930},
{"f_1483:chicken_syntax_scm",(void*)f_1483},
{"f_5890:chicken_syntax_scm",(void*)f_5890},
{"f_5894:chicken_syntax_scm",(void*)f_5894},
{"f_5914:chicken_syntax_scm",(void*)f_5914},
{"f_5922:chicken_syntax_scm",(void*)f_5922},
{"f_5897:chicken_syntax_scm",(void*)f_5897},
{"f_5904:chicken_syntax_scm",(void*)f_5904},
{"f_5908:chicken_syntax_scm",(void*)f_5908},
{"f_5888:chicken_syntax_scm",(void*)f_5888},
{"f_1486:chicken_syntax_scm",(void*)f_1486},
{"f_5502:chicken_syntax_scm",(void*)f_5502},
{"f_5506:chicken_syntax_scm",(void*)f_5506},
{"f_5515:chicken_syntax_scm",(void*)f_5515},
{"f_5518:chicken_syntax_scm",(void*)f_5518},
{"f_5593:chicken_syntax_scm",(void*)f_5593},
{"f_5846:chicken_syntax_scm",(void*)f_5846},
{"f_5859:chicken_syntax_scm",(void*)f_5859},
{"f_5596:chicken_syntax_scm",(void*)f_5596},
{"f_5832:chicken_syntax_scm",(void*)f_5832},
{"f_5844:chicken_syntax_scm",(void*)f_5844},
{"f_5840:chicken_syntax_scm",(void*)f_5840},
{"f_5599:chicken_syntax_scm",(void*)f_5599},
{"f_5786:chicken_syntax_scm",(void*)f_5786},
{"f_5819:chicken_syntax_scm",(void*)f_5819},
{"f_5826:chicken_syntax_scm",(void*)f_5826},
{"f_5802:chicken_syntax_scm",(void*)f_5802},
{"f_5611:chicken_syntax_scm",(void*)f_5611},
{"f_5780:chicken_syntax_scm",(void*)f_5780},
{"f_5618:chicken_syntax_scm",(void*)f_5618},
{"f_5620:chicken_syntax_scm",(void*)f_5620},
{"f_5774:chicken_syntax_scm",(void*)f_5774},
{"f_5658:chicken_syntax_scm",(void*)f_5658},
{"f_5740:chicken_syntax_scm",(void*)f_5740},
{"f_5697:chicken_syntax_scm",(void*)f_5697},
{"f_5677:chicken_syntax_scm",(void*)f_5677},
{"f_5644:chicken_syntax_scm",(void*)f_5644},
{"f_5652:chicken_syntax_scm",(void*)f_5652},
{"f_5638:chicken_syntax_scm",(void*)f_5638},
{"f_5642:chicken_syntax_scm",(void*)f_5642},
{"f_5600:chicken_syntax_scm",(void*)f_5600},
{"f_5551:chicken_syntax_scm",(void*)f_5551},
{"f_5574:chicken_syntax_scm",(void*)f_5574},
{"f_5578:chicken_syntax_scm",(void*)f_5578},
{"f_5520:chicken_syntax_scm",(void*)f_5520},
{"f_5541:chicken_syntax_scm",(void*)f_5541},
{"f_5500:chicken_syntax_scm",(void*)f_5500},
{"f_1489:chicken_syntax_scm",(void*)f_1489},
{"f_5430:chicken_syntax_scm",(void*)f_5430},
{"f_5434:chicken_syntax_scm",(void*)f_5434},
{"f_5443:chicken_syntax_scm",(void*)f_5443},
{"f_5446:chicken_syntax_scm",(void*)f_5446},
{"f_5451:chicken_syntax_scm",(void*)f_5451},
{"f_5488:chicken_syntax_scm",(void*)f_5488},
{"f_5469:chicken_syntax_scm",(void*)f_5469},
{"f_5428:chicken_syntax_scm",(void*)f_5428},
{"f_1492:chicken_syntax_scm",(void*)f_1492},
{"f_5264:chicken_syntax_scm",(void*)f_5264},
{"f_5268:chicken_syntax_scm",(void*)f_5268},
{"f_5277:chicken_syntax_scm",(void*)f_5277},
{"f_5280:chicken_syntax_scm",(void*)f_5280},
{"f_5420:chicken_syntax_scm",(void*)f_5420},
{"f_5418:chicken_syntax_scm",(void*)f_5418},
{"f_5283:chicken_syntax_scm",(void*)f_5283},
{"f_5402:chicken_syntax_scm",(void*)f_5402},
{"f_5414:chicken_syntax_scm",(void*)f_5414},
{"f_5410:chicken_syntax_scm",(void*)f_5410},
{"f_5286:chicken_syntax_scm",(void*)f_5286},
{"f_5396:chicken_syntax_scm",(void*)f_5396},
{"f_5306:chicken_syntax_scm",(void*)f_5306},
{"f_5320:chicken_syntax_scm",(void*)f_5320},
{"f_5348:chicken_syntax_scm",(void*)f_5348},
{"f_5358:chicken_syntax_scm",(void*)f_5358},
{"f_5374:chicken_syntax_scm",(void*)f_5374},
{"f_5356:chicken_syntax_scm",(void*)f_5356},
{"f_5352:chicken_syntax_scm",(void*)f_5352},
{"f_5314:chicken_syntax_scm",(void*)f_5314},
{"f_5318:chicken_syntax_scm",(void*)f_5318},
{"f_5310:chicken_syntax_scm",(void*)f_5310},
{"f_5287:chicken_syntax_scm",(void*)f_5287},
{"f_5262:chicken_syntax_scm",(void*)f_5262},
{"f_1495:chicken_syntax_scm",(void*)f_1495},
{"f_5190:chicken_syntax_scm",(void*)f_5190},
{"f_5194:chicken_syntax_scm",(void*)f_5194},
{"f_5197:chicken_syntax_scm",(void*)f_5197},
{"f_5200:chicken_syntax_scm",(void*)f_5200},
{"f_5203:chicken_syntax_scm",(void*)f_5203},
{"f_5188:chicken_syntax_scm",(void*)f_5188},
{"f_1498:chicken_syntax_scm",(void*)f_1498},
{"f_5089:chicken_syntax_scm",(void*)f_5089},
{"f_5093:chicken_syntax_scm",(void*)f_5093},
{"f_5180:chicken_syntax_scm",(void*)f_5180},
{"f_5176:chicken_syntax_scm",(void*)f_5176},
{"f_5095:chicken_syntax_scm",(void*)f_5095},
{"f_5099:chicken_syntax_scm",(void*)f_5099},
{"f_5156:chicken_syntax_scm",(void*)f_5156},
{"f_5108:chicken_syntax_scm",(void*)f_5108},
{"f_5130:chicken_syntax_scm",(void*)f_5130},
{"f_5120:chicken_syntax_scm",(void*)f_5120},
{"f_5111:chicken_syntax_scm",(void*)f_5111},
{"f_5087:chicken_syntax_scm",(void*)f_5087},
{"f_1501:chicken_syntax_scm",(void*)f_1501},
{"f_4926:chicken_syntax_scm",(void*)f_4926},
{"f_4930:chicken_syntax_scm",(void*)f_4930},
{"f_4939:chicken_syntax_scm",(void*)f_4939},
{"f_4942:chicken_syntax_scm",(void*)f_4942},
{"f_4947:chicken_syntax_scm",(void*)f_4947},
{"f_4992:chicken_syntax_scm",(void*)f_4992},
{"f_5059:chicken_syntax_scm",(void*)f_5059},
{"f_5021:chicken_syntax_scm",(void*)f_5021},
{"f_4961:chicken_syntax_scm",(void*)f_4961},
{"f_4965:chicken_syntax_scm",(void*)f_4965},
{"f_4924:chicken_syntax_scm",(void*)f_4924},
{"f_1504:chicken_syntax_scm",(void*)f_1504},
{"f_4757:chicken_syntax_scm",(void*)f_4757},
{"f_4761:chicken_syntax_scm",(void*)f_4761},
{"f_4770:chicken_syntax_scm",(void*)f_4770},
{"f_4773:chicken_syntax_scm",(void*)f_4773},
{"f_4776:chicken_syntax_scm",(void*)f_4776},
{"f_4779:chicken_syntax_scm",(void*)f_4779},
{"f_4782:chicken_syntax_scm",(void*)f_4782},
{"f_4785:chicken_syntax_scm",(void*)f_4785},
{"f_4792:chicken_syntax_scm",(void*)f_4792},
{"f_4810:chicken_syntax_scm",(void*)f_4810},
{"f_4826:chicken_syntax_scm",(void*)f_4826},
{"f_4832:chicken_syntax_scm",(void*)f_4832},
{"f_4888:chicken_syntax_scm",(void*)f_4888},
{"f_4886:chicken_syntax_scm",(void*)f_4886},
{"f_4882:chicken_syntax_scm",(void*)f_4882},
{"f_4874:chicken_syntax_scm",(void*)f_4874},
{"f_4870:chicken_syntax_scm",(void*)f_4870},
{"f_4839:chicken_syntax_scm",(void*)f_4839},
{"f_4808:chicken_syntax_scm",(void*)f_4808},
{"f_4755:chicken_syntax_scm",(void*)f_4755},
{"f_1507:chicken_syntax_scm",(void*)f_1507},
{"f_4325:chicken_syntax_scm",(void*)f_4325},
{"f_4329:chicken_syntax_scm",(void*)f_4329},
{"f_4341:chicken_syntax_scm",(void*)f_4341},
{"f_4344:chicken_syntax_scm",(void*)f_4344},
{"f_4347:chicken_syntax_scm",(void*)f_4347},
{"f_4350:chicken_syntax_scm",(void*)f_4350},
{"f_4353:chicken_syntax_scm",(void*)f_4353},
{"f_4356:chicken_syntax_scm",(void*)f_4356},
{"f_4644:chicken_syntax_scm",(void*)f_4644},
{"f_4647:chicken_syntax_scm",(void*)f_4647},
{"f_4650:chicken_syntax_scm",(void*)f_4650},
{"f_4743:chicken_syntax_scm",(void*)f_4743},
{"f_4751:chicken_syntax_scm",(void*)f_4751},
{"f_4666:chicken_syntax_scm",(void*)f_4666},
{"f_4669:chicken_syntax_scm",(void*)f_4669},
{"f_4672:chicken_syntax_scm",(void*)f_4672},
{"f_4675:chicken_syntax_scm",(void*)f_4675},
{"f_4733:chicken_syntax_scm",(void*)f_4733},
{"f_4741:chicken_syntax_scm",(void*)f_4741},
{"f_4678:chicken_syntax_scm",(void*)f_4678},
{"f_4681:chicken_syntax_scm",(void*)f_4681},
{"f_4684:chicken_syntax_scm",(void*)f_4684},
{"f_4691:chicken_syntax_scm",(void*)f_4691},
{"f_4651:chicken_syntax_scm",(void*)f_4651},
{"f_4663:chicken_syntax_scm",(void*)f_4663},
{"f_4659:chicken_syntax_scm",(void*)f_4659},
{"f_4455:chicken_syntax_scm",(void*)f_4455},
{"f_4461:chicken_syntax_scm",(void*)f_4461},
{"f_4637:chicken_syntax_scm",(void*)f_4637},
{"f_4581:chicken_syntax_scm",(void*)f_4581},
{"f_4523:chicken_syntax_scm",(void*)f_4523},
{"f_4358:chicken_syntax_scm",(void*)f_4358},
{"f_4366:chicken_syntax_scm",(void*)f_4366},
{"f_4370:chicken_syntax_scm",(void*)f_4370},
{"f_4374:chicken_syntax_scm",(void*)f_4374},
{"f_4376:chicken_syntax_scm",(void*)f_4376},
{"f_4429:chicken_syntax_scm",(void*)f_4429},
{"f_4445:chicken_syntax_scm",(void*)f_4445},
{"f_4441:chicken_syntax_scm",(void*)f_4441},
{"f_4397:chicken_syntax_scm",(void*)f_4397},
{"f_4323:chicken_syntax_scm",(void*)f_4323},
{"f_1510:chicken_syntax_scm",(void*)f_1510},
{"f_4141:chicken_syntax_scm",(void*)f_4141},
{"f_4145:chicken_syntax_scm",(void*)f_4145},
{"f_4148:chicken_syntax_scm",(void*)f_4148},
{"f_4151:chicken_syntax_scm",(void*)f_4151},
{"f_4154:chicken_syntax_scm",(void*)f_4154},
{"f_4161:chicken_syntax_scm",(void*)f_4161},
{"f_4196:chicken_syntax_scm",(void*)f_4196},
{"f_4280:chicken_syntax_scm",(void*)f_4280},
{"f_4256:chicken_syntax_scm",(void*)f_4256},
{"f_4139:chicken_syntax_scm",(void*)f_4139},
{"f_1513:chicken_syntax_scm",(void*)f_1513},
{"f_3839:chicken_syntax_scm",(void*)f_3839},
{"f_3843:chicken_syntax_scm",(void*)f_3843},
{"f_3855:chicken_syntax_scm",(void*)f_3855},
{"f_3858:chicken_syntax_scm",(void*)f_3858},
{"f_3861:chicken_syntax_scm",(void*)f_3861},
{"f_3864:chicken_syntax_scm",(void*)f_3864},
{"f_3867:chicken_syntax_scm",(void*)f_3867},
{"f_3870:chicken_syntax_scm",(void*)f_3870},
{"f_3891:chicken_syntax_scm",(void*)f_3891},
{"f_4119:chicken_syntax_scm",(void*)f_4119},
{"f_3981:chicken_syntax_scm",(void*)f_3981},
{"f_4000:chicken_syntax_scm",(void*)f_4000},
{"f_3957:chicken_syntax_scm",(void*)f_3957},
{"f_3889:chicken_syntax_scm",(void*)f_3889},
{"f_3837:chicken_syntax_scm",(void*)f_3837},
{"f_1516:chicken_syntax_scm",(void*)f_1516},
{"f_3418:chicken_syntax_scm",(void*)f_3418},
{"f_3422:chicken_syntax_scm",(void*)f_3422},
{"f_3459:chicken_syntax_scm",(void*)f_3459},
{"f_3818:chicken_syntax_scm",(void*)f_3818},
{"f_3828:chicken_syntax_scm",(void*)f_3828},
{"f_3816:chicken_syntax_scm",(void*)f_3816},
{"f_3462:chicken_syntax_scm",(void*)f_3462},
{"f_3465:chicken_syntax_scm",(void*)f_3465},
{"f_3468:chicken_syntax_scm",(void*)f_3468},
{"f_3471:chicken_syntax_scm",(void*)f_3471},
{"f_3474:chicken_syntax_scm",(void*)f_3474},
{"f_3477:chicken_syntax_scm",(void*)f_3477},
{"f_3480:chicken_syntax_scm",(void*)f_3480},
{"f_3491:chicken_syntax_scm",(void*)f_3491},
{"f_3517:chicken_syntax_scm",(void*)f_3517},
{"f_3527:chicken_syntax_scm",(void*)f_3527},
{"f_3531:chicken_syntax_scm",(void*)f_3531},
{"f_3780:chicken_syntax_scm",(void*)f_3780},
{"f_3765:chicken_syntax_scm",(void*)f_3765},
{"f_3545:chicken_syntax_scm",(void*)f_3545},
{"f_3569:chicken_syntax_scm",(void*)f_3569},
{"f_3596:chicken_syntax_scm",(void*)f_3596},
{"f_3752:chicken_syntax_scm",(void*)f_3752},
{"f_3664:chicken_syntax_scm",(void*)f_3664},
{"f_3744:chicken_syntax_scm",(void*)f_3744},
{"f_3724:chicken_syntax_scm",(void*)f_3724},
{"f_3683:chicken_syntax_scm",(void*)f_3683},
{"f_3653:chicken_syntax_scm",(void*)f_3653},
{"f_3621:chicken_syntax_scm",(void*)f_3621},
{"f_3573:chicken_syntax_scm",(void*)f_3573},
{"f_3590:chicken_syntax_scm",(void*)f_3590},
{"f_3559:chicken_syntax_scm",(void*)f_3559},
{"f_3567:chicken_syntax_scm",(void*)f_3567},
{"f_3553:chicken_syntax_scm",(void*)f_3553},
{"f_3515:chicken_syntax_scm",(void*)f_3515},
{"f_3424:chicken_syntax_scm",(void*)f_3424},
{"f_3430:chicken_syntax_scm",(void*)f_3430},
{"f_3456:chicken_syntax_scm",(void*)f_3456},
{"f_3444:chicken_syntax_scm",(void*)f_3444},
{"f_3448:chicken_syntax_scm",(void*)f_3448},
{"f_3416:chicken_syntax_scm",(void*)f_3416},
{"f_1519:chicken_syntax_scm",(void*)f_1519},
{"f_3320:chicken_syntax_scm",(void*)f_3320},
{"f_3324:chicken_syntax_scm",(void*)f_3324},
{"f_3389:chicken_syntax_scm",(void*)f_3389},
{"f_3404:chicken_syntax_scm",(void*)f_3404},
{"f_3339:chicken_syntax_scm",(void*)f_3339},
{"f_3362:chicken_syntax_scm",(void*)f_3362},
{"f_3374:chicken_syntax_scm",(void*)f_3374},
{"f_3318:chicken_syntax_scm",(void*)f_3318},
{"f_1522:chicken_syntax_scm",(void*)f_1522},
{"f_3126:chicken_syntax_scm",(void*)f_3126},
{"f_3130:chicken_syntax_scm",(void*)f_3130},
{"f_3133:chicken_syntax_scm",(void*)f_3133},
{"f_3136:chicken_syntax_scm",(void*)f_3136},
{"f_3139:chicken_syntax_scm",(void*)f_3139},
{"f_3150:chicken_syntax_scm",(void*)f_3150},
{"f_3178:chicken_syntax_scm",(void*)f_3178},
{"f_3270:chicken_syntax_scm",(void*)f_3270},
{"f_3124:chicken_syntax_scm",(void*)f_3124},
{"f_1525:chicken_syntax_scm",(void*)f_1525},
{"f_2799:chicken_syntax_scm",(void*)f_2799},
{"f_2803:chicken_syntax_scm",(void*)f_2803},
{"f_2806:chicken_syntax_scm",(void*)f_2806},
{"f_2809:chicken_syntax_scm",(void*)f_2809},
{"f_2812:chicken_syntax_scm",(void*)f_2812},
{"f_2815:chicken_syntax_scm",(void*)f_2815},
{"f_2818:chicken_syntax_scm",(void*)f_2818},
{"f_2821:chicken_syntax_scm",(void*)f_2821},
{"f_2996:chicken_syntax_scm",(void*)f_2996},
{"f_3036:chicken_syntax_scm",(void*)f_3036},
{"f_3044:chicken_syntax_scm",(void*)f_3044},
{"f_3040:chicken_syntax_scm",(void*)f_3040},
{"f_2823:chicken_syntax_scm",(void*)f_2823},
{"f_2947:chicken_syntax_scm",(void*)f_2947},
{"f_2945:chicken_syntax_scm",(void*)f_2945},
{"f_2941:chicken_syntax_scm",(void*)f_2941},
{"f_2933:chicken_syntax_scm",(void*)f_2933},
{"f_2914:chicken_syntax_scm",(void*)f_2914},
{"f_2899:chicken_syntax_scm",(void*)f_2899},
{"f_2884:chicken_syntax_scm",(void*)f_2884},
{"f_2865:chicken_syntax_scm",(void*)f_2865},
{"f_2850:chicken_syntax_scm",(void*)f_2850},
{"f_2797:chicken_syntax_scm",(void*)f_2797},
{"f_1528:chicken_syntax_scm",(void*)f_1528},
{"f_2424:chicken_syntax_scm",(void*)f_2424},
{"f_2428:chicken_syntax_scm",(void*)f_2428},
{"f_2443:chicken_syntax_scm",(void*)f_2443},
{"f_2446:chicken_syntax_scm",(void*)f_2446},
{"f_2449:chicken_syntax_scm",(void*)f_2449},
{"f_2455:chicken_syntax_scm",(void*)f_2455},
{"f_2458:chicken_syntax_scm",(void*)f_2458},
{"f_2461:chicken_syntax_scm",(void*)f_2461},
{"f_2464:chicken_syntax_scm",(void*)f_2464},
{"f_2782:chicken_syntax_scm",(void*)f_2782},
{"f_2780:chicken_syntax_scm",(void*)f_2780},
{"f_2776:chicken_syntax_scm",(void*)f_2776},
{"f_2493:chicken_syntax_scm",(void*)f_2493},
{"f_2519:chicken_syntax_scm",(void*)f_2519},
{"f_2559:chicken_syntax_scm",(void*)f_2559},
{"f_2535:chicken_syntax_scm",(void*)f_2535},
{"f_2531:chicken_syntax_scm",(void*)f_2531},
{"f_2491:chicken_syntax_scm",(void*)f_2491},
{"f_2487:chicken_syntax_scm",(void*)f_2487},
{"f_2422:chicken_syntax_scm",(void*)f_2422},
{"f_1531:chicken_syntax_scm",(void*)f_1531},
{"f_2236:chicken_syntax_scm",(void*)f_2236},
{"f_2240:chicken_syntax_scm",(void*)f_2240},
{"f_2243:chicken_syntax_scm",(void*)f_2243},
{"f_2246:chicken_syntax_scm",(void*)f_2246},
{"f_2249:chicken_syntax_scm",(void*)f_2249},
{"f_2252:chicken_syntax_scm",(void*)f_2252},
{"f_2261:chicken_syntax_scm",(void*)f_2261},
{"f_2364:chicken_syntax_scm",(void*)f_2364},
{"f_2392:chicken_syntax_scm",(void*)f_2392},
{"f_2386:chicken_syntax_scm",(void*)f_2386},
{"f_2367:chicken_syntax_scm",(void*)f_2367},
{"f_2271:chicken_syntax_scm",(void*)f_2271},
{"f_2274:chicken_syntax_scm",(void*)f_2274},
{"f_2346:chicken_syntax_scm",(void*)f_2346},
{"f_2323:chicken_syntax_scm",(void*)f_2323},
{"f_2280:chicken_syntax_scm",(void*)f_2280},
{"f_2291:chicken_syntax_scm",(void*)f_2291},
{"f_2311:chicken_syntax_scm",(void*)f_2311},
{"f_2234:chicken_syntax_scm",(void*)f_2234},
{"f_1534:chicken_syntax_scm",(void*)f_1534},
{"f_2017:chicken_syntax_scm",(void*)f_2017},
{"f_2021:chicken_syntax_scm",(void*)f_2021},
{"f_2024:chicken_syntax_scm",(void*)f_2024},
{"f_2027:chicken_syntax_scm",(void*)f_2027},
{"f_2030:chicken_syntax_scm",(void*)f_2030},
{"f_2033:chicken_syntax_scm",(void*)f_2033},
{"f_2042:chicken_syntax_scm",(void*)f_2042},
{"f_2161:chicken_syntax_scm",(void*)f_2161},
{"f_2189:chicken_syntax_scm",(void*)f_2189},
{"f_2222:chicken_syntax_scm",(void*)f_2222},
{"f_2195:chicken_syntax_scm",(void*)f_2195},
{"f_2183:chicken_syntax_scm",(void*)f_2183},
{"f_2164:chicken_syntax_scm",(void*)f_2164},
{"f_2052:chicken_syntax_scm",(void*)f_2052},
{"f_2055:chicken_syntax_scm",(void*)f_2055},
{"f_2151:chicken_syntax_scm",(void*)f_2151},
{"f_2116:chicken_syntax_scm",(void*)f_2116},
{"f_2061:chicken_syntax_scm",(void*)f_2061},
{"f_2084:chicken_syntax_scm",(void*)f_2084},
{"f_2104:chicken_syntax_scm",(void*)f_2104},
{"f_2015:chicken_syntax_scm",(void*)f_2015},
{"f_1537:chicken_syntax_scm",(void*)f_1537},
{"f_1740:chicken_syntax_scm",(void*)f_1740},
{"f_1744:chicken_syntax_scm",(void*)f_1744},
{"f_1747:chicken_syntax_scm",(void*)f_1747},
{"f_1750:chicken_syntax_scm",(void*)f_1750},
{"f_1753:chicken_syntax_scm",(void*)f_1753},
{"f_1756:chicken_syntax_scm",(void*)f_1756},
{"f_1759:chicken_syntax_scm",(void*)f_1759},
{"f_1768:chicken_syntax_scm",(void*)f_1768},
{"f_1914:chicken_syntax_scm",(void*)f_1914},
{"f_1917:chicken_syntax_scm",(void*)f_1917},
{"f_1926:chicken_syntax_scm",(void*)f_1926},
{"f_1951:chicken_syntax_scm",(void*)f_1951},
{"f_1976:chicken_syntax_scm",(void*)f_1976},
{"f_1998:chicken_syntax_scm",(void*)f_1998},
{"f_1991:chicken_syntax_scm",(void*)f_1991},
{"f_1983:chicken_syntax_scm",(void*)f_1983},
{"f_1970:chicken_syntax_scm",(void*)f_1970},
{"f_1966:chicken_syntax_scm",(void*)f_1966},
{"f_1945:chicken_syntax_scm",(void*)f_1945},
{"f_1941:chicken_syntax_scm",(void*)f_1941},
{"f_1908:chicken_syntax_scm",(void*)f_1908},
{"f_1778:chicken_syntax_scm",(void*)f_1778},
{"f_1785:chicken_syntax_scm",(void*)f_1785},
{"f_1893:chicken_syntax_scm",(void*)f_1893},
{"f_1881:chicken_syntax_scm",(void*)f_1881},
{"f_1877:chicken_syntax_scm",(void*)f_1877},
{"f_1813:chicken_syntax_scm",(void*)f_1813},
{"f_1841:chicken_syntax_scm",(void*)f_1841},
{"f_1853:chicken_syntax_scm",(void*)f_1853},
{"f_1837:chicken_syntax_scm",(void*)f_1837},
{"f_1738:chicken_syntax_scm",(void*)f_1738},
{"f_1540:chicken_syntax_scm",(void*)f_1540},
{"f_1636:chicken_syntax_scm",(void*)f_1636},
{"f_1640:chicken_syntax_scm",(void*)f_1640},
{"f_1646:chicken_syntax_scm",(void*)f_1646},
{"f_1730:chicken_syntax_scm",(void*)f_1730},
{"f_1691:chicken_syntax_scm",(void*)f_1691},
{"f_1703:chicken_syntax_scm",(void*)f_1703},
{"f_1634:chicken_syntax_scm",(void*)f_1634},
{"f_1543:chicken_syntax_scm",(void*)f_1543},
{"f_1599:chicken_syntax_scm",(void*)f_1599},
{"f_1603:chicken_syntax_scm",(void*)f_1603},
{"f_1610:chicken_syntax_scm",(void*)f_1610},
{"f_1622:chicken_syntax_scm",(void*)f_1622},
{"f_1626:chicken_syntax_scm",(void*)f_1626},
{"f_1597:chicken_syntax_scm",(void*)f_1597},
{"f_1546:chicken_syntax_scm",(void*)f_1546},
{"f_1574:chicken_syntax_scm",(void*)f_1574},
{"f_1578:chicken_syntax_scm",(void*)f_1578},
{"f_1572:chicken_syntax_scm",(void*)f_1572},
{"f_1549:chicken_syntax_scm",(void*)f_1549},
{"f_1564:chicken_syntax_scm",(void*)f_1564},
{"f_1562:chicken_syntax_scm",(void*)f_1562},
{"f_1552:chicken_syntax_scm",(void*)f_1552},
{"f_1555:chicken_syntax_scm",(void*)f_1555},
{"f_1558:chicken_syntax_scm",(void*)f_1558},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
