/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-01 13:59
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[399];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,56,57,32,102,108,97,103,115,57,48,32,46,32,109,111,100,101,57,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,49,52,32,115,105,122,101,49,49,53,32,46,32,98,117,102,102,101,114,49,49,54,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,49,51,52,32,98,117,102,102,101,114,49,51,53,32,46,32,115,105,122,101,49,51,54,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,20),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,56,56,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,115,116,97,116,32,102,50,49,48,32,46,32,116,109,112,50,48,57,50,49,49,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,50,55,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,50,51,50,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,51,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,52,50,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,50,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,50,53,55,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,102,95,51,48,50,55,32,102,110,97,109,101,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,115,116,97,116,45,116,121,112,101,32,110,97,109,101,50,55,49,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,50,56,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,48,48,32,112,111,115,51,48,49,32,46,32,119,104,101,110,99,101,51,48,50,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,48,57,32,110,97,109,101,51,55,49,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,50,56,32,110,97,109,101,51,54,53,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,16),40,102,95,51,49,57,56,32,110,97,109,101,51,54,49,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,51,49,56,56,32,120,51,53,57,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,102,95,51,49,55,55,32,110,97,109,101,51,53,49,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,54,48,32,110,97,109,101,51,55,55,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,51,56,32,46,32,116,109,112,51,51,55,51,51,57,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,49,55,32,115,112,101,99,52,50,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,56,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,48,32,37,115,112,101,99,52,49,53,52,55,52,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,49,57,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,48,55,52,48,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,56,57,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,53,48,52,53,48,53,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,53,53,48,53,53,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,51,54,50,55,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,97,51,54,50,49,32,101,120,118,97,114,53,54,52,53,56,48,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,51,54,52,53,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,51,54,53,55,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,97,51,54,53,49,32,46,32,97,114,103,115,53,55,51,53,57,56,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,51,54,51,57,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,97,51,54,49,53,32,107,53,55,50,53,55,56,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,54,50,55,32,114,54,50,56,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,54,48,50,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,54,52,48,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,54,52,50,32,105,110,112,54,52,51,32,114,54,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,53,48,32,46,32,109,54,53,49,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,54,51,32,46,32,109,54,54,52,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,53,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,97,52,49,54,49,32,46,32,114,101,115,117,108,116,115,55,48,51,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,57,54,32,112,114,111,99,54,57,55,32,46,32,109,111,100,101,54,57,56,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,49,55,57,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,20),40,97,52,49,56,53,32,46,32,114,101,115,117,108,116,115,55,49,51,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,55,48,54,32,112,114,111,99,55,48,55,32,46,32,109,111,100,101,55,48,56,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,97,52,50,48,52,32,46,32,114,101,115,117,108,116,115,55,50,51,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,55,49,54,32,116,104,117,110,107,55,49,55,32,46,32,109,111,100,101,55,49,56,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,52,50,50,52,32,46,32,114,101,115,117,108,116,115,55,51,53,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,55,50,56,32,116,104,117,110,107,55,50,57,32,46,32,109,111,100,101,55,51,48,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,116,109,112,55,53,49,55,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,56,48,55,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,56,49,48,32,112,114,111,99,56,49,49,41,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,56,49,55,32,115,116,97,116,101,56,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,57,48,51,32,109,57,48,52,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,57,49,55,32,97,99,99,57,49,56,32,108,111,99,57,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,50,55,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,50,57,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,57,52,55,32,109,57,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,57,54,54,32,105,110,112,57,54,55,32,114,57,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,57,55,52,32,46,32,109,57,55,53,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,57,55,56,32,46,32,109,57,55,57,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,57,56,54,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,57,57,54,32,46,32,110,101,119,57,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,48,49,48,32,118,97,108,49,48,49,49,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,48,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,48,52,50,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,48,51,54,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,49,48,53,49,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,49,48,53,54,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,49,48,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,48,57,57,32,46,32,116,109,112,49,48,57,56,49,49,48,48,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,49,50,55,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,49,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,49,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,49,53,57,32,109,111,100,101,49,49,54,48,32,46,32,115,105,122,101,49,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,7),40,97,52,57,57,55,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,50,50,55,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,55),40,97,53,48,48,51,32,100,105,114,49,49,57,53,49,49,57,54,49,50,48,51,32,102,105,108,49,49,57,55,49,49,57,56,49,50,48,52,32,101,120,116,49,49,57,57,49,50,48,48,49,50,48,53,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,49,57,48,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,49,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,55,56,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,49,50,55,50,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,108,115,116,49,50,57,50,32,111,108,115,116,49,50,57,51,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,37),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,49,50,54,56,32,101,120,97,99,116,102,49,50,54,57,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,38),40,115,101,116,97,114,103,32,97,49,51,48,54,49,51,49,48,32,97,49,51,48,53,49,51,49,49,32,97,49,51,48,52,49,51,49,50,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,38),40,115,101,116,101,110,118,32,97,49,51,49,56,49,51,50,50,32,97,49,51,49,55,49,51,50,51,32,97,49,51,49,54,49,51,50,52,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,51,51,32,108,49,51,51,57,32,105,49,51,52,48,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,61),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,49,51,50,56,32,108,115,116,49,51,50,57,32,97,114,103,118,101,99,45,115,101,116,116,101,114,49,51,51,48,32,105,100,120,49,51,51,49,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,67),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,49,51,53,49,32,102,105,108,101,110,97,109,101,49,51,53,50,32,97,114,103,108,115,116,49,51,53,51,32,101,110,118,108,115,116,49,51,53,52,32,101,120,97,99,116,102,49,51,53,53,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,53),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,49,51,54,54,32,109,115,103,49,51,54,55,32,102,105,108,101,110,97,109,101,49,51,54,56,32,114,101,115,49,51,54,57,41,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,51,57,51,32,97,114,103,108,115,116,49,52,48,52,32,101,110,118,108,115,116,49,52,48,53,32,101,120,97,99,116,102,49,52,48,54,41,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,51,57,55,32,37,97,114,103,108,115,116,49,51,57,48,49,52,49,50,32,37,101,110,118,108,115,116,49,51,57,49,49,52,49,51,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,51,57,54,32,37,97,114,103,108,115,116,49,51,57,48,49,52,49,55,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,51,57,53,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,51,56,50,32,46,32,116,109,112,49,51,56,49,49,51,56,51,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,52,53,51,32,97,114,103,108,115,116,49,52,54,52,32,101,110,118,108,115,116,49,52,54,53,32,101,120,97,99,116,102,49,52,54,54,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,53,55,32,37,97,114,103,108,115,116,49,52,53,48,49,52,55,50,32,37,101,110,118,108,115,116,49,52,53,49,49,52,55,51,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,53,54,32,37,97,114,103,108,115,116,49,52,53,48,49,52,55,55,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,52,53,53,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,51),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,49,52,52,49,32,102,105,108,101,110,97,109,101,49,52,52,50,32,46,32,116,109,112,49,52,52,48,49,52,52,51,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,53,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,53,49,54,32,46,32,97,114,103,115,49,53,49,55,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,24),40,99,108,111,115,101,45,104,97,110,100,108,101,32,97,49,53,50,53,49,53,50,56,41};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,97),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,53,55,57,32,99,109,100,49,53,56,48,32,97,114,103,115,49,53,56,49,32,101,110,118,49,53,56,50,32,115,116,100,111,117,116,102,49,53,56,51,32,115,116,100,105,110,102,49,53,56,52,32,115,116,100,101,114,114,102,49,53,56,53,32,46,32,116,109,112,49,53,55,56,49,53,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,21),40,97,53,55,51,49,32,103,49,54,54,57,49,54,55,48,49,54,55,49,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,54,54,50,41,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,7),40,97,53,55,52,57,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,38),40,97,53,55,53,53,32,105,110,49,54,56,50,32,111,117,116,49,54,56,51,32,112,105,100,49,54,56,52,32,101,114,114,49,54,56,53,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,63),40,37,112,114,111,99,101,115,115,32,108,111,99,49,54,53,52,32,101,114,114,63,49,54,53,53,32,99,109,100,49,54,53,54,32,97,114,103,115,49,54,53,55,32,101,110,118,49,54,53,56,32,101,120,97,99,116,102,49,54,53,57,41,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,48,56,32,97,114,103,115,49,55,49,57,32,101,110,118,49,55,50,48,32,101,120,97,99,116,102,49,55,50,49,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,49,50,32,37,97,114,103,115,49,55,48,53,49,55,50,53,32,37,101,110,118,49,55,48,54,49,55,50,54,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,49,49,32,37,97,114,103,115,49,55,48,53,49,55,51,48,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,49,48,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,49,54,57,55,32,46,32,116,109,112,49,54,57,54,49,54,57,56,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,54,51,32,97,114,103,115,49,55,55,52,32,101,110,118,49,55,55,53,32,101,120,97,99,116,102,49,55,55,54,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,54,55,32,37,97,114,103,115,49,55,54,48,49,55,56,48,32,37,101,110,118,49,55,54,49,49,55,56,49,41,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,54,54,32,37,97,114,103,115,49,55,54,48,49,55,56,53,41,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,54,53,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,49,55,53,50,32,46,32,116,109,112,49,55,53,49,49,55,53,51,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,48,53,32,110,111,104,97,110,103,49,56,48,54,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,53,57,55,53,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,97,53,57,56,49,32,101,112,105,100,49,56,50,56,32,101,110,111,114,109,49,56,50,57,32,101,99,111,100,101,49,56,51,48,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,48,57,32,46,32,97,114,103,115,49,56,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,13),40,115,108,101,101,112,32,116,49,56,51,53,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,14),40,102,95,54,49,57,54,32,120,49,57,48,50,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,7),40,97,54,49,52,50,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,7),40,97,54,49,52,55,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,7),40,97,54,49,54,49,41,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,57,48,56,32,114,49,57,48,57,41,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,49,50,32,46,32,95,49,56,57,56,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,48,52,32,46,32,95,49,56,57,54,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,56,55,48,32,97,99,116,105,111,110,49,56,56,49,32,105,100,49,56,56,50,32,108,105,109,105,116,49,56,56,51,41,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,56,55,52,32,37,97,99,116,105,111,110,49,56,54,55,49,57,52,57,32,37,105,100,49,56,54,56,49,57,53,48,41,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,56,55,51,32,37,97,99,116,105,111,110,49,56,54,55,49,57,53,52,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,19),40,97,54,50,51,50,32,120,49,57,53,57,32,121,49,57,54,48,41,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,56,55,50,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,56,53,56,32,112,114,101,100,49,56,53,57,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,56,54,48,41,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,13),40,102,105,102,111,63,32,95,50,51,54,54,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,50,51,55,48,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,52,55,32,110,97,109,101,50,51,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,53,55,32,110,97,109,101,50,51,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,54,55,32,110,97,109,101,50,51,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,55,55,32,110,97,109,101,50,51,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,56,55,32,110,97,109,101,50,51,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,57,55,32,110,97,109,101,50,51,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,48,55,32,110,97,109,101,50,51,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,49,55,32,110,97,109,101,50,50,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,50,55,32,110,97,109,101,50,50,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,51,55,32,110,97,109,101,50,50,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,52,55,32,110,97,109,101,50,50,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,53,55,32,110,97,109,101,50,50,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,54,55,32,110,97,109,101,50,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,55,55,32,110,97,109,101,50,50,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,56,55,32,110,97,109,101,50,50,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,57,55,32,110,97,109,101,50,50,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,48,55,32,110,97,109,101,50,50,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,49,55,32,110,97,109,101,50,50,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,50,55,32,110,97,109,101,50,49,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,51,55,32,110,97,109,101,50,49,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,52,55,32,110,97,109,101,50,49,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,53,55,32,110,97,109,101,50,49,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,54,55,32,110,97,109,101,50,49,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,55,55,32,110,97,109,101,50,49,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,56,55,32,110,97,109,101,50,49,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,57,55,32,110,97,109,101,50,49,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,48,55,32,110,97,109,101,50,49,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,49,55,32,110,97,109,101,50,49,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,50,55,32,110,97,109,101,50,49,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,51,55,32,110,97,109,101,50,48,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,52,55,32,110,97,109,101,50,48,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,53,55,32,110,97,109,101,50,48,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,54,55,32,110,97,109,101,50,48,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,55,55,32,110,97,109,101,50,48,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,56,55,32,110,97,109,101,50,48,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,57,55,32,110,97,109,101,50,48,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,48,55,32,110,97,109,101,50,48,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,49,55,32,110,97,109,101,50,48,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,50,55,32,110,97,109,101,50,48,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,51,55,32,110,97,109,101,50,48,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,52,55,32,110,97,109,101,49,57,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,53,55,32,110,97,109,101,49,57,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,54,55,32,110,97,109,101,49,57,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k5570 */
static C_word C_fcall stub1540(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1540(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static C_word C_fcall stub1526(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1526(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static C_word C_fcall stub1494(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1494(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k5199 */
static C_word C_fcall stub1319(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1319(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k5182 */
static C_word C_fcall stub1307(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1307(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k4893 */
static C_word C_fcall stub1142(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1142(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1134(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1134(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub1085(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1085(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1077(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1077(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k4740 */
static C_word C_fcall stub1062(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1062(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4646 */
static C_word C_fcall stub1026(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1026(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2659 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_ccall f_6707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6587)
static void C_ccall f_6587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6557)
static void C_ccall f_6557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6227)
static void C_fcall f_6227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6217)
static void C_fcall f_6217(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6078)
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6085)
static void C_fcall f_6085(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6061)
static void C_ccall f_6061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5880)
static void C_fcall f_5880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5870)
static void C_fcall f_5870(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5865)
static void C_fcall f_5865(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5800)
static void C_fcall f_5800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_fcall f_5795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5790)
static void C_fcall f_5790(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5785)
static void C_fcall f_5785(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5721)
static void C_fcall f_5721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_fcall f_5723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5414)
static void C_fcall f_5414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5404)
static void C_fcall f_5404(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5392)
static void C_fcall f_5392(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5327)
static void C_fcall f_5327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_fcall f_5322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5317)
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5305)
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_fcall f_5288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_fcall f_5255(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_fcall f_5205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5217)
static void C_fcall f_5217(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5092)
static void C_fcall f_5092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5135)
static void C_fcall f_5135(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_fcall f_5097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_fcall f_5106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4983)
static void C_fcall f_4983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_fcall f_5023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_fcall f_4667(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4589)
static void C_fcall f_4589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_fcall f_4501(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_fcall f_4464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4419)
static void C_fcall f_4419(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_fcall f_4032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static C_word C_fcall f_4020(C_word t0);
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_fcall f_3839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_fcall f_3881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_fcall f_3679(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_fcall f_3758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_fcall f_3607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static C_word C_fcall f_3596(C_word t0);
C_noret_decl(f_3591)
static void C_fcall f_3591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3461)
static void C_fcall f_3461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_fcall f_3456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3355)
static void C_fcall f_3355(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_fcall f_3389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_fcall f_3411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_fcall f_3025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_fcall f_2892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6227)
static void C_fcall trf_6227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6227(t0,t1);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6222(t0,t1,t2);}

C_noret_decl(trf_6217)
static void C_fcall trf_6217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6217(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6217(t0,t1,t2,t3);}

C_noret_decl(trf_6078)
static void C_fcall trf_6078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6078(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6078(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6085)
static void C_fcall trf_6085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6085(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6085(t0,t1);}

C_noret_decl(trf_6097)
static void C_fcall trf_6097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6097(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6097(t0,t1,t2,t3);}

C_noret_decl(trf_5880)
static void C_fcall trf_5880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5880(t0,t1);}

C_noret_decl(trf_5875)
static void C_fcall trf_5875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5875(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5875(t0,t1,t2);}

C_noret_decl(trf_5870)
static void C_fcall trf_5870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5870(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5870(t0,t1,t2,t3);}

C_noret_decl(trf_5865)
static void C_fcall trf_5865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5865(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5865(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5800)
static void C_fcall trf_5800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5800(t0,t1);}

C_noret_decl(trf_5795)
static void C_fcall trf_5795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5795(t0,t1,t2);}

C_noret_decl(trf_5790)
static void C_fcall trf_5790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5790(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5790(t0,t1,t2,t3);}

C_noret_decl(trf_5785)
static void C_fcall trf_5785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5785(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5785(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5721)
static void C_fcall trf_5721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5721(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5721(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5723)
static void C_fcall trf_5723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5723(t0,t1,t2);}

C_noret_decl(trf_5414)
static void C_fcall trf_5414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5414(t0,t1);}

C_noret_decl(trf_5409)
static void C_fcall trf_5409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5409(t0,t1,t2);}

C_noret_decl(trf_5404)
static void C_fcall trf_5404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5404(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5404(t0,t1,t2,t3);}

C_noret_decl(trf_5392)
static void C_fcall trf_5392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5392(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5392(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5327)
static void C_fcall trf_5327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5327(t0,t1);}

C_noret_decl(trf_5322)
static void C_fcall trf_5322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5322(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5322(t0,t1,t2);}

C_noret_decl(trf_5317)
static void C_fcall trf_5317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5317(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5317(t0,t1,t2,t3);}

C_noret_decl(trf_5305)
static void C_fcall trf_5305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5305(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5305(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5288)
static void C_fcall trf_5288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5288(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5288(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5255)
static void C_fcall trf_5255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5255(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5255(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5205)
static void C_fcall trf_5205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5205(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5205(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5217)
static void C_fcall trf_5217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5217(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5217(t0,t1,t2,t3);}

C_noret_decl(trf_5092)
static void C_fcall trf_5092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5092(t0,t1,t2,t3);}

C_noret_decl(trf_5135)
static void C_fcall trf_5135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5135(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5135(t0,t1,t2,t3);}

C_noret_decl(trf_5097)
static void C_fcall trf_5097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5097(t0,t1,t2);}

C_noret_decl(trf_5106)
static void C_fcall trf_5106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5106(t0,t1,t2);}

C_noret_decl(trf_4983)
static void C_fcall trf_4983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4983(t0,t1,t2);}

C_noret_decl(trf_5023)
static void C_fcall trf_5023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5023(t0,t1,t2);}

C_noret_decl(trf_4655)
static void C_fcall trf_4655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4655(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4655(t0,t1,t2);}

C_noret_decl(trf_4667)
static void C_fcall trf_4667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4667(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4667(t0,t1,t2);}

C_noret_decl(trf_4589)
static void C_fcall trf_4589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4589(t0,t1);}

C_noret_decl(trf_4501)
static void C_fcall trf_4501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4501(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4501(t0,t1,t2,t3);}

C_noret_decl(trf_4464)
static void C_fcall trf_4464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4464(t0,t1,t2);}

C_noret_decl(trf_4419)
static void C_fcall trf_4419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4419(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4419(t0,t1,t2,t3);}

C_noret_decl(trf_4038)
static void C_fcall trf_4038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4038(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4038(t0,t1,t2,t3);}

C_noret_decl(trf_4032)
static void C_fcall trf_4032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4032(t0,t1);}

C_noret_decl(trf_3809)
static void C_fcall trf_3809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3809(t0,t1);}

C_noret_decl(trf_3839)
static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3839(t0,t1);}

C_noret_decl(trf_3881)
static void C_fcall trf_3881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3881(t0,t1);}

C_noret_decl(trf_3679)
static void C_fcall trf_3679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3679(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3679(t0,t1,t2,t3);}

C_noret_decl(trf_3758)
static void C_fcall trf_3758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3758(t0,t1);}

C_noret_decl(trf_3607)
static void C_fcall trf_3607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3607(t0,t1);}

C_noret_decl(trf_3591)
static void C_fcall trf_3591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3591(t0,t1);}

C_noret_decl(trf_3461)
static void C_fcall trf_3461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3461(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3461(t0,t1);}

C_noret_decl(trf_3456)
static void C_fcall trf_3456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3456(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3456(t0,t1,t2);}

C_noret_decl(trf_3355)
static void C_fcall trf_3355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3355(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3355(t0,t1,t2,t3);}

C_noret_decl(trf_3389)
static void C_fcall trf_3389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3389(t0,t1);}

C_noret_decl(trf_3411)
static void C_fcall trf_3411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3411(t0,t1);}

C_noret_decl(trf_3025)
static void C_fcall trf_3025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3025(t0,t1);}

C_noret_decl(trf_2892)
static void C_fcall trf_2892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2892(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3120)){
C_save(t1);
C_rereclaim2(3120*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,399);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"\003syserror");
lf[63]=C_h_intern(&lf[63],9,"file-size");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],16,"file-access-time");
lf[66]=C_h_intern(&lf[66],16,"file-change-time");
lf[67]=C_h_intern(&lf[67],10,"file-owner");
lf[68]=C_h_intern(&lf[68],16,"file-permissions");
lf[69]=C_h_intern(&lf[69],13,"regular-file\077");
lf[70]=C_h_intern(&lf[70],13,"\003sysfile-info");
lf[71]=C_h_intern(&lf[71],14,"symbolic-link\077");
lf[72]=C_h_intern(&lf[72],13,"stat-regular\077");
lf[73]=C_h_intern(&lf[73],15,"stat-directory\077");
lf[74]=C_h_intern(&lf[74],17,"stat-char-device\077");
lf[75]=C_h_intern(&lf[75],18,"stat-block-device\077");
lf[76]=C_h_intern(&lf[76],10,"stat-fifo\077");
lf[77]=C_h_intern(&lf[77],13,"stat-symlink\077");
lf[78]=C_h_intern(&lf[78],12,"stat-socket\077");
lf[79]=C_h_intern(&lf[79],13,"file-position");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[81]=C_h_intern(&lf[81],6,"stream");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[83]=C_h_intern(&lf[83],5,"port\077");
lf[84]=C_h_intern(&lf[84],18,"set-file-position!");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[87]=C_h_intern(&lf[87],13,"\000bounds-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[89]=C_h_intern(&lf[89],16,"create-directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[91]=C_h_intern(&lf[91],12,"file-exists\077");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[93]=C_h_intern(&lf[93],12,"\003sysfor-each");
lf[94]=C_h_intern(&lf[94],12,"string-split");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[96]=C_h_intern(&lf[96],14,"canonical-path");
lf[97]=C_h_intern(&lf[97],16,"change-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[99]=C_h_intern(&lf[99],16,"delete-directory");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[101]=C_h_intern(&lf[101],6,"string");
lf[102]=C_h_intern(&lf[102],9,"directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[104]=C_h_intern(&lf[104],16,"\003sysmake-pointer");
lf[105]=C_h_intern(&lf[105],17,"current-directory");
lf[106]=C_h_intern(&lf[106],10,"directory\077");
lf[107]=C_h_intern(&lf[107],27,"\003sysplatform-fixup-pathname");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[109]=C_h_intern(&lf[109],5,"null\077");
lf[110]=C_h_intern(&lf[110],6,"char=\077");
lf[111]=C_h_intern(&lf[111],8,"string=\077");
lf[112]=C_h_intern(&lf[112],16,"char-alphabetic\077");
lf[113]=C_h_intern(&lf[113],10,"string-ref");
lf[114]=C_h_intern(&lf[114],18,"string-intersperse");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[116]=C_h_intern(&lf[116],17,"current-user-name");
lf[117]=C_h_intern(&lf[117],9,"condition");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[119]=C_h_intern(&lf[119],22,"with-exception-handler");
lf[120]=C_h_intern(&lf[120],30,"call-with-current-continuation");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[122]=C_h_intern(&lf[122],7,"reverse");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[132]=C_h_intern(&lf[132],5,"\000text");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[135]=C_h_intern(&lf[135],13,"\003sysmake-port");
lf[136]=C_h_intern(&lf[136],21,"\003sysstream-port-class");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[138]=C_h_intern(&lf[138],15,"open-input-pipe");
lf[139]=C_h_intern(&lf[139],7,"\000binary");
lf[140]=C_h_intern(&lf[140],16,"open-output-pipe");
lf[141]=C_h_intern(&lf[141],16,"close-input-pipe");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[143]=C_h_intern(&lf[143],14,"\003syscheck-port");
lf[144]=C_h_intern(&lf[144],17,"close-output-pipe");
lf[145]=C_h_intern(&lf[145],20,"call-with-input-pipe");
lf[146]=C_h_intern(&lf[146],21,"call-with-output-pipe");
lf[147]=C_h_intern(&lf[147],20,"with-input-from-pipe");
lf[148]=C_h_intern(&lf[148],18,"\003sysstandard-input");
lf[149]=C_h_intern(&lf[149],19,"with-output-to-pipe");
lf[150]=C_h_intern(&lf[150],19,"\003sysstandard-output");
lf[151]=C_h_intern(&lf[151],11,"create-pipe");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[153]=C_h_intern(&lf[153],11,"signal/term");
lf[154]=C_h_intern(&lf[154],10,"signal/int");
lf[155]=C_h_intern(&lf[155],10,"signal/fpe");
lf[156]=C_h_intern(&lf[156],10,"signal/ill");
lf[157]=C_h_intern(&lf[157],11,"signal/segv");
lf[158]=C_h_intern(&lf[158],11,"signal/abrt");
lf[159]=C_h_intern(&lf[159],12,"signal/break");
lf[160]=C_h_intern(&lf[160],11,"signal/alrm");
lf[161]=C_h_intern(&lf[161],11,"signal/chld");
lf[162]=C_h_intern(&lf[162],11,"signal/cont");
lf[163]=C_h_intern(&lf[163],10,"signal/hup");
lf[164]=C_h_intern(&lf[164],9,"signal/io");
lf[165]=C_h_intern(&lf[165],11,"signal/kill");
lf[166]=C_h_intern(&lf[166],11,"signal/pipe");
lf[167]=C_h_intern(&lf[167],11,"signal/prof");
lf[168]=C_h_intern(&lf[168],11,"signal/quit");
lf[169]=C_h_intern(&lf[169],11,"signal/stop");
lf[170]=C_h_intern(&lf[170],11,"signal/trap");
lf[171]=C_h_intern(&lf[171],11,"signal/tstp");
lf[172]=C_h_intern(&lf[172],10,"signal/urg");
lf[173]=C_h_intern(&lf[173],11,"signal/usr1");
lf[174]=C_h_intern(&lf[174],11,"signal/usr2");
lf[175]=C_h_intern(&lf[175],13,"signal/vtalrm");
lf[176]=C_h_intern(&lf[176],12,"signal/winch");
lf[177]=C_h_intern(&lf[177],11,"signal/xcpu");
lf[178]=C_h_intern(&lf[178],11,"signal/xfsz");
lf[179]=C_h_intern(&lf[179],12,"signals-list");
lf[180]=C_h_intern(&lf[180],18,"\003sysinterrupt-hook");
lf[181]=C_h_intern(&lf[181],14,"signal-handler");
lf[182]=C_h_intern(&lf[182],19,"set-signal-handler!");
lf[183]=C_h_intern(&lf[183],10,"errno/perm");
lf[184]=C_h_intern(&lf[184],11,"errno/noent");
lf[185]=C_h_intern(&lf[185],10,"errno/srch");
lf[186]=C_h_intern(&lf[186],10,"errno/intr");
lf[187]=C_h_intern(&lf[187],8,"errno/io");
lf[188]=C_h_intern(&lf[188],12,"errno/noexec");
lf[189]=C_h_intern(&lf[189],10,"errno/badf");
lf[190]=C_h_intern(&lf[190],11,"errno/child");
lf[191]=C_h_intern(&lf[191],11,"errno/nomem");
lf[192]=C_h_intern(&lf[192],11,"errno/acces");
lf[193]=C_h_intern(&lf[193],11,"errno/fault");
lf[194]=C_h_intern(&lf[194],10,"errno/busy");
lf[195]=C_h_intern(&lf[195],11,"errno/exist");
lf[196]=C_h_intern(&lf[196],12,"errno/notdir");
lf[197]=C_h_intern(&lf[197],11,"errno/isdir");
lf[198]=C_h_intern(&lf[198],11,"errno/inval");
lf[199]=C_h_intern(&lf[199],11,"errno/mfile");
lf[200]=C_h_intern(&lf[200],11,"errno/nospc");
lf[201]=C_h_intern(&lf[201],11,"errno/spipe");
lf[202]=C_h_intern(&lf[202],10,"errno/pipe");
lf[203]=C_h_intern(&lf[203],11,"errno/again");
lf[204]=C_h_intern(&lf[204],10,"errno/rofs");
lf[205]=C_h_intern(&lf[205],10,"errno/nxio");
lf[206]=C_h_intern(&lf[206],10,"errno/2big");
lf[207]=C_h_intern(&lf[207],10,"errno/xdev");
lf[208]=C_h_intern(&lf[208],11,"errno/nodev");
lf[209]=C_h_intern(&lf[209],11,"errno/nfile");
lf[210]=C_h_intern(&lf[210],11,"errno/notty");
lf[211]=C_h_intern(&lf[211],10,"errno/fbig");
lf[212]=C_h_intern(&lf[212],11,"errno/mlink");
lf[213]=C_h_intern(&lf[213],9,"errno/dom");
lf[214]=C_h_intern(&lf[214],11,"errno/range");
lf[215]=C_h_intern(&lf[215],12,"errno/deadlk");
lf[216]=C_h_intern(&lf[216],17,"errno/nametoolong");
lf[217]=C_h_intern(&lf[217],11,"errno/nolck");
lf[218]=C_h_intern(&lf[218],11,"errno/nosys");
lf[219]=C_h_intern(&lf[219],14,"errno/notempty");
lf[220]=C_h_intern(&lf[220],11,"errno/ilseq");
lf[221]=C_h_intern(&lf[221],16,"change-file-mode");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[223]=C_h_intern(&lf[223],17,"file-read-access\077");
lf[224]=C_h_intern(&lf[224],18,"file-write-access\077");
lf[225]=C_h_intern(&lf[225],20,"file-execute-access\077");
lf[226]=C_h_intern(&lf[226],12,"fileno/stdin");
lf[227]=C_h_intern(&lf[227],13,"fileno/stdout");
lf[228]=C_h_intern(&lf[228],13,"fileno/stderr");
lf[229]=C_h_intern(&lf[229],7,"\000append");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[237]=C_h_intern(&lf[237],16,"open-input-file*");
lf[238]=C_h_intern(&lf[238],17,"open-output-file*");
lf[239]=C_h_intern(&lf[239],12,"port->fileno");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[242]=C_h_intern(&lf[242],25,"\003syspeek-unsigned-integer");
lf[243]=C_h_intern(&lf[243],16,"duplicate-fileno");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[245]=C_h_intern(&lf[245],6,"setenv");
lf[246]=C_h_intern(&lf[246],8,"unsetenv");
lf[247]=C_h_intern(&lf[247],9,"substring");
lf[248]=C_h_intern(&lf[248],25,"get-environment-variables");
lf[249]=C_h_intern(&lf[249],19,"current-environment");
lf[250]=C_h_intern(&lf[250],19,"seconds->local-time");
lf[251]=C_h_intern(&lf[251],18,"\003sysdecode-seconds");
lf[252]=C_h_intern(&lf[252],17,"seconds->utc-time");
lf[253]=C_h_intern(&lf[253],15,"seconds->string");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[255]=C_h_intern(&lf[255],12,"time->string");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[259]=C_h_intern(&lf[259],19,"local-time->seconds");
lf[260]=C_h_intern(&lf[260],15,"\003syscons-flonum");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[263]=C_h_intern(&lf[263],27,"local-timezone-abbreviation");
lf[264]=C_h_intern(&lf[264],5,"_exit");
lf[265]=C_h_intern(&lf[265],14,"terminal-port\077");
lf[266]=C_h_intern(&lf[266],19,"set-buffering-mode!");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[268]=C_h_intern(&lf[268],5,"\000full");
lf[269]=C_h_intern(&lf[269],5,"\000line");
lf[270]=C_h_intern(&lf[270],5,"\000none");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[272]=C_h_intern(&lf[272],6,"regexp");
lf[273]=C_h_intern(&lf[273],21,"make-anchored-pattern");
lf[274]=C_h_intern(&lf[274],12,"string-match");
lf[275]=C_h_intern(&lf[275],12,"glob->regexp");
lf[276]=C_h_intern(&lf[276],13,"make-pathname");
lf[277]=C_h_intern(&lf[277],18,"decompose-pathname");
lf[278]=C_h_intern(&lf[278],4,"glob");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[281]=C_h_intern(&lf[281],13,"spawn/overlay");
lf[282]=C_h_intern(&lf[282],10,"spawn/wait");
lf[283]=C_h_intern(&lf[283],12,"spawn/nowait");
lf[284]=C_h_intern(&lf[284],13,"spawn/nowaito");
lf[285]=C_h_intern(&lf[285],12,"spawn/detach");
lf[286]=C_h_intern(&lf[286],16,"char-whitespace\077");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[290]=C_h_intern(&lf[290],24,"pathname-strip-directory");
lf[293]=C_h_intern(&lf[293],15,"process-execute");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[295]=C_h_intern(&lf[295],13,"process-spawn");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[297]=C_h_intern(&lf[297],18,"current-process-id");
lf[298]=C_h_intern(&lf[298],17,"\003sysshell-command");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[300]=C_h_intern(&lf[300],6,"getenv");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[302]=C_h_intern(&lf[302],27,"\003sysshell-command-arguments");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[304]=C_h_intern(&lf[304],11,"process-run");
lf[306]=C_h_intern(&lf[306],11,"\003sysprocess");
lf[307]=C_h_intern(&lf[307],5,"g1615");
lf[308]=C_h_intern(&lf[308],5,"g1621");
lf[309]=C_h_intern(&lf[309],5,"g1627");
lf[310]=C_h_intern(&lf[310],5,"g1633");
lf[311]=C_h_intern(&lf[311],14,"\000process-error");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[313]=C_h_intern(&lf[313],17,"\003sysmake-locative");
lf[314]=C_h_intern(&lf[314],8,"location");
lf[315]=C_h_intern(&lf[315],7,"process");
lf[316]=C_h_intern(&lf[316],8,"process*");
lf[317]=C_h_intern(&lf[317],16,"\003sysprocess-wait");
lf[318]=C_h_intern(&lf[318],12,"process-wait");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[320]=C_h_intern(&lf[320],5,"sleep");
lf[321]=C_h_intern(&lf[321],13,"get-host-name");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[323]=C_h_intern(&lf[323],18,"system-information");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[327]=C_h_intern(&lf[327],10,"find-files");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[331]=C_h_intern(&lf[331],16,"\003sysdynamic-wind");
lf[332]=C_h_intern(&lf[332],13,"pathname-file");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[334]=C_h_intern(&lf[334],16,"errno/wouldblock");
lf[335]=C_h_intern(&lf[335],5,"fifo\077");
lf[336]=C_h_intern(&lf[336],19,"memory-mapped-file\077");
lf[337]=C_h_intern(&lf[337],13,"map/anonymous");
lf[338]=C_h_intern(&lf[338],8,"map/file");
lf[339]=C_h_intern(&lf[339],9,"map/fixed");
lf[340]=C_h_intern(&lf[340],11,"map/private");
lf[341]=C_h_intern(&lf[341],10,"map/shared");
lf[342]=C_h_intern(&lf[342],10,"open/fsync");
lf[343]=C_h_intern(&lf[343],11,"open/noctty");
lf[344]=C_h_intern(&lf[344],13,"open/nonblock");
lf[345]=C_h_intern(&lf[345],9,"open/sync");
lf[346]=C_h_intern(&lf[346],10,"perm/isgid");
lf[347]=C_h_intern(&lf[347],10,"perm/isuid");
lf[348]=C_h_intern(&lf[348],10,"perm/isvtx");
lf[349]=C_h_intern(&lf[349],9,"prot/exec");
lf[350]=C_h_intern(&lf[350],9,"prot/none");
lf[351]=C_h_intern(&lf[351],9,"prot/read");
lf[352]=C_h_intern(&lf[352],10,"prot/write");
lf[353]=C_h_intern(&lf[353],12,"string->time");
lf[354]=C_h_intern(&lf[354],17,"utc-time->seconds");
lf[355]=C_h_intern(&lf[355],16,"user-information");
lf[356]=C_h_intern(&lf[356],22,"unmap-file-from-memory");
lf[357]=C_h_intern(&lf[357],13,"terminal-size");
lf[358]=C_h_intern(&lf[358],13,"terminal-name");
lf[359]=C_h_intern(&lf[359],14,"signal-unmask!");
lf[360]=C_h_intern(&lf[360],14,"signal-masked\077");
lf[361]=C_h_intern(&lf[361],12,"signal-mask!");
lf[362]=C_h_intern(&lf[362],11,"signal-mask");
lf[363]=C_h_intern(&lf[363],12,"set-user-id!");
lf[364]=C_h_intern(&lf[364],16,"set-signal-mask!");
lf[365]=C_h_intern(&lf[365],19,"set-root-directory!");
lf[366]=C_h_intern(&lf[366],21,"set-process-group-id!");
lf[367]=C_h_intern(&lf[367],11,"set-groups!");
lf[368]=C_h_intern(&lf[368],13,"set-group-id!");
lf[369]=C_h_intern(&lf[369],10,"set-alarm!");
lf[370]=C_h_intern(&lf[370],18,"read-symbolic-link");
lf[371]=C_h_intern(&lf[371],14,"process-signal");
lf[372]=C_h_intern(&lf[372],16,"process-group-id");
lf[373]=C_h_intern(&lf[373],12,"process-fork");
lf[374]=C_h_intern(&lf[374],17,"parent-process-id");
lf[375]=C_h_intern(&lf[375],26,"memory-mapped-file-pointer");
lf[376]=C_h_intern(&lf[376],17,"initialize-groups");
lf[377]=C_h_intern(&lf[377],17,"group-information");
lf[378]=C_h_intern(&lf[378],10,"get-groups");
lf[379]=C_h_intern(&lf[379],11,"file-unlock");
lf[380]=C_h_intern(&lf[380],13,"file-truncate");
lf[381]=C_h_intern(&lf[381],14,"file-test-lock");
lf[382]=C_h_intern(&lf[382],11,"file-select");
lf[383]=C_h_intern(&lf[383],18,"file-lock/blocking");
lf[384]=C_h_intern(&lf[384],9,"file-lock");
lf[385]=C_h_intern(&lf[385],9,"file-link");
lf[386]=C_h_intern(&lf[386],18,"map-file-to-memory");
lf[387]=C_h_intern(&lf[387],15,"current-user-id");
lf[388]=C_h_intern(&lf[388],16,"current-group-id");
lf[389]=C_h_intern(&lf[389],27,"current-effective-user-name");
lf[390]=C_h_intern(&lf[390],25,"current-effective-user-id");
lf[391]=C_h_intern(&lf[391],26,"current-effective-group-id");
lf[392]=C_h_intern(&lf[392],20,"create-symbolic-link");
lf[393]=C_h_intern(&lf[393],14,"create-session");
lf[394]=C_h_intern(&lf[394],11,"create-fifo");
lf[395]=C_h_intern(&lf[395],17,"change-file-owner");
lf[396]=C_h_intern(&lf[396],11,"make-vector");
lf[397]=C_h_intern(&lf[397],17,"register-feature!");
lf[398]=C_h_intern(&lf[398],5,"posix");
C_register_lf2(lf,399,create_ptable());
t2=C_mutate(&lf[0] /* (set! c1984 ...) */,lf[1]);
t3=C_mutate(&lf[2] /* (set! c222 ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k2633 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2636 in k2633 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2639 in k2636 in k2633 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 929  register-feature! */
t3=*((C_word*)lf[397]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[398]);}

/* k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2662,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* (set! posix-error ...) */,lf[5]);
t5=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2708,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[41]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[48]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2854,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[55]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2930,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2961,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2967,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[65]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2973,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3020,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[72]+1 /* (set! stat-regular? ...) */,*((C_word*)lf[69]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1114 stat-type */
f_3025(t54,lf[73]);}

/* k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1115 stat-type */
f_3025(t3,lf[74]);}

/* k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! stat-char-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1116 stat-type */
f_3025(t3,lf[75]);}

/* k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1117 stat-type */
f_3025(t3,lf[76]);}

/* k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1118 stat-type */
f_3025(t3,lf[77]);}

/* k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1119 stat-type */
f_3025(t3,lf[78]);}

/* k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[121],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[79]+1 /* (set! file-position ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[84]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3098,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[89]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3159,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[97]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[99]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[4]+1);
t9=*((C_word*)lf[43]+1);
t10=*((C_word*)lf[101]+1);
t11=C_mutate((C_word*)lf[102]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3353,a[2]=t9,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[106]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[43]+1);
t14=C_mutate((C_word*)lf[105]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3540,a[2]=t13,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[109]+1);
t16=*((C_word*)lf[110]+1);
t17=*((C_word*)lf[111]+1);
t18=*((C_word*)lf[112]+1);
t19=*((C_word*)lf[113]+1);
t20=*((C_word*)lf[4]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3591,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3596,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[116]+1);
t24=*((C_word*)lf[105]+1);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=t24,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t26=C_mutate((C_word*)lf[96]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3663,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4020,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4032,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[138]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4056,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[140]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4092,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t32=C_mutate((C_word*)lf[141]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[144]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[141]+1));
t34=*((C_word*)lf[138]+1);
t35=*((C_word*)lf[140]+1);
t36=*((C_word*)lf[141]+1);
t37=*((C_word*)lf[144]+1);
t38=C_mutate((C_word*)lf[145]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4147,a[2]=t34,a[3]=t36,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[146]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4171,a[2]=t35,a[3]=t37,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[147]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4195,a[2]=t34,a[3]=t36,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[149]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4215,a[2]=t35,a[3]=t37,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t42=C_mutate((C_word*)lf[151]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4235,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[153]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[154]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[155]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[156]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[157]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[158]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[159]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[160] /* signal/alrm */,0,C_fix(0));
t51=C_set_block_item(lf[161] /* signal/chld */,0,C_fix(0));
t52=C_set_block_item(lf[162] /* signal/cont */,0,C_fix(0));
t53=C_set_block_item(lf[163] /* signal/hup */,0,C_fix(0));
t54=C_set_block_item(lf[164] /* signal/io */,0,C_fix(0));
t55=C_set_block_item(lf[165] /* signal/kill */,0,C_fix(0));
t56=C_set_block_item(lf[166] /* signal/pipe */,0,C_fix(0));
t57=C_set_block_item(lf[167] /* signal/prof */,0,C_fix(0));
t58=C_set_block_item(lf[168] /* signal/quit */,0,C_fix(0));
t59=C_set_block_item(lf[169] /* signal/stop */,0,C_fix(0));
t60=C_set_block_item(lf[170] /* signal/trap */,0,C_fix(0));
t61=C_set_block_item(lf[171] /* signal/tstp */,0,C_fix(0));
t62=C_set_block_item(lf[172] /* signal/urg */,0,C_fix(0));
t63=C_set_block_item(lf[173] /* signal/usr1 */,0,C_fix(0));
t64=C_set_block_item(lf[174] /* signal/usr2 */,0,C_fix(0));
t65=C_set_block_item(lf[175] /* signal/vtalrm */,0,C_fix(0));
t66=C_set_block_item(lf[176] /* signal/winch */,0,C_fix(0));
t67=C_set_block_item(lf[177] /* signal/xcpu */,0,C_fix(0));
t68=C_set_block_item(lf[178] /* signal/xfsz */,0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1),*((C_word*)lf[158]+1),*((C_word*)lf[159]+1));
t70=C_mutate((C_word*)lf[179]+1 /* (set! signals-list ...) */,t69);
t71=*((C_word*)lf[180]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1467 make-vector */
t73=*((C_word*)lf[396]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word ab[193],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=C_mutate((C_word*)lf[181]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=t1,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[182]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4320,a[2]=t1,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[180]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4333,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[183]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[184]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[185]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[186]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[187]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[188]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[189]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[190]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[191]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[192]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[193]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[194]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[195]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[196]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[197]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[198]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[199]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[200]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[201]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[202]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[203]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[204]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[205]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[206]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[207]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[208]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[209]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[210]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[211]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[212]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[213]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[214]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[215]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[216]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[217]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[218]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[219]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[220]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[221]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4389,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4419,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[223]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=t44,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[224]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4449,a[2]=t44,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[225]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4455,a[2]=t44,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[226]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[227]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[228]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4501,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[237]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=t51,a[3]=t52,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[238]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=t51,a[3]=t52,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[239]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4547,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[243]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4582,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[245]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4612,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[246]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4629,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[247]+1);
t60=C_mutate((C_word*)lf[248]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4649,a[2]=t59,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[249]+1 /* (set! current-environment ...) */,*((C_word*)lf[248]+1));
t62=C_mutate((C_word*)lf[250]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4715,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[252]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4724,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[253]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4743,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[255]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4776,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[259]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4856,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[263]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4884,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[264]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4896,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[265]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4912,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[266]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t71=*((C_word*)lf[272]+1);
t72=*((C_word*)lf[273]+1);
t73=*((C_word*)lf[274]+1);
t74=*((C_word*)lf[275]+1);
t75=*((C_word*)lf[102]+1);
t76=*((C_word*)lf[276]+1);
t77=*((C_word*)lf[277]+1);
t78=C_mutate((C_word*)lf[278]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4977,a[2]=t74,a[3]=t72,a[4]=t71,a[5]=t75,a[6]=t73,a[7]=t76,a[8]=t77,a[9]=((C_word)li97),tmp=(C_word)a,a+=10,tmp));
t79=C_mutate((C_word*)lf[281]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t80=C_mutate((C_word*)lf[282]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t81=C_mutate((C_word*)lf[283]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t82=C_mutate((C_word*)lf[284]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t83=C_mutate((C_word*)lf[285]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t84=*((C_word*)lf[286]+1);
t85=*((C_word*)lf[51]+1);
t86=*((C_word*)lf[113]+1);
t87=*((C_word*)lf[4]+1);
t88=C_mutate(&lf[287] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5092,a[2]=t87,a[3]=t85,a[4]=t86,a[5]=t84,a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t89=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5171,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5188,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t91=*((C_word*)lf[290]+1);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5205,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t93=C_mutate(&lf[291] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5255,a[2]=t91,a[3]=t89,a[4]=t90,a[5]=t92,a[6]=((C_word)li106),tmp=(C_word)a,a+=7,tmp));
t94=C_mutate(&lf[292] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5288,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[293]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5303,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[295]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5390,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[297]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5477,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[298]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5480,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[302]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5501,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t100=*((C_word*)lf[295]+1);
t101=*((C_word*)lf[300]+1);
t102=C_mutate((C_word*)lf[304]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=t100,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t103=C_mutate(&lf[305] /* (set! close-handle ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5536,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t104=C_mutate((C_word*)lf[306]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5602,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t105=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5721,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
t106=C_mutate((C_word*)lf[315]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5783,a[2]=t105,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp));
t107=C_mutate((C_word*)lf[316]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5863,a[2]=t105,a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp));
t108=C_mutate((C_word*)lf[317]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5943,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[318]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5955,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[320]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6015,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[321]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6018,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[323]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6030,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t113=C_mutate((C_word*)lf[116]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6061,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t114=*((C_word*)lf[278]+1);
t115=*((C_word*)lf[274]+1);
t116=*((C_word*)lf[276]+1);
t117=*((C_word*)lf[106]+1);
t118=C_mutate((C_word*)lf[327]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6076,a[2]=t117,a[3]=t116,a[4]=t114,a[5]=t115,a[6]=((C_word)li159),tmp=(C_word)a,a+=7,tmp));
t119=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t120=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6867,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t120+1)))(3,t120,t119,*((C_word*)lf[395]+1));}

/* f_6867 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6867,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6857,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[394]+1));}

/* f_6857 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6857,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6847,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[393]+1));}

/* f_6847 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6847,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6837,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[392]+1));}

/* f_6837 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6837,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6827,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[391]+1));}

/* f_6827 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6827,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6817,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[390]+1));}

/* f_6817 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6817,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[389]+1));}

/* f_6807 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6807,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6797,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[388]+1));}

/* f_6797 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6797,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[387]+1));}

/* f_6787 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6787,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6777,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[386]+1));}

/* f_6777 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6777,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6767,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[385]+1));}

/* f_6767 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6767,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6757,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[384]+1));}

/* f_6757 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6757,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6747,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[383]+1));}

/* f_6747 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6747,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6737,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[382]+1));}

/* f_6737 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6737,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6727,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[381]+1));}

/* f_6727 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6727,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6717,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[380]+1));}

/* f_6717 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6717,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6707,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[379]+1));}

/* f_6707 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6707,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6697,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[378]+1));}

/* f_6697 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6697,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6687,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[377]+1));}

/* f_6687 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6687,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6677,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[376]+1));}

/* f_6677 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6677,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6667,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[375]+1));}

/* f_6667 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6667,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6657,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[374]+1));}

/* f_6657 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6657,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6647,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[373]+1));}

/* f_6647 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6647,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6637,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[372]+1));}

/* f_6637 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6637,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6627,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[371]+1));}

/* f_6627 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6627,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6617,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[370]+1));}

/* f_6617 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6617,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6607,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[369]+1));}

/* f_6607 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6607,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6597,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[368]+1));}

/* f_6597 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6597,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6587,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[367]+1));}

/* f_6587 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6587,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6577,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[366]+1));}

/* f_6577 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6577,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6567,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[365]+1));}

/* f_6567 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6567,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6557,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[364]+1));}

/* f_6557 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6557,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6547,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[363]+1));}

/* f_6547 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6547,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6537,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[362]+1));}

/* f_6537 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6537,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6527,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[361]+1));}

/* f_6527 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6527,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6517,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[360]+1));}

/* f_6517 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6517,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6507,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[359]+1));}

/* f_6507 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6507,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6497,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[358]+1));}

/* f_6497 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6497,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6487,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[357]+1));}

/* f_6487 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6487,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6477,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[356]+1));}

/* f_6477 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6477,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6467,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[355]+1));}

/* f_6467 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6467,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6457,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[354]+1));}

/* f_6457 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6457,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[353]+1));}

/* f_6447 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6447,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=C_set_block_item(lf[334] /* errno/wouldblock */,0,C_fix(0));
t3=C_mutate((C_word*)lf[335]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6426,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[336]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6429,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t5=C_set_block_item(lf[337] /* map/anonymous */,0,C_fix(0));
t6=C_set_block_item(lf[338] /* map/file */,0,C_fix(0));
t7=C_set_block_item(lf[339] /* map/fixed */,0,C_fix(0));
t8=C_set_block_item(lf[340] /* map/private */,0,C_fix(0));
t9=C_set_block_item(lf[341] /* map/shared */,0,C_fix(0));
t10=C_set_block_item(lf[342] /* open/fsync */,0,C_fix(0));
t11=C_set_block_item(lf[343] /* open/noctty */,0,C_fix(0));
t12=C_set_block_item(lf[344] /* open/nonblock */,0,C_fix(0));
t13=C_set_block_item(lf[345] /* open/sync */,0,C_fix(0));
t14=C_set_block_item(lf[346] /* perm/isgid */,0,C_fix(0));
t15=C_set_block_item(lf[347] /* perm/isuid */,0,C_fix(0));
t16=C_set_block_item(lf[348] /* perm/isvtx */,0,C_fix(0));
t17=C_set_block_item(lf[349] /* prot/exec */,0,C_fix(0));
t18=C_set_block_item(lf[350] /* prot/none */,0,C_fix(0));
t19=C_set_block_item(lf[351] /* prot/read */,0,C_fix(0));
t20=C_set_block_item(lf[352] /* prot/write */,0,C_fix(0));
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6429,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6426,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6076r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6076r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6076r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li154),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6217,a[2]=t5,a[3]=((C_word)li155),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6222,a[2]=t6,a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6227,a[2]=t7,a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action18721957 */
t9=t8;
f_6227(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id18731953 */
t11=t7;
f_6222(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit18741948 */
t13=t6;
f_6217(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body18701880 */
t15=t5;
f_6078(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-action1872 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_6227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6227,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6233,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp);
/* def-id18731953 */
t3=((C_word*)t0)[2];
f_6222(t3,t1,t2);}

/* a6232 in def-action1872 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6233,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1873 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_6222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6222,NULL,3,t0,t1,t2);}
/* def-limit18741948 */
t3=((C_word*)t0)[2];
f_6217(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1874 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_6217(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6217,NULL,4,t0,t1,t2,t3);}
/* body18701880 */
t4=((C_word*)t0)[2];
f_6078(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6078,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[327]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6085(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6212,a[2]=t4,a[3]=t7,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6085(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6204,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));}}

/* f_6204 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6212 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_6085(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6085,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2051 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[333]);}

/* k6190 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2051 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6095,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6097,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li151),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6097(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6097,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2057 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2058 pathname-file */
t3=*((C_word*)lf[332]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2064 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k6176 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6178,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2064 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2065 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6097(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6183 in k6176 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2064 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6097(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[328]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[329]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2058 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_6097(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2059 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6131,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6143,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li148),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li149),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6162,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[331]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2063 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_6097(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a6161 in k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6162,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a6147 in k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6156,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6160,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2062 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[330]);}

/* k6158 in a6147 in k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2062 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6154 in a6147 in k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2062 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6097(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6142 in k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k6139 in k6129 in k6170 in k6114 in loop in k6093 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2060 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6097(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6196 in k6083 in body1870 in find-files in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6196,3,t0,t1,t2);}
/* posixwin.scm: 2049 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6061,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6071,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2025 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6069 in current-user-name in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2026 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[116],lf[326]);}

/* system-information in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6041,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6056,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2016 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6054 in system-information in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2017 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[323],lf[325]);}

/* k6039 in system-information in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6045,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k6043 in k6039 in system-information in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6049,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k6047 in k6043 in k6039 in system-information in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6053,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k6051 in k6047 in k6043 in k6039 in system-information in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[324],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6018,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2006 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[321],lf[322]);}}

/* sleep in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6015,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_5955r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5955r(t0,t1,t2,t3);}}

static void C_ccall f_5955r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[318]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5976,a[2]=t5,a[3]=t2,a[4]=((C_word)li140),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=t2,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[2],t7);}}

/* a5981 in process-wait in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5982,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1988 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1990 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5990 in a5981 in process-wait in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1989 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[311],lf[318],lf[319],((C_word*)t0)[2]);}

/* a5975 in process-wait in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
/* posixwin.scm: 1985 ##sys#process-wait */
t2=*((C_word*)lf[317]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5943,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1978 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1979 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5863r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5863r(t0,t1,t2,t3);}}

static void C_ccall f_5863r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5865,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5870,a[2]=t4,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5875,a[2]=t5,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5880,a[2]=t6,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17651788 */
t8=t7;
f_5880(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17661784 */
t10=t6;
f_5875(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17671779 */
t12=t5;
f_5870(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17631773 */
t14=t4;
f_5865(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args1765 in process* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5880,NULL,2,t0,t1);}
/* def-env17661784 */
t2=((C_word*)t0)[2];
f_5875(t2,t1,C_SCHEME_FALSE);}

/* def-env1766 in process* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5875,NULL,3,t0,t1,t2);}
/* def-exactf17671779 */
t3=((C_word*)t0)[2];
f_5870(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1767 in process* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5870(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5870,NULL,4,t0,t1,t2,t3);}
/* body17631773 */
t4=((C_word*)t0)[2];
f_5865(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1763 in process* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5865(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5865,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1972 %process */
f_5721(t1,lf[316],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5783r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5783r(t0,t1,t2,t3);}}

static void C_ccall f_5783r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5785,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5790,a[2]=t4,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5795,a[2]=t5,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5800,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17101733 */
t8=t7;
f_5800(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17111729 */
t10=t6;
f_5795(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17121724 */
t12=t5;
f_5790(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17081718 */
t14=t4;
f_5785(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args1710 in process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5800,NULL,2,t0,t1);}
/* def-env17111729 */
t2=((C_word*)t0)[2];
f_5795(t2,t1,C_SCHEME_FALSE);}

/* def-env1711 in process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5795(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5795,NULL,3,t0,t1,t2);}
/* def-exactf17121724 */
t3=((C_word*)t0)[2];
f_5790(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1712 in process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5790(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5790,NULL,4,t0,t1,t2,t3);}
/* body17081718 */
t4=((C_word*)t0)[2];
f_5785(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1708 in process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5785(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5785,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1969 %process */
f_5721(t1,lf[315],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5721(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5721,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5723,a[2]=t2,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5742,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1957 chkstrlst */
t14=t11;
f_5723(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5777,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1960 ##sys#shell-command-arguments */
t16=*((C_word*)lf[302]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,((C_word*)t8)[1]);}}

/* k5775 in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5777,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1961 ##sys#shell-command */
t4=*((C_word*)lf[298]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5779 in k5775 in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5742(2,t3,t2);}

/* k5740 in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1962 chkstrlst */
t3=((C_word*)t0)[2];
f_5723(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_5745(2,t3,C_SCHEME_UNDEFINED);}}

/* k5743 in k5740 in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li126),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[4],a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5755 in k5743 in k5740 in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5756,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1965 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1966 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5749 in k5743 in k5740 in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
/* posixwin.scm: 1963 ##sys#process */
t2=*((C_word*)lf[306]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5723,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5732,a[2]=((C_word*)t0)[2],a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5731 in chkstrlst in %process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5732,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_5602r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_5602r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_5602r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5606,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_5606(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_5606(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[2],t9);}}}

/* k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5697,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1929 $quote-args-list */
t5=lf[287];
f_5092(t5,t3,t4,t1);}

/* k5695 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1929 string-intersperse */
t2=*((C_word*)lf[114]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(*((C_word*)lf[307]+1)))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(*((C_word*)lf[308]+1)))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(*((C_word*)lf[309]+1)))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(*((C_word*)lf[310]+1)))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t15=*((C_word*)lf[313]+1);
((C_proc6)C_retrieve_proc(t15))(6,t15,t14,t2,C_fix(0),C_SCHEME_FALSE,lf[314]);}

/* k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[313]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[314]);}

/* k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[313]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[314]);}

/* k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[313]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[314]);}

/* k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1936 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5681,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5544,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5544(2,t9,C_SCHEME_FALSE);}}

/* k5542 in k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5548(2,t3,C_SCHEME_FALSE);}}

/* k5546 in k5542 in k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub1540(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1939 open-input-file* */
t8=*((C_word*)lf[237]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_5638(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1944 ##sys#update-errno */
t8=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5656 in k5546 in k5542 in k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1945 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[311],((C_word*)t0)[3],lf[312],((C_word*)t0)[2]);}

/* k5636 in k5546 in k5542 in k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1940 open-output-file* */
t3=*((C_word*)lf[238]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5642(2,t3,C_SCHEME_FALSE);}}

/* k5640 in k5636 in k5546 in k5542 in k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1942 open-input-file* */
t3=*((C_word*)lf[237]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5646(2,t3,C_SCHEME_FALSE);}}

/* k5644 in k5640 in k5636 in k5546 in k5542 in k5679 in k5675 in k5671 in k5667 in k5663 in k5607 in k5604 in ##sys#process in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1938 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5536,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1526(C_SCHEME_UNDEFINED,t2));}

/* process-run in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5507r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5507r(t0,t1,t2,t3);}}

static void C_ccall f_5507r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1897 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[283]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5524,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1898 ##sys#shell-command */
t7=*((C_word*)lf[298]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k5522 in process-run in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5528,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1898 ##sys#shell-command-arguments */
t3=*((C_word*)lf[302]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5526 in k5522 in process-run in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1898 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[283]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5501,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[303],t2));}

/* ##sys#shell-command in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1881 getenv */
t3=*((C_word*)lf[300]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[301]);}

/* k5482 in ##sys#shell-command in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1885 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k5494 in k5482 in ##sys#shell-command in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1886 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[298],lf[299]);}

/* current-process-id in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1494(C_SCHEME_UNDEFINED));}

/* process-spawn in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5390r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5390r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5390r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5392,a[2]=t3,a[3]=t2,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5404,a[2]=t5,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5409,a[2]=t6,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t7,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst14551480 */
t9=t8;
f_5414(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst14561476 */
t11=t7;
f_5409(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf14571471 */
t13=t6;
f_5404(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body14531463 */
t15=t5;
f_5392(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-arglst1455 in process-spawn in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5414,NULL,2,t0,t1);}
/* def-envlst14561476 */
t2=((C_word*)t0)[2];
f_5409(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1456 in process-spawn in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5409,NULL,3,t0,t1,t2);}
/* def-exactf14571471 */
t3=((C_word*)t0)[2];
f_5404(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1457 in process-spawn in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5404(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5404,NULL,4,t0,t1,t2,t3);}
/* body14531463 */
t4=((C_word*)t0)[2];
f_5392(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1453 in process-spawn in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5392(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5392,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5396,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1872 $exec-setup */
t6=lf[291];
f_5255(t6,t5,lf[295],((C_word*)t0)[2],t2,t3,t4);}

/* k5394 in body1453 in process-spawn in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1873 $exec-teardown */
f_5288(((C_word*)t0)[3],lf[295],lf[296],((C_word*)t0)[2],t2);}

/* process-execute in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_5303r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5303r(t0,t1,t2,t3);}}

static void C_ccall f_5303r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t2,a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5317,a[2]=t4,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5322,a[2]=t5,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5327,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst13951420 */
t8=t7;
f_5327(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst13961416 */
t10=t6;
f_5322(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf13971411 */
t12=t5;
f_5317(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body13931403 */
t14=t4;
f_5305(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-arglst1395 in process-execute in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5327,NULL,2,t0,t1);}
/* def-envlst13961416 */
t2=((C_word*)t0)[2];
f_5322(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1396 in process-execute in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5322,NULL,3,t0,t1,t2);}
/* def-exactf13971411 */
t3=((C_word*)t0)[2];
f_5317(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1397 in process-execute in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5317,NULL,4,t0,t1,t2,t3);}
/* body13931403 */
t4=((C_word*)t0)[2];
f_5305(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1393 in process-execute in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5305,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1867 $exec-setup */
t6=lf[291];
f_5255(t6,t5,lf[293],((C_word*)t0)[2],t2,t3,t4);}

/* k5307 in body1393 in process-execute in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1868 $exec-teardown */
f_5288(((C_word*)t0)[3],lf[293],lf[294],((C_word*)t0)[2],t2);}

/* $exec-teardown in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5288(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5288,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5292,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1859 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5290 in $exec-teardown in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1863 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5255(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5255,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5262,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1851 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5260 in $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1852 setarg */
t4=((C_word*)t0)[4];
f_5171(5,t4,t2,C_fix(0),t1,t3);}

/* k5263 in k5260 in $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1853 $quote-args-list */
t4=lf[287];
f_5092(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5280 in k5263 in k5260 in $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1853 build-exec-argvec */
f_5205(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k5266 in k5263 in k5260 in $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1854 build-exec-argvec */
f_5205(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k5269 in k5266 in k5263 in k5260 in $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1856 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5276 in k5269 in k5266 in k5263 in k5260 in $exec-setup in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1856 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5205(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5205,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5217,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5217(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1848 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop1333 in build-exec-argvec in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5217(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5217,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1844 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5236,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1847 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k5234 in doloop1333 in build-exec-argvec in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5217(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5188,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1319(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5171,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1307(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5092,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li99),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5135,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5135(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5135(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5135,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1825 reverse */
t4=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5163,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5166,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1830 needs-quoting? */
t8=((C_word*)t0)[2];
f_5097(t8,t7,t4);}}

/* k5164 in loop in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1830 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[288],((C_word*)t0)[2],lf[289]);}
else{
t2=((C_word*)t0)[3];
f_5163(2,t2,((C_word*)t0)[2]);}}

/* k5161 in loop in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1827 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5135(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5097,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5101,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1817 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5099 in needs-quoting? in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5101,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li98),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5106(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5099 in needs-quoting? in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5106,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5130,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1821 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k5128 in loop in k5099 in needs-quoting? in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1821 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5117 in loop in k5099 in needs-quoting? in $quote-args-list in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1822 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5106(t3,((C_word*)t0)[4],t2);}}

/* glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4977r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4977r(t0,t1,t2);}}

static void C_ccall f_4977r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li96),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_4983(t6,t1,t2);}

/* conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4983,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4998,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li95),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5004,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5081,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[280]);
/* posixwin.scm: 1778 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5079 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1778 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1779 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1780 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5012 in k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[279]);
/* posixwin.scm: 1781 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5019 in k5012 in k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li94),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5023(t5,((C_word*)t0)[2],t1);}

/* loop in k5019 in k5012 in k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_5023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5023,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1782 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4983(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1783 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5038 in loop in k5019 in k5012 in k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5040,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1784 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1785 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5023(t3,((C_word*)t0)[6],t2);}}

/* k5048 in k5038 in loop in k5019 in k5012 in k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5054,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1784 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5023(t4,t2,t3);}

/* k5052 in k5048 in k5038 in loop in k5019 in k5012 in k5009 in k5006 in a5003 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5054,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4997 in conc-loop in glob in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4998,2,t0,t1);}
/* posixwin.scm: 1777 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4918r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4918r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4918r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4922,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1748 ##sys#check-port */
t6=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[266]);}

/* k4920 in set-buffering-mode! in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t6)){
t7=t5;
f_4928(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[269]);
if(C_truep(t7)){
t8=t5;
f_4928(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[270]);
if(C_truep(t8)){
t9=t5;
f_4928(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1754 ##sys#error */
t9=*((C_word*)lf[62]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[266],lf[271],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4926 in k4920 in set-buffering-mode! in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[266]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[81],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1760 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[266],lf[267],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4912,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4916,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1738 ##sys#check-port */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[265]);}

/* k4914 in terminal-port? in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4896r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4896r(t0,t1,t2);}}

static void C_ccall f_4896r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1142(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4884,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1134(t2),C_fix(0));}

/* local-time->seconds in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4856,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[259]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4863,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1720 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[259],lf[262],t2);}
else{
t6=t4;
f_4863(2,t6,C_SCHEME_UNDEFINED);}}

/* k4861 in local-time->seconds in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1722 ##sys#cons-flonum */
t2=*((C_word*)lf[260]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1723 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[259],lf[261],((C_word*)t0)[3]);}}

/* time->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4776r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4776r(t0,t1,t2,t3);}}

static void C_ccall f_4776r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4780,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4780(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4780(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k4778 in time->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4780,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[255]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixwin.scm: 1707 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[255],lf[258],((C_word*)t0)[3]);}
else{
t5=t3;
f_4786(2,t5,C_SCHEME_UNDEFINED);}}

/* k4784 in k4778 in time->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4786,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[255]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4805,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1711 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1077(t4,t3),C_fix(0));}}

/* k4806 in k4784 in k4778 in time->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1715 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1716 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[257],((C_word*)t0)[2]);}}

/* k4803 in k4784 in k4778 in time->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1085(t3,t2,t1),C_fix(0));}

/* k4793 in k4784 in k4778 in time->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1712 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[256],((C_word*)t0)[2]);}}

/* seconds->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4743,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4747,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub1062(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4745 in seconds->string in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1699 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1700 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[253],lf[254],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4724,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[252]);
/* posixwin.scm: 1692 ##sys#decode-seconds */
t4=*((C_word*)lf[251]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4715,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[250]);
/* posixwin.scm: 1688 ##sys#decode-seconds */
t4=*((C_word*)lf[251]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4655(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4655,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4659,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1026(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4657 in loop in get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4667,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li81),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4667(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4657 in loop in get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4667(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4667,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1678 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1679 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4691 in scan in k4657 in loop in get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1678 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k4695 in k4691 in scan in k4657 in loop in get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4685,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1678 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4655(t5,t3,t4);}

/* k4683 in k4695 in k4691 in scan in k4657 in loop in get-environment-variables in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4629,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[246]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1666 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4635 in unsetenv in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4612,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[245]);
t5=(C_word)C_i_check_string_2(t3,lf[245]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4623,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1661 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4621 in setenv in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1661 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4625 in k4621 in setenv in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4582r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4582r(t0,t1,t2,t3);}}

static void C_ccall f_4582r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[243]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4589,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4589(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[243]);
t8=t5;
f_4589(t8,(C_word)C_dup2(t2,t6));}}

/* k4587 in duplicate-fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4589,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4592,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1650 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4592(2,t3,C_SCHEME_UNDEFINED);}}

/* k4596 in k4587 in duplicate-fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1651 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[243],lf[244],((C_word*)t0)[2]);}

/* k4590 in k4587 in duplicate-fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4551,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1632 ##sys#check-port */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[239]);}

/* k4549 in port->fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1633 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4578 in k4549 in port->fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1639 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[239],lf[240],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4560,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1636 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4560(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4564 in k4578 in k4549 in port->fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1637 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[239],lf[241],((C_word*)t0)[2]);}

/* k4558 in k4578 in k4549 in port->fileno in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4533r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4533r(t0,t1,t2,t3);}}

static void C_ccall f_4533r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[238]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1628 mode */
f_4464(t5,C_SCHEME_FALSE,t3);}

/* k4543 in open-output-file* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1628 check */
f_4501(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4519r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4519r(t0,t1,t2,t3);}}

static void C_ccall f_4519r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[237]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4531,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1624 mode */
f_4464(t5,C_SCHEME_TRUE,t3);}

/* k4529 in open-input-file* in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1624 check */
f_4501(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4501(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4501,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4505,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1615 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4503 in check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1617 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[235],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1618 ##sys#make-port */
t3=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[136]+1),lf[236],lf[81]);}}

/* k4515 in k4503 in check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4464(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4464,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4472,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[229]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1610 ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[230],t5);}
else{
t8=t4;
f_4472(2,t8,lf[231]);}}
else{
/* posixwin.scm: 1611 ##sys#error */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[232],t5);}}
else{
t5=t4;
f_4472(2,t5,(C_truep(t2)?lf[233]:lf[234]));}}

/* k4470 in mode in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1606 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4455,3,t0,t1,t2);}
/* posixwin.scm: 1590 check */
f_4419(t1,t2,C_fix((C_word)2),lf[225]);}

/* file-write-access? in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4449,3,t0,t1,t2);}
/* posixwin.scm: 1589 check */
f_4419(t1,t2,C_fix((C_word)4),lf[224]);}

/* file-read-access? in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4443,3,t0,t1,t2);}
/* posixwin.scm: 1588 check */
f_4419(t1,t2,C_fix((C_word)2),lf[223]);}

/* check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4419(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4419,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1585 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k4439 in check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1585 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4435 in check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4429,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4429(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1586 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4427 in k4435 in check in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4389,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[221]);
t5=(C_word)C_i_check_exact_2(t3,lf[221]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4413,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1574 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k4415 in change-file-mode in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1574 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4411 in change-file-mode in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1575 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4403 in k4411 in change-file-mode in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1576 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[221],lf[222],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4333,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4343,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1482 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1484 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4341 in ##sys#interrupt-hook in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1483 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4320,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[182]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4307 in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4311,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[181]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4235r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4235r(t0,t1,t2);}}

static void C_ccall f_4235r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4239(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4239(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k4237 in create-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4251,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1419 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4242(2,t3,C_SCHEME_UNDEFINED);}}

/* k4249 in k4237 in create-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1420 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[151],lf[152]);}

/* k4240 in k4237 in create-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1421 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4215r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4215r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4215r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[150]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4219,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4217 in with-output-to-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
t2=C_mutate((C_word*)lf[150]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4225,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1404 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4224 in k4217 in with-output-to-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4225r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4225r(t0,t1,t2);}}

static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4229,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1406 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4227 in a4224 in k4217 in with-output-to-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[150]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4195r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4195r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4195r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[148]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4199,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4197 in with-input-from-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4205,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1394 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4204 in k4197 in with-input-from-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4205r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4205r(t0,t1,t2);}}

static void C_ccall f_4205r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4209,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1396 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4207 in a4204 in k4197 in with-input-from-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4171r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4171r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4171r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4175,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4173 in call-with-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4186,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1384 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4185 in k4173 in call-with-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4186r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4186r(t0,t1,t2);}}

static void C_ccall f_4186r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4190,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1387 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4188 in a4185 in k4173 in call-with-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4179 in k4173 in call-with-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
/* posixwin.scm: 1385 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4147r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4147r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4147r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4151,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4149 in call-with-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4156,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4162,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1376 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4161 in k4149 in call-with-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4162r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4162r(t0,t1,t2);}}

static void C_ccall f_4162r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4166,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1379 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4164 in a4161 in k4149 in call-with-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4155 in k4149 in call-with-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
/* posixwin.scm: 1377 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4132,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1363 ##sys#check-port */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[141]);}

/* k4130 in close-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1365 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4133 in k4130 in close-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1366 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[141],lf[142],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4092r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4092r(t0,t1,t2,t3);}}

static void C_ccall f_4092r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[140]);
t5=f_4020(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4106,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[132]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4113,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1358 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4123,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1359 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1360 badmode */
f_4032(t6,t5);}}}

/* k4121 in open-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4123,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4106(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4111 in open-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4106(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4104 in open-output-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1355 check */
f_4038(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4056r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4056r(t0,t1,t2,t3);}}

static void C_ccall f_4056r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[138]);
t5=f_4020(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[132]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1348 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4087,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1349 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1350 badmode */
f_4032(t6,t5);}}}

/* k4085 in open-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4070(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4075 in open-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4070(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4068 in open-input-pipe in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1345 check */
f_4038(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4038(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4038,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4042,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1335 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4040 in check in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1337 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[134],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1338 ##sys#make-port */
t3=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[136]+1),lf[137],lf[81]);}}

/* k4052 in k4040 in check in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_4032(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4032,NULL,2,t1,t2);}
/* posixwin.scm: 1333 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[133],t2);}

/* mode in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static C_word C_fcall f_4020(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[132]));}

/* canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3663,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3670,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3803,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1272 cwd */
t8=((C_word*)t0)[5];
f_3607(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1274 sref */
t10=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3809(t9,C_SCHEME_FALSE);}}}

/* k4008 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1274 sep? */
t2=((C_word*)t0)[3];
f_3809(t2,f_3596(t1));}

/* k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1276 cwd */
t4=((C_word*)t0)[7];
f_3607(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1279 cwd */
t5=((C_word*)t0)[7];
f_3607(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3996,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1280 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3994 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1280 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3983 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1281 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3839(t2,C_SCHEME_FALSE);}}

/* k3990 in k3983 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1281 sep? */
t2=((C_word*)t0)[3];
f_3839(t2,f_3596(t1));}

/* k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3839,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3862,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1283 cwd */
t4=((C_word*)t0)[6];
f_3607(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1289 cwd */
t5=((C_word*)t0)[6];
f_3607(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3978,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1290 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3976 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3955 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1291 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_3881(t2,C_SCHEME_FALSE);}}

/* k3972 in k3955 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1291 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3961 in k3955 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1292 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_3881(t2,C_SCHEME_FALSE);}}

/* k3968 in k3961 in k3955 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1292 sep? */
t2=((C_word*)t0)[3];
f_3881(t2,f_3596(t1));}

/* k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3881,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_3670(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1294 sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3952 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1294 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3931 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3950,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1295 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3887(2,t2,C_SCHEME_FALSE);}}

/* k3948 in k3931 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1295 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3937 in k3931 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1296 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3887(2,t2,C_SCHEME_FALSE);}}

/* k3944 in k3937 in k3931 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1298 ##sys#substring */
t3=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1302 sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k3928 in k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=f_3596(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1304 cwd */
t5=((C_word*)t0)[2];
f_3607(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1307 cwd */
t4=((C_word*)t0)[2];
f_3607(t4,t3);}}

/* k3924 in k3928 in k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1307 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[131],((C_word*)t0)[2]);}

/* k3917 in k3928 in k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3913 in k3928 in k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3892 in k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3898,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1300 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3896 in k3892 in k3885 in k3879 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[130],t1);}

/* k3873 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1289 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[129],((C_word*)t0)[2]);}

/* k3860 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3844 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1285 user */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3848 in k3844 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3854,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1286 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3852 in k3848 in k3844 in k3837 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1282 sappend */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],t1);}

/* k3831 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1279 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[127],((C_word*)t0)[2]);}

/* k3818 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1276 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3814 in k3807 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3801 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1272 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[126]);}

/* k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1308 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t1,C_fix(3),t4);}

/* k3787 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[125]);}

/* k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3679(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3679(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3679,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1310 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1311 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3758,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1322 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[124],t5);}}

/* k3759 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3758(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1324 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[123],t3);}}

/* k3768 in k3759 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3758(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3758(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3756 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1320 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3679(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1312 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1313 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=f_3596(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1315 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1318 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k3725 in k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3731,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3735,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1319 reverse */
t4=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3733 in k3725 in k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1319 isperse */
f_3591(((C_word*)t0)[2],t1);}

/* k3729 in k3725 in k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1317 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3706 in k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3712,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3716,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[121],((C_word*)t0)[2]);
/* posixwin.scm: 1316 reverse */
t5=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3714 in k3706 in k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1316 isperse */
f_3591(((C_word*)t0)[2],t1);}

/* k3710 in k3706 in k3737 in k3690 in k3684 in loop in k3675 in k3668 in canonical-path in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1314 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3607,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3616,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3622,a[2]=t2,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[119]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3639 in a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[3],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[2],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3651 in a3639 in a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3652r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3652r(t0,t1,t2);}}

static void C_ccall f_3652r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3658,a[2]=t2,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* k572578 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3657 in a3651 in a3639 in a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3658,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3645 in a3639 in a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3646,2,t0,t1);}
/* posixwin.scm: 1267 cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3621 in a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3622,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3628,a[2]=t2,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* k572578 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3627 in a3621 in a3615 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[117]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[118]);}

/* k3612 in cwd in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static C_word C_fcall f_3596(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3591(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3591,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[114]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[115]);}

/* current-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3540r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3540r(t0,t1,t2);}}

static void C_ccall f_3540r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3544(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3544(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k3542 in current-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1245 change-directory */
t2=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1246 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3551 in k3542 in current-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3556,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1248 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3554 in k3551 in k3542 in current-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1250 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1251 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[105],lf[108]);}}

/* directory? in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3513,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3534,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1238 ##sys#expand-home-path */
t7=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k3536 in directory? in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1238 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[107]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3532 in directory? in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1237 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3518 in directory? in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_3353r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3353r(t0,t1,t2);}}

static void C_ccall f_3353r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t3,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3461,a[2]=t4,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec419477 */
t6=t5;
f_3461(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?420473 */
t8=t4;
f_3456(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body417426 */
t10=t3;
f_3355(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[2],t9);}}}}

/* def-spec419 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3461,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1208 current-directory */
t3=*((C_word*)lf[105]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3467 in def-spec419 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?420473 */
t2=((C_word*)t0)[3];
f_3456(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?420 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3456,NULL,3,t0,t1,t2);}
/* body417426 */
t3=((C_word*)t0)[2];
f_3355(t3,t1,t2,C_SCHEME_FALSE);}

/* body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3355(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3355,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3362,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1210 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1211 ##sys#make-pointer */
t3=*((C_word*)lf[104]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1212 ##sys#make-pointer */
t3=*((C_word*)lf[104]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1213 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3453 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1213 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3370 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1216 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li29),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3389(t6,((C_word*)t0)[6]);}}

/* loop in k3370 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3389,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1225 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k3397 in loop in k3370 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3411,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_3411(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_3411(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_3411(t7,C_SCHEME_FALSE);}}

/* k3409 in k3397 in loop in k3370 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3411,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1232 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3389(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1233 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3389(t3,t2);}}

/* k3419 in k3409 in k3397 in loop in k3370 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3379 in k3370 in k3366 in k3363 in k3360 in body417 in directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1217 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[102],lf[103],((C_word*)t0)[2]);}

/* delete-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3326,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[99]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3351,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1200 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3349 in delete-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1200 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3345 in delete-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1201 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3337 in k3345 in delete-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1202 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[99],lf[100],((C_word*)t0)[2]);}

/* change-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3299,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3324,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1193 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3322 in change-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1193 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3318 in change-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1194 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3310 in k3318 in change-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1195 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[97],lf[98],((C_word*)t0)[2]);}

/* create-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3159r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3159r(t0,t1,t2,t3);}}

static void C_ccall f_3159r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3163,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3163(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3163(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k3161 in create-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3163,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[89]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1181 canonical-path */
t4=*((C_word*)lf[96]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1182 canonical-path */
t4=*((C_word*)lf[96]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}

/* k3257 in k3161 in create-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3260 in k3257 in k3161 in create-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3260,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3278,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1152 ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3276 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3268 in k3276 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1154 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* k3174 in k3161 in create-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3177 in k3174 in k3161 in create-directory in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3177,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1169 string-split */
t4=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[95]);}

/* k3179 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=t4,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t1);
/* for-each */
t7=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a3188 in k3179 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3189,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3194,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1173 string-append */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[92],t2);}

/* k3192 in a3188 in k3179 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_3198 in k3192 in a3188 in k3179 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3198,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3205,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3228 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3228,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1158 file-exists? */
t4=*((C_word*)lf[91]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3233 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1159 ##sys#file-info */
t3=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3236 in k3233 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3203 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_3209 in k3203 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3209,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3227,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1152 ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3225 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3217 in k3225 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1154 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* set-file-position! in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3098r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3098r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3098r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[84]);
t8=(C_word)C_i_check_exact_2(t6,lf[84]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3111,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1139 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[87],lf[84],lf[88],t3,t2);}
else{
t10=t9;
f_3111(2,t10,C_SCHEME_UNDEFINED);}}

/* k3109 in set-file-position! in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1140 port? */
t4=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3124 in k3109 in set-file-position! in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[4];
f_3117(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3117(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1144 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[84],lf[86],((C_word*)t0)[5]);}}}

/* k3115 in k3109 in set-file-position! in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1145 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3118 in k3115 in k3109 in set-file-position! in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1146 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[84],lf[85],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3077,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1123 port? */
t5=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3075 in file-position in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[2];
f_3062(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_3062(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1128 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[79],lf[82],((C_word*)t0)[3]);}}}

/* k3060 in file-position in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3065,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1130 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3065(2,t3,C_SCHEME_UNDEFINED);}}

/* k3069 in k3060 in file-position in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1131 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[79],lf[80],((C_word*)t0)[2]);}

/* k3063 in k3060 in file-position in k3054 in k3050 in k3046 in k3042 in k3038 in k3034 in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_3025(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3025,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));}

/* f_3027 in stat-type in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3027,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3020,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2997,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3004,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3018,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1101 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3016 in regular-file? in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1101 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3002 in regular-file? in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2991,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_2892(t3,t2);}

/* k2993 in file-permissions in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2892(t3,t2);}

/* k2987 in file-owner in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2979,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_2892(t3,t2);}

/* k2981 in file-change-time in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2973,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_2892(t3,t2);}

/* k2975 in file-access-time in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2977,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2967,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1093 ##sys#stat */
f_2892(t3,t2);}

/* k2969 in file-modification-time in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2961,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1092 ##sys#stat */
f_2892(t3,t2);}

/* k2963 in file-size in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2930r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2930r(t0,t1,t2,t3);}}

static void C_ccall f_2930r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2934,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2934(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2934(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k2932 in file-stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1086 ##sys#stat */
f_2892(t2,((C_word*)t0)[2]);}

/* k2935 in k2932 in file-stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_fcall f_2892(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2892,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2896(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1079 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1080 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k2923 in ##sys#stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1079 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2919 in ##sys#stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2896(2,t2,(C_word)C_stat(t1));}

/* k2894 in ##sys#stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1082 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2903 in k2894 in ##sys#stat in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1083 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2854,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1048 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2859 in file-mkstemp in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1050 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2862 in k2859 in file-mkstemp in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1052 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2867(2,t4,C_SCHEME_UNDEFINED);}}

/* k2882 in k2862 in k2859 in file-mkstemp in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1053 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k2865 in k2862 in k2859 in file-mkstemp in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1054 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2872 in k2865 in k2862 in k2859 in file-mkstemp in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1054 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2812r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2812r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2819,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2819(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1035 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k2817 in file-write in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2828,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2834,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1040 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2828(2,t8,C_SCHEME_UNDEFINED);}}

/* k2832 in k2817 in file-write in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1041 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2826 in k2817 in file-write in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2767r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2767r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2767r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2777,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2777(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1022 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2775 in file-read in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2780(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1024 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k2778 in k2775 in file-read in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2783,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1027 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2783(2,t5,C_SCHEME_UNDEFINED);}}

/* k2790 in k2778 in k2775 in file-read in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1028 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2781 in k2778 in k2775 in file-read in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2749,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2762,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1014 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2760 in file-close in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1015 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2708r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2708r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2725,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2741,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1004 ##sys#expand-home-path */
t12=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k2739 in file-open in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1004 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2723 in file-open in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1006 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2728(2,t5,C_SCHEME_UNDEFINED);}}

/* k2732 in k2723 in file-open in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1007 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2726 in k2723 in file-open in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2662r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2662r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2662r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2666,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 935  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2664 in posix-error in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2675 in k2664 in posix-error in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 936  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k2671 in k2664 in posix-error in k2648 in k2645 in k2642 in k2639 in k2636 in k2633 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[508] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_2635posixwin.scm",(void*)f_2635},
{"f_2638posixwin.scm",(void*)f_2638},
{"f_2641posixwin.scm",(void*)f_2641},
{"f_2644posixwin.scm",(void*)f_2644},
{"f_2647posixwin.scm",(void*)f_2647},
{"f_2650posixwin.scm",(void*)f_2650},
{"f_3036posixwin.scm",(void*)f_3036},
{"f_3040posixwin.scm",(void*)f_3040},
{"f_3044posixwin.scm",(void*)f_3044},
{"f_3048posixwin.scm",(void*)f_3048},
{"f_3052posixwin.scm",(void*)f_3052},
{"f_3056posixwin.scm",(void*)f_3056},
{"f_4309posixwin.scm",(void*)f_4309},
{"f_6867posixwin.scm",(void*)f_6867},
{"f_6297posixwin.scm",(void*)f_6297},
{"f_6857posixwin.scm",(void*)f_6857},
{"f_6300posixwin.scm",(void*)f_6300},
{"f_6847posixwin.scm",(void*)f_6847},
{"f_6303posixwin.scm",(void*)f_6303},
{"f_6837posixwin.scm",(void*)f_6837},
{"f_6306posixwin.scm",(void*)f_6306},
{"f_6827posixwin.scm",(void*)f_6827},
{"f_6309posixwin.scm",(void*)f_6309},
{"f_6817posixwin.scm",(void*)f_6817},
{"f_6312posixwin.scm",(void*)f_6312},
{"f_6807posixwin.scm",(void*)f_6807},
{"f_6315posixwin.scm",(void*)f_6315},
{"f_6797posixwin.scm",(void*)f_6797},
{"f_6318posixwin.scm",(void*)f_6318},
{"f_6787posixwin.scm",(void*)f_6787},
{"f_6321posixwin.scm",(void*)f_6321},
{"f_6777posixwin.scm",(void*)f_6777},
{"f_6324posixwin.scm",(void*)f_6324},
{"f_6767posixwin.scm",(void*)f_6767},
{"f_6327posixwin.scm",(void*)f_6327},
{"f_6757posixwin.scm",(void*)f_6757},
{"f_6330posixwin.scm",(void*)f_6330},
{"f_6747posixwin.scm",(void*)f_6747},
{"f_6333posixwin.scm",(void*)f_6333},
{"f_6737posixwin.scm",(void*)f_6737},
{"f_6336posixwin.scm",(void*)f_6336},
{"f_6727posixwin.scm",(void*)f_6727},
{"f_6339posixwin.scm",(void*)f_6339},
{"f_6717posixwin.scm",(void*)f_6717},
{"f_6342posixwin.scm",(void*)f_6342},
{"f_6707posixwin.scm",(void*)f_6707},
{"f_6345posixwin.scm",(void*)f_6345},
{"f_6697posixwin.scm",(void*)f_6697},
{"f_6348posixwin.scm",(void*)f_6348},
{"f_6687posixwin.scm",(void*)f_6687},
{"f_6351posixwin.scm",(void*)f_6351},
{"f_6677posixwin.scm",(void*)f_6677},
{"f_6354posixwin.scm",(void*)f_6354},
{"f_6667posixwin.scm",(void*)f_6667},
{"f_6357posixwin.scm",(void*)f_6357},
{"f_6657posixwin.scm",(void*)f_6657},
{"f_6360posixwin.scm",(void*)f_6360},
{"f_6647posixwin.scm",(void*)f_6647},
{"f_6363posixwin.scm",(void*)f_6363},
{"f_6637posixwin.scm",(void*)f_6637},
{"f_6366posixwin.scm",(void*)f_6366},
{"f_6627posixwin.scm",(void*)f_6627},
{"f_6369posixwin.scm",(void*)f_6369},
{"f_6617posixwin.scm",(void*)f_6617},
{"f_6372posixwin.scm",(void*)f_6372},
{"f_6607posixwin.scm",(void*)f_6607},
{"f_6375posixwin.scm",(void*)f_6375},
{"f_6597posixwin.scm",(void*)f_6597},
{"f_6378posixwin.scm",(void*)f_6378},
{"f_6587posixwin.scm",(void*)f_6587},
{"f_6381posixwin.scm",(void*)f_6381},
{"f_6577posixwin.scm",(void*)f_6577},
{"f_6384posixwin.scm",(void*)f_6384},
{"f_6567posixwin.scm",(void*)f_6567},
{"f_6387posixwin.scm",(void*)f_6387},
{"f_6557posixwin.scm",(void*)f_6557},
{"f_6390posixwin.scm",(void*)f_6390},
{"f_6547posixwin.scm",(void*)f_6547},
{"f_6393posixwin.scm",(void*)f_6393},
{"f_6537posixwin.scm",(void*)f_6537},
{"f_6396posixwin.scm",(void*)f_6396},
{"f_6527posixwin.scm",(void*)f_6527},
{"f_6399posixwin.scm",(void*)f_6399},
{"f_6517posixwin.scm",(void*)f_6517},
{"f_6402posixwin.scm",(void*)f_6402},
{"f_6507posixwin.scm",(void*)f_6507},
{"f_6405posixwin.scm",(void*)f_6405},
{"f_6497posixwin.scm",(void*)f_6497},
{"f_6408posixwin.scm",(void*)f_6408},
{"f_6487posixwin.scm",(void*)f_6487},
{"f_6411posixwin.scm",(void*)f_6411},
{"f_6477posixwin.scm",(void*)f_6477},
{"f_6414posixwin.scm",(void*)f_6414},
{"f_6467posixwin.scm",(void*)f_6467},
{"f_6417posixwin.scm",(void*)f_6417},
{"f_6457posixwin.scm",(void*)f_6457},
{"f_6420posixwin.scm",(void*)f_6420},
{"f_6447posixwin.scm",(void*)f_6447},
{"f_6423posixwin.scm",(void*)f_6423},
{"f_6429posixwin.scm",(void*)f_6429},
{"f_6426posixwin.scm",(void*)f_6426},
{"f_6076posixwin.scm",(void*)f_6076},
{"f_6227posixwin.scm",(void*)f_6227},
{"f_6233posixwin.scm",(void*)f_6233},
{"f_6222posixwin.scm",(void*)f_6222},
{"f_6217posixwin.scm",(void*)f_6217},
{"f_6078posixwin.scm",(void*)f_6078},
{"f_6204posixwin.scm",(void*)f_6204},
{"f_6212posixwin.scm",(void*)f_6212},
{"f_6085posixwin.scm",(void*)f_6085},
{"f_6192posixwin.scm",(void*)f_6192},
{"f_6095posixwin.scm",(void*)f_6095},
{"f_6097posixwin.scm",(void*)f_6097},
{"f_6116posixwin.scm",(void*)f_6116},
{"f_6178posixwin.scm",(void*)f_6178},
{"f_6185posixwin.scm",(void*)f_6185},
{"f_6172posixwin.scm",(void*)f_6172},
{"f_6131posixwin.scm",(void*)f_6131},
{"f_6162posixwin.scm",(void*)f_6162},
{"f_6148posixwin.scm",(void*)f_6148},
{"f_6160posixwin.scm",(void*)f_6160},
{"f_6156posixwin.scm",(void*)f_6156},
{"f_6143posixwin.scm",(void*)f_6143},
{"f_6141posixwin.scm",(void*)f_6141},
{"f_6196posixwin.scm",(void*)f_6196},
{"f_6061posixwin.scm",(void*)f_6061},
{"f_6071posixwin.scm",(void*)f_6071},
{"f_6030posixwin.scm",(void*)f_6030},
{"f_6056posixwin.scm",(void*)f_6056},
{"f_6041posixwin.scm",(void*)f_6041},
{"f_6045posixwin.scm",(void*)f_6045},
{"f_6049posixwin.scm",(void*)f_6049},
{"f_6053posixwin.scm",(void*)f_6053},
{"f_6018posixwin.scm",(void*)f_6018},
{"f_6015posixwin.scm",(void*)f_6015},
{"f_5955posixwin.scm",(void*)f_5955},
{"f_5982posixwin.scm",(void*)f_5982},
{"f_5992posixwin.scm",(void*)f_5992},
{"f_5976posixwin.scm",(void*)f_5976},
{"f_5943posixwin.scm",(void*)f_5943},
{"f_5863posixwin.scm",(void*)f_5863},
{"f_5880posixwin.scm",(void*)f_5880},
{"f_5875posixwin.scm",(void*)f_5875},
{"f_5870posixwin.scm",(void*)f_5870},
{"f_5865posixwin.scm",(void*)f_5865},
{"f_5783posixwin.scm",(void*)f_5783},
{"f_5800posixwin.scm",(void*)f_5800},
{"f_5795posixwin.scm",(void*)f_5795},
{"f_5790posixwin.scm",(void*)f_5790},
{"f_5785posixwin.scm",(void*)f_5785},
{"f_5721posixwin.scm",(void*)f_5721},
{"f_5777posixwin.scm",(void*)f_5777},
{"f_5781posixwin.scm",(void*)f_5781},
{"f_5742posixwin.scm",(void*)f_5742},
{"f_5745posixwin.scm",(void*)f_5745},
{"f_5756posixwin.scm",(void*)f_5756},
{"f_5750posixwin.scm",(void*)f_5750},
{"f_5723posixwin.scm",(void*)f_5723},
{"f_5732posixwin.scm",(void*)f_5732},
{"f_5602posixwin.scm",(void*)f_5602},
{"f_5606posixwin.scm",(void*)f_5606},
{"f_5697posixwin.scm",(void*)f_5697},
{"f_5609posixwin.scm",(void*)f_5609},
{"f_5665posixwin.scm",(void*)f_5665},
{"f_5669posixwin.scm",(void*)f_5669},
{"f_5673posixwin.scm",(void*)f_5673},
{"f_5677posixwin.scm",(void*)f_5677},
{"f_5681posixwin.scm",(void*)f_5681},
{"f_5544posixwin.scm",(void*)f_5544},
{"f_5548posixwin.scm",(void*)f_5548},
{"f_5658posixwin.scm",(void*)f_5658},
{"f_5638posixwin.scm",(void*)f_5638},
{"f_5642posixwin.scm",(void*)f_5642},
{"f_5646posixwin.scm",(void*)f_5646},
{"f_5536posixwin.scm",(void*)f_5536},
{"f_5507posixwin.scm",(void*)f_5507},
{"f_5524posixwin.scm",(void*)f_5524},
{"f_5528posixwin.scm",(void*)f_5528},
{"f_5501posixwin.scm",(void*)f_5501},
{"f_5480posixwin.scm",(void*)f_5480},
{"f_5484posixwin.scm",(void*)f_5484},
{"f_5496posixwin.scm",(void*)f_5496},
{"f_5477posixwin.scm",(void*)f_5477},
{"f_5390posixwin.scm",(void*)f_5390},
{"f_5414posixwin.scm",(void*)f_5414},
{"f_5409posixwin.scm",(void*)f_5409},
{"f_5404posixwin.scm",(void*)f_5404},
{"f_5392posixwin.scm",(void*)f_5392},
{"f_5396posixwin.scm",(void*)f_5396},
{"f_5303posixwin.scm",(void*)f_5303},
{"f_5327posixwin.scm",(void*)f_5327},
{"f_5322posixwin.scm",(void*)f_5322},
{"f_5317posixwin.scm",(void*)f_5317},
{"f_5305posixwin.scm",(void*)f_5305},
{"f_5309posixwin.scm",(void*)f_5309},
{"f_5288posixwin.scm",(void*)f_5288},
{"f_5292posixwin.scm",(void*)f_5292},
{"f_5255posixwin.scm",(void*)f_5255},
{"f_5262posixwin.scm",(void*)f_5262},
{"f_5265posixwin.scm",(void*)f_5265},
{"f_5282posixwin.scm",(void*)f_5282},
{"f_5268posixwin.scm",(void*)f_5268},
{"f_5271posixwin.scm",(void*)f_5271},
{"f_5278posixwin.scm",(void*)f_5278},
{"f_5205posixwin.scm",(void*)f_5205},
{"f_5217posixwin.scm",(void*)f_5217},
{"f_5236posixwin.scm",(void*)f_5236},
{"f_5188posixwin.scm",(void*)f_5188},
{"f_5171posixwin.scm",(void*)f_5171},
{"f_5092posixwin.scm",(void*)f_5092},
{"f_5135posixwin.scm",(void*)f_5135},
{"f_5166posixwin.scm",(void*)f_5166},
{"f_5163posixwin.scm",(void*)f_5163},
{"f_5097posixwin.scm",(void*)f_5097},
{"f_5101posixwin.scm",(void*)f_5101},
{"f_5106posixwin.scm",(void*)f_5106},
{"f_5130posixwin.scm",(void*)f_5130},
{"f_5119posixwin.scm",(void*)f_5119},
{"f_4977posixwin.scm",(void*)f_4977},
{"f_4983posixwin.scm",(void*)f_4983},
{"f_5004posixwin.scm",(void*)f_5004},
{"f_5081posixwin.scm",(void*)f_5081},
{"f_5008posixwin.scm",(void*)f_5008},
{"f_5011posixwin.scm",(void*)f_5011},
{"f_5014posixwin.scm",(void*)f_5014},
{"f_5021posixwin.scm",(void*)f_5021},
{"f_5023posixwin.scm",(void*)f_5023},
{"f_5040posixwin.scm",(void*)f_5040},
{"f_5050posixwin.scm",(void*)f_5050},
{"f_5054posixwin.scm",(void*)f_5054},
{"f_4998posixwin.scm",(void*)f_4998},
{"f_4918posixwin.scm",(void*)f_4918},
{"f_4922posixwin.scm",(void*)f_4922},
{"f_4928posixwin.scm",(void*)f_4928},
{"f_4912posixwin.scm",(void*)f_4912},
{"f_4916posixwin.scm",(void*)f_4916},
{"f_4896posixwin.scm",(void*)f_4896},
{"f_4884posixwin.scm",(void*)f_4884},
{"f_4856posixwin.scm",(void*)f_4856},
{"f_4863posixwin.scm",(void*)f_4863},
{"f_4776posixwin.scm",(void*)f_4776},
{"f_4780posixwin.scm",(void*)f_4780},
{"f_4786posixwin.scm",(void*)f_4786},
{"f_4808posixwin.scm",(void*)f_4808},
{"f_4805posixwin.scm",(void*)f_4805},
{"f_4795posixwin.scm",(void*)f_4795},
{"f_4743posixwin.scm",(void*)f_4743},
{"f_4747posixwin.scm",(void*)f_4747},
{"f_4724posixwin.scm",(void*)f_4724},
{"f_4715posixwin.scm",(void*)f_4715},
{"f_4649posixwin.scm",(void*)f_4649},
{"f_4655posixwin.scm",(void*)f_4655},
{"f_4659posixwin.scm",(void*)f_4659},
{"f_4667posixwin.scm",(void*)f_4667},
{"f_4693posixwin.scm",(void*)f_4693},
{"f_4697posixwin.scm",(void*)f_4697},
{"f_4685posixwin.scm",(void*)f_4685},
{"f_4629posixwin.scm",(void*)f_4629},
{"f_4637posixwin.scm",(void*)f_4637},
{"f_4612posixwin.scm",(void*)f_4612},
{"f_4623posixwin.scm",(void*)f_4623},
{"f_4627posixwin.scm",(void*)f_4627},
{"f_4582posixwin.scm",(void*)f_4582},
{"f_4589posixwin.scm",(void*)f_4589},
{"f_4598posixwin.scm",(void*)f_4598},
{"f_4592posixwin.scm",(void*)f_4592},
{"f_4547posixwin.scm",(void*)f_4547},
{"f_4551posixwin.scm",(void*)f_4551},
{"f_4580posixwin.scm",(void*)f_4580},
{"f_4566posixwin.scm",(void*)f_4566},
{"f_4560posixwin.scm",(void*)f_4560},
{"f_4533posixwin.scm",(void*)f_4533},
{"f_4545posixwin.scm",(void*)f_4545},
{"f_4519posixwin.scm",(void*)f_4519},
{"f_4531posixwin.scm",(void*)f_4531},
{"f_4501posixwin.scm",(void*)f_4501},
{"f_4505posixwin.scm",(void*)f_4505},
{"f_4517posixwin.scm",(void*)f_4517},
{"f_4464posixwin.scm",(void*)f_4464},
{"f_4472posixwin.scm",(void*)f_4472},
{"f_4455posixwin.scm",(void*)f_4455},
{"f_4449posixwin.scm",(void*)f_4449},
{"f_4443posixwin.scm",(void*)f_4443},
{"f_4419posixwin.scm",(void*)f_4419},
{"f_4441posixwin.scm",(void*)f_4441},
{"f_4437posixwin.scm",(void*)f_4437},
{"f_4429posixwin.scm",(void*)f_4429},
{"f_4389posixwin.scm",(void*)f_4389},
{"f_4417posixwin.scm",(void*)f_4417},
{"f_4413posixwin.scm",(void*)f_4413},
{"f_4405posixwin.scm",(void*)f_4405},
{"f_4333posixwin.scm",(void*)f_4333},
{"f_4343posixwin.scm",(void*)f_4343},
{"f_4320posixwin.scm",(void*)f_4320},
{"f_4311posixwin.scm",(void*)f_4311},
{"f_4235posixwin.scm",(void*)f_4235},
{"f_4239posixwin.scm",(void*)f_4239},
{"f_4251posixwin.scm",(void*)f_4251},
{"f_4242posixwin.scm",(void*)f_4242},
{"f_4215posixwin.scm",(void*)f_4215},
{"f_4219posixwin.scm",(void*)f_4219},
{"f_4225posixwin.scm",(void*)f_4225},
{"f_4229posixwin.scm",(void*)f_4229},
{"f_4195posixwin.scm",(void*)f_4195},
{"f_4199posixwin.scm",(void*)f_4199},
{"f_4205posixwin.scm",(void*)f_4205},
{"f_4209posixwin.scm",(void*)f_4209},
{"f_4171posixwin.scm",(void*)f_4171},
{"f_4175posixwin.scm",(void*)f_4175},
{"f_4186posixwin.scm",(void*)f_4186},
{"f_4190posixwin.scm",(void*)f_4190},
{"f_4180posixwin.scm",(void*)f_4180},
{"f_4147posixwin.scm",(void*)f_4147},
{"f_4151posixwin.scm",(void*)f_4151},
{"f_4162posixwin.scm",(void*)f_4162},
{"f_4166posixwin.scm",(void*)f_4166},
{"f_4156posixwin.scm",(void*)f_4156},
{"f_4128posixwin.scm",(void*)f_4128},
{"f_4132posixwin.scm",(void*)f_4132},
{"f_4135posixwin.scm",(void*)f_4135},
{"f_4092posixwin.scm",(void*)f_4092},
{"f_4123posixwin.scm",(void*)f_4123},
{"f_4113posixwin.scm",(void*)f_4113},
{"f_4106posixwin.scm",(void*)f_4106},
{"f_4056posixwin.scm",(void*)f_4056},
{"f_4087posixwin.scm",(void*)f_4087},
{"f_4077posixwin.scm",(void*)f_4077},
{"f_4070posixwin.scm",(void*)f_4070},
{"f_4038posixwin.scm",(void*)f_4038},
{"f_4042posixwin.scm",(void*)f_4042},
{"f_4054posixwin.scm",(void*)f_4054},
{"f_4032posixwin.scm",(void*)f_4032},
{"f_4020posixwin.scm",(void*)f_4020},
{"f_3663posixwin.scm",(void*)f_3663},
{"f_4010posixwin.scm",(void*)f_4010},
{"f_3809posixwin.scm",(void*)f_3809},
{"f_3996posixwin.scm",(void*)f_3996},
{"f_3985posixwin.scm",(void*)f_3985},
{"f_3992posixwin.scm",(void*)f_3992},
{"f_3839posixwin.scm",(void*)f_3839},
{"f_3978posixwin.scm",(void*)f_3978},
{"f_3957posixwin.scm",(void*)f_3957},
{"f_3974posixwin.scm",(void*)f_3974},
{"f_3963posixwin.scm",(void*)f_3963},
{"f_3970posixwin.scm",(void*)f_3970},
{"f_3881posixwin.scm",(void*)f_3881},
{"f_3954posixwin.scm",(void*)f_3954},
{"f_3933posixwin.scm",(void*)f_3933},
{"f_3950posixwin.scm",(void*)f_3950},
{"f_3939posixwin.scm",(void*)f_3939},
{"f_3946posixwin.scm",(void*)f_3946},
{"f_3887posixwin.scm",(void*)f_3887},
{"f_3930posixwin.scm",(void*)f_3930},
{"f_3926posixwin.scm",(void*)f_3926},
{"f_3919posixwin.scm",(void*)f_3919},
{"f_3915posixwin.scm",(void*)f_3915},
{"f_3894posixwin.scm",(void*)f_3894},
{"f_3898posixwin.scm",(void*)f_3898},
{"f_3875posixwin.scm",(void*)f_3875},
{"f_3862posixwin.scm",(void*)f_3862},
{"f_3846posixwin.scm",(void*)f_3846},
{"f_3850posixwin.scm",(void*)f_3850},
{"f_3854posixwin.scm",(void*)f_3854},
{"f_3833posixwin.scm",(void*)f_3833},
{"f_3820posixwin.scm",(void*)f_3820},
{"f_3816posixwin.scm",(void*)f_3816},
{"f_3803posixwin.scm",(void*)f_3803},
{"f_3670posixwin.scm",(void*)f_3670},
{"f_3789posixwin.scm",(void*)f_3789},
{"f_3677posixwin.scm",(void*)f_3677},
{"f_3679posixwin.scm",(void*)f_3679},
{"f_3686posixwin.scm",(void*)f_3686},
{"f_3761posixwin.scm",(void*)f_3761},
{"f_3770posixwin.scm",(void*)f_3770},
{"f_3758posixwin.scm",(void*)f_3758},
{"f_3692posixwin.scm",(void*)f_3692},
{"f_3739posixwin.scm",(void*)f_3739},
{"f_3727posixwin.scm",(void*)f_3727},
{"f_3735posixwin.scm",(void*)f_3735},
{"f_3731posixwin.scm",(void*)f_3731},
{"f_3708posixwin.scm",(void*)f_3708},
{"f_3716posixwin.scm",(void*)f_3716},
{"f_3712posixwin.scm",(void*)f_3712},
{"f_3607posixwin.scm",(void*)f_3607},
{"f_3616posixwin.scm",(void*)f_3616},
{"f_3640posixwin.scm",(void*)f_3640},
{"f_3652posixwin.scm",(void*)f_3652},
{"f_3658posixwin.scm",(void*)f_3658},
{"f_3646posixwin.scm",(void*)f_3646},
{"f_3622posixwin.scm",(void*)f_3622},
{"f_3628posixwin.scm",(void*)f_3628},
{"f_3614posixwin.scm",(void*)f_3614},
{"f_3596posixwin.scm",(void*)f_3596},
{"f_3591posixwin.scm",(void*)f_3591},
{"f_3540posixwin.scm",(void*)f_3540},
{"f_3544posixwin.scm",(void*)f_3544},
{"f_3553posixwin.scm",(void*)f_3553},
{"f_3556posixwin.scm",(void*)f_3556},
{"f_3513posixwin.scm",(void*)f_3513},
{"f_3538posixwin.scm",(void*)f_3538},
{"f_3534posixwin.scm",(void*)f_3534},
{"f_3520posixwin.scm",(void*)f_3520},
{"f_3353posixwin.scm",(void*)f_3353},
{"f_3461posixwin.scm",(void*)f_3461},
{"f_3469posixwin.scm",(void*)f_3469},
{"f_3456posixwin.scm",(void*)f_3456},
{"f_3355posixwin.scm",(void*)f_3355},
{"f_3362posixwin.scm",(void*)f_3362},
{"f_3365posixwin.scm",(void*)f_3365},
{"f_3368posixwin.scm",(void*)f_3368},
{"f_3455posixwin.scm",(void*)f_3455},
{"f_3372posixwin.scm",(void*)f_3372},
{"f_3389posixwin.scm",(void*)f_3389},
{"f_3399posixwin.scm",(void*)f_3399},
{"f_3411posixwin.scm",(void*)f_3411},
{"f_3421posixwin.scm",(void*)f_3421},
{"f_3381posixwin.scm",(void*)f_3381},
{"f_3326posixwin.scm",(void*)f_3326},
{"f_3351posixwin.scm",(void*)f_3351},
{"f_3347posixwin.scm",(void*)f_3347},
{"f_3339posixwin.scm",(void*)f_3339},
{"f_3299posixwin.scm",(void*)f_3299},
{"f_3324posixwin.scm",(void*)f_3324},
{"f_3320posixwin.scm",(void*)f_3320},
{"f_3312posixwin.scm",(void*)f_3312},
{"f_3159posixwin.scm",(void*)f_3159},
{"f_3163posixwin.scm",(void*)f_3163},
{"f_3259posixwin.scm",(void*)f_3259},
{"f_3260posixwin.scm",(void*)f_3260},
{"f_3278posixwin.scm",(void*)f_3278},
{"f_3270posixwin.scm",(void*)f_3270},
{"f_3176posixwin.scm",(void*)f_3176},
{"f_3177posixwin.scm",(void*)f_3177},
{"f_3181posixwin.scm",(void*)f_3181},
{"f_3189posixwin.scm",(void*)f_3189},
{"f_3194posixwin.scm",(void*)f_3194},
{"f_3198posixwin.scm",(void*)f_3198},
{"f_3228posixwin.scm",(void*)f_3228},
{"f_3235posixwin.scm",(void*)f_3235},
{"f_3238posixwin.scm",(void*)f_3238},
{"f_3205posixwin.scm",(void*)f_3205},
{"f_3209posixwin.scm",(void*)f_3209},
{"f_3227posixwin.scm",(void*)f_3227},
{"f_3219posixwin.scm",(void*)f_3219},
{"f_3098posixwin.scm",(void*)f_3098},
{"f_3111posixwin.scm",(void*)f_3111},
{"f_3126posixwin.scm",(void*)f_3126},
{"f_3117posixwin.scm",(void*)f_3117},
{"f_3120posixwin.scm",(void*)f_3120},
{"f_3058posixwin.scm",(void*)f_3058},
{"f_3077posixwin.scm",(void*)f_3077},
{"f_3062posixwin.scm",(void*)f_3062},
{"f_3071posixwin.scm",(void*)f_3071},
{"f_3065posixwin.scm",(void*)f_3065},
{"f_3025posixwin.scm",(void*)f_3025},
{"f_3027posixwin.scm",(void*)f_3027},
{"f_3020posixwin.scm",(void*)f_3020},
{"f_2997posixwin.scm",(void*)f_2997},
{"f_3018posixwin.scm",(void*)f_3018},
{"f_3004posixwin.scm",(void*)f_3004},
{"f_2991posixwin.scm",(void*)f_2991},
{"f_2995posixwin.scm",(void*)f_2995},
{"f_2985posixwin.scm",(void*)f_2985},
{"f_2989posixwin.scm",(void*)f_2989},
{"f_2979posixwin.scm",(void*)f_2979},
{"f_2983posixwin.scm",(void*)f_2983},
{"f_2973posixwin.scm",(void*)f_2973},
{"f_2977posixwin.scm",(void*)f_2977},
{"f_2967posixwin.scm",(void*)f_2967},
{"f_2971posixwin.scm",(void*)f_2971},
{"f_2961posixwin.scm",(void*)f_2961},
{"f_2965posixwin.scm",(void*)f_2965},
{"f_2930posixwin.scm",(void*)f_2930},
{"f_2934posixwin.scm",(void*)f_2934},
{"f_2937posixwin.scm",(void*)f_2937},
{"f_2892posixwin.scm",(void*)f_2892},
{"f_2925posixwin.scm",(void*)f_2925},
{"f_2921posixwin.scm",(void*)f_2921},
{"f_2896posixwin.scm",(void*)f_2896},
{"f_2905posixwin.scm",(void*)f_2905},
{"f_2854posixwin.scm",(void*)f_2854},
{"f_2861posixwin.scm",(void*)f_2861},
{"f_2864posixwin.scm",(void*)f_2864},
{"f_2884posixwin.scm",(void*)f_2884},
{"f_2867posixwin.scm",(void*)f_2867},
{"f_2874posixwin.scm",(void*)f_2874},
{"f_2812posixwin.scm",(void*)f_2812},
{"f_2819posixwin.scm",(void*)f_2819},
{"f_2834posixwin.scm",(void*)f_2834},
{"f_2828posixwin.scm",(void*)f_2828},
{"f_2767posixwin.scm",(void*)f_2767},
{"f_2777posixwin.scm",(void*)f_2777},
{"f_2780posixwin.scm",(void*)f_2780},
{"f_2792posixwin.scm",(void*)f_2792},
{"f_2783posixwin.scm",(void*)f_2783},
{"f_2749posixwin.scm",(void*)f_2749},
{"f_2762posixwin.scm",(void*)f_2762},
{"f_2708posixwin.scm",(void*)f_2708},
{"f_2741posixwin.scm",(void*)f_2741},
{"f_2725posixwin.scm",(void*)f_2725},
{"f_2734posixwin.scm",(void*)f_2734},
{"f_2728posixwin.scm",(void*)f_2728},
{"f_2662posixwin.scm",(void*)f_2662},
{"f_2666posixwin.scm",(void*)f_2666},
{"f_2677posixwin.scm",(void*)f_2677},
{"f_2673posixwin.scm",(void*)f_2673},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
