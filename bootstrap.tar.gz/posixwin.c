/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-12 23:07
   Version 3.0.2 - macosx-unix-gnu-ppc	[ manyargs dload ptables applyhook lockts ]
   SVN rev. 8608	compiled 2008-02-23 on apfel (Darwin)
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[389];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,51,32,102,108,97,103,115,49,52,32,46,32,109,111,100,101,49,53,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,50,55,32,115,105,122,101,50,56,32,46,32,98,117,102,102,101,114,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,51,55,32,98,117,102,102,101,114,51,56,32,46,32,115,105,122,101,51,57,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,53,53,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,115,116,97,116,32,102,53,57,32,46,32,103,53,56,54,48,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,102,105,108,101,45,115,105,122,101,32,102,54,54,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,54,56,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,55,48,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,55,50,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,111,119,110,101,114,32,102,55,52,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,55,54,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,23),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,55,56,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,24),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,56,49,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,16),40,102,95,49,53,48,48,32,102,110,97,109,101,56,53,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,115,116,97,116,45,116,121,112,101,32,110,97,109,101,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,57,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,44),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,57,55,32,112,111,115,57,56,32,46,32,119,104,101,110,99,101,57,57,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,50,49,32,115,112,101,99,49,50,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,50,56,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,50,52,32,37,115,112,101,99,49,49,57,49,52,56,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,49,50,51,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,49,49,55,49,49,56,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,49,53,52,41,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,49,53,56,49,53,57,41,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,17),40,105,115,112,101,114,115,101,32,103,49,55,57,49,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,49,56,55,32,114,49,56,56,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,49,56,52,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,49,57,53,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,49,57,54,32,105,110,112,49,57,55,32,114,49,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,48,50,32,46,32,109,50,48,51,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,48,56,32,46,32,109,50,48,57,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,50,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,50,52,53,57,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,97,50,52,54,53,32,46,32,114,101,115,117,108,116,115,50,51,50,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,50,56,32,112,114,111,99,50,50,57,32,46,32,109,111,100,101,50,51,48,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,50,52,56,51,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,20),40,97,50,52,56,57,32,46,32,114,101,115,117,108,116,115,50,51,56,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,51,52,32,112,114,111,99,50,51,53,32,46,32,109,111,100,101,50,51,54,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,97,50,53,48,56,32,46,32,114,101,115,117,108,116,115,50,52,53,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,50,52,48,32,116,104,117,110,107,50,52,49,32,46,32,109,111,100,101,50,52,50,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,20),40,97,50,53,50,56,32,46,32,114,101,115,117,108,116,115,50,53,52,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,50,52,57,32,116,104,117,110,107,50,53,48,32,46,32,109,111,100,101,50,53,49,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,103,50,54,49,50,54,50,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,50,55,48,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,50,55,50,32,112,114,111,99,50,55,51,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,50,55,54,32,115,116,97,116,101,50,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,50,56,50,32,109,50,56,51,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,50,56,56,32,97,99,99,50,56,57,32,108,111,99,50,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,57,52,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,57,53,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,51,48,50,32,109,51,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,51,48,55,32,105,110,112,51,48,56,32,114,51,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,51,49,51,32,46,32,109,51,49,52,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,51,49,54,32,46,32,109,51,49,55,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,51,50,50,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,51,50,55,32,46,32,110,101,119,51,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,51,51,53,32,118,97,108,51,51,54,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,51,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,51,53,52,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,53,49,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,51,53,55,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,51,53,57,41,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,51,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,30),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,51,56,52,32,46,32,103,51,56,51,51,56,53,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,51,57,53,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,52,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,52,48,55,32,109,111,100,101,52,48,56,32,46,32,115,105,122,101,52,48,57,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,7),40,97,51,50,57,52,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,52,52,50,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,37),40,97,51,51,48,48,32,100,105,114,52,50,55,52,51,48,32,102,105,108,52,50,56,52,51,49,32,101,120,116,52,50,57,52,51,50,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,52,50,53,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,52,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,54,48,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,21),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,52,53,55,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,105,108,115,116,52,54,51,32,111,108,115,116,52,54,52,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,35),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,52,53,52,32,101,120,97,99,116,102,52,53,53,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,32),40,115,101,116,97,114,103,32,97,52,55,51,52,55,55,32,97,52,55,50,52,55,56,32,97,52,55,49,52,55,57,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,32),40,115,101,116,101,110,118,32,97,52,56,51,52,56,55,32,97,52,56,50,52,56,56,32,97,52,56,49,52,56,57,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,17),40,100,111,52,57,53,32,108,52,57,55,32,105,52,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,57),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,52,57,49,32,108,115,116,52,57,50,32,97,114,103,118,101,99,45,115,101,116,116,101,114,52,57,51,32,105,100,120,52,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,62),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,53,48,52,32,102,105,108,101,110,97,109,101,53,48,53,32,97,114,103,108,115,116,53,48,54,32,101,110,118,108,115,116,53,48,55,32,101,120,97,99,116,102,53,48,56,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,49),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,53,49,53,32,109,115,103,53,49,54,32,102,105,108,101,110,97,109,101,53,49,55,32,114,101,115,53,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,39),40,98,111,100,121,53,50,56,32,97,114,103,108,115,116,53,51,53,32,101,110,118,108,115,116,53,51,54,32,101,120,97,99,116,102,53,51,55,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,53,51,50,32,37,97,114,103,108,115,116,53,50,53,53,52,48,32,37,101,110,118,108,115,116,53,50,54,53,52,49,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,101,110,118,108,115,116,53,51,49,32,37,97,114,103,108,115,116,53,50,53,53,52,51,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,114,103,108,115,116,53,51,48,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,39),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,53,50,51,32,46,32,103,53,50,50,53,50,52,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,39),40,98,111,100,121,53,53,56,32,97,114,103,108,115,116,53,54,53,32,101,110,118,108,115,116,53,54,54,32,101,120,97,99,116,102,53,54,55,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,53,54,50,32,37,97,114,103,108,115,116,53,53,53,53,55,48,32,37,101,110,118,108,115,116,53,53,54,53,55,49,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,101,110,118,108,115,116,53,54,49,32,37,97,114,103,108,115,116,53,53,53,53,55,51,41,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,114,103,108,115,116,53,54,48,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,45),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,53,53,50,32,102,105,108,101,110,97,109,101,53,53,51,32,46,32,103,53,53,49,53,53,52,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,53,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,28),40,112,114,111,99,101,115,115,45,114,117,110,32,102,53,56,57,32,46,32,97,114,103,115,53,57,48,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,22),40,99,108,111,115,101,45,104,97,110,100,108,101,32,97,53,57,50,53,57,53,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,54,51,48,32,99,109,100,54,51,49,32,97,114,103,115,54,51,50,32,101,110,118,54,51,51,32,115,116,100,111,117,116,102,54,51,52,32,115,116,100,105,110,102,54,51,53,32,115,116,100,101,114,114,102,54,51,54,32,46,32,103,54,50,57,54,51,55,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,97,52,48,50,56,32,103,54,55,55,54,55,56,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,18),40,99,104,107,115,116,114,108,115,116,32,108,115,116,54,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,7),40,97,52,48,52,54,41,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,34),40,97,52,48,53,50,32,105,110,54,56,50,32,111,117,116,54,56,51,32,112,105,100,54,56,52,32,101,114,114,54,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,57),40,37,112,114,111,99,101,115,115,32,108,111,99,54,54,57,32,101,114,114,63,54,55,48,32,99,109,100,54,55,49,32,97,114,103,115,54,55,50,32,101,110,118,54,55,51,32,101,120,97,99,116,102,54,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,54,57,53,32,97,114,103,115,55,48,50,32,101,110,118,55,48,51,32,101,120,97,99,116,102,55,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,101,120,97,99,116,102,54,57,57,32,37,97,114,103,115,54,57,50,55,48,54,32,37,101,110,118,54,57,51,55,48,55,41,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,101,110,118,54,57,56,32,37,97,114,103,115,54,57,50,55,48,57,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,97,114,103,115,54,57,55,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,32,99,109,100,54,57,48,32,46,32,103,54,56,57,54,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,55,50,51,32,97,114,103,115,55,51,48,32,101,110,118,55,51,49,32,101,120,97,99,116,102,55,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,101,120,97,99,116,102,55,50,55,32,37,97,114,103,115,55,50,48,55,51,52,32,37,101,110,118,55,50,49,55,51,53,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,101,110,118,55,50,54,32,37,97,114,103,115,55,50,48,55,51,55,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,97,114,103,115,55,50,53,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,27),40,112,114,111,99,101,115,115,42,32,99,109,100,55,49,56,32,46,32,103,55,49,55,55,49,57,41,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,55,52,54,32,110,111,104,97,110,103,55,52,55,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,7),40,97,52,50,55,50,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,33),40,97,52,50,55,56,32,101,112,105,100,55,53,53,32,101,110,111,114,109,55,53,54,32,101,99,111,100,101,55,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,55,52,56,32,46,32,97,114,103,115,55,52,57,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,12),40,115,108,101,101,112,32,116,55,54,48,41,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,13),40,102,95,52,52,57,57,32,120,55,56,57,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,7),40,97,52,52,51,57,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,7),40,97,52,52,52,55,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,7),40,97,52,52,54,49,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,102,115,55,57,49,32,114,55,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,15),40,102,95,52,53,49,53,32,46,32,95,55,56,55,41,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,15),40,102,95,52,53,48,55,32,46,32,95,55,56,54,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,55,55,52,32,97,99,116,105,111,110,55,56,49,32,105,100,55,56,50,32,108,105,109,105,116,55,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,108,105,109,105,116,55,55,56,32,37,97,99,116,105,111,110,55,55,49,56,48,54,32,37,105,100,55,55,50,56,48,55,41,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,105,100,55,55,55,32,37,97,99,116,105,111,110,55,55,49,56,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,17),40,97,52,53,51,53,32,120,56,49,49,32,121,56,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,99,116,105,111,110,55,55,54,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,48),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,55,54,56,32,112,114,101,100,55,54,57,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,55,55,48,41};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,46,32,95,56,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,20),40,99,114,101,97,116,101,45,102,105,102,111,32,46,32,95,56,50,49,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,23),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,32,46,32,95,56,50,50,41,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,29),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,56,50,51,41,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,35),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,103,114,111,117,112,45,105,100,32,46,32,95,56,50,52,41,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,34),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,105,100,32,46,32,95,56,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,36),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,32,46,32,95,56,50,54,41,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,25),40,99,117,114,114,101,110,116,45,103,114,111,117,112,45,105,100,32,46,32,95,56,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,24),40,99,117,114,114,101,110,116,45,117,115,101,114,45,105,100,32,46,32,95,56,50,56,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,27),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,46,32,95,56,50,57,41,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,108,105,110,107,32,46,32,95,56,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,108,111,99,107,32,46,32,95,56,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,46,32,95,56,51,50,41,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,20),40,102,105,108,101,45,115,101,108,101,99,116,32,46,32,95,56,51,51,41,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,46,32,95,56,51,52,41,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,46,32,95,56,51,53,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,20),40,102,105,108,101,45,117,110,108,111,99,107,32,46,32,95,56,51,54,41,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,19),40,103,101,116,45,103,114,111,117,112,115,32,46,32,95,56,51,55,41,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,26),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,56,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,26),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,46,32,95,56,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,35),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,46,32,95,56,52,48,41,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,26),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,32,46,32,95,56,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,95,56,52,50,41,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,32,46,32,95,56,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,23),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,46,32,95,56,52,52,41,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,27),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,56,52,53,41,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,19),40,115,101,116,45,97,108,97,114,109,33,32,46,32,95,56,52,54,41,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,46,32,95,56,52,55,41,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,103,114,111,117,112,115,33,32,46,32,95,56,52,56,41,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,30),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,46,32,95,56,52,57,41,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,28),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,46,32,95,56,53,48,41,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,25),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,56,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,117,115,101,114,45,105,100,33,32,46,32,95,56,53,50,41,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,20),40,115,105,103,110,97,108,45,109,97,115,107,32,46,32,95,56,53,51,41,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,56,53,52,41,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,46,32,95,56,53,53,41,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,46,32,95,56,53,54,41,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,22),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,46,32,95,56,53,55,41,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,46,32,95,56,53,56,41,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,22),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,46,32,95,56,53,57,41,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,31),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,46,32,95,56,54,48,41,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,25),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,56,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,46,32,95,56,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,21),40,115,116,114,105,110,103,45,62,116,105,109,101,32,46,32,95,56,54,51,41,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,12),40,102,105,102,111,63,32,95,56,54,52,41,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,56,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k3867 */
static C_word C_fcall stub605(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub605(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static C_word C_fcall stub593(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub593(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static C_word C_fcall stub581(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub581(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k3496 */
static C_word C_fcall stub484(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub484(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k3479 */
static C_word C_fcall stub474(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub474(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k3196 */
static C_word C_fcall stub403(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub403(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub398(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub398(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub378(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub378(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub372(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub372(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k3043 */
static C_word C_fcall stub363(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub363(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k2950 */
static C_word C_fcall stub346(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k1132 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4530)
static void C_fcall f_4530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4525)
static void C_fcall f_4525(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4520)
static void C_fcall f_4520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4375)
static void C_fcall f_4375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4382)
static void C_fcall f_4382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4394)
static void C_fcall f_4394(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4177)
static void C_fcall f_4177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_fcall f_4172(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4167)
static void C_fcall f_4167(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4162)
static void C_fcall f_4162(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4097)
static void C_fcall f_4097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_fcall f_4092(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4087)
static void C_fcall f_4087(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4082)
static void C_fcall f_4082(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4018)
static void C_fcall f_4018(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_fcall f_4020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3711)
static void C_fcall f_3711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_fcall f_3706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3701)
static void C_fcall f_3701(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3689)
static void C_fcall f_3689(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3624)
static void C_fcall f_3624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_fcall f_3619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3614)
static void C_fcall f_3614(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3602)
static void C_fcall f_3602(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_fcall f_3585(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_fcall f_3552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_fcall f_3502(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3514)
static void C_fcall f_3514(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3389)
static void C_fcall f_3389(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3432)
static void C_fcall f_3432(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_fcall f_3403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3280)
static void C_fcall f_3280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_fcall f_3320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_fcall f_2959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_fcall f_2971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2893)
static void C_fcall f_2893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_fcall f_2805(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2723)
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_fcall f_2342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_fcall f_2336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static C_word C_fcall f_2324(C_word t0);
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_fcall f_2113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_fcall f_2143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_fcall f_2185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_fcall f_1983(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_fcall f_2062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static C_word C_fcall f_1956(C_word t0);
C_noret_decl(f_1951)
static void C_fcall f_1951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1821)
static void C_fcall f_1821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_fcall f_1816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1715)
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_fcall f_1749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_fcall f_1771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_fcall f_1498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_fcall f_1365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4530)
static void C_fcall trf_4530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4530(t0,t1);}

C_noret_decl(trf_4525)
static void C_fcall trf_4525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4525(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4525(t0,t1,t2);}

C_noret_decl(trf_4520)
static void C_fcall trf_4520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4520(t0,t1,t2,t3);}

C_noret_decl(trf_4375)
static void C_fcall trf_4375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4375(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4375(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4382)
static void C_fcall trf_4382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4382(t0,t1);}

C_noret_decl(trf_4394)
static void C_fcall trf_4394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4394(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4394(t0,t1,t2,t3);}

C_noret_decl(trf_4177)
static void C_fcall trf_4177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4177(t0,t1);}

C_noret_decl(trf_4172)
static void C_fcall trf_4172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4172(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4172(t0,t1,t2);}

C_noret_decl(trf_4167)
static void C_fcall trf_4167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4167(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4167(t0,t1,t2,t3);}

C_noret_decl(trf_4162)
static void C_fcall trf_4162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4162(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4162(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4097)
static void C_fcall trf_4097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4097(t0,t1);}

C_noret_decl(trf_4092)
static void C_fcall trf_4092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4092(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4092(t0,t1,t2);}

C_noret_decl(trf_4087)
static void C_fcall trf_4087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4087(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4087(t0,t1,t2,t3);}

C_noret_decl(trf_4082)
static void C_fcall trf_4082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4082(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4082(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4018)
static void C_fcall trf_4018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4018(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4018(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4020)
static void C_fcall trf_4020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4020(t0,t1,t2);}

C_noret_decl(trf_3711)
static void C_fcall trf_3711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3711(t0,t1);}

C_noret_decl(trf_3706)
static void C_fcall trf_3706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3706(t0,t1,t2);}

C_noret_decl(trf_3701)
static void C_fcall trf_3701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3701(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3701(t0,t1,t2,t3);}

C_noret_decl(trf_3689)
static void C_fcall trf_3689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3689(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3689(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3624)
static void C_fcall trf_3624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3624(t0,t1);}

C_noret_decl(trf_3619)
static void C_fcall trf_3619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3619(t0,t1,t2);}

C_noret_decl(trf_3614)
static void C_fcall trf_3614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3614(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3614(t0,t1,t2,t3);}

C_noret_decl(trf_3602)
static void C_fcall trf_3602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3602(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3602(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3585)
static void C_fcall trf_3585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3585(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3585(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3552)
static void C_fcall trf_3552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3552(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3552(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3502)
static void C_fcall trf_3502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3502(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3502(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3514)
static void C_fcall trf_3514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3514(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3514(t0,t1,t2,t3);}

C_noret_decl(trf_3389)
static void C_fcall trf_3389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3389(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3389(t0,t1,t2,t3);}

C_noret_decl(trf_3432)
static void C_fcall trf_3432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3432(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3432(t0,t1,t2,t3);}

C_noret_decl(trf_3394)
static void C_fcall trf_3394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3394(t0,t1,t2);}

C_noret_decl(trf_3403)
static void C_fcall trf_3403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3403(t0,t1,t2);}

C_noret_decl(trf_3280)
static void C_fcall trf_3280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3280(t0,t1,t2);}

C_noret_decl(trf_3320)
static void C_fcall trf_3320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3320(t0,t1,t2);}

C_noret_decl(trf_2959)
static void C_fcall trf_2959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2959(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2959(t0,t1,t2);}

C_noret_decl(trf_2971)
static void C_fcall trf_2971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2971(t0,t1,t2);}

C_noret_decl(trf_2893)
static void C_fcall trf_2893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2893(t0,t1);}

C_noret_decl(trf_2805)
static void C_fcall trf_2805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2805(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2805(t0,t1,t2,t3);}

C_noret_decl(trf_2768)
static void C_fcall trf_2768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2768(t0,t1,t2);}

C_noret_decl(trf_2723)
static void C_fcall trf_2723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2723(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2723(t0,t1,t2,t3);}

C_noret_decl(trf_2342)
static void C_fcall trf_2342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2342(t0,t1,t2,t3);}

C_noret_decl(trf_2336)
static void C_fcall trf_2336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2336(t0,t1);}

C_noret_decl(trf_2113)
static void C_fcall trf_2113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2113(t0,t1);}

C_noret_decl(trf_2143)
static void C_fcall trf_2143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2143(t0,t1);}

C_noret_decl(trf_2185)
static void C_fcall trf_2185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2185(t0,t1);}

C_noret_decl(trf_1983)
static void C_fcall trf_1983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1983(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1983(t0,t1,t2,t3);}

C_noret_decl(trf_2062)
static void C_fcall trf_2062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2062(t0,t1);}

C_noret_decl(trf_1951)
static void C_fcall trf_1951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1951(t0,t1);}

C_noret_decl(trf_1821)
static void C_fcall trf_1821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1821(t0,t1);}

C_noret_decl(trf_1816)
static void C_fcall trf_1816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1816(t0,t1,t2);}

C_noret_decl(trf_1715)
static void C_fcall trf_1715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1715(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1715(t0,t1,t2,t3);}

C_noret_decl(trf_1749)
static void C_fcall trf_1749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1749(t0,t1);}

C_noret_decl(trf_1771)
static void C_fcall trf_1771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1771(t0,t1);}

C_noret_decl(trf_1498)
static void C_fcall trf_1498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1498(t0,t1);}

C_noret_decl(trf_1365)
static void C_fcall trf_1365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1365(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3050)){
C_save(t1);
C_rereclaim2(3050*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,389);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"\003syserror");
lf[63]=C_h_intern(&lf[63],9,"file-size");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],16,"file-access-time");
lf[66]=C_h_intern(&lf[66],16,"file-change-time");
lf[67]=C_h_intern(&lf[67],10,"file-owner");
lf[68]=C_h_intern(&lf[68],16,"file-permissions");
lf[69]=C_h_intern(&lf[69],13,"regular-file\077");
lf[70]=C_h_intern(&lf[70],13,"\003sysfile-info");
lf[71]=C_h_intern(&lf[71],14,"symbolic-link\077");
lf[72]=C_h_intern(&lf[72],13,"stat-regular\077");
lf[73]=C_h_intern(&lf[73],15,"stat-directory\077");
lf[74]=C_h_intern(&lf[74],17,"stat-char-device\077");
lf[75]=C_h_intern(&lf[75],18,"stat-block-device\077");
lf[76]=C_h_intern(&lf[76],10,"stat-fifo\077");
lf[77]=C_h_intern(&lf[77],13,"stat-symlink\077");
lf[78]=C_h_intern(&lf[78],12,"stat-socket\077");
lf[79]=C_h_intern(&lf[79],13,"file-position");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[81]=C_h_intern(&lf[81],6,"stream");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[83]=C_h_intern(&lf[83],5,"port\077");
lf[84]=C_h_intern(&lf[84],18,"set-file-position!");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[87]=C_h_intern(&lf[87],13,"\000bounds-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[89]=C_h_intern(&lf[89],16,"create-directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[91]=C_h_intern(&lf[91],16,"change-directory");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[93]=C_h_intern(&lf[93],16,"delete-directory");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[95]=C_h_intern(&lf[95],6,"string");
lf[96]=C_h_intern(&lf[96],9,"directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[98]=C_h_intern(&lf[98],16,"\003sysmake-pointer");
lf[99]=C_h_intern(&lf[99],17,"current-directory");
lf[100]=C_h_intern(&lf[100],10,"directory\077");
lf[101]=C_h_intern(&lf[101],27,"\003sysplatform-fixup-pathname");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[103]=C_h_intern(&lf[103],5,"null\077");
lf[104]=C_h_intern(&lf[104],6,"char=\077");
lf[105]=C_h_intern(&lf[105],8,"string=\077");
lf[106]=C_h_intern(&lf[106],16,"char-alphabetic\077");
lf[107]=C_h_intern(&lf[107],10,"string-ref");
lf[108]=C_h_intern(&lf[108],18,"string-intersperse");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[110]=C_h_intern(&lf[110],17,"current-user-name");
lf[111]=C_h_intern(&lf[111],14,"canonical-path");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[113]=C_h_intern(&lf[113],7,"reverse");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[116]=C_h_intern(&lf[116],12,"string-split");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[124]=C_h_intern(&lf[124],5,"\000text");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[127]=C_h_intern(&lf[127],13,"\003sysmake-port");
lf[128]=C_h_intern(&lf[128],21,"\003sysstream-port-class");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[130]=C_h_intern(&lf[130],15,"open-input-pipe");
lf[131]=C_h_intern(&lf[131],7,"\000binary");
lf[132]=C_h_intern(&lf[132],16,"open-output-pipe");
lf[133]=C_h_intern(&lf[133],16,"close-input-pipe");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[135]=C_h_intern(&lf[135],14,"\003syscheck-port");
lf[136]=C_h_intern(&lf[136],17,"close-output-pipe");
lf[137]=C_h_intern(&lf[137],20,"call-with-input-pipe");
lf[138]=C_h_intern(&lf[138],21,"call-with-output-pipe");
lf[139]=C_h_intern(&lf[139],20,"with-input-from-pipe");
lf[140]=C_h_intern(&lf[140],18,"\003sysstandard-input");
lf[141]=C_h_intern(&lf[141],19,"with-output-to-pipe");
lf[142]=C_h_intern(&lf[142],19,"\003sysstandard-output");
lf[143]=C_h_intern(&lf[143],11,"create-pipe");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[145]=C_h_intern(&lf[145],11,"signal/term");
lf[146]=C_h_intern(&lf[146],10,"signal/int");
lf[147]=C_h_intern(&lf[147],10,"signal/fpe");
lf[148]=C_h_intern(&lf[148],10,"signal/ill");
lf[149]=C_h_intern(&lf[149],11,"signal/segv");
lf[150]=C_h_intern(&lf[150],11,"signal/abrt");
lf[151]=C_h_intern(&lf[151],12,"signal/break");
lf[152]=C_h_intern(&lf[152],11,"signal/alrm");
lf[153]=C_h_intern(&lf[153],11,"signal/chld");
lf[154]=C_h_intern(&lf[154],11,"signal/cont");
lf[155]=C_h_intern(&lf[155],10,"signal/hup");
lf[156]=C_h_intern(&lf[156],9,"signal/io");
lf[157]=C_h_intern(&lf[157],11,"signal/kill");
lf[158]=C_h_intern(&lf[158],11,"signal/pipe");
lf[159]=C_h_intern(&lf[159],11,"signal/prof");
lf[160]=C_h_intern(&lf[160],11,"signal/quit");
lf[161]=C_h_intern(&lf[161],11,"signal/stop");
lf[162]=C_h_intern(&lf[162],11,"signal/trap");
lf[163]=C_h_intern(&lf[163],11,"signal/tstp");
lf[164]=C_h_intern(&lf[164],10,"signal/urg");
lf[165]=C_h_intern(&lf[165],11,"signal/usr1");
lf[166]=C_h_intern(&lf[166],11,"signal/usr2");
lf[167]=C_h_intern(&lf[167],13,"signal/vtalrm");
lf[168]=C_h_intern(&lf[168],12,"signal/winch");
lf[169]=C_h_intern(&lf[169],11,"signal/xcpu");
lf[170]=C_h_intern(&lf[170],11,"signal/xfsz");
lf[171]=C_h_intern(&lf[171],12,"signals-list");
lf[172]=C_h_intern(&lf[172],18,"\003sysinterrupt-hook");
lf[173]=C_h_intern(&lf[173],14,"signal-handler");
lf[174]=C_h_intern(&lf[174],19,"set-signal-handler!");
lf[175]=C_h_intern(&lf[175],10,"errno/perm");
lf[176]=C_h_intern(&lf[176],11,"errno/noent");
lf[177]=C_h_intern(&lf[177],10,"errno/srch");
lf[178]=C_h_intern(&lf[178],10,"errno/intr");
lf[179]=C_h_intern(&lf[179],8,"errno/io");
lf[180]=C_h_intern(&lf[180],12,"errno/noexec");
lf[181]=C_h_intern(&lf[181],10,"errno/badf");
lf[182]=C_h_intern(&lf[182],11,"errno/child");
lf[183]=C_h_intern(&lf[183],11,"errno/nomem");
lf[184]=C_h_intern(&lf[184],11,"errno/acces");
lf[185]=C_h_intern(&lf[185],11,"errno/fault");
lf[186]=C_h_intern(&lf[186],10,"errno/busy");
lf[187]=C_h_intern(&lf[187],11,"errno/exist");
lf[188]=C_h_intern(&lf[188],12,"errno/notdir");
lf[189]=C_h_intern(&lf[189],11,"errno/isdir");
lf[190]=C_h_intern(&lf[190],11,"errno/inval");
lf[191]=C_h_intern(&lf[191],11,"errno/mfile");
lf[192]=C_h_intern(&lf[192],11,"errno/nospc");
lf[193]=C_h_intern(&lf[193],11,"errno/spipe");
lf[194]=C_h_intern(&lf[194],10,"errno/pipe");
lf[195]=C_h_intern(&lf[195],11,"errno/again");
lf[196]=C_h_intern(&lf[196],10,"errno/rofs");
lf[197]=C_h_intern(&lf[197],10,"errno/nxio");
lf[198]=C_h_intern(&lf[198],10,"errno/2big");
lf[199]=C_h_intern(&lf[199],10,"errno/xdev");
lf[200]=C_h_intern(&lf[200],11,"errno/nodev");
lf[201]=C_h_intern(&lf[201],11,"errno/nfile");
lf[202]=C_h_intern(&lf[202],11,"errno/notty");
lf[203]=C_h_intern(&lf[203],10,"errno/fbig");
lf[204]=C_h_intern(&lf[204],11,"errno/mlink");
lf[205]=C_h_intern(&lf[205],9,"errno/dom");
lf[206]=C_h_intern(&lf[206],11,"errno/range");
lf[207]=C_h_intern(&lf[207],12,"errno/deadlk");
lf[208]=C_h_intern(&lf[208],17,"errno/nametoolong");
lf[209]=C_h_intern(&lf[209],11,"errno/nolck");
lf[210]=C_h_intern(&lf[210],11,"errno/nosys");
lf[211]=C_h_intern(&lf[211],14,"errno/notempty");
lf[212]=C_h_intern(&lf[212],11,"errno/ilseq");
lf[213]=C_h_intern(&lf[213],16,"change-file-mode");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[215]=C_h_intern(&lf[215],17,"file-read-access\077");
lf[216]=C_h_intern(&lf[216],18,"file-write-access\077");
lf[217]=C_h_intern(&lf[217],20,"file-execute-access\077");
lf[218]=C_h_intern(&lf[218],12,"fileno/stdin");
lf[219]=C_h_intern(&lf[219],13,"fileno/stdout");
lf[220]=C_h_intern(&lf[220],13,"fileno/stderr");
lf[221]=C_h_intern(&lf[221],7,"\000append");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[229]=C_h_intern(&lf[229],16,"open-input-file*");
lf[230]=C_h_intern(&lf[230],17,"open-output-file*");
lf[231]=C_h_intern(&lf[231],12,"port->fileno");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[234]=C_h_intern(&lf[234],25,"\003syspeek-unsigned-integer");
lf[235]=C_h_intern(&lf[235],16,"duplicate-fileno");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[237]=C_h_intern(&lf[237],6,"setenv");
lf[238]=C_h_intern(&lf[238],8,"unsetenv");
lf[239]=C_h_intern(&lf[239],9,"substring");
lf[240]=C_h_intern(&lf[240],19,"current-environment");
lf[241]=C_h_intern(&lf[241],19,"seconds->local-time");
lf[242]=C_h_intern(&lf[242],18,"\003sysdecode-seconds");
lf[243]=C_h_intern(&lf[243],17,"seconds->utc-time");
lf[244]=C_h_intern(&lf[244],15,"seconds->string");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[246]=C_h_intern(&lf[246],12,"time->string");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[250]=C_h_intern(&lf[250],19,"local-time->seconds");
lf[251]=C_h_intern(&lf[251],15,"\003syscons-flonum");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[254]=C_h_intern(&lf[254],27,"local-timezone-abbreviation");
lf[255]=C_h_intern(&lf[255],5,"_exit");
lf[256]=C_h_intern(&lf[256],19,"set-buffering-mode!");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[258]=C_h_intern(&lf[258],5,"\000full");
lf[259]=C_h_intern(&lf[259],5,"\000line");
lf[260]=C_h_intern(&lf[260],5,"\000none");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[262]=C_h_intern(&lf[262],6,"regexp");
lf[263]=C_h_intern(&lf[263],21,"make-anchored-pattern");
lf[264]=C_h_intern(&lf[264],12,"string-match");
lf[265]=C_h_intern(&lf[265],12,"glob->regexp");
lf[266]=C_h_intern(&lf[266],13,"make-pathname");
lf[267]=C_h_intern(&lf[267],18,"decompose-pathname");
lf[268]=C_h_intern(&lf[268],4,"glob");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[271]=C_h_intern(&lf[271],13,"spawn/overlay");
lf[272]=C_h_intern(&lf[272],10,"spawn/wait");
lf[273]=C_h_intern(&lf[273],12,"spawn/nowait");
lf[274]=C_h_intern(&lf[274],13,"spawn/nowaito");
lf[275]=C_h_intern(&lf[275],12,"spawn/detach");
lf[276]=C_h_intern(&lf[276],16,"char-whitespace\077");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[280]=C_h_intern(&lf[280],24,"pathname-strip-directory");
lf[283]=C_h_intern(&lf[283],15,"process-execute");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[285]=C_h_intern(&lf[285],13,"process-spawn");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[287]=C_h_intern(&lf[287],18,"current-process-id");
lf[288]=C_h_intern(&lf[288],17,"\003sysshell-command");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[290]=C_h_intern(&lf[290],6,"getenv");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[292]=C_h_intern(&lf[292],27,"\003sysshell-command-arguments");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[294]=C_h_intern(&lf[294],11,"process-run");
lf[296]=C_h_intern(&lf[296],11,"\003sysprocess");
lf[297]=C_h_intern(&lf[297],14,"\000process-error");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[299]=C_h_intern(&lf[299],17,"\003sysmake-locative");
lf[300]=C_h_intern(&lf[300],8,"location");
lf[301]=C_h_intern(&lf[301],12,"\003sysfor-each");
lf[302]=C_h_intern(&lf[302],7,"process");
lf[303]=C_h_intern(&lf[303],8,"process*");
lf[304]=C_h_intern(&lf[304],16,"\003sysprocess-wait");
lf[305]=C_h_intern(&lf[305],12,"process-wait");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[307]=C_h_intern(&lf[307],5,"sleep");
lf[308]=C_h_intern(&lf[308],13,"get-host-name");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[310]=C_h_intern(&lf[310],18,"system-information");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[314]=C_h_intern(&lf[314],10,"find-files");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[317]=C_h_intern(&lf[317],19,"\003sysundefined-value");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[319]=C_h_intern(&lf[319],16,"\003sysdynamic-wind");
lf[320]=C_h_intern(&lf[320],13,"pathname-file");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[322]=C_h_intern(&lf[322],17,"change-file-owner");
lf[323]=C_h_intern(&lf[323],5,"error");
lf[324]=C_h_intern(&lf[324],11,"create-fifo");
lf[325]=C_h_intern(&lf[325],14,"create-session");
lf[326]=C_h_intern(&lf[326],20,"create-symbolic-link");
lf[327]=C_h_intern(&lf[327],26,"current-effective-group-id");
lf[328]=C_h_intern(&lf[328],25,"current-effective-user-id");
lf[329]=C_h_intern(&lf[329],27,"current-effective-user-name");
lf[330]=C_h_intern(&lf[330],16,"current-group-id");
lf[331]=C_h_intern(&lf[331],15,"current-user-id");
lf[332]=C_h_intern(&lf[332],18,"map-file-to-memory");
lf[333]=C_h_intern(&lf[333],9,"file-link");
lf[334]=C_h_intern(&lf[334],9,"file-lock");
lf[335]=C_h_intern(&lf[335],18,"file-lock/blocking");
lf[336]=C_h_intern(&lf[336],11,"file-select");
lf[337]=C_h_intern(&lf[337],14,"file-test-lock");
lf[338]=C_h_intern(&lf[338],13,"file-truncate");
lf[339]=C_h_intern(&lf[339],11,"file-unlock");
lf[340]=C_h_intern(&lf[340],10,"get-groups");
lf[341]=C_h_intern(&lf[341],17,"group-information");
lf[342]=C_h_intern(&lf[342],17,"initialize-groups");
lf[343]=C_h_intern(&lf[343],26,"memory-mapped-file-pointer");
lf[344]=C_h_intern(&lf[344],17,"parent-process-id");
lf[345]=C_h_intern(&lf[345],12,"process-fork");
lf[346]=C_h_intern(&lf[346],16,"process-group-id");
lf[347]=C_h_intern(&lf[347],14,"process-signal");
lf[348]=C_h_intern(&lf[348],18,"read-symbolic-link");
lf[349]=C_h_intern(&lf[349],10,"set-alarm!");
lf[350]=C_h_intern(&lf[350],13,"set-group-id!");
lf[351]=C_h_intern(&lf[351],11,"set-groups!");
lf[352]=C_h_intern(&lf[352],21,"set-process-group-id!");
lf[353]=C_h_intern(&lf[353],19,"set-root-directory!");
lf[354]=C_h_intern(&lf[354],16,"set-signal-mask!");
lf[355]=C_h_intern(&lf[355],12,"set-user-id!");
lf[356]=C_h_intern(&lf[356],11,"signal-mask");
lf[357]=C_h_intern(&lf[357],12,"signal-mask!");
lf[358]=C_h_intern(&lf[358],14,"signal-masked\077");
lf[359]=C_h_intern(&lf[359],14,"signal-unmask!");
lf[360]=C_h_intern(&lf[360],13,"terminal-name");
lf[361]=C_h_intern(&lf[361],14,"terminal-port\077");
lf[362]=C_h_intern(&lf[362],13,"terminal-size");
lf[363]=C_h_intern(&lf[363],22,"unmap-file-from-memory");
lf[364]=C_h_intern(&lf[364],16,"user-information");
lf[365]=C_h_intern(&lf[365],17,"utc-time->seconds");
lf[366]=C_h_intern(&lf[366],12,"string->time");
lf[367]=C_h_intern(&lf[367],16,"errno/wouldblock");
lf[368]=C_h_intern(&lf[368],5,"fifo\077");
lf[369]=C_h_intern(&lf[369],19,"memory-mapped-file\077");
lf[370]=C_h_intern(&lf[370],13,"map/anonymous");
lf[371]=C_h_intern(&lf[371],8,"map/file");
lf[372]=C_h_intern(&lf[372],9,"map/fixed");
lf[373]=C_h_intern(&lf[373],11,"map/private");
lf[374]=C_h_intern(&lf[374],10,"map/shared");
lf[375]=C_h_intern(&lf[375],10,"open/fsync");
lf[376]=C_h_intern(&lf[376],11,"open/noctty");
lf[377]=C_h_intern(&lf[377],13,"open/nonblock");
lf[378]=C_h_intern(&lf[378],9,"open/sync");
lf[379]=C_h_intern(&lf[379],10,"perm/isgid");
lf[380]=C_h_intern(&lf[380],10,"perm/isuid");
lf[381]=C_h_intern(&lf[381],10,"perm/isvtx");
lf[382]=C_h_intern(&lf[382],9,"prot/exec");
lf[383]=C_h_intern(&lf[383],9,"prot/none");
lf[384]=C_h_intern(&lf[384],9,"prot/read");
lf[385]=C_h_intern(&lf[385],10,"prot/write");
lf[386]=C_h_intern(&lf[386],11,"make-vector");
lf[387]=C_h_intern(&lf[387],17,"register-feature!");
lf[388]=C_h_intern(&lf[388],5,"posix");
C_register_lf2(lf,389,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k1109 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1112 in k1109 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1115 in k1112 in k1109 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 944  register-feature! */
t3=*((C_word*)lf[387]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[388]);}

/* k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[10]+1,lf[5]);
t5=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1181,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1222,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1240,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1327,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[55]+1,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1458,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1464,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1470,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1498,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[72]+1,*((C_word*)lf[69]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1129 stat-type */
f_1498(t54,lf[73]);}

/* k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1130 stat-type */
f_1498(t3,lf[74]);}

/* k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1131 stat-type */
f_1498(t3,lf[75]);}

/* k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1132 stat-type */
f_1498(t3,lf[76]);}

/* k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1133 stat-type */
f_1498(t3,lf[77]);}

/* k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1134 stat-type */
f_1498(t3,lf[78]);}

/* k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word ab[117],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1571,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1659,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1686,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[4]+1);
t9=*((C_word*)lf[43]+1);
t10=*((C_word*)lf[95]+1);
t11=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1713,a[2]=t9,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[43]+1);
t14=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t13,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[103]+1);
t16=*((C_word*)lf[104]+1);
t17=*((C_word*)lf[105]+1);
t18=*((C_word*)lf[106]+1);
t19=*((C_word*)lf[107]+1);
t20=*((C_word*)lf[4]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1956,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[110]+1);
t24=*((C_word*)lf[99]+1);
t25=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1967,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t24,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,a[12]=((C_word)li33),tmp=(C_word)a,a+=13,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2336,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2360,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2396,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2432,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[136]+1,*((C_word*)lf[133]+1));
t33=*((C_word*)lf[130]+1);
t34=*((C_word*)lf[132]+1);
t35=*((C_word*)lf[133]+1);
t36=*((C_word*)lf[136]+1);
t37=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2451,a[2]=t33,a[3]=t35,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2475,a[2]=t34,a[3]=t36,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2499,a[2]=t33,a[3]=t35,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2519,a[2]=t34,a[3]=t36,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[143]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[145]+1,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[146]+1,C_fix((C_word)SIGINT));
t44=C_mutate((C_word*)lf[147]+1,C_fix((C_word)SIGFPE));
t45=C_mutate((C_word*)lf[148]+1,C_fix((C_word)SIGILL));
t46=C_mutate((C_word*)lf[149]+1,C_fix((C_word)SIGSEGV));
t47=C_mutate((C_word*)lf[150]+1,C_fix((C_word)SIGABRT));
t48=C_mutate((C_word*)lf[151]+1,C_fix((C_word)SIGBREAK));
t49=C_set_block_item(lf[152],0,C_fix(0));
t50=C_set_block_item(lf[153],0,C_fix(0));
t51=C_set_block_item(lf[154],0,C_fix(0));
t52=C_set_block_item(lf[155],0,C_fix(0));
t53=C_set_block_item(lf[156],0,C_fix(0));
t54=C_set_block_item(lf[157],0,C_fix(0));
t55=C_set_block_item(lf[158],0,C_fix(0));
t56=C_set_block_item(lf[159],0,C_fix(0));
t57=C_set_block_item(lf[160],0,C_fix(0));
t58=C_set_block_item(lf[161],0,C_fix(0));
t59=C_set_block_item(lf[162],0,C_fix(0));
t60=C_set_block_item(lf[163],0,C_fix(0));
t61=C_set_block_item(lf[164],0,C_fix(0));
t62=C_set_block_item(lf[165],0,C_fix(0));
t63=C_set_block_item(lf[166],0,C_fix(0));
t64=C_set_block_item(lf[167],0,C_fix(0));
t65=C_set_block_item(lf[168],0,C_fix(0));
t66=C_set_block_item(lf[169],0,C_fix(0));
t67=C_set_block_item(lf[170],0,C_fix(0));
t68=(C_word)C_a_i_list(&a,7,*((C_word*)lf[145]+1),*((C_word*)lf[146]+1),*((C_word*)lf[147]+1),*((C_word*)lf[148]+1),*((C_word*)lf[149]+1),*((C_word*)lf[150]+1),*((C_word*)lf[151]+1));
t69=C_mutate((C_word*)lf[171]+1,t68);
t70=*((C_word*)lf[172]+1);
t71=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=t70,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1447 make-vector */
t72=*((C_word*)lf[386]+1);
((C_proc4)(void*)(*((C_word*)t72+1)))(4,t72,t71,C_fix(256),C_SCHEME_FALSE);}

/* k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word ab[322],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2615,a[2]=t1,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[174]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2624,a[2]=t1,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[175]+1,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[176]+1,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[177]+1,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[178]+1,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[179]+1,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[180]+1,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[181]+1,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[182]+1,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[183]+1,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[184]+1,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[185]+1,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[186]+1,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[187]+1,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[188]+1,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[189]+1,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[190]+1,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[191]+1,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[192]+1,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[193]+1,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[194]+1,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[195]+1,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[196]+1,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[197]+1,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[198]+1,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[199]+1,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[200]+1,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[201]+1,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[202]+1,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[203]+1,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[204]+1,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[205]+1,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[206]+1,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[207]+1,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[208]+1,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[209]+1,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[210]+1,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[211]+1,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[212]+1,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2693,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2723,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t44,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[216]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t44,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t44,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[218]+1,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[219]+1,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[220]+1,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2823,a[2]=t51,a[3]=t52,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2837,a[2]=t51,a[3]=t52,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[231]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2916,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[238]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[239]+1);
t60=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=t59,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[241]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3018,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[243]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3159,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[255]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t69=*((C_word*)lf[262]+1);
t70=*((C_word*)lf[263]+1);
t71=*((C_word*)lf[264]+1);
t72=*((C_word*)lf[265]+1);
t73=*((C_word*)lf[96]+1);
t74=*((C_word*)lf[266]+1);
t75=*((C_word*)lf[267]+1);
t76=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3274,a[2]=t72,a[3]=t70,a[4]=t69,a[5]=t73,a[6]=t71,a[7]=t74,a[8]=t75,a[9]=((C_word)li82),tmp=(C_word)a,a+=10,tmp));
t77=C_mutate((C_word*)lf[271]+1,C_fix((C_word)P_OVERLAY));
t78=C_mutate((C_word*)lf[272]+1,C_fix((C_word)P_WAIT));
t79=C_mutate((C_word*)lf[273]+1,C_fix((C_word)P_NOWAIT));
t80=C_mutate((C_word*)lf[274]+1,C_fix((C_word)P_NOWAITO));
t81=C_mutate((C_word*)lf[275]+1,C_fix((C_word)P_DETACH));
t82=*((C_word*)lf[276]+1);
t83=*((C_word*)lf[51]+1);
t84=*((C_word*)lf[107]+1);
t85=*((C_word*)lf[4]+1);
t86=C_mutate(&lf[277],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3389,a[2]=t85,a[3]=t83,a[4]=t84,a[5]=t82,a[6]=((C_word)li86),tmp=(C_word)a,a+=7,tmp));
t87=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3468,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
t89=*((C_word*)lf[280]+1);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3502,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t91=C_mutate(&lf[281],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3552,a[2]=t89,a[3]=t87,a[4]=t88,a[5]=t90,a[6]=((C_word)li91),tmp=(C_word)a,a+=7,tmp));
t92=C_mutate(&lf[282],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3585,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t94=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3774,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3777,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t98=*((C_word*)lf[285]+1);
t99=*((C_word*)lf[290]+1);
t100=C_mutate((C_word*)lf[294]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3804,a[2]=t98,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t101=C_mutate(&lf[295],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3833,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t102=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3899,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t103=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp);
t104=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4080,a[2]=t103,a[3]=((C_word)li118),tmp=(C_word)a,a+=4,tmp));
t105=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4160,a[2]=t103,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4240,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4252,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4315,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4327,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4358,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t112=*((C_word*)lf[268]+1);
t113=*((C_word*)lf[264]+1);
t114=*((C_word*)lf[266]+1);
t115=*((C_word*)lf[100]+1);
t116=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4373,a[2]=t115,a[3]=t114,a[4]=t112,a[5]=t113,a[6]=((C_word)li144),tmp=(C_word)a,a+=7,tmp));
t117=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4599,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t118=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4605,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t119=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4611,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t120=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4617,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t121=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4623,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t122=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4629,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t123=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4635,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t124=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4641,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t125=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4647,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t126=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t127=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t128=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4665,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t129=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4671,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t130=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4677,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t131=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t132=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4689,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t133=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4695,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t134=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4701,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t135=C_mutate((C_word*)lf[341]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4707,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t136=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4713,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t137=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4719,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t138=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4725,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t139=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4731,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t140=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4737,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t141=C_mutate((C_word*)lf[347]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4743,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t142=C_mutate((C_word*)lf[348]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4749,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t143=C_mutate((C_word*)lf[349]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t144=C_mutate((C_word*)lf[350]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4761,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t145=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4767,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t146=C_mutate((C_word*)lf[352]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4773,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t147=C_mutate((C_word*)lf[353]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4779,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t148=C_mutate((C_word*)lf[354]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4785,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t149=C_mutate((C_word*)lf[355]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4791,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t150=C_mutate((C_word*)lf[356]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t151=C_mutate((C_word*)lf[357]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4803,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t152=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t153=C_mutate((C_word*)lf[359]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4815,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t154=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4821,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t155=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4827,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t156=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp));
t157=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4839,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t158=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4845,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp));
t159=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4851,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp));
t160=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4857,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp));
t161=C_set_block_item(lf[367],0,C_fix(0));
t162=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4864,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp));
t163=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4867,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp));
t164=C_set_block_item(lf[370],0,C_fix(0));
t165=C_set_block_item(lf[371],0,C_fix(0));
t166=C_set_block_item(lf[372],0,C_fix(0));
t167=C_set_block_item(lf[373],0,C_fix(0));
t168=C_set_block_item(lf[374],0,C_fix(0));
t169=C_set_block_item(lf[375],0,C_fix(0));
t170=C_set_block_item(lf[376],0,C_fix(0));
t171=C_set_block_item(lf[377],0,C_fix(0));
t172=C_set_block_item(lf[378],0,C_fix(0));
t173=C_set_block_item(lf[379],0,C_fix(0));
t174=C_set_block_item(lf[380],0,C_fix(0));
t175=C_set_block_item(lf[381],0,C_fix(0));
t176=C_set_block_item(lf[382],0,C_fix(0));
t177=C_set_block_item(lf[383],0,C_fix(0));
t178=C_set_block_item(lf[384],0,C_fix(0));
t179=C_set_block_item(lf[385],0,C_fix(0));
t180=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t180+1)))(2,t180,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4867,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4864,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
/* posixwin.scm: 2089 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[366],lf[0]);}

/* utc-time->seconds in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4851,2,t0,t1);}
/* posixwin.scm: 2088 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],lf[0]);}

/* user-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4845,2,t0,t1);}
/* posixwin.scm: 2087 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[364],lf[0]);}

/* unmap-file-from-memory in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
/* posixwin.scm: 2086 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[363],lf[0]);}

/* terminal-size in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
/* posixwin.scm: 2085 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[362],lf[0]);}

/* terminal-port? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
/* posixwin.scm: 2084 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[361],lf[0]);}

/* terminal-name in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
/* posixwin.scm: 2083 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[360],lf[0]);}

/* signal-unmask! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
/* posixwin.scm: 2082 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[359],lf[0]);}

/* signal-masked? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
/* posixwin.scm: 2081 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[358],lf[0]);}

/* signal-mask! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
/* posixwin.scm: 2080 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[357],lf[0]);}

/* signal-mask in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
/* posixwin.scm: 2079 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[356],lf[0]);}

/* set-user-id! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
/* posixwin.scm: 2078 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[355],lf[0]);}

/* set-signal-mask! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
/* posixwin.scm: 2077 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[354],lf[0]);}

/* set-root-directory! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
/* posixwin.scm: 2076 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[353],lf[0]);}

/* set-process-group-id! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
/* posixwin.scm: 2075 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[352],lf[0]);}

/* set-groups! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
/* posixwin.scm: 2074 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[351],lf[0]);}

/* set-group-id! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
/* posixwin.scm: 2073 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],lf[0]);}

/* set-alarm! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
/* posixwin.scm: 2072 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[349],lf[0]);}

/* read-symbolic-link in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4749,2,t0,t1);}
/* posixwin.scm: 2071 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[348],lf[0]);}

/* process-signal in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
/* posixwin.scm: 2070 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[347],lf[0]);}

/* process-group-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
/* posixwin.scm: 2069 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[346],lf[0]);}

/* process-fork in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
/* posixwin.scm: 2068 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[345],lf[0]);}

/* parent-process-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
/* posixwin.scm: 2067 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[344],lf[0]);}

/* memory-mapped-file-pointer in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4719,2,t0,t1);}
/* posixwin.scm: 2066 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[343],lf[0]);}

/* initialize-groups in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
/* posixwin.scm: 2065 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* group-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
/* posixwin.scm: 2064 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* get-groups in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
/* posixwin.scm: 2063 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* file-unlock in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
/* posixwin.scm: 2062 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* file-truncate in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
/* posixwin.scm: 2061 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* file-test-lock in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
/* posixwin.scm: 2060 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* file-select in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
/* posixwin.scm: 2059 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* file-lock/blocking in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
/* posixwin.scm: 2058 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* file-lock in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
/* posixwin.scm: 2057 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* file-link in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
/* posixwin.scm: 2056 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* map-file-to-memory in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
/* posixwin.scm: 2055 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* current-user-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
/* posixwin.scm: 2054 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* current-group-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
/* posixwin.scm: 2053 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* current-effective-user-name in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
/* posixwin.scm: 2052 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* current-effective-user-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4629,2,t0,t1);}
/* posixwin.scm: 2051 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* current-effective-group-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
/* posixwin.scm: 2050 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[327],lf[0]);}

/* create-symbolic-link in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
/* posixwin.scm: 2049 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* create-session in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4611,2,t0,t1);}
/* posixwin.scm: 2048 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[325],lf[0]);}

/* create-fifo in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4605,2,t0,t1);}
/* posixwin.scm: 2047 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[324],lf[0]);}

/* change-file-owner in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
/* posixwin.scm: 2046 error */
t2=*((C_word*)lf[323]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[322],lf[0]);}

/* find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_4373r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4373r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4373r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li139),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4520,a[2]=t5,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=t6,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4530,a[2]=t7,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action776810 */
t9=t8;
f_4530(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id777808 */
t11=t7;
f_4525(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit778805 */
t13=t6;
f_4520(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body774780 */
t15=t5;
f_4375(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-action776 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4530,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4536,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp);
/* def-id777808 */
t3=((C_word*)t0)[2];
f_4525(t3,t1,t2);}

/* a4535 in def-action776 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4536,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id777 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4525(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4525,NULL,3,t0,t1,t2);}
/* def-limit778805 */
t3=((C_word*)t0)[2];
f_4520(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit778 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4520,NULL,4,t0,t1,t2,t3);}
/* body774780 */
t4=((C_word*)t0)[2];
f_4375(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4375(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4375,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[314]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_4382(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4515,a[2]=t4,a[3]=t7,a[4]=((C_word)li137),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_4382(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4507,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));}}

/* f_4507 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4515 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4382,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li132),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4495,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2024 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[321]);}

/* k4493 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2024 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li136),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4394(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4394(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4394,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2030 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2031 pathname-file */
t3=*((C_word*)lf[320]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2037 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k4479 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2037 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2038 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4394(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4486 in k4479 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2037 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4394(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[315]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[316]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2031 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_4394(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2032 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4440,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li133),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li134),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4462,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li135),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 2034 ##sys#dynamic-wind */
t11=*((C_word*)lf[319]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2036 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4394(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a4461 in k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[317]+1));}

/* a4447 in k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4460,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2035 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[318]);}

/* k4458 in a4447 in k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2035 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4454 in a4447 in k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2035 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4394(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4439 in k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[317]+1));}

/* k4436 in k4426 in k4473 in k4411 in loop in k4390 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2033 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4394(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4499 in k4380 in body774 in find-files in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4499,3,t0,t1,t2);}
/* posixwin.scm: 2022 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4358,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4368,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1998 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4366 in current-user-name in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1999 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[110],lf[313]);}

/* system-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4353,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1989 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4351 in system-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1990 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[310],lf[312]);}

/* k4336 in system-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k4340 in k4336 in system-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4346,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k4344 in k4340 in k4336 in system-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4350,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k4348 in k4344 in k4340 in k4336 in system-information in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[311],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1979 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[308],lf[309]);}}

/* sleep in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4312,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4252r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4252r(t0,t1,t2,t3);}}

static void C_ccall f_4252r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[305]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4273,a[2]=t5,a[3]=t2,a[4]=((C_word)li125),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4279,a[2]=t2,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1958 ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[2],t7);}}

/* a4278 in process-wait in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4279,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1961 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1963 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k4287 in a4278 in process-wait in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1962 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[297],lf[305],lf[306],((C_word*)t0)[2]);}

/* a4272 in process-wait in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
/* posixwin.scm: 1958 ##sys#process-wait */
t2=*((C_word*)lf[304]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4240,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1951 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1952 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_4160r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4160r(t0,t1,t2,t3);}}

static void C_ccall f_4160r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4162,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li119),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4167,a[2]=t4,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=t5,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4177,a[2]=t6,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args725738 */
t8=t7;
f_4177(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env726736 */
t10=t6;
f_4172(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf727733 */
t12=t5;
f_4167(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body723729 */
t14=t4;
f_4162(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args725 in process* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4177,NULL,2,t0,t1);}
/* def-env726736 */
t2=((C_word*)t0)[2];
f_4172(t2,t1,C_SCHEME_FALSE);}

/* def-env726 in process* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4172(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4172,NULL,3,t0,t1,t2);}
/* def-exactf727733 */
t3=((C_word*)t0)[2];
f_4167(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf727 in process* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4167(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4167,NULL,4,t0,t1,t2,t3);}
/* body723729 */
t4=((C_word*)t0)[2];
f_4162(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body723 in process* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4162(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4162,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1945 %process */
f_4018(t1,lf[303],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_4080r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4080r(t0,t1,t2,t3);}}

static void C_ccall f_4080r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4082,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4087,a[2]=t4,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4092,a[2]=t5,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4097,a[2]=t6,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args697710 */
t8=t7;
f_4097(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env698708 */
t10=t6;
f_4092(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf699705 */
t12=t5;
f_4087(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body695701 */
t14=t4;
f_4082(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args697 in process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4097,NULL,2,t0,t1);}
/* def-env698708 */
t2=((C_word*)t0)[2];
f_4092(t2,t1,C_SCHEME_FALSE);}

/* def-env698 in process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4092(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4092,NULL,3,t0,t1,t2);}
/* def-exactf699705 */
t3=((C_word*)t0)[2];
f_4087(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf699 in process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4087(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4087,NULL,4,t0,t1,t2,t3);}
/* body695701 */
t4=((C_word*)t0)[2];
f_4082(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body695 in process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4082(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4082,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1942 %process */
f_4018(t1,lf[302],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4018(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4018,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t2,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4039,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1930 chkstrlst */
t14=t11;
f_4020(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4074,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1933 ##sys#shell-command-arguments */
t16=*((C_word*)lf[292]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,((C_word*)t8)[1]);}}

/* k4072 in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1934 ##sys#shell-command */
t4=*((C_word*)lf[288]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4076 in k4072 in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4039(2,t3,t2);}

/* k4037 in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1935 chkstrlst */
t3=((C_word*)t0)[2];
f_4020(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_4042(2,t3,C_SCHEME_UNDEFINED);}}

/* k4040 in k4037 in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li111),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[4],a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1936 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4052 in k4040 in k4037 in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4053,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1938 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1939 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a4046 in k4040 in k4037 in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
/* posixwin.scm: 1936 ##sys#process */
t2=*((C_word*)lf[296]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_4020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4020,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[301]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4028 in chkstrlst in %process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4029,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_3899r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_3899r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_3899r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3903,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_3903(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_3903(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[2],t9);}}}

/* k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3994,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1902 $quote-args-list */
t5=lf[277];
f_3389(t5,t3,t4,t1);}

/* k3992 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1902 string-intersperse */
t2=*((C_word*)lf[108]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(t2))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(t5))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(t8))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(t11))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t15=*((C_word*)lf[299]+1);
((C_proc6)C_retrieve_proc(t15))(6,t15,t14,t2,C_fix(0),C_SCHEME_FALSE,lf[300]);}

/* k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[299]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[300]);}

/* k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[299]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[300]);}

/* k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[299]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[300]);}

/* k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1909 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3841,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3841(2,t9,C_SCHEME_FALSE);}}

/* k3839 in k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_3845(2,t3,C_SCHEME_FALSE);}}

/* k3843 in k3839 in k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub605(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1912 open-input-file* */
t8=*((C_word*)lf[229]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_3935(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1917 ##sys#update-errno */
t8=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k3953 in k3843 in k3839 in k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1918 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[297],((C_word*)t0)[3],lf[298],((C_word*)t0)[2]);}

/* k3933 in k3843 in k3839 in k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1913 open-output-file* */
t3=*((C_word*)lf[230]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3939(2,t3,C_SCHEME_FALSE);}}

/* k3937 in k3933 in k3843 in k3839 in k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1915 open-input-file* */
t3=*((C_word*)lf[229]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3943(2,t3,C_SCHEME_FALSE);}}

/* k3941 in k3937 in k3933 in k3843 in k3839 in k3976 in k3972 in k3968 in k3964 in k3960 in k3904 in k3901 in ##sys#process in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1911 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3833,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub593(C_SCHEME_UNDEFINED,t2));}

/* process-run in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3804r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3804r(t0,t1,t2,t3);}}

static void C_ccall f_3804r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1870 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[273]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3821,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1871 ##sys#shell-command */
t7=*((C_word*)lf[288]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k3819 in process-run in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3825,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1871 ##sys#shell-command-arguments */
t3=*((C_word*)lf[292]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3823 in k3819 in process-run in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1871 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[273]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3798,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[293],t2));}

/* ##sys#shell-command in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1854 getenv */
t3=*((C_word*)lf[290]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[291]);}

/* k3779 in ##sys#shell-command in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3781,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1858 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k3791 in k3779 in ##sys#shell-command in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1859 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[288],lf[289]);}

/* current-process-id in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3774,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub581(C_SCHEME_UNDEFINED));}

/* process-spawn in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3687r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3687r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3687r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3689,a[2]=t3,a[3]=t2,a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3701,a[2]=t5,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=t6,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=t7,a[3]=((C_word)li101),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst560574 */
t9=t8;
f_3711(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst561572 */
t11=t7;
f_3706(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf562569 */
t13=t6;
f_3701(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body558564 */
t15=t5;
f_3689(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-arglst560 in process-spawn in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3711,NULL,2,t0,t1);}
/* def-envlst561572 */
t2=((C_word*)t0)[2];
f_3706(t2,t1,C_SCHEME_FALSE);}

/* def-envlst561 in process-spawn in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3706,NULL,3,t0,t1,t2);}
/* def-exactf562569 */
t3=((C_word*)t0)[2];
f_3701(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf562 in process-spawn in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3701(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3701,NULL,4,t0,t1,t2,t3);}
/* body558564 */
t4=((C_word*)t0)[2];
f_3689(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body558 in process-spawn in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3689(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3689,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1845 $exec-setup */
t6=lf[281];
f_3552(t6,t5,lf[285],((C_word*)t0)[2],t2,t3,t4);}

/* k3691 in body558 in process-spawn in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1846 $exec-teardown */
f_3585(((C_word*)t0)[3],lf[285],lf[286],((C_word*)t0)[2],t2);}

/* process-execute in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_3600r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3600r(t0,t1,t2,t3);}}

static void C_ccall f_3600r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3602,a[2]=t2,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3614,a[2]=t4,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3619,a[2]=t5,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=t6,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst530544 */
t8=t7;
f_3624(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst531542 */
t10=t6;
f_3619(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf532539 */
t12=t5;
f_3614(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body528534 */
t14=t4;
f_3602(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-arglst530 in process-execute in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3624,NULL,2,t0,t1);}
/* def-envlst531542 */
t2=((C_word*)t0)[2];
f_3619(t2,t1,C_SCHEME_FALSE);}

/* def-envlst531 in process-execute in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3619(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3619,NULL,3,t0,t1,t2);}
/* def-exactf532539 */
t3=((C_word*)t0)[2];
f_3614(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf532 in process-execute in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3614(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3614,NULL,4,t0,t1,t2,t3);}
/* body528534 */
t4=((C_word*)t0)[2];
f_3602(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body528 in process-execute in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3602(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3602,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1840 $exec-setup */
t6=lf[281];
f_3552(t6,t5,lf[283],((C_word*)t0)[2],t2,t3,t4);}

/* k3604 in body528 in process-execute in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1841 $exec-teardown */
f_3585(((C_word*)t0)[3],lf[283],lf[284],((C_word*)t0)[2],t2);}

/* $exec-teardown in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3585(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3585,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3589,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1832 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3587 in $exec-teardown in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1836 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3552,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3559,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1824 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k3557 in $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1825 setarg */
t4=((C_word*)t0)[4];
f_3468(5,t4,t2,C_fix(0),t1,t3);}

/* k3560 in k3557 in $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1826 $quote-args-list */
t4=lf[277];
f_3389(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3577 in k3560 in k3557 in $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1826 build-exec-argvec */
f_3502(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k3563 in k3560 in k3557 in $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1827 build-exec-argvec */
f_3502(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k3566 in k3563 in k3560 in k3557 in $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1829 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3573 in k3566 in k3563 in k3560 in k3557 in $exec-setup in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1829 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3502(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3502,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3514,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li89),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3514(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1821 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* do495 in build-exec-argvec in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3514(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3514,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1817 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3533,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1820 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k3531 in do495 in build-exec-argvec in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3514(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3485,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub484(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3468,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub474(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3389(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3389,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3432,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3432(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3432(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3432,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1798 reverse */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3460,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3463,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1803 needs-quoting? */
t8=((C_word*)t0)[2];
f_3394(t8,t7,t4);}}

/* k3461 in loop in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1803 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[278],((C_word*)t0)[2],lf[279]);}
else{
t2=((C_word*)t0)[3];
f_3460(2,t2,((C_word*)t0)[2]);}}

/* k3458 in loop in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1800 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3432(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3394,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3398,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1790 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3396 in needs-quoting? in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li83),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3403(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3396 in needs-quoting? in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3403,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3427,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1794 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k3425 in loop in k3396 in needs-quoting? in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1794 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3414 in loop in k3396 in needs-quoting? in $quote-args-list in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1795 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3403(t3,((C_word*)t0)[4],t2);}}

/* glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_3274r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3274r(t0,t1,t2);}}

static void C_ccall f_3274r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li81),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3280(t6,t1,t2);}

/* conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3280,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li80),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3301,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3378,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[270]);
/* posixwin.scm: 1751 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k3376 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1751 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1752 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1753 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k3309 in k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[269]);
/* posixwin.scm: 1754 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k3316 in k3309 in k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li79),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_3320(t5,((C_word*)t0)[2],t1);}

/* loop in k3316 in k3309 in k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_3320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3320,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1755 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3280(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1756 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k3335 in loop in k3316 in k3309 in k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1757 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1758 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3320(t3,((C_word*)t0)[6],t2);}}

/* k3345 in k3335 in loop in k3316 in k3309 in k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1757 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3320(t4,t2,t3);}

/* k3349 in k3345 in k3335 in loop in k3316 in k3309 in k3306 in k3303 in a3300 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3294 in conc-loop in glob in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
/* posixwin.scm: 1750 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3215r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3215r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3215r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3219,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1721 ##sys#check-port */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[256]);}

/* k3217 in set-buffering-mode! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[258]);
if(C_truep(t6)){
t7=t5;
f_3225(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[259]);
if(C_truep(t7)){
t8=t5;
f_3225(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[260]);
if(C_truep(t8)){
t9=t5;
f_3225(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1727 ##sys#error */
t9=*((C_word*)lf[62]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[256],lf[261],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k3223 in k3217 in set-buffering-mode! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[256]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[81],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1733 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[256],lf[257],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* _exit in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3199r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3199r(t0,t1,t2);}}

static void C_ccall f_3199r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub403(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub398(t2),C_fix(0));}

/* local-time->seconds in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3159,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[250]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3166,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1697 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[250],lf[253],t2);}
else{
t6=t4;
f_3166(2,t6,C_SCHEME_UNDEFINED);}}

/* k3164 in local-time->seconds in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1699 ##sys#cons-flonum */
t2=*((C_word*)lf[251]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1700 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[250],lf[252],((C_word*)t0)[3]);}}

/* time->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3079r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3079r(t0,t1,t2,t3);}}

static void C_ccall f_3079r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3083(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3083(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k3081 in time->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[246]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixwin.scm: 1684 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[246],lf[249],((C_word*)t0)[3]);}
else{
t5=t3;
f_3089(2,t5,C_SCHEME_UNDEFINED);}}

/* k3087 in k3081 in time->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[246]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1688 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub372(t4,t3),C_fix(0));}}

/* k3109 in k3087 in k3081 in time->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1692 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1693 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[246],lf[248],((C_word*)t0)[2]);}}

/* k3106 in k3087 in k3081 in time->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3108,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub378(t3,t2,t1),C_fix(0));}

/* k3096 in k3087 in k3081 in time->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1689 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[246],lf[247],((C_word*)t0)[2]);}}

/* seconds->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub363(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3048 in seconds->string in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1676 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1677 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[244],lf[245],((C_word*)t0)[2]);}}

/* seconds->utc-time in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3027,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[243]);
/* posixwin.scm: 1669 ##sys#decode-seconds */
t4=*((C_word*)lf[242]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3018,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[241]);
/* posixwin.scm: 1665 ##sys#decode-seconds */
t4=*((C_word*)lf[242]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2959(t5,t1,C_fix(0));}

/* loop in current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2959,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2963,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub346(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k2961 in loop in current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2971,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li67),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2971(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k2961 in loop in current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2971,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1657 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1658 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k2995 in scan in k2961 in loop in current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1657 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k2999 in k2995 in scan in k2961 in loop in current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2989,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1657 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2959(t5,t3,t4);}

/* k2987 in k2999 in k2995 in scan in k2961 in loop in current-environment in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2933,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[238]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1645 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2939 in unsetenv in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2916,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[237]);
t5=(C_word)C_i_check_string_2(t3,lf[237]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1640 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2925 in setenv in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2931,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1640 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2929 in k2925 in setenv in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2886r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2886r(t0,t1,t2,t3);}}

static void C_ccall f_2886r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[235]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_2893(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[235]);
t8=t5;
f_2893(t8,(C_word)C_dup2(t2,t6));}}

/* k2891 in duplicate-fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2893,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1630 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2896(2,t3,C_SCHEME_UNDEFINED);}}

/* k2900 in k2891 in duplicate-fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1631 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[235],lf[236],((C_word*)t0)[2]);}

/* k2894 in k2891 in duplicate-fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2851,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2855,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1612 ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[231]);}

/* k2853 in port->fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1613 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2882 in k2853 in port->fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1619 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[231],lf[232],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2864,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1616 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2864(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2868 in k2882 in k2853 in port->fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1617 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[231],lf[233],((C_word*)t0)[2]);}

/* k2862 in k2882 in k2853 in port->fileno in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2837r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2837r(t0,t1,t2,t3);}}

static void C_ccall f_2837r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[230]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1608 mode */
f_2768(t5,C_SCHEME_FALSE,t3);}

/* k2847 in open-output-file* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1608 check */
f_2805(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2823r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2823r(t0,t1,t2,t3);}}

static void C_ccall f_2823r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[229]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2835,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1604 mode */
f_2768(t5,C_SCHEME_TRUE,t3);}

/* k2833 in open-input-file* in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1604 check */
f_2805(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2805(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2805,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2809,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1595 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2807 in check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1597 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[227],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1598 ##sys#make-port */
t3=*((C_word*)lf[127]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[128]+1),lf[228],lf[81]);}}

/* k2819 in k2807 in check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2768(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2768,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2776,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[221]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1590 ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[222],t5);}
else{
t8=t4;
f_2776(2,t8,lf[223]);}}
else{
/* posixwin.scm: 1591 ##sys#error */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[224],t5);}}
else{
t5=t4;
f_2776(2,t5,(C_truep(t2)?lf[225]:lf[226]));}}

/* k2774 in mode in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1586 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2759,3,t0,t1,t2);}
/* posixwin.scm: 1570 check */
f_2723(t1,t2,C_fix((C_word)2),lf[217]);}

/* file-write-access? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2753,3,t0,t1,t2);}
/* posixwin.scm: 1569 check */
f_2723(t1,t2,C_fix((C_word)4),lf[216]);}

/* file-read-access? in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2747,3,t0,t1,t2);}
/* posixwin.scm: 1568 check */
f_2723(t1,t2,C_fix((C_word)2),lf[215]);}

/* check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2723(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2723,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2741,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1565 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2743 in check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1565 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2739 in check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2733(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1566 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2731 in k2739 in check in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2693,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[213]);
t5=(C_word)C_i_check_exact_2(t3,lf[213]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2717,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1554 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2719 in change-file-mode in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1554 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2715 in change-file-mode in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1555 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2707 in k2715 in change-file-mode in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1556 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[213],lf[214],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2637,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2647,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1462 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1464 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2645 in ##sys#interrupt-hook in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1463 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2624,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[174]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2611 in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2615,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[173]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2539r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2539r(t0,t1,t2);}}

static void C_ccall f_2539r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2543,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2543(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2543(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k2541 in create-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1399 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2546(2,t3,C_SCHEME_UNDEFINED);}}

/* k2553 in k2541 in create-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1400 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[143],lf[144]);}

/* k2544 in k2541 in create-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1401 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2519r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2519r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[142]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2523,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2521 in with-output-to-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2529,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1384 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2528 in k2521 in with-output-to-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2529r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2529r(t0,t1,t2);}}

static void C_ccall f_2529r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2533,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1386 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2531 in a2528 in k2521 in with-output-to-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[142]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2499r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2499r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2499r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[140]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2503,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2501 in with-input-from-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
t2=C_mutate((C_word*)lf[140]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2509,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1374 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2508 in k2501 in with-input-from-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2509r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2509r(t0,t1,t2);}}

static void C_ccall f_2509r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2513,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1376 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2511 in a2508 in k2501 in with-input-from-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[140]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2475r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2475r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2475r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2479,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2477 in call-with-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2484,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2490,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1364 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2489 in k2477 in call-with-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2490r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2490r(t0,t1,t2);}}

static void C_ccall f_2490r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2494,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1367 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2492 in a2489 in k2477 in call-with-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2483 in k2477 in call-with-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
/* posixwin.scm: 1365 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2451r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2451r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2453 in call-with-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2466,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1356 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2465 in k2453 in call-with-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2466r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2466r(t0,t1,t2);}}

static void C_ccall f_2466r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1359 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2468 in a2465 in k2453 in call-with-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2459 in k2453 in call-with-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
/* posixwin.scm: 1357 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2432,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1343 ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[133]);}

/* k2434 in close-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1345 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2437 in k2434 in close-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1346 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[133],lf[134],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2396r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2396r(t0,t1,t2,t3);}}

static void C_ccall f_2396r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[132]);
t5=f_2324(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2410,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[124]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1338 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[131]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1339 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1340 badmode */
f_2336(t6,t5);}}}

/* k2425 in open-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2410(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k2415 in open-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2417,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2410(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k2408 in open-output-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1335 check */
f_2342(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2360r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2360r(t0,t1,t2,t3);}}

static void C_ccall f_2360r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[130]);
t5=f_2324(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2374,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[124]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2381,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1328 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[131]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2391,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1329 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1330 badmode */
f_2336(t6,t5);}}}

/* k2389 in open-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2374(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k2379 in open-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2374(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k2372 in open-input-pipe in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1325 check */
f_2342(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2342(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2342,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2346,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1315 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2344 in check in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1317 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[126],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1318 ##sys#make-port */
t3=*((C_word*)lf[127]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[128]+1),lf[129],lf[81]);}}

/* k2356 in k2344 in check in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2336(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2336,NULL,2,t1,t2);}
/* posixwin.scm: 1313 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[125],t2);}

/* mode in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static C_word C_fcall f_2324(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[124]));}

/* canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1967,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[111]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1974,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1252 cwd */
t8=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1254 sref */
t10=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2113(t9,C_SCHEME_FALSE);}}}

/* k2312 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1254 sep? */
t2=((C_word*)t0)[3];
f_2113(t2,f_1956(t1));}

/* k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2113,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1256 cwd */
t4=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1259 cwd */
t5=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1260 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k2298 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1260 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k2287 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2289,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1261 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2143(t2,C_SCHEME_FALSE);}}

/* k2294 in k2287 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1261 sep? */
t2=((C_word*)t0)[3];
f_2143(t2,f_1956(t1));}

/* k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2143,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1263 cwd */
t4=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1269 cwd */
t5=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1270 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k2280 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1270 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2259 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2278,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1271 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_2185(t2,C_SCHEME_FALSE);}}

/* k2276 in k2259 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1271 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2265 in k2259 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1272 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_2185(t2,C_SCHEME_FALSE);}}

/* k2272 in k2265 in k2259 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1272 sep? */
t2=((C_word*)t0)[3];
f_2185(t2,f_1956(t1));}

/* k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2185,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_1974(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1274 sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k2256 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1274 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k2235 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1275 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2191(2,t2,C_SCHEME_FALSE);}}

/* k2252 in k2235 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2241 in k2235 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1276 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_2191(2,t2,C_SCHEME_FALSE);}}

/* k2248 in k2241 in k2235 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1276 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1278 ##sys#substring */
t3=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1282 sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k2232 in k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=f_1956(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1284 cwd */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1287 cwd */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2228 in k2232 in k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1287 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[123],((C_word*)t0)[2]);}

/* k2221 in k2232 in k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1284 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k2217 in k2232 in k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2196 in k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1280 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k2200 in k2196 in k2189 in k2183 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1277 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[122],t1);}

/* k2177 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1269 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[121],((C_word*)t0)[2]);}

/* k2164 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1263 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k2148 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1265 user */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2152 in k2148 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2158,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1266 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k2156 in k2152 in k2148 in k2141 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1262 sappend */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[120],((C_word*)t0)[2],t1);}

/* k2135 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1259 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[119],((C_word*)t0)[2]);}

/* k2122 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1256 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k2118 in k2111 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1255 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2105 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1252 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[118]);}

/* k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2093,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1288 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t1,C_fix(3),t4);}

/* k2091 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
t2=*((C_word*)lf[116]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[117]);}

/* k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li32),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1983(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1983(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1983,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1290 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1291 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1302 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[115],t5);}}

/* k2063 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2065,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2062(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1304 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[114],t3);}}

/* k2072 in k2063 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2062(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_2062(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k2060 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_2062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1300 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1983(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1292 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1293 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=f_1956(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1295 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1298 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k2029 in k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2035,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2039,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1299 reverse */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2037 in k2029 in k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1299 isperse */
f_1951(((C_word*)t0)[2],t1);}

/* k2033 in k2029 in k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2010 in k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2016,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[112],((C_word*)t0)[2]);
/* posixwin.scm: 1296 reverse */
t5=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k2018 in k2010 in k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 isperse */
f_1951(((C_word*)t0)[2],t1);}

/* k2014 in k2010 in k2041 in k1994 in k1988 in loop in k1979 in k1972 in canonical-path in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1294 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sep? in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static C_word C_fcall f_1956(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1951(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1951,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[109]);}

/* current-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1900r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1900r(t0,t1,t2);}}

static void C_ccall f_1900r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1904(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1904(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k1902 in current-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1228 change-directory */
t2=*((C_word*)lf[91]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1229 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k1911 in k1902 in current-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1231 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1914 in k1911 in k1902 in current-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1233 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1234 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[99],lf[102]);}}

/* directory? in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1873,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1221 ##sys#expand-home-path */
t7=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k1896 in directory? in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1221 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1892 in directory? in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1220 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1878 in directory? in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1713r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1713r(t0,t1,t2);}}

static void C_ccall f_1713r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[2],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1816,a[2]=t3,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1821,a[2]=t4,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec123149 */
t6=t5;
f_1821(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?124147 */
t8=t4;
f_1816(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body121126 */
t10=t3;
f_1715(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[2],t9);}}}}

/* def-spec123 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1821,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1829,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1191 current-directory */
t3=*((C_word*)lf[99]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1827 in def-spec123 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?124147 */
t2=((C_word*)t0)[3];
f_1816(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?124 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1816,NULL,3,t0,t1,t2);}
/* body121126 */
t3=((C_word*)t0)[2];
f_1715(t3,t1,t2,C_SCHEME_FALSE);}

/* body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1715,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[96]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1722,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1193 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1194 ##sys#make-pointer */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1195 ##sys#make-pointer */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1196 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1813 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1196 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1730 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1199 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1749(t6,((C_word*)t0)[6]);}}

/* loop in k1730 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1749,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1208 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1757 in loop in k1730 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1771,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_1771(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_1771(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_1771(t7,C_SCHEME_FALSE);}}

/* k1769 in k1757 in loop in k1730 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1771,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1215 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1749(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1216 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1749(t3,t2);}}

/* k1779 in k1769 in k1757 in loop in k1730 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1739 in k1730 in k1726 in k1723 in k1720 in body121 in directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1200 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[96],lf[97],((C_word*)t0)[2]);}

/* delete-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1686,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[93]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1707,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1183 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1709 in delete-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1183 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1705 in delete-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1184 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1697 in k1705 in delete-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1185 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[93],lf[94],((C_word*)t0)[2]);}

/* change-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1659,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1680,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1684,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1176 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1682 in change-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1176 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1678 in change-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1177 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1670 in k1678 in change-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1178 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[91],lf[92],((C_word*)t0)[2]);}

/* create-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1632,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1169 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1655 in create-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1169 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1651 in create-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1170 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1643 in k1651 in create-directory in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1171 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* set-file-position! in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1571r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1571r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1571r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[84]);
t8=(C_word)C_i_check_exact_2(t6,lf[84]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1584,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1154 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[87],lf[84],lf[88],t3,t2);}
else{
t10=t9;
f_1584(2,t10,C_SCHEME_UNDEFINED);}}

/* k1582 in set-file-position! in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1155 port? */
t4=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1597 in k1582 in set-file-position! in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[4];
f_1590(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1590(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1159 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[84],lf[86],((C_word*)t0)[5]);}}}

/* k1588 in k1582 in set-file-position! in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1160 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1591 in k1588 in k1582 in set-file-position! in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1161 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[84],lf[85],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1531,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1535,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1138 port? */
t5=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1548 in file-position in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[2];
f_1535(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1535(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1143 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[79],lf[82],((C_word*)t0)[3]);}}}

/* k1533 in file-position in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1538,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1145 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1538(2,t3,C_SCHEME_UNDEFINED);}}

/* k1542 in k1533 in file-position in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1146 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[79],lf[80],((C_word*)t0)[2]);}

/* k1536 in k1533 in file-position in k1527 in k1523 in k1519 in k1515 in k1511 in k1507 in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1498(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1498,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));}

/* f_1500 in stat-type in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1500,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1493,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1470,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1116 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1489 in regular-file? in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1116 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1475 in regular-file? in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1464,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1112 ##sys#stat */
f_1365(t3,t2);}

/* k1466 in file-permissions in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1458,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1462,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1111 ##sys#stat */
f_1365(t3,t2);}

/* k1460 in file-owner in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1452,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1110 ##sys#stat */
f_1365(t3,t2);}

/* k1454 in file-change-time in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1446,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1109 ##sys#stat */
f_1365(t3,t2);}

/* k1448 in file-access-time in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1108 ##sys#stat */
f_1365(t3,t2);}

/* k1442 in file-modification-time in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1434,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1107 ##sys#stat */
f_1365(t3,t2);}

/* k1436 in file-size in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1403r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1403r(t0,t1,t2,t3);}}

static void C_ccall f_1403r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1407(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1407(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k1405 in file-stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1101 ##sys#stat */
f_1365(t2,((C_word*)t0)[2]);}

/* k1408 in k1405 in file-stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1410,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_fcall f_1365(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1365,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_1369(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1394,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1398,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1095 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k1396 in ##sys#stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1094 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1392 in ##sys#stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1369(2,t2,(C_word)C_stat(t1));}

/* k1367 in ##sys#stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1097 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1376 in k1367 in ##sys#stat in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1098 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1327,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1063 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1332 in file-mkstemp in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1334,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1065 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1335 in k1332 in file-mkstemp in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1067 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1340(2,t4,C_SCHEME_UNDEFINED);}}

/* k1355 in k1335 in k1332 in file-mkstemp in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1068 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k1338 in k1335 in k1332 in file-mkstemp in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1069 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1345 in k1338 in k1335 in k1332 in file-mkstemp in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1069 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1285r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1285r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1285r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1292,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1292(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1050 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k1290 in file-write in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1292,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1301,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1307,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1055 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1301(2,t8,C_SCHEME_UNDEFINED);}}

/* k1305 in k1290 in file-write in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1056 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1299 in k1290 in file-write in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1240r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1240r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1240r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1250,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1250(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1037 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1248 in file-read in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1253(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1039 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k1251 in k1248 in file-read in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1256,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1042 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1256(2,t5,C_SCHEME_UNDEFINED);}}

/* k1263 in k1251 in k1248 in file-read in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1043 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1254 in k1251 in k1248 in file-read in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1222,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1029 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1233 in file-close in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1030 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1181r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1181r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1198,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1019 ##sys#expand-home-path */
t12=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k1212 in file-open in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1019 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1196 in file-open in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1198,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1201,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1021 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1201(2,t5,C_SCHEME_UNDEFINED);}}

/* k1205 in k1196 in file-open in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1022 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1199 in k1196 in file-open in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1135r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1135r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1135r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1139,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 950  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1137 in posix-error in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1148 in k1137 in posix-error in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 951  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k1144 in k1137 in posix-error in k1121 in k1118 in k1115 in k1112 in k1109 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[439] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_1111posixwin.scm",(void*)f_1111},
{"f_1114posixwin.scm",(void*)f_1114},
{"f_1117posixwin.scm",(void*)f_1117},
{"f_1120posixwin.scm",(void*)f_1120},
{"f_1123posixwin.scm",(void*)f_1123},
{"f_1509posixwin.scm",(void*)f_1509},
{"f_1513posixwin.scm",(void*)f_1513},
{"f_1517posixwin.scm",(void*)f_1517},
{"f_1521posixwin.scm",(void*)f_1521},
{"f_1525posixwin.scm",(void*)f_1525},
{"f_1529posixwin.scm",(void*)f_1529},
{"f_2613posixwin.scm",(void*)f_2613},
{"f_4867posixwin.scm",(void*)f_4867},
{"f_4864posixwin.scm",(void*)f_4864},
{"f_4857posixwin.scm",(void*)f_4857},
{"f_4851posixwin.scm",(void*)f_4851},
{"f_4845posixwin.scm",(void*)f_4845},
{"f_4839posixwin.scm",(void*)f_4839},
{"f_4833posixwin.scm",(void*)f_4833},
{"f_4827posixwin.scm",(void*)f_4827},
{"f_4821posixwin.scm",(void*)f_4821},
{"f_4815posixwin.scm",(void*)f_4815},
{"f_4809posixwin.scm",(void*)f_4809},
{"f_4803posixwin.scm",(void*)f_4803},
{"f_4797posixwin.scm",(void*)f_4797},
{"f_4791posixwin.scm",(void*)f_4791},
{"f_4785posixwin.scm",(void*)f_4785},
{"f_4779posixwin.scm",(void*)f_4779},
{"f_4773posixwin.scm",(void*)f_4773},
{"f_4767posixwin.scm",(void*)f_4767},
{"f_4761posixwin.scm",(void*)f_4761},
{"f_4755posixwin.scm",(void*)f_4755},
{"f_4749posixwin.scm",(void*)f_4749},
{"f_4743posixwin.scm",(void*)f_4743},
{"f_4737posixwin.scm",(void*)f_4737},
{"f_4731posixwin.scm",(void*)f_4731},
{"f_4725posixwin.scm",(void*)f_4725},
{"f_4719posixwin.scm",(void*)f_4719},
{"f_4713posixwin.scm",(void*)f_4713},
{"f_4707posixwin.scm",(void*)f_4707},
{"f_4701posixwin.scm",(void*)f_4701},
{"f_4695posixwin.scm",(void*)f_4695},
{"f_4689posixwin.scm",(void*)f_4689},
{"f_4683posixwin.scm",(void*)f_4683},
{"f_4677posixwin.scm",(void*)f_4677},
{"f_4671posixwin.scm",(void*)f_4671},
{"f_4665posixwin.scm",(void*)f_4665},
{"f_4659posixwin.scm",(void*)f_4659},
{"f_4653posixwin.scm",(void*)f_4653},
{"f_4647posixwin.scm",(void*)f_4647},
{"f_4641posixwin.scm",(void*)f_4641},
{"f_4635posixwin.scm",(void*)f_4635},
{"f_4629posixwin.scm",(void*)f_4629},
{"f_4623posixwin.scm",(void*)f_4623},
{"f_4617posixwin.scm",(void*)f_4617},
{"f_4611posixwin.scm",(void*)f_4611},
{"f_4605posixwin.scm",(void*)f_4605},
{"f_4599posixwin.scm",(void*)f_4599},
{"f_4373posixwin.scm",(void*)f_4373},
{"f_4530posixwin.scm",(void*)f_4530},
{"f_4536posixwin.scm",(void*)f_4536},
{"f_4525posixwin.scm",(void*)f_4525},
{"f_4520posixwin.scm",(void*)f_4520},
{"f_4375posixwin.scm",(void*)f_4375},
{"f_4507posixwin.scm",(void*)f_4507},
{"f_4515posixwin.scm",(void*)f_4515},
{"f_4382posixwin.scm",(void*)f_4382},
{"f_4495posixwin.scm",(void*)f_4495},
{"f_4392posixwin.scm",(void*)f_4392},
{"f_4394posixwin.scm",(void*)f_4394},
{"f_4413posixwin.scm",(void*)f_4413},
{"f_4481posixwin.scm",(void*)f_4481},
{"f_4488posixwin.scm",(void*)f_4488},
{"f_4475posixwin.scm",(void*)f_4475},
{"f_4428posixwin.scm",(void*)f_4428},
{"f_4462posixwin.scm",(void*)f_4462},
{"f_4448posixwin.scm",(void*)f_4448},
{"f_4460posixwin.scm",(void*)f_4460},
{"f_4456posixwin.scm",(void*)f_4456},
{"f_4440posixwin.scm",(void*)f_4440},
{"f_4438posixwin.scm",(void*)f_4438},
{"f_4499posixwin.scm",(void*)f_4499},
{"f_4358posixwin.scm",(void*)f_4358},
{"f_4368posixwin.scm",(void*)f_4368},
{"f_4327posixwin.scm",(void*)f_4327},
{"f_4353posixwin.scm",(void*)f_4353},
{"f_4338posixwin.scm",(void*)f_4338},
{"f_4342posixwin.scm",(void*)f_4342},
{"f_4346posixwin.scm",(void*)f_4346},
{"f_4350posixwin.scm",(void*)f_4350},
{"f_4315posixwin.scm",(void*)f_4315},
{"f_4312posixwin.scm",(void*)f_4312},
{"f_4252posixwin.scm",(void*)f_4252},
{"f_4279posixwin.scm",(void*)f_4279},
{"f_4289posixwin.scm",(void*)f_4289},
{"f_4273posixwin.scm",(void*)f_4273},
{"f_4240posixwin.scm",(void*)f_4240},
{"f_4160posixwin.scm",(void*)f_4160},
{"f_4177posixwin.scm",(void*)f_4177},
{"f_4172posixwin.scm",(void*)f_4172},
{"f_4167posixwin.scm",(void*)f_4167},
{"f_4162posixwin.scm",(void*)f_4162},
{"f_4080posixwin.scm",(void*)f_4080},
{"f_4097posixwin.scm",(void*)f_4097},
{"f_4092posixwin.scm",(void*)f_4092},
{"f_4087posixwin.scm",(void*)f_4087},
{"f_4082posixwin.scm",(void*)f_4082},
{"f_4018posixwin.scm",(void*)f_4018},
{"f_4074posixwin.scm",(void*)f_4074},
{"f_4078posixwin.scm",(void*)f_4078},
{"f_4039posixwin.scm",(void*)f_4039},
{"f_4042posixwin.scm",(void*)f_4042},
{"f_4053posixwin.scm",(void*)f_4053},
{"f_4047posixwin.scm",(void*)f_4047},
{"f_4020posixwin.scm",(void*)f_4020},
{"f_4029posixwin.scm",(void*)f_4029},
{"f_3899posixwin.scm",(void*)f_3899},
{"f_3903posixwin.scm",(void*)f_3903},
{"f_3994posixwin.scm",(void*)f_3994},
{"f_3906posixwin.scm",(void*)f_3906},
{"f_3962posixwin.scm",(void*)f_3962},
{"f_3966posixwin.scm",(void*)f_3966},
{"f_3970posixwin.scm",(void*)f_3970},
{"f_3974posixwin.scm",(void*)f_3974},
{"f_3978posixwin.scm",(void*)f_3978},
{"f_3841posixwin.scm",(void*)f_3841},
{"f_3845posixwin.scm",(void*)f_3845},
{"f_3955posixwin.scm",(void*)f_3955},
{"f_3935posixwin.scm",(void*)f_3935},
{"f_3939posixwin.scm",(void*)f_3939},
{"f_3943posixwin.scm",(void*)f_3943},
{"f_3833posixwin.scm",(void*)f_3833},
{"f_3804posixwin.scm",(void*)f_3804},
{"f_3821posixwin.scm",(void*)f_3821},
{"f_3825posixwin.scm",(void*)f_3825},
{"f_3798posixwin.scm",(void*)f_3798},
{"f_3777posixwin.scm",(void*)f_3777},
{"f_3781posixwin.scm",(void*)f_3781},
{"f_3793posixwin.scm",(void*)f_3793},
{"f_3774posixwin.scm",(void*)f_3774},
{"f_3687posixwin.scm",(void*)f_3687},
{"f_3711posixwin.scm",(void*)f_3711},
{"f_3706posixwin.scm",(void*)f_3706},
{"f_3701posixwin.scm",(void*)f_3701},
{"f_3689posixwin.scm",(void*)f_3689},
{"f_3693posixwin.scm",(void*)f_3693},
{"f_3600posixwin.scm",(void*)f_3600},
{"f_3624posixwin.scm",(void*)f_3624},
{"f_3619posixwin.scm",(void*)f_3619},
{"f_3614posixwin.scm",(void*)f_3614},
{"f_3602posixwin.scm",(void*)f_3602},
{"f_3606posixwin.scm",(void*)f_3606},
{"f_3585posixwin.scm",(void*)f_3585},
{"f_3589posixwin.scm",(void*)f_3589},
{"f_3552posixwin.scm",(void*)f_3552},
{"f_3559posixwin.scm",(void*)f_3559},
{"f_3562posixwin.scm",(void*)f_3562},
{"f_3579posixwin.scm",(void*)f_3579},
{"f_3565posixwin.scm",(void*)f_3565},
{"f_3568posixwin.scm",(void*)f_3568},
{"f_3575posixwin.scm",(void*)f_3575},
{"f_3502posixwin.scm",(void*)f_3502},
{"f_3514posixwin.scm",(void*)f_3514},
{"f_3533posixwin.scm",(void*)f_3533},
{"f_3485posixwin.scm",(void*)f_3485},
{"f_3468posixwin.scm",(void*)f_3468},
{"f_3389posixwin.scm",(void*)f_3389},
{"f_3432posixwin.scm",(void*)f_3432},
{"f_3463posixwin.scm",(void*)f_3463},
{"f_3460posixwin.scm",(void*)f_3460},
{"f_3394posixwin.scm",(void*)f_3394},
{"f_3398posixwin.scm",(void*)f_3398},
{"f_3403posixwin.scm",(void*)f_3403},
{"f_3427posixwin.scm",(void*)f_3427},
{"f_3416posixwin.scm",(void*)f_3416},
{"f_3274posixwin.scm",(void*)f_3274},
{"f_3280posixwin.scm",(void*)f_3280},
{"f_3301posixwin.scm",(void*)f_3301},
{"f_3378posixwin.scm",(void*)f_3378},
{"f_3305posixwin.scm",(void*)f_3305},
{"f_3308posixwin.scm",(void*)f_3308},
{"f_3311posixwin.scm",(void*)f_3311},
{"f_3318posixwin.scm",(void*)f_3318},
{"f_3320posixwin.scm",(void*)f_3320},
{"f_3337posixwin.scm",(void*)f_3337},
{"f_3347posixwin.scm",(void*)f_3347},
{"f_3351posixwin.scm",(void*)f_3351},
{"f_3295posixwin.scm",(void*)f_3295},
{"f_3215posixwin.scm",(void*)f_3215},
{"f_3219posixwin.scm",(void*)f_3219},
{"f_3225posixwin.scm",(void*)f_3225},
{"f_3199posixwin.scm",(void*)f_3199},
{"f_3187posixwin.scm",(void*)f_3187},
{"f_3159posixwin.scm",(void*)f_3159},
{"f_3166posixwin.scm",(void*)f_3166},
{"f_3079posixwin.scm",(void*)f_3079},
{"f_3083posixwin.scm",(void*)f_3083},
{"f_3089posixwin.scm",(void*)f_3089},
{"f_3111posixwin.scm",(void*)f_3111},
{"f_3108posixwin.scm",(void*)f_3108},
{"f_3098posixwin.scm",(void*)f_3098},
{"f_3046posixwin.scm",(void*)f_3046},
{"f_3050posixwin.scm",(void*)f_3050},
{"f_3027posixwin.scm",(void*)f_3027},
{"f_3018posixwin.scm",(void*)f_3018},
{"f_2953posixwin.scm",(void*)f_2953},
{"f_2959posixwin.scm",(void*)f_2959},
{"f_2963posixwin.scm",(void*)f_2963},
{"f_2971posixwin.scm",(void*)f_2971},
{"f_2997posixwin.scm",(void*)f_2997},
{"f_3001posixwin.scm",(void*)f_3001},
{"f_2989posixwin.scm",(void*)f_2989},
{"f_2933posixwin.scm",(void*)f_2933},
{"f_2941posixwin.scm",(void*)f_2941},
{"f_2916posixwin.scm",(void*)f_2916},
{"f_2927posixwin.scm",(void*)f_2927},
{"f_2931posixwin.scm",(void*)f_2931},
{"f_2886posixwin.scm",(void*)f_2886},
{"f_2893posixwin.scm",(void*)f_2893},
{"f_2902posixwin.scm",(void*)f_2902},
{"f_2896posixwin.scm",(void*)f_2896},
{"f_2851posixwin.scm",(void*)f_2851},
{"f_2855posixwin.scm",(void*)f_2855},
{"f_2884posixwin.scm",(void*)f_2884},
{"f_2870posixwin.scm",(void*)f_2870},
{"f_2864posixwin.scm",(void*)f_2864},
{"f_2837posixwin.scm",(void*)f_2837},
{"f_2849posixwin.scm",(void*)f_2849},
{"f_2823posixwin.scm",(void*)f_2823},
{"f_2835posixwin.scm",(void*)f_2835},
{"f_2805posixwin.scm",(void*)f_2805},
{"f_2809posixwin.scm",(void*)f_2809},
{"f_2821posixwin.scm",(void*)f_2821},
{"f_2768posixwin.scm",(void*)f_2768},
{"f_2776posixwin.scm",(void*)f_2776},
{"f_2759posixwin.scm",(void*)f_2759},
{"f_2753posixwin.scm",(void*)f_2753},
{"f_2747posixwin.scm",(void*)f_2747},
{"f_2723posixwin.scm",(void*)f_2723},
{"f_2745posixwin.scm",(void*)f_2745},
{"f_2741posixwin.scm",(void*)f_2741},
{"f_2733posixwin.scm",(void*)f_2733},
{"f_2693posixwin.scm",(void*)f_2693},
{"f_2721posixwin.scm",(void*)f_2721},
{"f_2717posixwin.scm",(void*)f_2717},
{"f_2709posixwin.scm",(void*)f_2709},
{"f_2637posixwin.scm",(void*)f_2637},
{"f_2647posixwin.scm",(void*)f_2647},
{"f_2624posixwin.scm",(void*)f_2624},
{"f_2615posixwin.scm",(void*)f_2615},
{"f_2539posixwin.scm",(void*)f_2539},
{"f_2543posixwin.scm",(void*)f_2543},
{"f_2555posixwin.scm",(void*)f_2555},
{"f_2546posixwin.scm",(void*)f_2546},
{"f_2519posixwin.scm",(void*)f_2519},
{"f_2523posixwin.scm",(void*)f_2523},
{"f_2529posixwin.scm",(void*)f_2529},
{"f_2533posixwin.scm",(void*)f_2533},
{"f_2499posixwin.scm",(void*)f_2499},
{"f_2503posixwin.scm",(void*)f_2503},
{"f_2509posixwin.scm",(void*)f_2509},
{"f_2513posixwin.scm",(void*)f_2513},
{"f_2475posixwin.scm",(void*)f_2475},
{"f_2479posixwin.scm",(void*)f_2479},
{"f_2490posixwin.scm",(void*)f_2490},
{"f_2494posixwin.scm",(void*)f_2494},
{"f_2484posixwin.scm",(void*)f_2484},
{"f_2451posixwin.scm",(void*)f_2451},
{"f_2455posixwin.scm",(void*)f_2455},
{"f_2466posixwin.scm",(void*)f_2466},
{"f_2470posixwin.scm",(void*)f_2470},
{"f_2460posixwin.scm",(void*)f_2460},
{"f_2432posixwin.scm",(void*)f_2432},
{"f_2436posixwin.scm",(void*)f_2436},
{"f_2439posixwin.scm",(void*)f_2439},
{"f_2396posixwin.scm",(void*)f_2396},
{"f_2427posixwin.scm",(void*)f_2427},
{"f_2417posixwin.scm",(void*)f_2417},
{"f_2410posixwin.scm",(void*)f_2410},
{"f_2360posixwin.scm",(void*)f_2360},
{"f_2391posixwin.scm",(void*)f_2391},
{"f_2381posixwin.scm",(void*)f_2381},
{"f_2374posixwin.scm",(void*)f_2374},
{"f_2342posixwin.scm",(void*)f_2342},
{"f_2346posixwin.scm",(void*)f_2346},
{"f_2358posixwin.scm",(void*)f_2358},
{"f_2336posixwin.scm",(void*)f_2336},
{"f_2324posixwin.scm",(void*)f_2324},
{"f_1967posixwin.scm",(void*)f_1967},
{"f_2314posixwin.scm",(void*)f_2314},
{"f_2113posixwin.scm",(void*)f_2113},
{"f_2300posixwin.scm",(void*)f_2300},
{"f_2289posixwin.scm",(void*)f_2289},
{"f_2296posixwin.scm",(void*)f_2296},
{"f_2143posixwin.scm",(void*)f_2143},
{"f_2282posixwin.scm",(void*)f_2282},
{"f_2261posixwin.scm",(void*)f_2261},
{"f_2278posixwin.scm",(void*)f_2278},
{"f_2267posixwin.scm",(void*)f_2267},
{"f_2274posixwin.scm",(void*)f_2274},
{"f_2185posixwin.scm",(void*)f_2185},
{"f_2258posixwin.scm",(void*)f_2258},
{"f_2237posixwin.scm",(void*)f_2237},
{"f_2254posixwin.scm",(void*)f_2254},
{"f_2243posixwin.scm",(void*)f_2243},
{"f_2250posixwin.scm",(void*)f_2250},
{"f_2191posixwin.scm",(void*)f_2191},
{"f_2234posixwin.scm",(void*)f_2234},
{"f_2230posixwin.scm",(void*)f_2230},
{"f_2223posixwin.scm",(void*)f_2223},
{"f_2219posixwin.scm",(void*)f_2219},
{"f_2198posixwin.scm",(void*)f_2198},
{"f_2202posixwin.scm",(void*)f_2202},
{"f_2179posixwin.scm",(void*)f_2179},
{"f_2166posixwin.scm",(void*)f_2166},
{"f_2150posixwin.scm",(void*)f_2150},
{"f_2154posixwin.scm",(void*)f_2154},
{"f_2158posixwin.scm",(void*)f_2158},
{"f_2137posixwin.scm",(void*)f_2137},
{"f_2124posixwin.scm",(void*)f_2124},
{"f_2120posixwin.scm",(void*)f_2120},
{"f_2107posixwin.scm",(void*)f_2107},
{"f_1974posixwin.scm",(void*)f_1974},
{"f_2093posixwin.scm",(void*)f_2093},
{"f_1981posixwin.scm",(void*)f_1981},
{"f_1983posixwin.scm",(void*)f_1983},
{"f_1990posixwin.scm",(void*)f_1990},
{"f_2065posixwin.scm",(void*)f_2065},
{"f_2074posixwin.scm",(void*)f_2074},
{"f_2062posixwin.scm",(void*)f_2062},
{"f_1996posixwin.scm",(void*)f_1996},
{"f_2043posixwin.scm",(void*)f_2043},
{"f_2031posixwin.scm",(void*)f_2031},
{"f_2039posixwin.scm",(void*)f_2039},
{"f_2035posixwin.scm",(void*)f_2035},
{"f_2012posixwin.scm",(void*)f_2012},
{"f_2020posixwin.scm",(void*)f_2020},
{"f_2016posixwin.scm",(void*)f_2016},
{"f_1956posixwin.scm",(void*)f_1956},
{"f_1951posixwin.scm",(void*)f_1951},
{"f_1900posixwin.scm",(void*)f_1900},
{"f_1904posixwin.scm",(void*)f_1904},
{"f_1913posixwin.scm",(void*)f_1913},
{"f_1916posixwin.scm",(void*)f_1916},
{"f_1873posixwin.scm",(void*)f_1873},
{"f_1898posixwin.scm",(void*)f_1898},
{"f_1894posixwin.scm",(void*)f_1894},
{"f_1880posixwin.scm",(void*)f_1880},
{"f_1713posixwin.scm",(void*)f_1713},
{"f_1821posixwin.scm",(void*)f_1821},
{"f_1829posixwin.scm",(void*)f_1829},
{"f_1816posixwin.scm",(void*)f_1816},
{"f_1715posixwin.scm",(void*)f_1715},
{"f_1722posixwin.scm",(void*)f_1722},
{"f_1725posixwin.scm",(void*)f_1725},
{"f_1728posixwin.scm",(void*)f_1728},
{"f_1815posixwin.scm",(void*)f_1815},
{"f_1732posixwin.scm",(void*)f_1732},
{"f_1749posixwin.scm",(void*)f_1749},
{"f_1759posixwin.scm",(void*)f_1759},
{"f_1771posixwin.scm",(void*)f_1771},
{"f_1781posixwin.scm",(void*)f_1781},
{"f_1741posixwin.scm",(void*)f_1741},
{"f_1686posixwin.scm",(void*)f_1686},
{"f_1711posixwin.scm",(void*)f_1711},
{"f_1707posixwin.scm",(void*)f_1707},
{"f_1699posixwin.scm",(void*)f_1699},
{"f_1659posixwin.scm",(void*)f_1659},
{"f_1684posixwin.scm",(void*)f_1684},
{"f_1680posixwin.scm",(void*)f_1680},
{"f_1672posixwin.scm",(void*)f_1672},
{"f_1632posixwin.scm",(void*)f_1632},
{"f_1657posixwin.scm",(void*)f_1657},
{"f_1653posixwin.scm",(void*)f_1653},
{"f_1645posixwin.scm",(void*)f_1645},
{"f_1571posixwin.scm",(void*)f_1571},
{"f_1584posixwin.scm",(void*)f_1584},
{"f_1599posixwin.scm",(void*)f_1599},
{"f_1590posixwin.scm",(void*)f_1590},
{"f_1593posixwin.scm",(void*)f_1593},
{"f_1531posixwin.scm",(void*)f_1531},
{"f_1550posixwin.scm",(void*)f_1550},
{"f_1535posixwin.scm",(void*)f_1535},
{"f_1544posixwin.scm",(void*)f_1544},
{"f_1538posixwin.scm",(void*)f_1538},
{"f_1498posixwin.scm",(void*)f_1498},
{"f_1500posixwin.scm",(void*)f_1500},
{"f_1493posixwin.scm",(void*)f_1493},
{"f_1470posixwin.scm",(void*)f_1470},
{"f_1491posixwin.scm",(void*)f_1491},
{"f_1477posixwin.scm",(void*)f_1477},
{"f_1464posixwin.scm",(void*)f_1464},
{"f_1468posixwin.scm",(void*)f_1468},
{"f_1458posixwin.scm",(void*)f_1458},
{"f_1462posixwin.scm",(void*)f_1462},
{"f_1452posixwin.scm",(void*)f_1452},
{"f_1456posixwin.scm",(void*)f_1456},
{"f_1446posixwin.scm",(void*)f_1446},
{"f_1450posixwin.scm",(void*)f_1450},
{"f_1440posixwin.scm",(void*)f_1440},
{"f_1444posixwin.scm",(void*)f_1444},
{"f_1434posixwin.scm",(void*)f_1434},
{"f_1438posixwin.scm",(void*)f_1438},
{"f_1403posixwin.scm",(void*)f_1403},
{"f_1407posixwin.scm",(void*)f_1407},
{"f_1410posixwin.scm",(void*)f_1410},
{"f_1365posixwin.scm",(void*)f_1365},
{"f_1398posixwin.scm",(void*)f_1398},
{"f_1394posixwin.scm",(void*)f_1394},
{"f_1369posixwin.scm",(void*)f_1369},
{"f_1378posixwin.scm",(void*)f_1378},
{"f_1327posixwin.scm",(void*)f_1327},
{"f_1334posixwin.scm",(void*)f_1334},
{"f_1337posixwin.scm",(void*)f_1337},
{"f_1357posixwin.scm",(void*)f_1357},
{"f_1340posixwin.scm",(void*)f_1340},
{"f_1347posixwin.scm",(void*)f_1347},
{"f_1285posixwin.scm",(void*)f_1285},
{"f_1292posixwin.scm",(void*)f_1292},
{"f_1307posixwin.scm",(void*)f_1307},
{"f_1301posixwin.scm",(void*)f_1301},
{"f_1240posixwin.scm",(void*)f_1240},
{"f_1250posixwin.scm",(void*)f_1250},
{"f_1253posixwin.scm",(void*)f_1253},
{"f_1265posixwin.scm",(void*)f_1265},
{"f_1256posixwin.scm",(void*)f_1256},
{"f_1222posixwin.scm",(void*)f_1222},
{"f_1235posixwin.scm",(void*)f_1235},
{"f_1181posixwin.scm",(void*)f_1181},
{"f_1214posixwin.scm",(void*)f_1214},
{"f_1198posixwin.scm",(void*)f_1198},
{"f_1207posixwin.scm",(void*)f_1207},
{"f_1201posixwin.scm",(void*)f_1201},
{"f_1135posixwin.scm",(void*)f_1135},
{"f_1139posixwin.scm",(void*)f_1139},
{"f_1150posixwin.scm",(void*)f_1150},
{"f_1146posixwin.scm",(void*)f_1146},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
