/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-04-15 09:10
   Version 4.0.1 - SVN rev. 14255
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-04-15 on lenovo-1 (MINGW32_NT-6.0)
   command line: posixwin.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[394];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,56,57,32,102,108,97,103,115,57,48,32,46,32,109,111,100,101,57,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,49,52,32,115,105,122,101,49,49,53,32,46,32,98,117,102,102,101,114,49,49,54,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,49,51,52,32,98,117,102,102,101,114,49,51,53,32,46,32,115,105,122,101,49,51,54,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,20),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,56,56,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,115,116,97,116,32,102,50,49,48,32,46,32,116,109,112,50,48,57,50,49,49,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,50,55,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,50,51,50,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,51,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,52,50,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,50,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,50,53,55,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,102,95,51,48,51,50,32,102,110,97,109,101,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,115,116,97,116,45,116,121,112,101,32,110,97,109,101,50,55,49,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,50,56,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,48,48,32,112,111,115,51,48,49,32,46,32,119,104,101,110,99,101,51,48,50,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,12),40,97,51,49,56,55,32,120,51,54,48,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,51,56,32,46,32,116,109,112,51,51,55,51,51,57,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,50,50,32,115,112,101,99,52,51,50,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,51,51,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,53,32,37,115,112,101,99,52,50,48,52,55,57,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,50,52,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,49,50,52,49,51,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,57,52,41,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,53,48,57,53,49,48,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,53,53,53,53,53,54,53,53,55,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,51,54,48,53,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,19),40,97,51,53,57,57,32,101,120,118,97,114,53,54,57,53,56,53,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,51,54,50,51,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,51,54,51,53,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,20),40,97,51,54,50,57,32,46,32,97,114,103,115,53,55,56,54,48,51,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,51,54,49,55,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,15),40,97,51,53,57,51,32,107,53,55,55,53,56,51,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,54,51,50,32,114,54,51,51,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,54,48,55,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,54,52,53,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,54,52,55,32,105,110,112,54,52,56,32,114,54,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,53,53,32,46,32,109,54,53,54,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,54,56,32,46,32,109,54,54,57,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,56,49,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,52,49,51,51,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,20),40,97,52,49,51,57,32,46,32,114,101,115,117,108,116,115,55,48,56,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,55,48,49,32,112,114,111,99,55,48,50,32,46,32,109,111,100,101,55,48,51,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,55,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,20),40,97,52,49,54,51,32,46,32,114,101,115,117,108,116,115,55,49,56,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,55,49,49,32,112,114,111,99,55,49,50,32,46,32,109,111,100,101,55,49,51,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,97,52,49,56,50,32,46,32,114,101,115,117,108,116,115,55,50,56,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,55,50,49,32,116,104,117,110,107,55,50,50,32,46,32,109,111,100,101,55,50,51,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,20),40,97,52,50,48,50,32,46,32,114,101,115,117,108,116,115,55,52,48,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,55,51,51,32,116,104,117,110,107,55,51,52,32,46,32,109,111,100,101,55,51,53,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,116,109,112,55,53,54,55,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,56,49,50,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,56,49,53,32,112,114,111,99,56,49,54,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,56,50,50,32,115,116,97,116,101,56,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,57,48,56,32,109,57,48,57,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,57,50,50,32,97,99,99,57,50,51,32,108,111,99,57,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,50,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,52,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,57,53,50,32,109,57,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,57,55,49,32,105,110,112,57,55,50,32,114,57,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,57,55,57,32,46,32,109,57,56,48,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,57,56,51,32,46,32,109,57,56,52,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,57,57,49,41,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,48,48,49,32,46,32,110,101,119,49,48,48,50,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,48,49,53,32,118,97,108,49,48,49,54,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,48,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,48,52,55,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,48,52,49,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,49,48,53,54,32,116,109,49,48,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,49,48,54,52,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,49,48,54,57,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,49,48,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,49,49,50,32,46,32,116,109,112,49,49,49,49,49,49,49,51,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,49,51,55,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,49,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,49,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,49,54,54,32,109,111,100,101,49,49,54,55,32,46,32,115,105,122,101,49,49,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,7),40,97,52,57,54,56,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,50,51,49,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,55),40,97,52,57,55,52,32,100,105,114,49,50,48,49,49,50,48,50,49,50,48,57,32,102,105,108,49,50,48,51,49,50,48,52,49,50,49,48,32,101,120,116,49,50,48,53,49,50,48,54,49,50,49,49,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,49,57,54,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,49,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,56,50,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,49,50,55,54,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,108,115,116,49,50,57,54,32,111,108,115,116,49,50,57,55,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,37),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,49,50,55,50,32,101,120,97,99,116,102,49,50,55,51,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,38),40,115,101,116,97,114,103,32,97,49,51,49,48,49,51,49,52,32,97,49,51,48,57,49,51,49,53,32,97,49,51,48,56,49,51,49,54,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,38),40,115,101,116,101,110,118,32,97,49,51,50,50,49,51,50,54,32,97,49,51,50,49,49,51,50,55,32,97,49,51,50,48,49,51,50,56,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,51,55,32,108,49,51,52,51,32,105,49,51,52,52,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,61),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,49,51,51,50,32,108,115,116,49,51,51,51,32,97,114,103,118,101,99,45,115,101,116,116,101,114,49,51,51,52,32,105,100,120,49,51,51,53,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,67),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,49,51,53,53,32,102,105,108,101,110,97,109,101,49,51,53,54,32,97,114,103,108,115,116,49,51,53,55,32,101,110,118,108,115,116,49,51,53,56,32,101,120,97,99,116,102,49,51,53,57,41,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,53),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,49,51,55,48,32,109,115,103,49,51,55,49,32,102,105,108,101,110,97,109,101,49,51,55,50,32,114,101,115,49,51,55,51,41,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,51,57,55,32,97,114,103,108,115,116,49,52,48,56,32,101,110,118,108,115,116,49,52,48,57,32,101,120,97,99,116,102,49,52,49,48,41,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,48,49,32,37,97,114,103,108,115,116,49,51,57,52,49,52,49,54,32,37,101,110,118,108,115,116,49,51,57,53,49,52,49,55,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,48,48,32,37,97,114,103,108,115,116,49,51,57,52,49,52,50,49,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,51,57,57,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,51,56,54,32,46,32,116,109,112,49,51,56,53,49,51,56,55,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,52,53,55,32,97,114,103,108,115,116,49,52,54,56,32,101,110,118,108,115,116,49,52,54,57,32,101,120,97,99,116,102,49,52,55,48,41,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,54,49,32,37,97,114,103,108,115,116,49,52,53,52,49,52,55,54,32,37,101,110,118,108,115,116,49,52,53,53,49,52,55,55,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,54,48,32,37,97,114,103,108,115,116,49,52,53,52,49,52,56,49,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,52,53,57,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,51),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,49,52,52,53,32,102,105,108,101,110,97,109,101,49,52,52,54,32,46,32,116,109,112,49,52,52,52,49,52,52,55,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,53,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,53,50,48,32,46,32,97,114,103,115,49,53,50,49,41,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,97),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,53,55,55,32,99,109,100,49,53,55,56,32,97,114,103,115,49,53,55,57,32,101,110,118,49,53,56,48,32,115,116,100,111,117,116,102,49,53,56,49,32,115,116,100,105,110,102,49,53,56,50,32,115,116,100,101,114,114,102,49,53,56,51,32,46,32,116,109,112,49,53,55,54,49,53,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,97,53,54,57,54,32,103,49,54,55,53,49,54,55,54,49,54,55,55,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,54,54,56,41,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,7),40,97,53,55,49,52,41,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,38),40,97,53,55,50,48,32,105,110,49,54,56,56,32,111,117,116,49,54,56,57,32,112,105,100,49,54,57,48,32,101,114,114,49,54,57,49,41,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,63),40,37,112,114,111,99,101,115,115,32,108,111,99,49,54,54,48,32,101,114,114,63,49,54,54,49,32,99,109,100,49,54,54,50,32,97,114,103,115,49,54,54,51,32,101,110,118,49,54,54,52,32,101,120,97,99,116,102,49,54,54,53,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,49,52,32,97,114,103,115,49,55,50,53,32,101,110,118,49,55,50,54,32,101,120,97,99,116,102,49,55,50,55,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,49,56,32,37,97,114,103,115,49,55,49,49,49,55,51,49,32,37,101,110,118,49,55,49,50,49,55,51,50,41,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,49,55,32,37,97,114,103,115,49,55,49,49,49,55,51,54,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,49,54,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,49,55,48,51,32,46,32,116,109,112,49,55,48,50,49,55,48,52,41,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,54,57,32,97,114,103,115,49,55,56,48,32,101,110,118,49,55,56,49,32,101,120,97,99,116,102,49,55,56,50,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,55,51,32,37,97,114,103,115,49,55,54,54,49,55,56,54,32,37,101,110,118,49,55,54,55,49,55,56,55,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,55,50,32,37,97,114,103,115,49,55,54,54,49,55,57,49,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,55,49,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,49,55,53,56,32,46,32,116,109,112,49,55,53,55,49,55,53,57,41};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,49,49,32,110,111,104,97,110,103,49,56,49,50,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,7),40,97,53,57,52,48,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,36),40,97,53,57,52,54,32,101,112,105,100,49,56,51,52,32,101,110,111,114,109,49,56,51,53,32,101,99,111,100,101,49,56,51,54,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,49,53,32,46,32,97,114,103,115,49,56,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,13),40,115,108,101,101,112,32,116,49,56,52,49,41,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,14),40,102,95,54,49,54,49,32,120,49,57,48,56,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,7),40,97,54,49,48,55,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,7),40,97,54,49,49,50,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,7),40,97,54,49,50,54,41,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,57,49,52,32,114,49,57,49,53,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,16),40,102,95,54,49,55,55,32,46,32,95,49,57,48,52,41};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,16),40,102,95,54,49,54,57,32,46,32,95,49,57,48,50,41};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,56,55,54,32,97,99,116,105,111,110,49,56,56,55,32,105,100,49,56,56,56,32,108,105,109,105,116,49,56,56,57,41,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,56,56,48,32,37,97,99,116,105,111,110,49,56,55,51,49,57,53,53,32,37,105,100,49,56,55,52,49,57,53,54,41,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,56,55,57,32,37,97,99,116,105,111,110,49,56,55,51,49,57,54,48,41,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,19),40,97,54,49,57,55,32,120,49,57,54,53,32,121,49,57,54,54,41,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,56,55,56,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,56,54,52,32,112,114,101,100,49,56,54,53,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,56,54,54,41,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,31),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,46,32,95,50,48,50,49,50,48,50,53,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,102,105,102,111,32,46,32,95,50,48,51,48,50,48,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,28),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,32,46,32,95,50,48,51,56,50,48,52,50,41,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,50,48,52,54,50,48,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,40),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,103,114,111,117,112,45,105,100,32,46,32,95,50,48,53,52,50,48,53,56,41};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,39),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,105,100,32,46,32,95,50,48,54,50,50,48,54,54,41,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,41),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,32,46,32,95,50,48,55,48,50,48,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,30),40,99,117,114,114,101,110,116,45,103,114,111,117,112,45,105,100,32,46,32,95,50,48,55,56,50,48,56,50,41,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,117,115,101,114,45,105,100,32,46,32,95,50,48,56,54,50,48,57,48,41,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,32),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,46,32,95,50,48,57,52,50,48,57,56,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,108,105,110,107,32,46,32,95,50,49,48,50,50,49,48,54,41,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,108,111,99,107,32,46,32,95,50,49,49,48,50,49,49,52,41,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,46,32,95,50,49,49,56,50,49,50,50,41};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,115,101,108,101,99,116,32,46,32,95,50,49,50,54,50,49,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,46,32,95,50,49,51,52,50,49,51,56,41,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,46,32,95,50,49,52,50,50,49,52,54,41,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,117,110,108,111,99,107,32,46,32,95,50,49,53,48,50,49,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,24),40,103,101,116,45,103,114,111,117,112,115,32,46,32,95,50,49,53,56,50,49,54,50,41};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,31),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,50,49,54,54,50,49,55,48,41,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,31),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,46,32,95,50,49,55,52,50,49,55,56,41,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,40),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,46,32,95,50,49,56,50,50,49,56,54,41};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,31),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,32,46,32,95,50,49,57,48,50,49,57,52,41,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,95,50,49,57,56,50,50,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,32,46,32,95,50,50,48,54,50,50,49,48,41,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,28),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,46,32,95,50,50,49,52,50,50,49,56,41,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,32),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,50,50,50,50,50,50,50,54,41};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,24),40,115,101,116,45,97,108,97,114,109,33,32,46,32,95,50,50,51,48,50,50,51,52,41};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,46,32,95,50,50,51,56,50,50,52,50,41,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,25),40,115,101,116,45,103,114,111,117,112,115,33,32,46,32,95,50,50,52,54,50,50,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,35),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,46,32,95,50,50,53,52,50,50,53,56,41,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,33),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,46,32,95,50,50,54,50,50,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,30),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,50,50,55,48,50,50,55,52,41,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,117,115,101,114,45,105,100,33,32,46,32,95,50,50,55,56,50,50,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,25),40,115,105,103,110,97,108,45,109,97,115,107,32,46,32,95,50,50,56,54,50,50,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,26),40,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,50,50,57,52,50,50,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,28),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,46,32,95,50,51,48,50,50,51,48,54,41,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,28),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,46,32,95,50,51,49,48,50,51,49,52,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,27),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,46,32,95,50,51,49,56,50,51,50,50,41,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,27),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,46,32,95,50,51,50,54,50,51,51,48,41,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,36),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,46,32,95,50,51,51,52,50,51,51,56,41,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,30),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,50,51,52,50,50,51,52,54,41,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,31),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,46,32,95,50,51,53,48,50,51,53,52,41,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,26),40,115,116,114,105,110,103,45,62,116,105,109,101,32,46,32,95,50,51,53,56,50,51,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,13),40,102,105,102,111,63,32,95,50,51,54,55,41,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,50,51,55,49,41,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k5535 */
static C_word C_fcall stub1538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from current-process-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static C_word C_fcall stub1498(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1498(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k5167 */
static C_word C_fcall stub1323(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1323(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k5150 */
static C_word C_fcall stub1311(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1311(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k4864 */
static C_word C_fcall stub1149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1141(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1141(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (_daylight ? _tzname[1] : _tzname[0]);
return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub1098(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1098(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1090(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1090(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k4737 */
static C_word C_fcall stub1075(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1075(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4624 */
static C_word C_fcall stub1031(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1031(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2664 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6513)
static void C_ccall f_6513(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6192)
static void C_fcall f_6192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6187)
static void C_fcall f_6187(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6182)
static void C_fcall f_6182(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6043)
static void C_fcall f_6043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6050)
static void C_fcall f_6050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_fcall f_6062(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5845)
static void C_fcall f_5845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_fcall f_5840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5835)
static void C_fcall f_5835(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5830)
static void C_fcall f_5830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5765)
static void C_fcall f_5765(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_fcall f_5760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5755)
static void C_fcall f_5755(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5750)
static void C_fcall f_5750(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5686)
static void C_fcall f_5686(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_fcall f_5688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_fcall f_5377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5372)
static void C_fcall f_5372(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5360)
static void C_fcall f_5360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5295)
static void C_fcall f_5295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5285)
static void C_fcall f_5285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5273)
static void C_fcall f_5273(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_fcall f_5256(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_fcall f_5223(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_fcall f_5173(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5185)
static void C_fcall f_5185(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5060)
static void C_fcall f_5060(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5103)
static void C_fcall f_5103(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_fcall f_5065(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_fcall f_5074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4954)
static void C_fcall f_4954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_fcall f_4991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4693)
static void C_fcall f_4693(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4567)
static void C_fcall f_4567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_fcall f_4479(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_fcall f_4442(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4397)
static void C_fcall f_4397(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_fcall f_4010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static C_word C_fcall f_3998(C_word t0);
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_fcall f_3787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_fcall f_3817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_fcall f_3859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_fcall f_3657(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3736)
static void C_fcall f_3736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_fcall f_3585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static C_word C_fcall f_3574(C_word t0);
C_noret_decl(f_3569)
static void C_fcall f_3569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3439)
static void C_fcall f_3439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_fcall f_3434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3333)
static void C_fcall f_3333(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_fcall f_3389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_fcall f_3199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_fcall f_3030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_fcall f_2897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6192)
static void C_fcall trf_6192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6192(t0,t1);}

C_noret_decl(trf_6187)
static void C_fcall trf_6187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6187(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6187(t0,t1,t2);}

C_noret_decl(trf_6182)
static void C_fcall trf_6182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6182(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6182(t0,t1,t2,t3);}

C_noret_decl(trf_6043)
static void C_fcall trf_6043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6043(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6043(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6050)
static void C_fcall trf_6050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6050(t0,t1);}

C_noret_decl(trf_6062)
static void C_fcall trf_6062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6062(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6062(t0,t1,t2,t3);}

C_noret_decl(trf_5845)
static void C_fcall trf_5845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5845(t0,t1);}

C_noret_decl(trf_5840)
static void C_fcall trf_5840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5840(t0,t1,t2);}

C_noret_decl(trf_5835)
static void C_fcall trf_5835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5835(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5835(t0,t1,t2,t3);}

C_noret_decl(trf_5830)
static void C_fcall trf_5830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5830(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5830(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5765)
static void C_fcall trf_5765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5765(t0,t1);}

C_noret_decl(trf_5760)
static void C_fcall trf_5760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5760(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5760(t0,t1,t2);}

C_noret_decl(trf_5755)
static void C_fcall trf_5755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5755(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5755(t0,t1,t2,t3);}

C_noret_decl(trf_5750)
static void C_fcall trf_5750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5750(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5750(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5686)
static void C_fcall trf_5686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5686(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5686(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5688)
static void C_fcall trf_5688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5688(t0,t1,t2);}

C_noret_decl(trf_5382)
static void C_fcall trf_5382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5382(t0,t1);}

C_noret_decl(trf_5377)
static void C_fcall trf_5377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5377(t0,t1,t2);}

C_noret_decl(trf_5372)
static void C_fcall trf_5372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5372(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5372(t0,t1,t2,t3);}

C_noret_decl(trf_5360)
static void C_fcall trf_5360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5360(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5360(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5295)
static void C_fcall trf_5295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5295(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5295(t0,t1);}

C_noret_decl(trf_5290)
static void C_fcall trf_5290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5290(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5290(t0,t1,t2);}

C_noret_decl(trf_5285)
static void C_fcall trf_5285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5285(t0,t1,t2,t3);}

C_noret_decl(trf_5273)
static void C_fcall trf_5273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5273(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5273(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5256)
static void C_fcall trf_5256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5256(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5256(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5223)
static void C_fcall trf_5223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5223(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5223(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5173)
static void C_fcall trf_5173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5173(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5173(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5185)
static void C_fcall trf_5185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5185(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5185(t0,t1,t2,t3);}

C_noret_decl(trf_5060)
static void C_fcall trf_5060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5060(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5060(t0,t1,t2,t3);}

C_noret_decl(trf_5103)
static void C_fcall trf_5103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5103(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5103(t0,t1,t2,t3);}

C_noret_decl(trf_5065)
static void C_fcall trf_5065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5065(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5065(t0,t1,t2);}

C_noret_decl(trf_5074)
static void C_fcall trf_5074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5074(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5074(t0,t1,t2);}

C_noret_decl(trf_4954)
static void C_fcall trf_4954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4954(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4954(t0,t1,t2);}

C_noret_decl(trf_4991)
static void C_fcall trf_4991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4991(t0,t1,t2);}

C_noret_decl(trf_4693)
static void C_fcall trf_4693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4693(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4693(t0,t1,t2);}

C_noret_decl(trf_4633)
static void C_fcall trf_4633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4633(t0,t1,t2);}

C_noret_decl(trf_4645)
static void C_fcall trf_4645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4645(t0,t1,t2);}

C_noret_decl(trf_4567)
static void C_fcall trf_4567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4567(t0,t1);}

C_noret_decl(trf_4479)
static void C_fcall trf_4479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4479(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4479(t0,t1,t2,t3);}

C_noret_decl(trf_4442)
static void C_fcall trf_4442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4442(t0,t1,t2);}

C_noret_decl(trf_4397)
static void C_fcall trf_4397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4397(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4397(t0,t1,t2,t3);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4016(t0,t1,t2,t3);}

C_noret_decl(trf_4010)
static void C_fcall trf_4010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4010(t0,t1);}

C_noret_decl(trf_3787)
static void C_fcall trf_3787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3787(t0,t1);}

C_noret_decl(trf_3817)
static void C_fcall trf_3817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3817(t0,t1);}

C_noret_decl(trf_3859)
static void C_fcall trf_3859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3859(t0,t1);}

C_noret_decl(trf_3657)
static void C_fcall trf_3657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3657(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3657(t0,t1,t2,t3);}

C_noret_decl(trf_3736)
static void C_fcall trf_3736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3736(t0,t1);}

C_noret_decl(trf_3585)
static void C_fcall trf_3585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3585(t0,t1);}

C_noret_decl(trf_3569)
static void C_fcall trf_3569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3569(t0,t1);}

C_noret_decl(trf_3439)
static void C_fcall trf_3439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3439(t0,t1);}

C_noret_decl(trf_3434)
static void C_fcall trf_3434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3434(t0,t1,t2);}

C_noret_decl(trf_3333)
static void C_fcall trf_3333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3333(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3333(t0,t1,t2,t3);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3367(t0,t1);}

C_noret_decl(trf_3389)
static void C_fcall trf_3389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3389(t0,t1);}

C_noret_decl(trf_3199)
static void C_fcall trf_3199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3199(t0,t1);}

C_noret_decl(trf_3030)
static void C_fcall trf_3030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3030(t0,t1);}

C_noret_decl(trf_2897)
static void C_fcall trf_2897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2897(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3080)){
C_save(t1);
C_rereclaim2(3080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,394);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"\003syserror");
lf[63]=C_h_intern(&lf[63],9,"file-size");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],16,"file-access-time");
lf[66]=C_h_intern(&lf[66],16,"file-change-time");
lf[67]=C_h_intern(&lf[67],10,"file-owner");
lf[68]=C_h_intern(&lf[68],16,"file-permissions");
lf[69]=C_h_intern(&lf[69],13,"regular-file\077");
lf[70]=C_h_intern(&lf[70],13,"\003sysfile-info");
lf[71]=C_h_intern(&lf[71],14,"symbolic-link\077");
lf[72]=C_h_intern(&lf[72],13,"stat-regular\077");
lf[73]=C_h_intern(&lf[73],15,"stat-directory\077");
lf[74]=C_h_intern(&lf[74],17,"stat-char-device\077");
lf[75]=C_h_intern(&lf[75],18,"stat-block-device\077");
lf[76]=C_h_intern(&lf[76],10,"stat-fifo\077");
lf[77]=C_h_intern(&lf[77],13,"stat-symlink\077");
lf[78]=C_h_intern(&lf[78],12,"stat-socket\077");
lf[79]=C_h_intern(&lf[79],13,"file-position");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[81]=C_h_intern(&lf[81],6,"stream");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[83]=C_h_intern(&lf[83],5,"port\077");
lf[84]=C_h_intern(&lf[84],18,"set-file-position!");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[87]=C_h_intern(&lf[87],13,"\000bounds-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[89]=C_h_intern(&lf[89],16,"create-directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[91]=C_h_intern(&lf[91],12,"file-exists\077");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[93]=C_h_intern(&lf[93],12,"\003sysfor-each");
lf[94]=C_h_intern(&lf[94],12,"string-split");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[96]=C_h_intern(&lf[96],14,"canonical-path");
lf[97]=C_h_intern(&lf[97],16,"change-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[99]=C_h_intern(&lf[99],16,"delete-directory");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[101]=C_h_intern(&lf[101],6,"string");
lf[102]=C_h_intern(&lf[102],9,"directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[104]=C_h_intern(&lf[104],16,"\003sysmake-pointer");
lf[105]=C_h_intern(&lf[105],17,"current-directory");
lf[106]=C_h_intern(&lf[106],10,"directory\077");
lf[107]=C_h_intern(&lf[107],27,"\003sysplatform-fixup-pathname");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[109]=C_h_intern(&lf[109],5,"null\077");
lf[110]=C_h_intern(&lf[110],6,"char=\077");
lf[111]=C_h_intern(&lf[111],8,"string=\077");
lf[112]=C_h_intern(&lf[112],16,"char-alphabetic\077");
lf[113]=C_h_intern(&lf[113],10,"string-ref");
lf[114]=C_h_intern(&lf[114],18,"string-intersperse");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[116]=C_h_intern(&lf[116],17,"current-user-name");
lf[117]=C_h_intern(&lf[117],9,"condition");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[119]=C_h_intern(&lf[119],22,"with-exception-handler");
lf[120]=C_h_intern(&lf[120],30,"call-with-current-continuation");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[122]=C_h_intern(&lf[122],7,"reverse");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[132]=C_h_intern(&lf[132],5,"\000text");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[135]=C_h_intern(&lf[135],13,"\003sysmake-port");
lf[136]=C_h_intern(&lf[136],21,"\003sysstream-port-class");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[138]=C_h_intern(&lf[138],15,"open-input-pipe");
lf[139]=C_h_intern(&lf[139],7,"\000binary");
lf[140]=C_h_intern(&lf[140],16,"open-output-pipe");
lf[141]=C_h_intern(&lf[141],16,"close-input-pipe");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[143]=C_h_intern(&lf[143],14,"\003syscheck-port");
lf[144]=C_h_intern(&lf[144],17,"close-output-pipe");
lf[145]=C_h_intern(&lf[145],20,"call-with-input-pipe");
lf[146]=C_h_intern(&lf[146],21,"call-with-output-pipe");
lf[147]=C_h_intern(&lf[147],20,"with-input-from-pipe");
lf[148]=C_h_intern(&lf[148],18,"\003sysstandard-input");
lf[149]=C_h_intern(&lf[149],19,"with-output-to-pipe");
lf[150]=C_h_intern(&lf[150],19,"\003sysstandard-output");
lf[151]=C_h_intern(&lf[151],11,"create-pipe");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[153]=C_h_intern(&lf[153],11,"signal/term");
lf[154]=C_h_intern(&lf[154],10,"signal/int");
lf[155]=C_h_intern(&lf[155],10,"signal/fpe");
lf[156]=C_h_intern(&lf[156],10,"signal/ill");
lf[157]=C_h_intern(&lf[157],11,"signal/segv");
lf[158]=C_h_intern(&lf[158],11,"signal/abrt");
lf[159]=C_h_intern(&lf[159],12,"signal/break");
lf[160]=C_h_intern(&lf[160],11,"signal/alrm");
lf[161]=C_h_intern(&lf[161],11,"signal/chld");
lf[162]=C_h_intern(&lf[162],11,"signal/cont");
lf[163]=C_h_intern(&lf[163],10,"signal/hup");
lf[164]=C_h_intern(&lf[164],9,"signal/io");
lf[165]=C_h_intern(&lf[165],11,"signal/kill");
lf[166]=C_h_intern(&lf[166],11,"signal/pipe");
lf[167]=C_h_intern(&lf[167],11,"signal/prof");
lf[168]=C_h_intern(&lf[168],11,"signal/quit");
lf[169]=C_h_intern(&lf[169],11,"signal/stop");
lf[170]=C_h_intern(&lf[170],11,"signal/trap");
lf[171]=C_h_intern(&lf[171],11,"signal/tstp");
lf[172]=C_h_intern(&lf[172],10,"signal/urg");
lf[173]=C_h_intern(&lf[173],11,"signal/usr1");
lf[174]=C_h_intern(&lf[174],11,"signal/usr2");
lf[175]=C_h_intern(&lf[175],13,"signal/vtalrm");
lf[176]=C_h_intern(&lf[176],12,"signal/winch");
lf[177]=C_h_intern(&lf[177],11,"signal/xcpu");
lf[178]=C_h_intern(&lf[178],11,"signal/xfsz");
lf[179]=C_h_intern(&lf[179],12,"signals-list");
lf[180]=C_h_intern(&lf[180],18,"\003sysinterrupt-hook");
lf[181]=C_h_intern(&lf[181],14,"signal-handler");
lf[182]=C_h_intern(&lf[182],19,"set-signal-handler!");
lf[183]=C_h_intern(&lf[183],10,"errno/perm");
lf[184]=C_h_intern(&lf[184],11,"errno/noent");
lf[185]=C_h_intern(&lf[185],10,"errno/srch");
lf[186]=C_h_intern(&lf[186],10,"errno/intr");
lf[187]=C_h_intern(&lf[187],8,"errno/io");
lf[188]=C_h_intern(&lf[188],12,"errno/noexec");
lf[189]=C_h_intern(&lf[189],10,"errno/badf");
lf[190]=C_h_intern(&lf[190],11,"errno/child");
lf[191]=C_h_intern(&lf[191],11,"errno/nomem");
lf[192]=C_h_intern(&lf[192],11,"errno/acces");
lf[193]=C_h_intern(&lf[193],11,"errno/fault");
lf[194]=C_h_intern(&lf[194],10,"errno/busy");
lf[195]=C_h_intern(&lf[195],11,"errno/exist");
lf[196]=C_h_intern(&lf[196],12,"errno/notdir");
lf[197]=C_h_intern(&lf[197],11,"errno/isdir");
lf[198]=C_h_intern(&lf[198],11,"errno/inval");
lf[199]=C_h_intern(&lf[199],11,"errno/mfile");
lf[200]=C_h_intern(&lf[200],11,"errno/nospc");
lf[201]=C_h_intern(&lf[201],11,"errno/spipe");
lf[202]=C_h_intern(&lf[202],10,"errno/pipe");
lf[203]=C_h_intern(&lf[203],11,"errno/again");
lf[204]=C_h_intern(&lf[204],10,"errno/rofs");
lf[205]=C_h_intern(&lf[205],10,"errno/nxio");
lf[206]=C_h_intern(&lf[206],10,"errno/2big");
lf[207]=C_h_intern(&lf[207],10,"errno/xdev");
lf[208]=C_h_intern(&lf[208],11,"errno/nodev");
lf[209]=C_h_intern(&lf[209],11,"errno/nfile");
lf[210]=C_h_intern(&lf[210],11,"errno/notty");
lf[211]=C_h_intern(&lf[211],10,"errno/fbig");
lf[212]=C_h_intern(&lf[212],11,"errno/mlink");
lf[213]=C_h_intern(&lf[213],9,"errno/dom");
lf[214]=C_h_intern(&lf[214],11,"errno/range");
lf[215]=C_h_intern(&lf[215],12,"errno/deadlk");
lf[216]=C_h_intern(&lf[216],17,"errno/nametoolong");
lf[217]=C_h_intern(&lf[217],11,"errno/nolck");
lf[218]=C_h_intern(&lf[218],11,"errno/nosys");
lf[219]=C_h_intern(&lf[219],14,"errno/notempty");
lf[220]=C_h_intern(&lf[220],11,"errno/ilseq");
lf[221]=C_h_intern(&lf[221],16,"change-file-mode");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[223]=C_h_intern(&lf[223],17,"file-read-access\077");
lf[224]=C_h_intern(&lf[224],18,"file-write-access\077");
lf[225]=C_h_intern(&lf[225],20,"file-execute-access\077");
lf[226]=C_h_intern(&lf[226],12,"fileno/stdin");
lf[227]=C_h_intern(&lf[227],13,"fileno/stdout");
lf[228]=C_h_intern(&lf[228],13,"fileno/stderr");
lf[229]=C_h_intern(&lf[229],7,"\000append");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[237]=C_h_intern(&lf[237],16,"open-input-file*");
lf[238]=C_h_intern(&lf[238],17,"open-output-file*");
lf[239]=C_h_intern(&lf[239],12,"port->fileno");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[242]=C_h_intern(&lf[242],25,"\003syspeek-unsigned-integer");
lf[243]=C_h_intern(&lf[243],16,"duplicate-fileno");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[245]=C_h_intern(&lf[245],6,"setenv");
lf[246]=C_h_intern(&lf[246],8,"unsetenv");
lf[247]=C_h_intern(&lf[247],9,"substring");
lf[248]=C_h_intern(&lf[248],25,"get-environment-variables");
lf[249]=C_h_intern(&lf[249],19,"current-environment");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[252]=C_h_intern(&lf[252],19,"seconds->local-time");
lf[253]=C_h_intern(&lf[253],18,"\003sysdecode-seconds");
lf[254]=C_h_intern(&lf[254],17,"seconds->utc-time");
lf[255]=C_h_intern(&lf[255],15,"seconds->string");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[257]=C_h_intern(&lf[257],12,"time->string");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[260]=C_h_intern(&lf[260],19,"local-time->seconds");
lf[261]=C_h_intern(&lf[261],15,"\003syscons-flonum");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[263]=C_h_intern(&lf[263],27,"local-timezone-abbreviation");
lf[264]=C_h_intern(&lf[264],5,"_exit");
lf[265]=C_h_intern(&lf[265],14,"terminal-port\077");
lf[266]=C_h_intern(&lf[266],19,"set-buffering-mode!");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[268]=C_h_intern(&lf[268],5,"\000full");
lf[269]=C_h_intern(&lf[269],5,"\000line");
lf[270]=C_h_intern(&lf[270],5,"\000none");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[272]=C_h_intern(&lf[272],6,"regexp");
lf[273]=C_h_intern(&lf[273],12,"string-match");
lf[274]=C_h_intern(&lf[274],12,"glob->regexp");
lf[275]=C_h_intern(&lf[275],13,"make-pathname");
lf[276]=C_h_intern(&lf[276],18,"decompose-pathname");
lf[277]=C_h_intern(&lf[277],4,"glob");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[280]=C_h_intern(&lf[280],13,"spawn/overlay");
lf[281]=C_h_intern(&lf[281],10,"spawn/wait");
lf[282]=C_h_intern(&lf[282],12,"spawn/nowait");
lf[283]=C_h_intern(&lf[283],13,"spawn/nowaito");
lf[284]=C_h_intern(&lf[284],12,"spawn/detach");
lf[285]=C_h_intern(&lf[285],16,"char-whitespace\077");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[289]=C_h_intern(&lf[289],24,"pathname-strip-directory");
lf[292]=C_h_intern(&lf[292],15,"process-execute");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[294]=C_h_intern(&lf[294],13,"process-spawn");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[296]=C_h_intern(&lf[296],18,"current-process-id");
lf[297]=C_h_intern(&lf[297],17,"\003sysshell-command");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[299]=C_h_intern(&lf[299],6,"getenv");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[301]=C_h_intern(&lf[301],27,"\003sysshell-command-arguments");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[303]=C_h_intern(&lf[303],11,"process-run");
lf[304]=C_h_intern(&lf[304],11,"\003sysprocess");
lf[305]=C_h_intern(&lf[305],14,"\000process-error");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[307]=C_h_intern(&lf[307],17,"\003sysmake-locative");
lf[308]=C_h_intern(&lf[308],8,"location");
lf[309]=C_h_intern(&lf[309],7,"process");
lf[310]=C_h_intern(&lf[310],8,"process*");
lf[311]=C_h_intern(&lf[311],16,"\003sysprocess-wait");
lf[312]=C_h_intern(&lf[312],12,"process-wait");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[314]=C_h_intern(&lf[314],5,"sleep");
lf[315]=C_h_intern(&lf[315],13,"get-host-name");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[317]=C_h_intern(&lf[317],18,"system-information");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[321]=C_h_intern(&lf[321],10,"find-files");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[325]=C_h_intern(&lf[325],16,"\003sysdynamic-wind");
lf[326]=C_h_intern(&lf[326],13,"pathname-file");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[328]=C_h_intern(&lf[328],17,"change-file-owner");
lf[329]=C_h_intern(&lf[329],5,"error");
lf[330]=C_h_intern(&lf[330],11,"create-fifo");
lf[331]=C_h_intern(&lf[331],14,"create-session");
lf[332]=C_h_intern(&lf[332],20,"create-symbolic-link");
lf[333]=C_h_intern(&lf[333],26,"current-effective-group-id");
lf[334]=C_h_intern(&lf[334],25,"current-effective-user-id");
lf[335]=C_h_intern(&lf[335],27,"current-effective-user-name");
lf[336]=C_h_intern(&lf[336],16,"current-group-id");
lf[337]=C_h_intern(&lf[337],15,"current-user-id");
lf[338]=C_h_intern(&lf[338],18,"map-file-to-memory");
lf[339]=C_h_intern(&lf[339],9,"file-link");
lf[340]=C_h_intern(&lf[340],9,"file-lock");
lf[341]=C_h_intern(&lf[341],18,"file-lock/blocking");
lf[342]=C_h_intern(&lf[342],11,"file-select");
lf[343]=C_h_intern(&lf[343],14,"file-test-lock");
lf[344]=C_h_intern(&lf[344],13,"file-truncate");
lf[345]=C_h_intern(&lf[345],11,"file-unlock");
lf[346]=C_h_intern(&lf[346],10,"get-groups");
lf[347]=C_h_intern(&lf[347],17,"group-information");
lf[348]=C_h_intern(&lf[348],17,"initialize-groups");
lf[349]=C_h_intern(&lf[349],26,"memory-mapped-file-pointer");
lf[350]=C_h_intern(&lf[350],17,"parent-process-id");
lf[351]=C_h_intern(&lf[351],12,"process-fork");
lf[352]=C_h_intern(&lf[352],16,"process-group-id");
lf[353]=C_h_intern(&lf[353],14,"process-signal");
lf[354]=C_h_intern(&lf[354],18,"read-symbolic-link");
lf[355]=C_h_intern(&lf[355],10,"set-alarm!");
lf[356]=C_h_intern(&lf[356],13,"set-group-id!");
lf[357]=C_h_intern(&lf[357],11,"set-groups!");
lf[358]=C_h_intern(&lf[358],21,"set-process-group-id!");
lf[359]=C_h_intern(&lf[359],19,"set-root-directory!");
lf[360]=C_h_intern(&lf[360],16,"set-signal-mask!");
lf[361]=C_h_intern(&lf[361],12,"set-user-id!");
lf[362]=C_h_intern(&lf[362],11,"signal-mask");
lf[363]=C_h_intern(&lf[363],12,"signal-mask!");
lf[364]=C_h_intern(&lf[364],14,"signal-masked\077");
lf[365]=C_h_intern(&lf[365],14,"signal-unmask!");
lf[366]=C_h_intern(&lf[366],13,"terminal-name");
lf[367]=C_h_intern(&lf[367],13,"terminal-size");
lf[368]=C_h_intern(&lf[368],22,"unmap-file-from-memory");
lf[369]=C_h_intern(&lf[369],16,"user-information");
lf[370]=C_h_intern(&lf[370],17,"utc-time->seconds");
lf[371]=C_h_intern(&lf[371],12,"string->time");
lf[372]=C_h_intern(&lf[372],16,"errno/wouldblock");
lf[373]=C_h_intern(&lf[373],5,"fifo\077");
lf[374]=C_h_intern(&lf[374],19,"memory-mapped-file\077");
lf[375]=C_h_intern(&lf[375],13,"map/anonymous");
lf[376]=C_h_intern(&lf[376],8,"map/file");
lf[377]=C_h_intern(&lf[377],9,"map/fixed");
lf[378]=C_h_intern(&lf[378],11,"map/private");
lf[379]=C_h_intern(&lf[379],10,"map/shared");
lf[380]=C_h_intern(&lf[380],10,"open/fsync");
lf[381]=C_h_intern(&lf[381],11,"open/noctty");
lf[382]=C_h_intern(&lf[382],13,"open/nonblock");
lf[383]=C_h_intern(&lf[383],9,"open/sync");
lf[384]=C_h_intern(&lf[384],10,"perm/isgid");
lf[385]=C_h_intern(&lf[385],10,"perm/isuid");
lf[386]=C_h_intern(&lf[386],10,"perm/isvtx");
lf[387]=C_h_intern(&lf[387],9,"prot/exec");
lf[388]=C_h_intern(&lf[388],9,"prot/none");
lf[389]=C_h_intern(&lf[389],9,"prot/read");
lf[390]=C_h_intern(&lf[390],10,"prot/write");
lf[391]=C_h_intern(&lf[391],11,"make-vector");
lf[392]=C_h_intern(&lf[392],17,"register-feature!");
lf[393]=C_h_intern(&lf[393],5,"posix");
C_register_lf2(lf,394,create_ptable());
t2=C_mutate(&lf[0] /* (set! c2027 ...) */,lf[1]);
t3=C_mutate(&lf[2] /* (set! c222 ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k2635 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2638 in k2635 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2641 in k2638 in k2635 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 930  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[392]+1)))(3,*((C_word*)lf[392]+1),t2,lf[393]);}

/* k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2667,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* (set! posix-error ...) */,lf[5]);
t5=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2713,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[41]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2754,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[48]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2817,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[55]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2966,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2972,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[65]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2978,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3002,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3030,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[72]+1 /* (set! stat-regular? ...) */,*((C_word*)lf[69]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1115 stat-type */
f_3030(t54,lf[73]);}

/* k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3041,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1116 stat-type */
f_3030(t3,lf[74]);}

/* k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! stat-char-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1117 stat-type */
f_3030(t3,lf[75]);}

/* k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1118 stat-type */
f_3030(t3,lf[76]);}

/* k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1119 stat-type */
f_3030(t3,lf[77]);}

/* k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1120 stat-type */
f_3030(t3,lf[78]);}

/* k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[121],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[79]+1 /* (set! file-position ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[84]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[89]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3164,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[97]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[99]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[4]+1);
t9=*((C_word*)lf[43]+1);
t10=*((C_word*)lf[101]+1);
t11=C_mutate((C_word*)lf[102]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t9,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[106]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3491,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[43]+1);
t14=C_mutate((C_word*)lf[105]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3518,a[2]=t13,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[109]+1);
t16=*((C_word*)lf[110]+1);
t17=*((C_word*)lf[111]+1);
t18=*((C_word*)lf[112]+1);
t19=*((C_word*)lf[113]+1);
t20=*((C_word*)lf[4]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[116]+1);
t24=*((C_word*)lf[105]+1);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3585,a[2]=t24,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t26=C_mutate((C_word*)lf[96]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3641,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,a[12]=((C_word)li42),tmp=(C_word)a,a+=13,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3998,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4010,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[138]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4034,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[140]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4070,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp));
t32=C_mutate((C_word*)lf[141]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[144]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[141]+1));
t34=*((C_word*)lf[138]+1);
t35=*((C_word*)lf[140]+1);
t36=*((C_word*)lf[141]+1);
t37=*((C_word*)lf[144]+1);
t38=C_mutate((C_word*)lf[145]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4125,a[2]=t34,a[3]=t36,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[146]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4149,a[2]=t35,a[3]=t37,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[147]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4173,a[2]=t34,a[3]=t36,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[149]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4193,a[2]=t35,a[3]=t37,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp));
t42=C_mutate((C_word*)lf[151]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4213,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[153]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[154]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[155]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[156]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[157]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[158]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[159]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[160] /* signal/alrm */,0,C_fix(0));
t51=C_set_block_item(lf[161] /* signal/chld */,0,C_fix(0));
t52=C_set_block_item(lf[162] /* signal/cont */,0,C_fix(0));
t53=C_set_block_item(lf[163] /* signal/hup */,0,C_fix(0));
t54=C_set_block_item(lf[164] /* signal/io */,0,C_fix(0));
t55=C_set_block_item(lf[165] /* signal/kill */,0,C_fix(0));
t56=C_set_block_item(lf[166] /* signal/pipe */,0,C_fix(0));
t57=C_set_block_item(lf[167] /* signal/prof */,0,C_fix(0));
t58=C_set_block_item(lf[168] /* signal/quit */,0,C_fix(0));
t59=C_set_block_item(lf[169] /* signal/stop */,0,C_fix(0));
t60=C_set_block_item(lf[170] /* signal/trap */,0,C_fix(0));
t61=C_set_block_item(lf[171] /* signal/tstp */,0,C_fix(0));
t62=C_set_block_item(lf[172] /* signal/urg */,0,C_fix(0));
t63=C_set_block_item(lf[173] /* signal/usr1 */,0,C_fix(0));
t64=C_set_block_item(lf[174] /* signal/usr2 */,0,C_fix(0));
t65=C_set_block_item(lf[175] /* signal/vtalrm */,0,C_fix(0));
t66=C_set_block_item(lf[176] /* signal/winch */,0,C_fix(0));
t67=C_set_block_item(lf[177] /* signal/xcpu */,0,C_fix(0));
t68=C_set_block_item(lf[178] /* signal/xfsz */,0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1),*((C_word*)lf[158]+1),*((C_word*)lf[159]+1));
t70=C_mutate((C_word*)lf[179]+1 /* (set! signals-list ...) */,t69);
t71=*((C_word*)lf[180]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4287,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1468 make-vector */
t73=*((C_word*)lf[391]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word ab[321],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=C_mutate((C_word*)lf[181]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4289,a[2]=t1,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[182]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t1,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[180]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[183]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[184]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[185]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[186]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[187]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[188]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[189]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[190]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[191]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[192]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[193]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[194]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[195]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[196]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[197]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[198]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[199]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[200]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[201]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[202]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[203]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[204]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[205]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[206]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[207]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[208]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[209]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[210]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[211]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[212]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[213]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[214]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[215]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[216]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[217]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[218]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[219]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[220]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[221]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4367,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[223]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4421,a[2]=t44,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[224]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4427,a[2]=t44,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[225]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4433,a[2]=t44,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[226]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[227]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[228]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4442,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[237]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4497,a[2]=t51,a[3]=t52,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[238]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4511,a[2]=t51,a[3]=t52,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[239]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[243]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4560,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[245]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4590,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[246]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4607,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[247]+1);
t60=C_mutate((C_word*)lf[248]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=t59,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[249]+1 /* (set! current-environment ...) */,*((C_word*)lf[248]+1));
t62=C_mutate(&lf[250] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4693,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[252]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4712,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[254]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4721,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[255]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4740,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[257]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4773,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[260]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4840,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[263]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[264]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4867,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[265]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4883,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[266]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4889,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t72=*((C_word*)lf[272]+1);
t73=*((C_word*)lf[273]+1);
t74=*((C_word*)lf[274]+1);
t75=*((C_word*)lf[102]+1);
t76=*((C_word*)lf[275]+1);
t77=*((C_word*)lf[276]+1);
t78=C_mutate((C_word*)lf[277]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4948,a[2]=t74,a[3]=t72,a[4]=t75,a[5]=t73,a[6]=t76,a[7]=t77,a[8]=((C_word)li93),tmp=(C_word)a,a+=9,tmp));
t79=C_mutate((C_word*)lf[280]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t80=C_mutate((C_word*)lf[281]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t81=C_mutate((C_word*)lf[282]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t82=C_mutate((C_word*)lf[283]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t83=C_mutate((C_word*)lf[284]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t84=*((C_word*)lf[285]+1);
t85=*((C_word*)lf[51]+1);
t86=*((C_word*)lf[113]+1);
t87=*((C_word*)lf[4]+1);
t88=C_mutate(&lf[286] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5060,a[2]=t87,a[3]=t85,a[4]=t86,a[5]=t84,a[6]=((C_word)li97),tmp=(C_word)a,a+=7,tmp));
t89=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5139,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5156,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
t91=*((C_word*)lf[289]+1);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5173,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
t93=C_mutate(&lf[290] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5223,a[2]=t91,a[3]=t89,a[4]=t90,a[5]=t92,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t94=C_mutate(&lf[291] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5256,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[292]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5271,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[294]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5358,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[296]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5445,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[297]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[301]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t100=*((C_word*)lf[294]+1);
t101=*((C_word*)lf[299]+1);
t102=C_mutate((C_word*)lf[303]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5475,a[2]=t100,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t103=C_mutate((C_word*)lf[304]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5567,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5686,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[309]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5748,a[2]=t104,a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[310]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=t104,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp));
t107=C_mutate((C_word*)lf[311]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5908,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[312]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5920,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[314]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5980,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[315]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5983,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[317]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5995,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[116]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t113=*((C_word*)lf[277]+1);
t114=*((C_word*)lf[273]+1);
t115=*((C_word*)lf[275]+1);
t116=*((C_word*)lf[106]+1);
t117=C_mutate((C_word*)lf[321]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6041,a[2]=t116,a[3]=t115,a[4]=t113,a[5]=t114,a[6]=((C_word)li154),tmp=(C_word)a,a+=7,tmp));
t118=C_mutate((C_word*)lf[328]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6261,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t119=C_mutate((C_word*)lf[330]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6267,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t120=C_mutate((C_word*)lf[331]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6273,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t121=C_mutate((C_word*)lf[332]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6279,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t122=C_mutate((C_word*)lf[333]+1 /* (set! current-effective-group-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6285,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t123=C_mutate((C_word*)lf[334]+1 /* (set! current-effective-user-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6291,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t124=C_mutate((C_word*)lf[335]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t125=C_mutate((C_word*)lf[336]+1 /* (set! current-group-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6303,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t126=C_mutate((C_word*)lf[337]+1 /* (set! current-user-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t127=C_mutate((C_word*)lf[338]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6315,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t128=C_mutate((C_word*)lf[339]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6321,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t129=C_mutate((C_word*)lf[340]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t130=C_mutate((C_word*)lf[341]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6333,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t131=C_mutate((C_word*)lf[342]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t132=C_mutate((C_word*)lf[343]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6345,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t133=C_mutate((C_word*)lf[344]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6351,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t134=C_mutate((C_word*)lf[345]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t135=C_mutate((C_word*)lf[346]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6363,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t136=C_mutate((C_word*)lf[347]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6369,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t137=C_mutate((C_word*)lf[348]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t138=C_mutate((C_word*)lf[349]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6381,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t139=C_mutate((C_word*)lf[350]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6387,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t140=C_mutate((C_word*)lf[351]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t141=C_mutate((C_word*)lf[352]+1 /* (set! process-group-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t142=C_mutate((C_word*)lf[353]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t143=C_mutate((C_word*)lf[354]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6411,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t144=C_mutate((C_word*)lf[355]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6417,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t145=C_mutate((C_word*)lf[356]+1 /* (set! set-group-id! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6423,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t146=C_mutate((C_word*)lf[357]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6429,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t147=C_mutate((C_word*)lf[358]+1 /* (set! set-process-group-id! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6435,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp));
t148=C_mutate((C_word*)lf[359]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6441,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t149=C_mutate((C_word*)lf[360]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp));
t150=C_mutate((C_word*)lf[361]+1 /* (set! set-user-id! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6453,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp));
t151=C_mutate((C_word*)lf[362]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6459,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp));
t152=C_mutate((C_word*)lf[363]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6465,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp));
t153=C_mutate((C_word*)lf[364]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6471,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp));
t154=C_mutate((C_word*)lf[365]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6477,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp));
t155=C_mutate((C_word*)lf[366]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6483,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp));
t156=C_mutate((C_word*)lf[367]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6489,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp));
t157=C_mutate((C_word*)lf[368]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp));
t158=C_mutate((C_word*)lf[369]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6501,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp));
t159=C_mutate((C_word*)lf[370]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6507,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp));
t160=C_mutate((C_word*)lf[371]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6513,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp));
t161=C_set_block_item(lf[372] /* errno/wouldblock */,0,C_fix(0));
t162=C_mutate((C_word*)lf[373]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6520,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp));
t163=C_mutate((C_word*)lf[374]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6523,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp));
t164=C_set_block_item(lf[375] /* map/anonymous */,0,C_fix(0));
t165=C_set_block_item(lf[376] /* map/file */,0,C_fix(0));
t166=C_set_block_item(lf[377] /* map/fixed */,0,C_fix(0));
t167=C_set_block_item(lf[378] /* map/private */,0,C_fix(0));
t168=C_set_block_item(lf[379] /* map/shared */,0,C_fix(0));
t169=C_set_block_item(lf[380] /* open/fsync */,0,C_fix(0));
t170=C_set_block_item(lf[381] /* open/noctty */,0,C_fix(0));
t171=C_set_block_item(lf[382] /* open/nonblock */,0,C_fix(0));
t172=C_set_block_item(lf[383] /* open/sync */,0,C_fix(0));
t173=C_set_block_item(lf[384] /* perm/isgid */,0,C_fix(0));
t174=C_set_block_item(lf[385] /* perm/isuid */,0,C_fix(0));
t175=C_set_block_item(lf[386] /* perm/isvtx */,0,C_fix(0));
t176=C_set_block_item(lf[387] /* prot/exec */,0,C_fix(0));
t177=C_set_block_item(lf[388] /* prot/none */,0,C_fix(0));
t178=C_set_block_item(lf[389] /* prot/read */,0,C_fix(0));
t179=C_set_block_item(lf[390] /* prot/write */,0,C_fix(0));
t180=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t180+1)))(2,t180,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6523,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6520,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6513(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6513,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[371],lf[0]);}

/* utc-time->seconds in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6507,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[370],lf[0]);}

/* user-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6501,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[369],lf[0]);}

/* unmap-file-from-memory in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[368],lf[0]);}

/* terminal-size in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[367],lf[0]);}

/* terminal-name in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[366],lf[0]);}

/* signal-unmask! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6477,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],lf[0]);}

/* signal-masked? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6471,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[364],lf[0]);}

/* signal-mask! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6465,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[363],lf[0]);}

/* signal-mask in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6459,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[362],lf[0]);}

/* set-user-id! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6453,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[361],lf[0]);}

/* set-signal-mask! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6447,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[360],lf[0]);}

/* set-root-directory! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6441,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[359],lf[0]);}

/* set-process-group-id! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[358],lf[0]);}

/* set-groups! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6429,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[357],lf[0]);}

/* set-group-id! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[356],lf[0]);}

/* set-alarm! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[355],lf[0]);}

/* read-symbolic-link in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[354],lf[0]);}

/* process-signal in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[353],lf[0]);}

/* process-group-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[352],lf[0]);}

/* process-fork in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[351],lf[0]);}

/* parent-process-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],lf[0]);}

/* memory-mapped-file-pointer in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[349],lf[0]);}

/* initialize-groups in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[348],lf[0]);}

/* group-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[347],lf[0]);}

/* get-groups in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[346],lf[0]);}

/* file-unlock in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[345],lf[0]);}

/* file-truncate in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[344],lf[0]);}

/* file-test-lock in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[343],lf[0]);}

/* file-select in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* file-lock/blocking in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* file-lock in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* file-link in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* map-file-to-memory in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* current-user-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* current-group-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* current-effective-user-name in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* current-effective-user-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* current-effective-group-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* create-symbolic-link in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6279,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* create-session in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* create-fifo in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* change-file-owner in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
/* error */
t2=*((C_word*)lf[329]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6041r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6041r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li149),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6182,a[2]=t5,a[3]=((C_word)li150),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6187,a[2]=t6,a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=t7,a[3]=((C_word)li153),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action18781963 */
t9=t8;
f_6192(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id18791959 */
t11=t7;
f_6187(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit18801954 */
t13=t6;
f_6182(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body18761886 */
t15=t5;
f_6043(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-action1878 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6192,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6198,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
/* def-id18791959 */
t3=((C_word*)t0)[2];
f_6187(t3,t1,t2);}

/* a6197 in def-action1878 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6198,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1879 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6187,NULL,3,t0,t1,t2);}
/* def-limit18801954 */
t3=((C_word*)t0)[2];
f_6182(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1880 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6182(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6182,NULL,4,t0,t1,t2,t3);}
/* body18761886 */
t4=((C_word*)t0)[2];
f_6043(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6043,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[321]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6050(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6177,a[2]=t4,a[3]=t7,a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6050(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6169,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));}}

/* f_6169 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6177 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6177,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6050,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6161,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li142),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6157,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2050 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[327]);}

/* k6155 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2050 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6060,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li146),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6062(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_6062(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6062,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2056 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2057 pathname-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[326]+1)))(3,*((C_word*)lf[326]+1),t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2063 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k6141 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2063 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2064 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6062(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6148 in k6141 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2063 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6062(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[322]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[323]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2057 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_6062(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2058 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6108,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li143),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li144),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6127,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li145),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[325]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2062 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_6062(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a6126 in k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6127,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a6112 in k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6125,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2061 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[324]);}

/* k6123 in a6112 in k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2061 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6119 in a6112 in k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2061 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6062(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6107 in k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6108,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k6104 in k6094 in k6135 in k6079 in loop in k6058 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2059 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6062(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6161 in k6048 in body1876 in find-files in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6161,3,t0,t1,t2);}
/* posixwin.scm: 2048 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6026,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6036,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2024 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6034 in current-user-name in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2025 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[116],lf[320]);}

/* system-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6006,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6021,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2015 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6019 in system-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2016 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[317],lf[319]);}

/* k6004 in system-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k6008 in k6004 in system-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k6012 in k6008 in k6004 in system-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6018,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k6016 in k6012 in k6008 in k6004 in system-information in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6018,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[318],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5983,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2005 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[315],lf[316]);}}

/* sleep in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5980,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_5920r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5920r(t0,t1,t2,t3);}}

static void C_ccall f_5920r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[312]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5941,a[2]=t5,a[3]=t2,a[4]=((C_word)li135),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=t2,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[2],t7);}}

/* a5946 in process-wait in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5947,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1987 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1989 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5955 in a5946 in process-wait in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1988 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[305],lf[312],lf[313],((C_word*)t0)[2]);}

/* a5940 in process-wait in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
/* posixwin.scm: 1984 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[311]+1)))(4,*((C_word*)lf[311]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5908,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1977 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1978 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5828r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5828r(t0,t1,t2,t3);}}

static void C_ccall f_5828r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5830,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5835,a[2]=t4,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5840,a[2]=t5,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5845,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17711794 */
t8=t7;
f_5845(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17721790 */
t10=t6;
f_5840(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17731785 */
t12=t5;
f_5835(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17691779 */
t14=t4;
f_5830(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args1771 in process* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5845,NULL,2,t0,t1);}
/* def-env17721790 */
t2=((C_word*)t0)[2];
f_5840(t2,t1,C_SCHEME_FALSE);}

/* def-env1772 in process* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5840,NULL,3,t0,t1,t2);}
/* def-exactf17731785 */
t3=((C_word*)t0)[2];
f_5835(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1773 in process* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5835(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5835,NULL,4,t0,t1,t2,t3);}
/* body17691779 */
t4=((C_word*)t0)[2];
f_5830(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1769 in process* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5830,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1971 %process */
f_5686(t1,lf[310],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5748r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5748r(t0,t1,t2,t3);}}

static void C_ccall f_5748r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5750,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5755,a[2]=t4,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5760,a[2]=t5,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5765,a[2]=t6,a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17161739 */
t8=t7;
f_5765(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17171735 */
t10=t6;
f_5760(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17181730 */
t12=t5;
f_5755(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17141724 */
t14=t4;
f_5750(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args1716 in process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5765,NULL,2,t0,t1);}
/* def-env17171735 */
t2=((C_word*)t0)[2];
f_5760(t2,t1,C_SCHEME_FALSE);}

/* def-env1717 in process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5760,NULL,3,t0,t1,t2);}
/* def-exactf17181730 */
t3=((C_word*)t0)[2];
f_5755(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1718 in process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5755(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5755,NULL,4,t0,t1,t2,t3);}
/* body17141724 */
t4=((C_word*)t0)[2];
f_5750(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1714 in process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5750(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5750,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1968 %process */
f_5686(t1,lf[309],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5686(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5686,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5688,a[2]=t2,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5707,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1956 chkstrlst */
t14=t11;
f_5688(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5742,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1959 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[301]+1)))(3,*((C_word*)lf[301]+1),t15,((C_word*)t8)[1]);}}

/* k5740 in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1960 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[297]+1)))(2,*((C_word*)lf[297]+1),t3);}

/* k5744 in k5740 in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5707(2,t3,t2);}

/* k5705 in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1961 chkstrlst */
t3=((C_word*)t0)[2];
f_5688(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_5710(2,t3,C_SCHEME_UNDEFINED);}}

/* k5708 in k5705 in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li121),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5721,a[2]=((C_word*)t0)[4],a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5720 in k5708 in k5705 in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5721,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1964 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1965 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5714 in k5708 in k5705 in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
/* posixwin.scm: 1962 ##sys#process */
t2=*((C_word*)lf[304]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5688,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[2],a[3]=((C_word)li119),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5696 in chkstrlst in %process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5697,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_5567r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_5567r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_5567r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5571,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_5571(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_5571(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[2],t9);}}}

/* k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5662,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1928 $quote-args-list */
t5=lf[286];
f_5060(t5,t3,t4,t1);}

/* k5660 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1928 string-intersperse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],t1);}

/* k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(t2))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(t5))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(t8))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(t11))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[307]+1)))(6,*((C_word*)lf[307]+1),t14,t2,C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[307]+1)))(6,*((C_word*)lf[307]+1),t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[307]+1)))(6,*((C_word*)lf[307]+1),t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[307]+1)))(6,*((C_word*)lf[307]+1),t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[308]);}

/* k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1935 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5509,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5509(2,t9,C_SCHEME_FALSE);}}

/* k5507 in k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5513(2,t3,C_SCHEME_FALSE);}}

/* k5511 in k5507 in k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub1538(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1938 open-input-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[237]+1)))(3,*((C_word*)lf[237]+1),t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_5603(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1943 ##sys#update-errno */
t8=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5621 in k5511 in k5507 in k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1944 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[305],((C_word*)t0)[3],lf[306],((C_word*)t0)[2]);}

/* k5601 in k5511 in k5507 in k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1939 open-output-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[238]+1)))(3,*((C_word*)lf[238]+1),t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5607(2,t3,C_SCHEME_FALSE);}}

/* k5605 in k5601 in k5511 in k5507 in k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5611,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1941 open-input-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[237]+1)))(3,*((C_word*)lf[237]+1),t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5611(2,t3,C_SCHEME_FALSE);}}

/* k5609 in k5605 in k5601 in k5511 in k5507 in k5644 in k5640 in k5636 in k5632 in k5628 in k5572 in k5569 in ##sys#process in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1937 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* process-run in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5475r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5475r(t0,t1,t2,t3);}}

static void C_ccall f_5475r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1899 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[282]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5492,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1900 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[297]+1)))(2,*((C_word*)lf[297]+1),t6);}}

/* k5490 in process-run in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5496,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1900 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[301]+1)))(3,*((C_word*)lf[301]+1),t2,((C_word*)t0)[2]);}

/* k5494 in k5490 in process-run in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1900 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[282]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5469,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[302],t2));}

/* ##sys#shell-command in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1883 getenv */
((C_proc3)C_retrieve_proc(*((C_word*)lf[299]+1)))(3,*((C_word*)lf[299]+1),t2,lf[300]);}

/* k5450 in ##sys#shell-command in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1887 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k5462 in k5450 in ##sys#shell-command in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1888 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[297],lf[298]);}

/* current-process-id in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1498(C_SCHEME_UNDEFINED));}

/* process-spawn in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5358r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5358r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5358r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5360,a[2]=t3,a[3]=t2,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5372,a[2]=t5,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5377,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5382,a[2]=t7,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst14591484 */
t9=t8;
f_5382(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst14601480 */
t11=t7;
f_5377(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf14611475 */
t13=t6;
f_5372(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body14571467 */
t15=t5;
f_5360(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-arglst1459 in process-spawn in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5382,NULL,2,t0,t1);}
/* def-envlst14601480 */
t2=((C_word*)t0)[2];
f_5377(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1460 in process-spawn in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5377(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5377,NULL,3,t0,t1,t2);}
/* def-exactf14611475 */
t3=((C_word*)t0)[2];
f_5372(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1461 in process-spawn in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5372(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5372,NULL,4,t0,t1,t2,t3);}
/* body14571467 */
t4=((C_word*)t0)[2];
f_5360(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1457 in process-spawn in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5360,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5364,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1874 $exec-setup */
t6=lf[290];
f_5223(t6,t5,lf[294],((C_word*)t0)[2],t2,t3,t4);}

/* k5362 in body1457 in process-spawn in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1875 $exec-teardown */
f_5256(((C_word*)t0)[3],lf[294],lf[295],((C_word*)t0)[2],t2);}

/* process-execute in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_5271r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5271r(t0,t1,t2,t3);}}

static void C_ccall f_5271r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5273,a[2]=t2,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5285,a[2]=t4,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5290,a[2]=t5,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5295,a[2]=t6,a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst13991424 */
t8=t7;
f_5295(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst14001420 */
t10=t6;
f_5290(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf14011415 */
t12=t5;
f_5285(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body13971407 */
t14=t4;
f_5273(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-arglst1399 in process-execute in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5295,NULL,2,t0,t1);}
/* def-envlst14001420 */
t2=((C_word*)t0)[2];
f_5290(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1400 in process-execute in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5290,NULL,3,t0,t1,t2);}
/* def-exactf14011415 */
t3=((C_word*)t0)[2];
f_5285(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1401 in process-execute in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5285(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5285,NULL,4,t0,t1,t2,t3);}
/* body13971407 */
t4=((C_word*)t0)[2];
f_5273(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1397 in process-execute in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5273(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5273,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1869 $exec-setup */
t6=lf[290];
f_5223(t6,t5,lf[292],((C_word*)t0)[2],t2,t3,t4);}

/* k5275 in body1397 in process-execute in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1870 $exec-teardown */
f_5256(((C_word*)t0)[3],lf[292],lf[293],((C_word*)t0)[2],t2);}

/* $exec-teardown in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5256(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5256,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5260,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1861 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5258 in $exec-teardown in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1865 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5223(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5223,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5230,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1853 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5228 in $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1854 setarg */
t4=((C_word*)t0)[4];
f_5139(5,t4,t2,C_fix(0),t1,t3);}

/* k5231 in k5228 in $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1855 $quote-args-list */
t4=lf[286];
f_5060(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5248 in k5231 in k5228 in $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1855 build-exec-argvec */
f_5173(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k5234 in k5231 in k5228 in $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5239,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1856 build-exec-argvec */
f_5173(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k5237 in k5234 in k5231 in k5228 in $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5239,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1858 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t3,((C_word*)t0)[2]);}

/* k5244 in k5237 in k5234 in k5231 in k5228 in $exec-setup in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1858 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5173(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5173,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5185,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5185(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1850 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop1337 in build-exec-argvec in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5185(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5185,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1846 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5204,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1849 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k5202 in doloop1337 in build-exec-argvec in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5185(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5156,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1323(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5139,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1311(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5060(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5060,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li95),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5103,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5103(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5103(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5103,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1827 reverse */
t4=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5131,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5134,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1832 needs-quoting? */
t8=((C_word*)t0)[2];
f_5065(t8,t7,t4);}}

/* k5132 in loop in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1832 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[287],((C_word*)t0)[2],lf[288]);}
else{
t2=((C_word*)t0)[3];
f_5131(2,t2,((C_word*)t0)[2]);}}

/* k5129 in loop in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5131,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1829 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5103(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5065(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5065,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5069,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1819 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5067 in needs-quoting? in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li94),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5074(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5067 in needs-quoting? in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_5074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5074,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5098,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1823 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k5096 in loop in k5067 in needs-quoting? in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1823 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5085 in loop in k5067 in needs-quoting? in $quote-args-list in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1824 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5074(t3,((C_word*)t0)[4],t2);}}

/* glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_4948r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4948r(t0,t1,t2);}}

static void C_ccall f_4948r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=((C_word)li92),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4954(t6,t1,t2);}

/* conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4954,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4969,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li91),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4975,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5049,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[279]);
/* posixwin.scm: 1781 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5047 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1781 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1782 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4980 in k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[278]);
/* posixwin.scm: 1783 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k4987 in k4980 in k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li90),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_4991(t5,((C_word*)t0)[2],t1);}

/* loop in k4987 in k4980 in k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4991,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1784 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4954(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1785 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5006 in loop in k4987 in k4980 in k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5008,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1786 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1787 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4991(t3,((C_word*)t0)[6],t2);}}

/* k5016 in k5006 in loop in k4987 in k4980 in k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5022,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1786 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4991(t4,t2,t3);}

/* k5020 in k5016 in k5006 in loop in k4987 in k4980 in k4977 in a4974 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4968 in conc-loop in glob in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4969,2,t0,t1);}
/* posixwin.scm: 1780 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4889r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4889r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4889r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4893,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1752 ##sys#check-port */
t6=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[266]);}

/* k4891 in set-buffering-mode! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t6)){
t7=t5;
f_4899(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[269]);
if(C_truep(t7)){
t8=t5;
f_4899(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[270]);
if(C_truep(t8)){
t9=t5;
f_4899(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1758 ##sys#error */
t9=*((C_word*)lf[62]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[266],lf[271],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4897 in k4891 in set-buffering-mode! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[266]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[81],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1764 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[266],lf[267],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4883,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4887,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1742 ##sys#check-port */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[265]);}

/* k4885 in terminal-port? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4867r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4867r(t0,t1,t2);}}

static void C_ccall f_4867r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1149(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1141(t2),C_fix(0));}

/* local-time->seconds in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4840,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4844,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1724 check-time-vector */
f_4693(t3,lf[260],t2);}

/* k4842 in local-time->seconds in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1726 ##sys#cons-flonum */
((C_proc2)C_retrieve_proc(*((C_word*)lf[261]+1)))(2,*((C_word*)lf[261]+1),((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1727 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[260],lf[262],((C_word*)t0)[3]);}}

/* time->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4773r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4773r(t0,t1,t2,t3);}}

static void C_ccall f_4773r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4777(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4777(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k4775 in time->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1712 check-time-vector */
f_4693(t2,lf[257],((C_word*)t0)[2]);}

/* k4778 in k4775 in time->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4780,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[257]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4799,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1716 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1090(t4,t3),C_fix(0));}}

/* k4800 in k4778 in k4775 in time->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1720 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1721 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[257],lf[259],((C_word*)t0)[2]);}}

/* k4797 in k4778 in k4775 in time->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1098(t3,t2,t1),C_fix(0));}

/* k4787 in k4778 in k4775 in time->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1717 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[257],lf[258],((C_word*)t0)[2]);}}

/* seconds->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4740,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4744,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub1075(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4742 in seconds->string in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1705 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1706 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[256],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4721,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[254]);
/* posixwin.scm: 1698 ##sys#decode-seconds */
((C_proc4)C_retrieve_proc(*((C_word*)lf[253]+1)))(4,*((C_word*)lf[253]+1),t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4712,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[252]);
/* posixwin.scm: 1694 ##sys#decode-seconds */
((C_proc4)C_retrieve_proc(*((C_word*)lf[253]+1)))(4,*((C_word*)lf[253]+1),t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4693(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4693,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1690 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[251],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li77),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4633(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4633(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4633,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4637,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1031(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4635 in loop in get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4645,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li76),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4645(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4635 in loop in get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4645,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1679 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1680 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4669 in scan in k4635 in loop in get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1679 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k4673 in k4669 in scan in k4635 in loop in get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1679 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4633(t5,t3,t4);}

/* k4661 in k4673 in k4669 in scan in k4635 in loop in get-environment-variables in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4607,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[246]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4615,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1667 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4613 in unsetenv in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4590,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[245]);
t5=(C_word)C_i_check_string_2(t3,lf[245]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1662 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4599 in setenv in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1662 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4603 in k4599 in setenv in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4560r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4560r(t0,t1,t2,t3);}}

static void C_ccall f_4560r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[243]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4567(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[243]);
t8=t5;
f_4567(t8,(C_word)C_dup2(t2,t6));}}

/* k4565 in duplicate-fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4567,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1651 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4570(2,t3,C_SCHEME_UNDEFINED);}}

/* k4574 in k4565 in duplicate-fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1652 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[243],lf[244],((C_word*)t0)[2]);}

/* k4568 in k4565 in duplicate-fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4525,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4529,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1633 ##sys#check-port */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[239]);}

/* k4527 in port->fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1634 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4556 in k4527 in port->fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1640 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[239],lf[240],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1637 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4538(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4542 in k4556 in k4527 in port->fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1638 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[239],lf[241],((C_word*)t0)[2]);}

/* k4536 in k4556 in k4527 in port->fileno in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4511r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4511r(t0,t1,t2,t3);}}

static void C_ccall f_4511r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[238]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1629 mode */
f_4442(t5,C_SCHEME_FALSE,t3);}

/* k4521 in open-output-file* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1629 check */
f_4479(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4497r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4497r(t0,t1,t2,t3);}}

static void C_ccall f_4497r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[237]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4509,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1625 mode */
f_4442(t5,C_SCHEME_TRUE,t3);}

/* k4507 in open-input-file* in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1625 check */
f_4479(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4479(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4479,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4483,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1616 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4481 in check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1618 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[235],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4495,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1619 ##sys#make-port */
t3=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[136]+1),lf[236],lf[81]);}}

/* k4493 in k4481 in check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4442(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4442,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[229]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1611 ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[230],t5);}
else{
t8=t4;
f_4450(2,t8,lf[231]);}}
else{
/* posixwin.scm: 1612 ##sys#error */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[232],t5);}}
else{
t5=t4;
f_4450(2,t5,(C_truep(t2)?lf[233]:lf[234]));}}

/* k4448 in mode in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1607 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4433,3,t0,t1,t2);}
/* posixwin.scm: 1591 check */
f_4397(t1,t2,C_fix((C_word)2),lf[225]);}

/* file-write-access? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4427,3,t0,t1,t2);}
/* posixwin.scm: 1590 check */
f_4397(t1,t2,C_fix((C_word)4),lf[224]);}

/* file-read-access? in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4421,3,t0,t1,t2);}
/* posixwin.scm: 1589 check */
f_4397(t1,t2,C_fix((C_word)2),lf[223]);}

/* check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4397(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4397,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4415,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4419,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1586 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t7,t2);}

/* k4417 in check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1586 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4413 in check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4415,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4407,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4407(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1587 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4405 in k4413 in check in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4367,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[221]);
t5=(C_word)C_i_check_exact_2(t3,lf[221]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4391,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4395,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1575 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t7,t2);}

/* k4393 in change-file-mode in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1575 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4389 in change-file-mode in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1576 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4381 in k4389 in change-file-mode in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1577 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[221],lf[222],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4311,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4321,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1483 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1485 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4319 in ##sys#interrupt-hook in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1484 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4298,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[182]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4285 in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4289,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[181]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4213r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4213r(t0,t1,t2);}}

static void C_ccall f_4213r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4217(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4217(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k4215 in create-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1420 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4220(2,t3,C_SCHEME_UNDEFINED);}}

/* k4227 in k4215 in create-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1421 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[151],lf[152]);}

/* k4218 in k4215 in create-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1422 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4193r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4193r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4193r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[150]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4197,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4195 in with-output-to-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=C_mutate((C_word*)lf[150]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4203,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1405 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4202 in k4195 in with-output-to-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4203r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4203r(t0,t1,t2);}}

static void C_ccall f_4203r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4207,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1407 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4205 in a4202 in k4195 in with-output-to-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[150]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4173r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4173r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4173r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[148]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4175 in with-input-from-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4183,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1395 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4182 in k4175 in with-input-from-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4183r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4183r(t0,t1,t2);}}

static void C_ccall f_4183r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4187,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1397 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4185 in a4182 in k4175 in with-input-from-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4149r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4149r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4149r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4153,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4151 in call-with-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4158,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1385 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4163 in k4151 in call-with-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4164r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4164r(t0,t1,t2);}}

static void C_ccall f_4164r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4168,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1388 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4166 in a4163 in k4151 in call-with-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4157 in k4151 in call-with-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
/* posixwin.scm: 1386 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4125r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4125r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4125r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4129,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4127 in call-with-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4134,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4140,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1377 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4139 in k4127 in call-with-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4140r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4140r(t0,t1,t2);}}

static void C_ccall f_4140r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1380 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4142 in a4139 in k4127 in call-with-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4133 in k4127 in call-with-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
/* posixwin.scm: 1378 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4110,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1364 ##sys#check-port */
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[141]);}

/* k4108 in close-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1366 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4111 in k4108 in close-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1367 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[141],lf[142],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4070r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4070r(t0,t1,t2,t3);}}

static void C_ccall f_4070r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[140]);
t5=f_3998(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4084,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[132]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1359 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4101,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1360 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1361 badmode */
f_4010(t6,t5);}}}

/* k4099 in open-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4084(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4089 in open-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4084(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4082 in open-output-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1356 check */
f_4016(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4034r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4034r(t0,t1,t2,t3);}}

static void C_ccall f_4034r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[138]);
t5=f_3998(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4048,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[132]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1349 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1350 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1351 badmode */
f_4010(t6,t5);}}}

/* k4063 in open-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4048(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4053 in open-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4048(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4046 in open-input-pipe in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1346 check */
f_4016(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4016(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4020,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1336 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4018 in check in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1338 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[134],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1339 ##sys#make-port */
t3=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[136]+1),lf[137],lf[81]);}}

/* k4030 in k4018 in check in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_4010(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4010,NULL,2,t1,t2);}
/* posixwin.scm: 1334 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[133],t2);}

/* mode in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static C_word C_fcall f_3998(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[132]));}

/* canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3641,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3648,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3781,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1273 cwd */
t8=((C_word*)t0)[5];
f_3585(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1275 sref */
t10=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3787(t9,C_SCHEME_FALSE);}}}

/* k3986 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 sep? */
t2=((C_word*)t0)[3];
f_3787(t2,f_3574(t1));}

/* k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3787,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1277 cwd */
t4=((C_word*)t0)[7];
f_3585(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1280 cwd */
t5=((C_word*)t0)[7];
f_3585(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1281 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3972 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1281 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3961 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1282 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3817(t2,C_SCHEME_FALSE);}}

/* k3968 in k3961 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1282 sep? */
t2=((C_word*)t0)[3];
f_3817(t2,f_3574(t1));}

/* k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1284 cwd */
t4=((C_word*)t0)[6];
f_3585(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1290 cwd */
t5=((C_word*)t0)[6];
f_3585(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3956,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1291 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3954 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1291 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3933 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3952,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1292 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_3859(t2,C_SCHEME_FALSE);}}

/* k3950 in k3933 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1292 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3939 in k3933 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1293 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_3859(t2,C_SCHEME_FALSE);}}

/* k3946 in k3939 in k3933 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1293 sep? */
t2=((C_word*)t0)[3];
f_3859(t2,f_3574(t1));}

/* k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3859,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_3648(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3932,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1295 sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3930 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1295 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3909 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3928,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1296 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3865(2,t2,C_SCHEME_FALSE);}}

/* k3926 in k3909 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3915 in k3909 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1297 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3865(2,t2,C_SCHEME_FALSE);}}

/* k3922 in k3915 in k3909 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1299 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1303 sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k3906 in k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3908,2,t0,t1);}
t2=f_3574(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3897,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1305 cwd */
t5=((C_word*)t0)[2];
f_3585(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1308 cwd */
t4=((C_word*)t0)[2];
f_3585(t4,t3);}}

/* k3902 in k3906 in k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1308 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[131],((C_word*)t0)[2]);}

/* k3895 in k3906 in k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1305 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3891 in k3906 in k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3870 in k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3876,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1301 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3874 in k3870 in k3863 in k3857 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1298 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[130],t1);}

/* k3851 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[129],((C_word*)t0)[2]);}

/* k3838 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1284 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3822 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3828,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1286 user */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3826 in k3822 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3832,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1287 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3830 in k3826 in k3822 in k3815 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 sappend */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],t1);}

/* k3809 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1280 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[127],((C_word*)t0)[2]);}

/* k3796 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1277 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3792 in k3785 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1276 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3779 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1273 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[126]);}

/* k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3767,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1309 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t3,t1,C_fix(3),t4);}

/* k3765 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),((C_word*)t0)[2],t1,lf[125]);}

/* k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3655,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li41),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3657(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3657(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3657,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1311 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1312 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3736,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1323 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[124],t5);}}

/* k3737 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3736(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1325 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[123],t3);}}

/* k3746 in k3737 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3736(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3736(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3734 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1321 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3657(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1313 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1314 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=f_3574(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1316 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1319 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k3703 in k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1320 reverse */
t4=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3711 in k3703 in k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1320 isperse */
f_3569(((C_word*)t0)[2],t1);}

/* k3707 in k3703 in k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1318 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3684 in k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3690,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3694,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[121],((C_word*)t0)[2]);
/* posixwin.scm: 1317 reverse */
t5=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3692 in k3684 in k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1317 isperse */
f_3569(((C_word*)t0)[2],t1);}

/* k3688 in k3684 in k3715 in k3668 in k3662 in loop in k3653 in k3646 in canonical-path in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1315 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3585,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3594,a[2]=((C_word*)t0)[2],a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3594,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3600,a[2]=t2,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3618,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[119]+1)))(4,*((C_word*)lf[119]+1),t1,t3,t4);}

/* a3617 in a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[3],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3630,a[2]=((C_word*)t0)[2],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3629 in a3617 in a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3630r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3630r(t0,t1,t2);}}

static void C_ccall f_3630r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3636,a[2]=t2,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
/* k577583 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3635 in a3629 in a3617 in a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3636,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3623 in a3617 in a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
/* posixwin.scm: 1268 cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3599 in a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3600,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=t2,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
/* k577583 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3605 in a3599 in a3593 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[117]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[118]);}

/* k3590 in cwd in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static C_word C_fcall f_3574(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3569(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3569,NULL,2,t1,t2);}
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t1,t2,lf[115]);}

/* current-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3518r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3518r(t0,t1,t2);}}

static void C_ccall f_3518r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3522(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3522(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k3520 in current-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1246 change-directory */
((C_proc3)C_retrieve_proc(*((C_word*)lf[97]+1)))(3,*((C_word*)lf[97]+1),((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1247 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3529 in k3520 in current-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3534,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3532 in k3529 in k3520 in current-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1251 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1252 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[105],lf[108]);}}

/* directory? in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3491,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3498,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3512,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1239 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t6,t2);}

/* k3514 in directory? in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1239 ##sys#platform-fixup-pathname */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1);}

/* k3510 in directory? in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1238 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3496 in directory? in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_3331r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3331r(t0,t1,t2);}}

static void C_ccall f_3331r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[2],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=t3,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3439,a[2]=t4,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec424482 */
t6=t5;
f_3439(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?425478 */
t8=t4;
f_3434(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body422431 */
t10=t3;
f_3333(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[2],t9);}}}}

/* def-spec424 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3439,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3447,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1209 current-directory */
((C_proc2)C_retrieve_proc(*((C_word*)lf[105]+1)))(2,*((C_word*)lf[105]+1),t2);}

/* k3445 in def-spec424 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?425478 */
t2=((C_word*)t0)[3];
f_3434(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?425 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3434,NULL,3,t0,t1,t2);}
/* body422431 */
t3=((C_word*)t0)[2];
f_3333(t3,t1,t2,C_SCHEME_FALSE);}

/* body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3333(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3333,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3340,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1211 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1212 ##sys#make-pointer */
((C_proc2)C_retrieve_proc(*((C_word*)lf[104]+1)))(2,*((C_word*)lf[104]+1),t2);}

/* k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1213 ##sys#make-pointer */
((C_proc2)C_retrieve_proc(*((C_word*)lf[104]+1)))(2,*((C_word*)lf[104]+1),t2);}

/* k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1214 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t3,((C_word*)t0)[4]);}

/* k3431 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1214 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3348 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1217 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li24),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3367(t6,((C_word*)t0)[6]);}}

/* loop in k3348 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1226 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k3375 in loop in k3348 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3389,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_3389(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_3389(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_3389(t7,C_SCHEME_FALSE);}}

/* k3387 in k3375 in loop in k3348 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3389,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1233 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3367(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1234 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3367(t3,t2);}}

/* k3397 in k3387 in k3375 in loop in k3348 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3357 in k3348 in k3344 in k3341 in k3338 in body422 in directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1218 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[102],lf[103],((C_word*)t0)[2]);}

/* delete-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[99]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3325,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1201 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t5,t2);}

/* k3327 in delete-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1201 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3323 in delete-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1202 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3315 in k3323 in delete-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1203 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[99],lf[100],((C_word*)t0)[2]);}

/* change-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3277,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1194 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t5,t2);}

/* k3300 in change-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1194 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3296 in change-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1195 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3288 in k3296 in change-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1196 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[97],lf[98],((C_word*)t0)[2]);}

/* create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3164r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3164r(t0,t1,t2,t3);}}

static void C_ccall f_3164r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3168(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3168(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[89]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1182 canonical-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[96]+1)))(3,*((C_word*)lf[96]+1),t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1183 canonical-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[96]+1)))(3,*((C_word*)lf[96]+1),t3,((C_word*)t0)[3]);}}

/* k3237 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3256,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3254 in k3237 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3256,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1154 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3246 in k3254 in k3237 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1155 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1170 string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[94]+1)))(4,*((C_word*)lf[94]+1),t2,t1,lf[95]);}

/* k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3188,a[2]=t4,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t1);
/* for-each */
t7=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3188,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3193,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1174 string-append */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[92],t2);}

/* k3191 in a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3199,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3219,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1159 file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t5,t3);}

/* k3217 in k3191 in a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1160 ##sys#file-info */
t3=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3199(t2,C_SCHEME_FALSE);}}

/* k3220 in k3217 in k3191 in a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
f_3199(t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
f_3199(t2,C_SCHEME_FALSE);}}

/* k3197 in k3191 in a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3199,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3214 in k3197 in k3191 in a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1154 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3206 in k3214 in k3197 in k3191 in a3187 in k3178 in k3175 in k3166 in create-directory in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1155 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* set-file-position! in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3103r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3103r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3103r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[84]);
t8=(C_word)C_i_check_exact_2(t6,lf[84]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3116,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1140 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[87],lf[84],lf[88],t3,t2);}
else{
t10=t9;
f_3116(2,t10,C_SCHEME_UNDEFINED);}}

/* k3114 in set-file-position! in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1141 port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),t3,((C_word*)t0)[4]);}

/* k3129 in k3114 in set-file-position! in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[4];
f_3122(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3122(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1145 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[84],lf[86],((C_word*)t0)[5]);}}}

/* k3120 in k3114 in set-file-position! in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1146 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3123 in k3120 in k3114 in set-file-position! in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1147 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[84],lf[85],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3063,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3067,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3082,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1124 port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),t4,t2);}

/* k3080 in file-position in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[2];
f_3067(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_3067(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1129 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[79],lf[82],((C_word*)t0)[3]);}}}

/* k3065 in file-position in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1131 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3070(2,t3,C_SCHEME_UNDEFINED);}}

/* k3074 in k3065 in file-position in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1132 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[79],lf[80],((C_word*)t0)[2]);}

/* k3068 in k3065 in file-position in k3059 in k3055 in k3051 in k3047 in k3043 in k3039 in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_3030(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3030,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3032,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));}

/* f_3032 in stat-type in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3032,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3025,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3002,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3009,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1102 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t5,t2);}

/* k3021 in regular-file? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1102 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3007 in regular-file? in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1098 ##sys#stat */
f_2897(t3,t2);}

/* k2998 in file-permissions in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2990,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_2897(t3,t2);}

/* k2992 in file-owner in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2984,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2897(t3,t2);}

/* k2986 in file-change-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_2897(t3,t2);}

/* k2980 in file-access-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_2897(t3,t2);}

/* k2974 in file-modification-time in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2966,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1093 ##sys#stat */
f_2897(t3,t2);}

/* k2968 in file-size in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2935r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2935r(t0,t1,t2,t3);}}

static void C_ccall f_2935r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2939,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2939(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2939(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k2937 in file-stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1087 ##sys#stat */
f_2897(t2,((C_word*)t0)[2]);}

/* k2940 in k2937 in file-stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_fcall f_2897(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2897,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2901(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2930,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1080 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t5,t2);}
else{
/* posixwin.scm: 1081 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k2928 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1080 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2924 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2901(2,t2,(C_word)C_stat(t1));}

/* k2899 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1083 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2908 in k2899 in ##sys#stat in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1084 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2859,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1049 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2864 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1051 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2867 in k2864 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1053 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2872(2,t4,C_SCHEME_UNDEFINED);}}

/* k2887 in k2867 in k2864 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1054 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k2870 in k2867 in k2864 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1055 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2877 in k2870 in k2867 in k2864 in file-mkstemp in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1055 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2817r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2817r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2824(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1036 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k2822 in file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2833,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2839,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1041 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2833(2,t8,C_SCHEME_UNDEFINED);}}

/* k2837 in k2822 in file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1042 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2831 in k2822 in file-write in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2772r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2772r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2772r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2782,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2782(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1023 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2780 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2785(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1025 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k2783 in k2780 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2788,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1028 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2788(2,t5,C_SCHEME_UNDEFINED);}}

/* k2795 in k2783 in k2780 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1029 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2786 in k2783 in k2780 in file-read in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2754,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1015 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2765 in file-close in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1016 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2713r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2713r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2730,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1005 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),t11,t2);}

/* k2744 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1005 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2728 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1007 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2733(2,t5,C_SCHEME_UNDEFINED);}}

/* k2737 in k2728 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1008 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2731 in k2728 in file-open in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2667r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2667r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2667r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2671,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 936  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2669 in posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2680 in k2669 in posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 937  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k2676 in k2669 in posix-error in k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2635 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[460] = {
{"toplevel:posixwin_scm",(void*)C_posix_toplevel},
{"f_2637:posixwin_scm",(void*)f_2637},
{"f_2640:posixwin_scm",(void*)f_2640},
{"f_2643:posixwin_scm",(void*)f_2643},
{"f_2646:posixwin_scm",(void*)f_2646},
{"f_2649:posixwin_scm",(void*)f_2649},
{"f_2652:posixwin_scm",(void*)f_2652},
{"f_2655:posixwin_scm",(void*)f_2655},
{"f_3041:posixwin_scm",(void*)f_3041},
{"f_3045:posixwin_scm",(void*)f_3045},
{"f_3049:posixwin_scm",(void*)f_3049},
{"f_3053:posixwin_scm",(void*)f_3053},
{"f_3057:posixwin_scm",(void*)f_3057},
{"f_3061:posixwin_scm",(void*)f_3061},
{"f_4287:posixwin_scm",(void*)f_4287},
{"f_6523:posixwin_scm",(void*)f_6523},
{"f_6520:posixwin_scm",(void*)f_6520},
{"f_6513:posixwin_scm",(void*)f_6513},
{"f_6507:posixwin_scm",(void*)f_6507},
{"f_6501:posixwin_scm",(void*)f_6501},
{"f_6495:posixwin_scm",(void*)f_6495},
{"f_6489:posixwin_scm",(void*)f_6489},
{"f_6483:posixwin_scm",(void*)f_6483},
{"f_6477:posixwin_scm",(void*)f_6477},
{"f_6471:posixwin_scm",(void*)f_6471},
{"f_6465:posixwin_scm",(void*)f_6465},
{"f_6459:posixwin_scm",(void*)f_6459},
{"f_6453:posixwin_scm",(void*)f_6453},
{"f_6447:posixwin_scm",(void*)f_6447},
{"f_6441:posixwin_scm",(void*)f_6441},
{"f_6435:posixwin_scm",(void*)f_6435},
{"f_6429:posixwin_scm",(void*)f_6429},
{"f_6423:posixwin_scm",(void*)f_6423},
{"f_6417:posixwin_scm",(void*)f_6417},
{"f_6411:posixwin_scm",(void*)f_6411},
{"f_6405:posixwin_scm",(void*)f_6405},
{"f_6399:posixwin_scm",(void*)f_6399},
{"f_6393:posixwin_scm",(void*)f_6393},
{"f_6387:posixwin_scm",(void*)f_6387},
{"f_6381:posixwin_scm",(void*)f_6381},
{"f_6375:posixwin_scm",(void*)f_6375},
{"f_6369:posixwin_scm",(void*)f_6369},
{"f_6363:posixwin_scm",(void*)f_6363},
{"f_6357:posixwin_scm",(void*)f_6357},
{"f_6351:posixwin_scm",(void*)f_6351},
{"f_6345:posixwin_scm",(void*)f_6345},
{"f_6339:posixwin_scm",(void*)f_6339},
{"f_6333:posixwin_scm",(void*)f_6333},
{"f_6327:posixwin_scm",(void*)f_6327},
{"f_6321:posixwin_scm",(void*)f_6321},
{"f_6315:posixwin_scm",(void*)f_6315},
{"f_6309:posixwin_scm",(void*)f_6309},
{"f_6303:posixwin_scm",(void*)f_6303},
{"f_6297:posixwin_scm",(void*)f_6297},
{"f_6291:posixwin_scm",(void*)f_6291},
{"f_6285:posixwin_scm",(void*)f_6285},
{"f_6279:posixwin_scm",(void*)f_6279},
{"f_6273:posixwin_scm",(void*)f_6273},
{"f_6267:posixwin_scm",(void*)f_6267},
{"f_6261:posixwin_scm",(void*)f_6261},
{"f_6041:posixwin_scm",(void*)f_6041},
{"f_6192:posixwin_scm",(void*)f_6192},
{"f_6198:posixwin_scm",(void*)f_6198},
{"f_6187:posixwin_scm",(void*)f_6187},
{"f_6182:posixwin_scm",(void*)f_6182},
{"f_6043:posixwin_scm",(void*)f_6043},
{"f_6169:posixwin_scm",(void*)f_6169},
{"f_6177:posixwin_scm",(void*)f_6177},
{"f_6050:posixwin_scm",(void*)f_6050},
{"f_6157:posixwin_scm",(void*)f_6157},
{"f_6060:posixwin_scm",(void*)f_6060},
{"f_6062:posixwin_scm",(void*)f_6062},
{"f_6081:posixwin_scm",(void*)f_6081},
{"f_6143:posixwin_scm",(void*)f_6143},
{"f_6150:posixwin_scm",(void*)f_6150},
{"f_6137:posixwin_scm",(void*)f_6137},
{"f_6096:posixwin_scm",(void*)f_6096},
{"f_6127:posixwin_scm",(void*)f_6127},
{"f_6113:posixwin_scm",(void*)f_6113},
{"f_6125:posixwin_scm",(void*)f_6125},
{"f_6121:posixwin_scm",(void*)f_6121},
{"f_6108:posixwin_scm",(void*)f_6108},
{"f_6106:posixwin_scm",(void*)f_6106},
{"f_6161:posixwin_scm",(void*)f_6161},
{"f_6026:posixwin_scm",(void*)f_6026},
{"f_6036:posixwin_scm",(void*)f_6036},
{"f_5995:posixwin_scm",(void*)f_5995},
{"f_6021:posixwin_scm",(void*)f_6021},
{"f_6006:posixwin_scm",(void*)f_6006},
{"f_6010:posixwin_scm",(void*)f_6010},
{"f_6014:posixwin_scm",(void*)f_6014},
{"f_6018:posixwin_scm",(void*)f_6018},
{"f_5983:posixwin_scm",(void*)f_5983},
{"f_5980:posixwin_scm",(void*)f_5980},
{"f_5920:posixwin_scm",(void*)f_5920},
{"f_5947:posixwin_scm",(void*)f_5947},
{"f_5957:posixwin_scm",(void*)f_5957},
{"f_5941:posixwin_scm",(void*)f_5941},
{"f_5908:posixwin_scm",(void*)f_5908},
{"f_5828:posixwin_scm",(void*)f_5828},
{"f_5845:posixwin_scm",(void*)f_5845},
{"f_5840:posixwin_scm",(void*)f_5840},
{"f_5835:posixwin_scm",(void*)f_5835},
{"f_5830:posixwin_scm",(void*)f_5830},
{"f_5748:posixwin_scm",(void*)f_5748},
{"f_5765:posixwin_scm",(void*)f_5765},
{"f_5760:posixwin_scm",(void*)f_5760},
{"f_5755:posixwin_scm",(void*)f_5755},
{"f_5750:posixwin_scm",(void*)f_5750},
{"f_5686:posixwin_scm",(void*)f_5686},
{"f_5742:posixwin_scm",(void*)f_5742},
{"f_5746:posixwin_scm",(void*)f_5746},
{"f_5707:posixwin_scm",(void*)f_5707},
{"f_5710:posixwin_scm",(void*)f_5710},
{"f_5721:posixwin_scm",(void*)f_5721},
{"f_5715:posixwin_scm",(void*)f_5715},
{"f_5688:posixwin_scm",(void*)f_5688},
{"f_5697:posixwin_scm",(void*)f_5697},
{"f_5567:posixwin_scm",(void*)f_5567},
{"f_5571:posixwin_scm",(void*)f_5571},
{"f_5662:posixwin_scm",(void*)f_5662},
{"f_5574:posixwin_scm",(void*)f_5574},
{"f_5630:posixwin_scm",(void*)f_5630},
{"f_5634:posixwin_scm",(void*)f_5634},
{"f_5638:posixwin_scm",(void*)f_5638},
{"f_5642:posixwin_scm",(void*)f_5642},
{"f_5646:posixwin_scm",(void*)f_5646},
{"f_5509:posixwin_scm",(void*)f_5509},
{"f_5513:posixwin_scm",(void*)f_5513},
{"f_5623:posixwin_scm",(void*)f_5623},
{"f_5603:posixwin_scm",(void*)f_5603},
{"f_5607:posixwin_scm",(void*)f_5607},
{"f_5611:posixwin_scm",(void*)f_5611},
{"f_5475:posixwin_scm",(void*)f_5475},
{"f_5492:posixwin_scm",(void*)f_5492},
{"f_5496:posixwin_scm",(void*)f_5496},
{"f_5469:posixwin_scm",(void*)f_5469},
{"f_5448:posixwin_scm",(void*)f_5448},
{"f_5452:posixwin_scm",(void*)f_5452},
{"f_5464:posixwin_scm",(void*)f_5464},
{"f_5445:posixwin_scm",(void*)f_5445},
{"f_5358:posixwin_scm",(void*)f_5358},
{"f_5382:posixwin_scm",(void*)f_5382},
{"f_5377:posixwin_scm",(void*)f_5377},
{"f_5372:posixwin_scm",(void*)f_5372},
{"f_5360:posixwin_scm",(void*)f_5360},
{"f_5364:posixwin_scm",(void*)f_5364},
{"f_5271:posixwin_scm",(void*)f_5271},
{"f_5295:posixwin_scm",(void*)f_5295},
{"f_5290:posixwin_scm",(void*)f_5290},
{"f_5285:posixwin_scm",(void*)f_5285},
{"f_5273:posixwin_scm",(void*)f_5273},
{"f_5277:posixwin_scm",(void*)f_5277},
{"f_5256:posixwin_scm",(void*)f_5256},
{"f_5260:posixwin_scm",(void*)f_5260},
{"f_5223:posixwin_scm",(void*)f_5223},
{"f_5230:posixwin_scm",(void*)f_5230},
{"f_5233:posixwin_scm",(void*)f_5233},
{"f_5250:posixwin_scm",(void*)f_5250},
{"f_5236:posixwin_scm",(void*)f_5236},
{"f_5239:posixwin_scm",(void*)f_5239},
{"f_5246:posixwin_scm",(void*)f_5246},
{"f_5173:posixwin_scm",(void*)f_5173},
{"f_5185:posixwin_scm",(void*)f_5185},
{"f_5204:posixwin_scm",(void*)f_5204},
{"f_5156:posixwin_scm",(void*)f_5156},
{"f_5139:posixwin_scm",(void*)f_5139},
{"f_5060:posixwin_scm",(void*)f_5060},
{"f_5103:posixwin_scm",(void*)f_5103},
{"f_5134:posixwin_scm",(void*)f_5134},
{"f_5131:posixwin_scm",(void*)f_5131},
{"f_5065:posixwin_scm",(void*)f_5065},
{"f_5069:posixwin_scm",(void*)f_5069},
{"f_5074:posixwin_scm",(void*)f_5074},
{"f_5098:posixwin_scm",(void*)f_5098},
{"f_5087:posixwin_scm",(void*)f_5087},
{"f_4948:posixwin_scm",(void*)f_4948},
{"f_4954:posixwin_scm",(void*)f_4954},
{"f_4975:posixwin_scm",(void*)f_4975},
{"f_5049:posixwin_scm",(void*)f_5049},
{"f_4979:posixwin_scm",(void*)f_4979},
{"f_4982:posixwin_scm",(void*)f_4982},
{"f_4989:posixwin_scm",(void*)f_4989},
{"f_4991:posixwin_scm",(void*)f_4991},
{"f_5008:posixwin_scm",(void*)f_5008},
{"f_5018:posixwin_scm",(void*)f_5018},
{"f_5022:posixwin_scm",(void*)f_5022},
{"f_4969:posixwin_scm",(void*)f_4969},
{"f_4889:posixwin_scm",(void*)f_4889},
{"f_4893:posixwin_scm",(void*)f_4893},
{"f_4899:posixwin_scm",(void*)f_4899},
{"f_4883:posixwin_scm",(void*)f_4883},
{"f_4887:posixwin_scm",(void*)f_4887},
{"f_4867:posixwin_scm",(void*)f_4867},
{"f_4855:posixwin_scm",(void*)f_4855},
{"f_4840:posixwin_scm",(void*)f_4840},
{"f_4844:posixwin_scm",(void*)f_4844},
{"f_4773:posixwin_scm",(void*)f_4773},
{"f_4777:posixwin_scm",(void*)f_4777},
{"f_4780:posixwin_scm",(void*)f_4780},
{"f_4802:posixwin_scm",(void*)f_4802},
{"f_4799:posixwin_scm",(void*)f_4799},
{"f_4789:posixwin_scm",(void*)f_4789},
{"f_4740:posixwin_scm",(void*)f_4740},
{"f_4744:posixwin_scm",(void*)f_4744},
{"f_4721:posixwin_scm",(void*)f_4721},
{"f_4712:posixwin_scm",(void*)f_4712},
{"f_4693:posixwin_scm",(void*)f_4693},
{"f_4627:posixwin_scm",(void*)f_4627},
{"f_4633:posixwin_scm",(void*)f_4633},
{"f_4637:posixwin_scm",(void*)f_4637},
{"f_4645:posixwin_scm",(void*)f_4645},
{"f_4671:posixwin_scm",(void*)f_4671},
{"f_4675:posixwin_scm",(void*)f_4675},
{"f_4663:posixwin_scm",(void*)f_4663},
{"f_4607:posixwin_scm",(void*)f_4607},
{"f_4615:posixwin_scm",(void*)f_4615},
{"f_4590:posixwin_scm",(void*)f_4590},
{"f_4601:posixwin_scm",(void*)f_4601},
{"f_4605:posixwin_scm",(void*)f_4605},
{"f_4560:posixwin_scm",(void*)f_4560},
{"f_4567:posixwin_scm",(void*)f_4567},
{"f_4576:posixwin_scm",(void*)f_4576},
{"f_4570:posixwin_scm",(void*)f_4570},
{"f_4525:posixwin_scm",(void*)f_4525},
{"f_4529:posixwin_scm",(void*)f_4529},
{"f_4558:posixwin_scm",(void*)f_4558},
{"f_4544:posixwin_scm",(void*)f_4544},
{"f_4538:posixwin_scm",(void*)f_4538},
{"f_4511:posixwin_scm",(void*)f_4511},
{"f_4523:posixwin_scm",(void*)f_4523},
{"f_4497:posixwin_scm",(void*)f_4497},
{"f_4509:posixwin_scm",(void*)f_4509},
{"f_4479:posixwin_scm",(void*)f_4479},
{"f_4483:posixwin_scm",(void*)f_4483},
{"f_4495:posixwin_scm",(void*)f_4495},
{"f_4442:posixwin_scm",(void*)f_4442},
{"f_4450:posixwin_scm",(void*)f_4450},
{"f_4433:posixwin_scm",(void*)f_4433},
{"f_4427:posixwin_scm",(void*)f_4427},
{"f_4421:posixwin_scm",(void*)f_4421},
{"f_4397:posixwin_scm",(void*)f_4397},
{"f_4419:posixwin_scm",(void*)f_4419},
{"f_4415:posixwin_scm",(void*)f_4415},
{"f_4407:posixwin_scm",(void*)f_4407},
{"f_4367:posixwin_scm",(void*)f_4367},
{"f_4395:posixwin_scm",(void*)f_4395},
{"f_4391:posixwin_scm",(void*)f_4391},
{"f_4383:posixwin_scm",(void*)f_4383},
{"f_4311:posixwin_scm",(void*)f_4311},
{"f_4321:posixwin_scm",(void*)f_4321},
{"f_4298:posixwin_scm",(void*)f_4298},
{"f_4289:posixwin_scm",(void*)f_4289},
{"f_4213:posixwin_scm",(void*)f_4213},
{"f_4217:posixwin_scm",(void*)f_4217},
{"f_4229:posixwin_scm",(void*)f_4229},
{"f_4220:posixwin_scm",(void*)f_4220},
{"f_4193:posixwin_scm",(void*)f_4193},
{"f_4197:posixwin_scm",(void*)f_4197},
{"f_4203:posixwin_scm",(void*)f_4203},
{"f_4207:posixwin_scm",(void*)f_4207},
{"f_4173:posixwin_scm",(void*)f_4173},
{"f_4177:posixwin_scm",(void*)f_4177},
{"f_4183:posixwin_scm",(void*)f_4183},
{"f_4187:posixwin_scm",(void*)f_4187},
{"f_4149:posixwin_scm",(void*)f_4149},
{"f_4153:posixwin_scm",(void*)f_4153},
{"f_4164:posixwin_scm",(void*)f_4164},
{"f_4168:posixwin_scm",(void*)f_4168},
{"f_4158:posixwin_scm",(void*)f_4158},
{"f_4125:posixwin_scm",(void*)f_4125},
{"f_4129:posixwin_scm",(void*)f_4129},
{"f_4140:posixwin_scm",(void*)f_4140},
{"f_4144:posixwin_scm",(void*)f_4144},
{"f_4134:posixwin_scm",(void*)f_4134},
{"f_4106:posixwin_scm",(void*)f_4106},
{"f_4110:posixwin_scm",(void*)f_4110},
{"f_4113:posixwin_scm",(void*)f_4113},
{"f_4070:posixwin_scm",(void*)f_4070},
{"f_4101:posixwin_scm",(void*)f_4101},
{"f_4091:posixwin_scm",(void*)f_4091},
{"f_4084:posixwin_scm",(void*)f_4084},
{"f_4034:posixwin_scm",(void*)f_4034},
{"f_4065:posixwin_scm",(void*)f_4065},
{"f_4055:posixwin_scm",(void*)f_4055},
{"f_4048:posixwin_scm",(void*)f_4048},
{"f_4016:posixwin_scm",(void*)f_4016},
{"f_4020:posixwin_scm",(void*)f_4020},
{"f_4032:posixwin_scm",(void*)f_4032},
{"f_4010:posixwin_scm",(void*)f_4010},
{"f_3998:posixwin_scm",(void*)f_3998},
{"f_3641:posixwin_scm",(void*)f_3641},
{"f_3988:posixwin_scm",(void*)f_3988},
{"f_3787:posixwin_scm",(void*)f_3787},
{"f_3974:posixwin_scm",(void*)f_3974},
{"f_3963:posixwin_scm",(void*)f_3963},
{"f_3970:posixwin_scm",(void*)f_3970},
{"f_3817:posixwin_scm",(void*)f_3817},
{"f_3956:posixwin_scm",(void*)f_3956},
{"f_3935:posixwin_scm",(void*)f_3935},
{"f_3952:posixwin_scm",(void*)f_3952},
{"f_3941:posixwin_scm",(void*)f_3941},
{"f_3948:posixwin_scm",(void*)f_3948},
{"f_3859:posixwin_scm",(void*)f_3859},
{"f_3932:posixwin_scm",(void*)f_3932},
{"f_3911:posixwin_scm",(void*)f_3911},
{"f_3928:posixwin_scm",(void*)f_3928},
{"f_3917:posixwin_scm",(void*)f_3917},
{"f_3924:posixwin_scm",(void*)f_3924},
{"f_3865:posixwin_scm",(void*)f_3865},
{"f_3908:posixwin_scm",(void*)f_3908},
{"f_3904:posixwin_scm",(void*)f_3904},
{"f_3897:posixwin_scm",(void*)f_3897},
{"f_3893:posixwin_scm",(void*)f_3893},
{"f_3872:posixwin_scm",(void*)f_3872},
{"f_3876:posixwin_scm",(void*)f_3876},
{"f_3853:posixwin_scm",(void*)f_3853},
{"f_3840:posixwin_scm",(void*)f_3840},
{"f_3824:posixwin_scm",(void*)f_3824},
{"f_3828:posixwin_scm",(void*)f_3828},
{"f_3832:posixwin_scm",(void*)f_3832},
{"f_3811:posixwin_scm",(void*)f_3811},
{"f_3798:posixwin_scm",(void*)f_3798},
{"f_3794:posixwin_scm",(void*)f_3794},
{"f_3781:posixwin_scm",(void*)f_3781},
{"f_3648:posixwin_scm",(void*)f_3648},
{"f_3767:posixwin_scm",(void*)f_3767},
{"f_3655:posixwin_scm",(void*)f_3655},
{"f_3657:posixwin_scm",(void*)f_3657},
{"f_3664:posixwin_scm",(void*)f_3664},
{"f_3739:posixwin_scm",(void*)f_3739},
{"f_3748:posixwin_scm",(void*)f_3748},
{"f_3736:posixwin_scm",(void*)f_3736},
{"f_3670:posixwin_scm",(void*)f_3670},
{"f_3717:posixwin_scm",(void*)f_3717},
{"f_3705:posixwin_scm",(void*)f_3705},
{"f_3713:posixwin_scm",(void*)f_3713},
{"f_3709:posixwin_scm",(void*)f_3709},
{"f_3686:posixwin_scm",(void*)f_3686},
{"f_3694:posixwin_scm",(void*)f_3694},
{"f_3690:posixwin_scm",(void*)f_3690},
{"f_3585:posixwin_scm",(void*)f_3585},
{"f_3594:posixwin_scm",(void*)f_3594},
{"f_3618:posixwin_scm",(void*)f_3618},
{"f_3630:posixwin_scm",(void*)f_3630},
{"f_3636:posixwin_scm",(void*)f_3636},
{"f_3624:posixwin_scm",(void*)f_3624},
{"f_3600:posixwin_scm",(void*)f_3600},
{"f_3606:posixwin_scm",(void*)f_3606},
{"f_3592:posixwin_scm",(void*)f_3592},
{"f_3574:posixwin_scm",(void*)f_3574},
{"f_3569:posixwin_scm",(void*)f_3569},
{"f_3518:posixwin_scm",(void*)f_3518},
{"f_3522:posixwin_scm",(void*)f_3522},
{"f_3531:posixwin_scm",(void*)f_3531},
{"f_3534:posixwin_scm",(void*)f_3534},
{"f_3491:posixwin_scm",(void*)f_3491},
{"f_3516:posixwin_scm",(void*)f_3516},
{"f_3512:posixwin_scm",(void*)f_3512},
{"f_3498:posixwin_scm",(void*)f_3498},
{"f_3331:posixwin_scm",(void*)f_3331},
{"f_3439:posixwin_scm",(void*)f_3439},
{"f_3447:posixwin_scm",(void*)f_3447},
{"f_3434:posixwin_scm",(void*)f_3434},
{"f_3333:posixwin_scm",(void*)f_3333},
{"f_3340:posixwin_scm",(void*)f_3340},
{"f_3343:posixwin_scm",(void*)f_3343},
{"f_3346:posixwin_scm",(void*)f_3346},
{"f_3433:posixwin_scm",(void*)f_3433},
{"f_3350:posixwin_scm",(void*)f_3350},
{"f_3367:posixwin_scm",(void*)f_3367},
{"f_3377:posixwin_scm",(void*)f_3377},
{"f_3389:posixwin_scm",(void*)f_3389},
{"f_3399:posixwin_scm",(void*)f_3399},
{"f_3359:posixwin_scm",(void*)f_3359},
{"f_3304:posixwin_scm",(void*)f_3304},
{"f_3329:posixwin_scm",(void*)f_3329},
{"f_3325:posixwin_scm",(void*)f_3325},
{"f_3317:posixwin_scm",(void*)f_3317},
{"f_3277:posixwin_scm",(void*)f_3277},
{"f_3302:posixwin_scm",(void*)f_3302},
{"f_3298:posixwin_scm",(void*)f_3298},
{"f_3290:posixwin_scm",(void*)f_3290},
{"f_3164:posixwin_scm",(void*)f_3164},
{"f_3168:posixwin_scm",(void*)f_3168},
{"f_3239:posixwin_scm",(void*)f_3239},
{"f_3256:posixwin_scm",(void*)f_3256},
{"f_3248:posixwin_scm",(void*)f_3248},
{"f_3177:posixwin_scm",(void*)f_3177},
{"f_3180:posixwin_scm",(void*)f_3180},
{"f_3188:posixwin_scm",(void*)f_3188},
{"f_3193:posixwin_scm",(void*)f_3193},
{"f_3219:posixwin_scm",(void*)f_3219},
{"f_3222:posixwin_scm",(void*)f_3222},
{"f_3199:posixwin_scm",(void*)f_3199},
{"f_3216:posixwin_scm",(void*)f_3216},
{"f_3208:posixwin_scm",(void*)f_3208},
{"f_3103:posixwin_scm",(void*)f_3103},
{"f_3116:posixwin_scm",(void*)f_3116},
{"f_3131:posixwin_scm",(void*)f_3131},
{"f_3122:posixwin_scm",(void*)f_3122},
{"f_3125:posixwin_scm",(void*)f_3125},
{"f_3063:posixwin_scm",(void*)f_3063},
{"f_3082:posixwin_scm",(void*)f_3082},
{"f_3067:posixwin_scm",(void*)f_3067},
{"f_3076:posixwin_scm",(void*)f_3076},
{"f_3070:posixwin_scm",(void*)f_3070},
{"f_3030:posixwin_scm",(void*)f_3030},
{"f_3032:posixwin_scm",(void*)f_3032},
{"f_3025:posixwin_scm",(void*)f_3025},
{"f_3002:posixwin_scm",(void*)f_3002},
{"f_3023:posixwin_scm",(void*)f_3023},
{"f_3009:posixwin_scm",(void*)f_3009},
{"f_2996:posixwin_scm",(void*)f_2996},
{"f_3000:posixwin_scm",(void*)f_3000},
{"f_2990:posixwin_scm",(void*)f_2990},
{"f_2994:posixwin_scm",(void*)f_2994},
{"f_2984:posixwin_scm",(void*)f_2984},
{"f_2988:posixwin_scm",(void*)f_2988},
{"f_2978:posixwin_scm",(void*)f_2978},
{"f_2982:posixwin_scm",(void*)f_2982},
{"f_2972:posixwin_scm",(void*)f_2972},
{"f_2976:posixwin_scm",(void*)f_2976},
{"f_2966:posixwin_scm",(void*)f_2966},
{"f_2970:posixwin_scm",(void*)f_2970},
{"f_2935:posixwin_scm",(void*)f_2935},
{"f_2939:posixwin_scm",(void*)f_2939},
{"f_2942:posixwin_scm",(void*)f_2942},
{"f_2897:posixwin_scm",(void*)f_2897},
{"f_2930:posixwin_scm",(void*)f_2930},
{"f_2926:posixwin_scm",(void*)f_2926},
{"f_2901:posixwin_scm",(void*)f_2901},
{"f_2910:posixwin_scm",(void*)f_2910},
{"f_2859:posixwin_scm",(void*)f_2859},
{"f_2866:posixwin_scm",(void*)f_2866},
{"f_2869:posixwin_scm",(void*)f_2869},
{"f_2889:posixwin_scm",(void*)f_2889},
{"f_2872:posixwin_scm",(void*)f_2872},
{"f_2879:posixwin_scm",(void*)f_2879},
{"f_2817:posixwin_scm",(void*)f_2817},
{"f_2824:posixwin_scm",(void*)f_2824},
{"f_2839:posixwin_scm",(void*)f_2839},
{"f_2833:posixwin_scm",(void*)f_2833},
{"f_2772:posixwin_scm",(void*)f_2772},
{"f_2782:posixwin_scm",(void*)f_2782},
{"f_2785:posixwin_scm",(void*)f_2785},
{"f_2797:posixwin_scm",(void*)f_2797},
{"f_2788:posixwin_scm",(void*)f_2788},
{"f_2754:posixwin_scm",(void*)f_2754},
{"f_2767:posixwin_scm",(void*)f_2767},
{"f_2713:posixwin_scm",(void*)f_2713},
{"f_2746:posixwin_scm",(void*)f_2746},
{"f_2730:posixwin_scm",(void*)f_2730},
{"f_2739:posixwin_scm",(void*)f_2739},
{"f_2733:posixwin_scm",(void*)f_2733},
{"f_2667:posixwin_scm",(void*)f_2667},
{"f_2671:posixwin_scm",(void*)f_2671},
{"f_2682:posixwin_scm",(void*)f_2682},
{"f_2678:posixwin_scm",(void*)f_2678},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
