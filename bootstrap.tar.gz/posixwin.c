/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:26
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: posixwin.scm -optimize-level 2 -include-path . -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[398];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,56,57,32,102,108,97,103,115,57,48,32,46,32,109,111,100,101,57,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,49,52,32,115,105,122,101,49,49,53,32,46,32,98,117,102,102,101,114,49,49,54,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,49,51,52,32,98,117,102,102,101,114,49,51,53,32,46,32,115,105,122,101,49,51,54,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,20),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,56,56,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,115,116,97,116,32,102,50,49,48,32,46,32,116,109,112,50,48,57,50,49,49,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,50,55,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,50,51,50,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,51,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,52,50,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,50,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,50,53,55,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,102,95,51,48,52,57,32,102,110,97,109,101,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,115,116,97,116,45,116,121,112,101,32,110,97,109,101,50,55,49,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,50,56,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,48,48,32,112,111,115,51,48,49,32,46,32,119,104,101,110,99,101,51,48,50,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,51,49,32,110,97,109,101,51,55,49,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,53,48,32,110,97,109,101,51,54,53,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,50,48,32,110,97,109,101,51,54,49,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,51,50,49,48,32,120,51,53,57,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,102,95,51,49,57,57,32,110,97,109,101,51,53,49,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,56,50,32,110,97,109,101,51,55,55,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,51,56,32,46,32,116,109,112,51,51,55,51,51,57,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,49,55,32,115,112,101,99,52,50,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,56,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,48,32,37,115,112,101,99,52,49,53,52,55,54,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,49,57,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,48,55,52,48,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,57,49,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,53,48,54,53,48,55,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,53,53,50,53,53,51,53,53,52,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,51,54,52,57,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,97,51,54,52,51,32,101,120,118,97,114,53,54,54,53,56,50,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,51,54,54,55,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,51,54,55,57,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,97,51,54,55,51,32,46,32,97,114,103,115,53,55,53,54,48,48,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,51,54,54,49,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,97,51,54,51,55,32,107,53,55,52,53,56,48,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,54,51,49,32,114,54,51,50,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,54,48,52,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,54,52,52,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,54,52,54,32,105,110,112,54,52,55,32,114,54,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,53,52,32,46,32,109,54,53,53,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,54,56,32,46,32,109,54,54,57,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,49,55,55,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,97,52,49,56,51,32,46,32,114,101,115,117,108,116,115,55,48,57,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,55,48,50,32,112,114,111,99,55,48,51,32,46,32,109,111,100,101,55,48,52,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,50,48,49,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,20),40,97,52,50,48,55,32,46,32,114,101,115,117,108,116,115,55,49,57,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,55,49,50,32,112,114,111,99,55,49,51,32,46,32,109,111,100,101,55,49,52,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,97,52,50,50,54,32,46,32,114,101,115,117,108,116,115,55,50,57,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,55,50,50,32,116,104,117,110,107,55,50,51,32,46,32,109,111,100,101,55,50,52,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,52,50,52,54,32,46,32,114,101,115,117,108,116,115,55,52,49,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,55,51,52,32,116,104,117,110,107,55,51,53,32,46,32,109,111,100,101,55,51,54,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,116,109,112,55,53,55,55,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,56,49,51,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,56,49,54,32,112,114,111,99,56,49,55,41,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,56,50,51,32,115,116,97,116,101,56,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,57,48,57,32,109,57,49,48,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,57,50,51,32,97,99,99,57,50,52,32,108,111,99,57,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,51,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,53,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,57,53,51,32,109,57,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,57,55,51,32,105,110,112,57,55,52,32,114,57,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,57,56,49,32,46,32,109,57,56,50,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,57,56,53,32,46,32,109,57,56,54,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,57,57,51,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,48,48,51,32,46,32,110,101,119,49,48,48,52,41,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,48,49,55,32,118,97,108,49,48,49,56,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,48,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,48,53,51,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,48,52,53,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,49,48,54,49,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,49,48,54,54,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,49,48,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,49,48,57,32,46,32,116,109,112,49,49,48,56,49,49,49,48,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,49,51,55,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,49,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,49,54,57,32,109,111,100,101,49,49,55,48,32,46,32,115,105,122,101,49,49,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,7),40,97,53,48,49,56,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,50,52,50,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,55),40,97,53,48,50,52,32,100,105,114,49,50,48,56,49,50,48,57,49,50,49,54,32,102,105,108,49,50,49,48,49,50,49,49,49,50,49,55,32,101,120,116,49,50,49,50,49,50,49,51,49,50,49,56,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,50,48,51,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,49,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,57,53,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,49,50,56,55,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,108,115,116,49,51,49,49,32,111,108,115,116,49,51,49,50,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,37),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,49,50,56,51,32,101,120,97,99,116,102,49,50,56,52,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,38),40,115,101,116,97,114,103,32,97,49,51,50,53,49,51,50,57,32,97,49,51,50,52,49,51,51,48,32,97,49,51,50,51,49,51,51,49,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,38),40,115,101,116,101,110,118,32,97,49,51,51,55,49,51,52,49,32,97,49,51,51,54,49,51,52,50,32,97,49,51,51,53,49,51,52,51,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,53,50,32,108,49,51,54,48,32,105,49,51,54,49,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,61),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,49,51,52,55,32,108,115,116,49,51,52,56,32,97,114,103,118,101,99,45,115,101,116,116,101,114,49,51,52,57,32,105,100,120,49,51,53,48,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,67),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,49,51,55,50,32,102,105,108,101,110,97,109,101,49,51,55,51,32,97,114,103,108,115,116,49,51,55,52,32,101,110,118,108,115,116,49,51,55,53,32,101,120,97,99,116,102,49,51,55,54,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,53),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,49,51,56,55,32,109,115,103,49,51,56,56,32,102,105,108,101,110,97,109,101,49,51,56,57,32,114,101,115,49,51,57,48,41,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,52,49,52,32,97,114,103,108,115,116,49,52,50,53,32,101,110,118,108,115,116,49,52,50,54,32,101,120,97,99,116,102,49,52,50,55,41,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,49,56,32,37,97,114,103,108,115,116,49,52,49,49,49,52,51,51,32,37,101,110,118,108,115,116,49,52,49,50,49,52,51,52,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,49,55,32,37,97,114,103,108,115,116,49,52,49,49,49,52,51,56,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,52,49,54,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,52,48,51,32,46,32,116,109,112,49,52,48,50,49,52,48,52,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,52,55,52,32,97,114,103,108,115,116,49,52,56,53,32,101,110,118,108,115,116,49,52,56,54,32,101,120,97,99,116,102,49,52,56,55,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,55,56,32,37,97,114,103,108,115,116,49,52,55,49,49,52,57,51,32,37,101,110,118,108,115,116,49,52,55,50,49,52,57,52,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,55,55,32,37,97,114,103,108,115,116,49,52,55,49,49,52,57,56,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,52,55,54,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,51),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,49,52,54,50,32,102,105,108,101,110,97,109,101,49,52,54,51,32,46,32,116,109,112,49,52,54,49,49,52,54,52,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,53,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,53,51,55,32,46,32,97,114,103,115,49,53,51,56,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,24),40,99,108,111,115,101,45,104,97,110,100,108,101,32,97,49,53,52,54,49,53,52,57,41};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,97),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,54,48,48,32,99,109,100,49,54,48,49,32,97,114,103,115,49,54,48,50,32,101,110,118,49,54,48,51,32,115,116,100,111,117,116,102,49,54,48,52,32,115,116,100,105,110,102,49,54,48,53,32,115,116,100,101,114,114,102,49,54,48,54,32,46,32,116,109,112,49,53,57,57,49,54,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,21),40,97,53,55,53,50,32,103,49,54,57,48,49,54,57,49,49,54,57,50,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,54,56,51,41,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,7),40,97,53,55,55,48,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,38),40,97,53,55,55,54,32,105,110,49,55,48,51,32,111,117,116,49,55,48,52,32,112,105,100,49,55,48,53,32,101,114,114,49,55,48,54,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,63),40,37,112,114,111,99,101,115,115,32,108,111,99,49,54,55,53,32,101,114,114,63,49,54,55,54,32,99,109,100,49,54,55,55,32,97,114,103,115,49,54,55,56,32,101,110,118,49,54,55,57,32,101,120,97,99,116,102,49,54,56,48,41,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,50,57,32,97,114,103,115,49,55,52,48,32,101,110,118,49,55,52,49,32,101,120,97,99,116,102,49,55,52,50,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,51,51,32,37,97,114,103,115,49,55,50,54,49,55,52,54,32,37,101,110,118,49,55,50,55,49,55,52,55,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,51,50,32,37,97,114,103,115,49,55,50,54,49,55,53,49,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,51,49,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,49,55,49,56,32,46,32,116,109,112,49,55,49,55,49,55,49,57,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,56,52,32,97,114,103,115,49,55,57,53,32,101,110,118,49,55,57,54,32,101,120,97,99,116,102,49,55,57,55,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,56,56,32,37,97,114,103,115,49,55,56,49,49,56,48,49,32,37,101,110,118,49,55,56,50,49,56,48,50,41,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,56,55,32,37,97,114,103,115,49,55,56,49,49,56,48,54,41,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,56,54,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,49,55,55,51,32,46,32,116,109,112,49,55,55,50,49,55,55,52,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,50,54,32,110,111,104,97,110,103,49,56,50,55,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,53,57,57,54,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,97,54,48,48,50,32,101,112,105,100,49,56,52,57,32,101,110,111,114,109,49,56,53,48,32,101,99,111,100,101,49,56,53,49,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,51,48,32,46,32,97,114,103,115,49,56,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,13),40,115,108,101,101,112,32,116,49,56,53,54,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,14),40,102,95,54,50,49,55,32,120,49,57,50,51,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,7),40,97,54,49,54,51,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,7),40,97,54,49,54,56,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,7),40,97,54,49,56,50,41,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,57,51,49,32,114,49,57,51,50,41,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,51,51,32,46,32,95,49,57,49,57,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,50,53,32,46,32,95,49,57,49,55,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,56,57,49,32,97,99,116,105,111,110,49,57,48,50,32,105,100,49,57,48,51,32,108,105,109,105,116,49,57,48,52,41,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,56,57,53,32,37,97,99,116,105,111,110,49,56,56,56,49,57,55,50,32,37,105,100,49,56,56,57,49,57,55,51,41,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,56,57,52,32,37,97,99,116,105,111,110,49,56,56,56,49,57,55,55,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,19),40,97,54,50,53,51,32,120,49,57,56,50,32,121,49,57,56,51,41,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,56,57,51,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,56,55,57,32,112,114,101,100,49,56,56,48,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,56,56,49,41,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,13),40,102,105,102,111,63,32,95,50,51,56,57,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,50,51,57,51,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,54,56,32,110,97,109,101,50,51,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,55,56,32,110,97,109,101,50,51,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,56,56,32,110,97,109,101,50,51,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,57,56,32,110,97,109,101,50,51,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,48,56,32,110,97,109,101,50,51,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,49,56,32,110,97,109,101,50,51,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,50,56,32,110,97,109,101,50,51,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,51,56,32,110,97,109,101,50,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,52,56,32,110,97,109,101,50,51,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,53,56,32,110,97,109,101,50,50,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,54,56,32,110,97,109,101,50,50,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,55,56,32,110,97,109,101,50,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,56,56,32,110,97,109,101,50,50,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,57,56,32,110,97,109,101,50,50,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,48,56,32,110,97,109,101,50,50,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,49,56,32,110,97,109,101,50,50,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,50,56,32,110,97,109,101,50,50,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,51,56,32,110,97,109,101,50,50,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,52,56,32,110,97,109,101,50,50,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,53,56,32,110,97,109,101,50,50,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,54,56,32,110,97,109,101,50,49,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,55,56,32,110,97,109,101,50,49,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,56,56,32,110,97,109,101,50,49,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,57,56,32,110,97,109,101,50,49,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,48,56,32,110,97,109,101,50,49,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,49,56,32,110,97,109,101,50,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,50,56,32,110,97,109,101,50,49,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,51,56,32,110,97,109,101,50,49,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,52,56,32,110,97,109,101,50,49,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,53,56,32,110,97,109,101,50,49,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,54,56,32,110,97,109,101,50,49,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,55,56,32,110,97,109,101,50,48,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,56,56,32,110,97,109,101,50,48,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,57,56,32,110,97,109,101,50,48,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,48,56,32,110,97,109,101,50,48,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,49,56,32,110,97,109,101,50,48,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,50,56,32,110,97,109,101,50,48,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,51,56,32,110,97,109,101,50,48,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,52,56,32,110,97,109,101,50,48,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,53,56,32,110,97,109,101,50,48,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,54,56,32,110,97,109,101,50,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,55,56,32,110,97,109,101,50,48,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,56,56,32,110,97,109,101,49,57,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k5591 */
static C_word C_fcall stub1561(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1561(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static C_word C_fcall stub1547(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1547(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static C_word C_fcall stub1515(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1515(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k5220 */
static C_word C_fcall stub1338(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1338(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k5203 */
static C_word C_fcall stub1326(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1326(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k4914 */
static C_word C_fcall stub1152(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1152(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1144(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1144(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub1095(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1095(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1087(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1087(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k4761 */
static C_word C_fcall stub1072(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1072(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4668 */
static C_word C_fcall stub1033(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1033(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2681 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_ccall f_6868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6828)
static void C_ccall f_6828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6728)
static void C_ccall f_6728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6548)
static void C_ccall f_6548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6432)
static void C_ccall f_6432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6254)
static void C_ccall f_6254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6243)
static void C_fcall f_6243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6238)
static void C_fcall f_6238(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6099)
static void C_fcall f_6099(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6106)
static void C_fcall f_6106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_fcall f_6118(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5901)
static void C_fcall f_5901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_fcall f_5896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5891)
static void C_fcall f_5891(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5886)
static void C_fcall f_5886(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5821)
static void C_fcall f_5821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_fcall f_5816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5811)
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5806)
static void C_fcall f_5806(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5742)
static void C_fcall f_5742(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_fcall f_5744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5435)
static void C_fcall f_5435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_fcall f_5430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5425)
static void C_fcall f_5425(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5413)
static void C_fcall f_5413(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5348)
static void C_fcall f_5348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_fcall f_5343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5338)
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5326)
static void C_fcall f_5326(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_fcall f_5309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_fcall f_5276(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_fcall f_5226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5238)
static void C_fcall f_5238(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5113)
static void C_fcall f_5113(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5156)
static void C_fcall f_5156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_fcall f_5118(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_fcall f_5127(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5004)
static void C_fcall f_5004(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_fcall f_5044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_ccall f_4807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_fcall f_4677(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4611)
static void C_fcall f_4611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_fcall f_4523(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4441)
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_fcall f_4060(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_fcall f_4054(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static C_word C_fcall f_4042(C_word t0);
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_fcall f_3831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_fcall f_3903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_fcall f_3701(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_fcall f_3780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_fcall f_3629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static C_word C_fcall f_3618(C_word t0);
C_noret_decl(f_3613)
static void C_fcall f_3613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3483)
static void C_fcall f_3483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_fcall f_3478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3377)
static void C_fcall f_3377(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_fcall f_3411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_fcall f_3433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_fcall f_3047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_fcall f_2914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6248(t0,t1);}

C_noret_decl(trf_6243)
static void C_fcall trf_6243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6243(t0,t1,t2);}

C_noret_decl(trf_6238)
static void C_fcall trf_6238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6238(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6238(t0,t1,t2,t3);}

C_noret_decl(trf_6099)
static void C_fcall trf_6099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6099(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6099(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6106)
static void C_fcall trf_6106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6106(t0,t1);}

C_noret_decl(trf_6118)
static void C_fcall trf_6118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6118(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6118(t0,t1,t2,t3);}

C_noret_decl(trf_5901)
static void C_fcall trf_5901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5901(t0,t1);}

C_noret_decl(trf_5896)
static void C_fcall trf_5896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5896(t0,t1,t2);}

C_noret_decl(trf_5891)
static void C_fcall trf_5891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5891(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5891(t0,t1,t2,t3);}

C_noret_decl(trf_5886)
static void C_fcall trf_5886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5886(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5886(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5821)
static void C_fcall trf_5821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5821(t0,t1);}

C_noret_decl(trf_5816)
static void C_fcall trf_5816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5816(t0,t1,t2);}

C_noret_decl(trf_5811)
static void C_fcall trf_5811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5811(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5811(t0,t1,t2,t3);}

C_noret_decl(trf_5806)
static void C_fcall trf_5806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5806(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5806(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5742)
static void C_fcall trf_5742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5742(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5742(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5744)
static void C_fcall trf_5744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5744(t0,t1,t2);}

C_noret_decl(trf_5435)
static void C_fcall trf_5435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5435(t0,t1);}

C_noret_decl(trf_5430)
static void C_fcall trf_5430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5430(t0,t1,t2);}

C_noret_decl(trf_5425)
static void C_fcall trf_5425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5425(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5425(t0,t1,t2,t3);}

C_noret_decl(trf_5413)
static void C_fcall trf_5413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5413(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5413(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5348)
static void C_fcall trf_5348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5348(t0,t1);}

C_noret_decl(trf_5343)
static void C_fcall trf_5343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5343(t0,t1,t2);}

C_noret_decl(trf_5338)
static void C_fcall trf_5338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5338(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5338(t0,t1,t2,t3);}

C_noret_decl(trf_5326)
static void C_fcall trf_5326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5326(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5326(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5309)
static void C_fcall trf_5309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5309(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5309(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5276)
static void C_fcall trf_5276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5276(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5276(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5226)
static void C_fcall trf_5226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5226(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5226(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5238)
static void C_fcall trf_5238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5238(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5238(t0,t1,t2,t3);}

C_noret_decl(trf_5113)
static void C_fcall trf_5113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5113(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5113(t0,t1,t2,t3);}

C_noret_decl(trf_5156)
static void C_fcall trf_5156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5156(t0,t1,t2,t3);}

C_noret_decl(trf_5118)
static void C_fcall trf_5118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5118(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5118(t0,t1,t2);}

C_noret_decl(trf_5127)
static void C_fcall trf_5127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5127(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5127(t0,t1,t2);}

C_noret_decl(trf_5004)
static void C_fcall trf_5004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5004(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5004(t0,t1,t2);}

C_noret_decl(trf_5044)
static void C_fcall trf_5044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5044(t0,t1,t2);}

C_noret_decl(trf_4677)
static void C_fcall trf_4677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4677(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4677(t0,t1,t2);}

C_noret_decl(trf_4689)
static void C_fcall trf_4689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4689(t0,t1,t2);}

C_noret_decl(trf_4611)
static void C_fcall trf_4611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4611(t0,t1);}

C_noret_decl(trf_4523)
static void C_fcall trf_4523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4523(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4523(t0,t1,t2,t3);}

C_noret_decl(trf_4486)
static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4486(t0,t1,t2);}

C_noret_decl(trf_4441)
static void C_fcall trf_4441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4441(t0,t1,t2,t3);}

C_noret_decl(trf_4060)
static void C_fcall trf_4060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4060(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4060(t0,t1,t2,t3);}

C_noret_decl(trf_4054)
static void C_fcall trf_4054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4054(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4054(t0,t1);}

C_noret_decl(trf_3831)
static void C_fcall trf_3831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3831(t0,t1);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3861(t0,t1);}

C_noret_decl(trf_3903)
static void C_fcall trf_3903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3903(t0,t1);}

C_noret_decl(trf_3701)
static void C_fcall trf_3701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3701(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3701(t0,t1,t2,t3);}

C_noret_decl(trf_3780)
static void C_fcall trf_3780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3780(t0,t1);}

C_noret_decl(trf_3629)
static void C_fcall trf_3629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3629(t0,t1);}

C_noret_decl(trf_3613)
static void C_fcall trf_3613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3613(t0,t1);}

C_noret_decl(trf_3483)
static void C_fcall trf_3483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3483(t0,t1);}

C_noret_decl(trf_3478)
static void C_fcall trf_3478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3478(t0,t1,t2);}

C_noret_decl(trf_3377)
static void C_fcall trf_3377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3377(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3377(t0,t1,t2,t3);}

C_noret_decl(trf_3411)
static void C_fcall trf_3411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3411(t0,t1);}

C_noret_decl(trf_3433)
static void C_fcall trf_3433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3433(t0,t1);}

C_noret_decl(trf_3047)
static void C_fcall trf_3047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3047(t0,t1);}

C_noret_decl(trf_2914)
static void C_fcall trf_2914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2914(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3110)){
C_save(t1);
C_rereclaim2(3110*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,398);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"\003syserror");
lf[63]=C_h_intern(&lf[63],9,"file-size");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],16,"file-access-time");
lf[66]=C_h_intern(&lf[66],16,"file-change-time");
lf[67]=C_h_intern(&lf[67],10,"file-owner");
lf[68]=C_h_intern(&lf[68],16,"file-permissions");
lf[69]=C_h_intern(&lf[69],13,"regular-file\077");
lf[70]=C_h_intern(&lf[70],13,"\003sysfile-info");
lf[71]=C_h_intern(&lf[71],14,"symbolic-link\077");
lf[72]=C_h_intern(&lf[72],13,"stat-regular\077");
lf[73]=C_h_intern(&lf[73],15,"stat-directory\077");
lf[74]=C_h_intern(&lf[74],17,"stat-char-device\077");
lf[75]=C_h_intern(&lf[75],18,"stat-block-device\077");
lf[76]=C_h_intern(&lf[76],10,"stat-fifo\077");
lf[77]=C_h_intern(&lf[77],13,"stat-symlink\077");
lf[78]=C_h_intern(&lf[78],12,"stat-socket\077");
lf[79]=C_h_intern(&lf[79],13,"file-position");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[81]=C_h_intern(&lf[81],6,"stream");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[83]=C_h_intern(&lf[83],5,"port\077");
lf[84]=C_h_intern(&lf[84],18,"set-file-position!");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[87]=C_h_intern(&lf[87],13,"\000bounds-error");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[89]=C_h_intern(&lf[89],16,"create-directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[91]=C_h_intern(&lf[91],12,"file-exists\077");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[93]=C_h_intern(&lf[93],12,"\003sysfor-each");
lf[94]=C_h_intern(&lf[94],12,"string-split");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[96]=C_h_intern(&lf[96],14,"canonical-path");
lf[97]=C_h_intern(&lf[97],16,"change-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[99]=C_h_intern(&lf[99],16,"delete-directory");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[101]=C_h_intern(&lf[101],6,"string");
lf[102]=C_h_intern(&lf[102],9,"directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[104]=C_h_intern(&lf[104],16,"\003sysmake-pointer");
lf[105]=C_h_intern(&lf[105],17,"current-directory");
lf[106]=C_h_intern(&lf[106],10,"directory\077");
lf[107]=C_h_intern(&lf[107],27,"\003sysplatform-fixup-pathname");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[109]=C_h_intern(&lf[109],5,"null\077");
lf[110]=C_h_intern(&lf[110],6,"char=\077");
lf[111]=C_h_intern(&lf[111],8,"string=\077");
lf[112]=C_h_intern(&lf[112],16,"char-alphabetic\077");
lf[113]=C_h_intern(&lf[113],10,"string-ref");
lf[114]=C_h_intern(&lf[114],18,"string-intersperse");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[116]=C_h_intern(&lf[116],17,"current-user-name");
lf[117]=C_h_intern(&lf[117],9,"condition");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[119]=C_h_intern(&lf[119],22,"with-exception-handler");
lf[120]=C_h_intern(&lf[120],30,"call-with-current-continuation");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[122]=C_h_intern(&lf[122],7,"reverse");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[132]=C_h_intern(&lf[132],5,"\000text");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[135]=C_h_intern(&lf[135],13,"\003sysmake-port");
lf[136]=C_h_intern(&lf[136],21,"\003sysstream-port-class");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[138]=C_h_intern(&lf[138],15,"open-input-pipe");
lf[139]=C_h_intern(&lf[139],7,"\000binary");
lf[140]=C_h_intern(&lf[140],16,"open-output-pipe");
lf[141]=C_h_intern(&lf[141],16,"close-input-pipe");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[143]=C_h_intern(&lf[143],14,"\003syscheck-port");
lf[144]=C_h_intern(&lf[144],17,"close-output-pipe");
lf[145]=C_h_intern(&lf[145],20,"call-with-input-pipe");
lf[146]=C_h_intern(&lf[146],21,"call-with-output-pipe");
lf[147]=C_h_intern(&lf[147],20,"with-input-from-pipe");
lf[148]=C_h_intern(&lf[148],18,"\003sysstandard-input");
lf[149]=C_h_intern(&lf[149],19,"with-output-to-pipe");
lf[150]=C_h_intern(&lf[150],19,"\003sysstandard-output");
lf[151]=C_h_intern(&lf[151],11,"create-pipe");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[153]=C_h_intern(&lf[153],11,"signal/term");
lf[154]=C_h_intern(&lf[154],10,"signal/int");
lf[155]=C_h_intern(&lf[155],10,"signal/fpe");
lf[156]=C_h_intern(&lf[156],10,"signal/ill");
lf[157]=C_h_intern(&lf[157],11,"signal/segv");
lf[158]=C_h_intern(&lf[158],11,"signal/abrt");
lf[159]=C_h_intern(&lf[159],12,"signal/break");
lf[160]=C_h_intern(&lf[160],11,"signal/alrm");
lf[161]=C_h_intern(&lf[161],11,"signal/chld");
lf[162]=C_h_intern(&lf[162],11,"signal/cont");
lf[163]=C_h_intern(&lf[163],10,"signal/hup");
lf[164]=C_h_intern(&lf[164],9,"signal/io");
lf[165]=C_h_intern(&lf[165],11,"signal/kill");
lf[166]=C_h_intern(&lf[166],11,"signal/pipe");
lf[167]=C_h_intern(&lf[167],11,"signal/prof");
lf[168]=C_h_intern(&lf[168],11,"signal/quit");
lf[169]=C_h_intern(&lf[169],11,"signal/stop");
lf[170]=C_h_intern(&lf[170],11,"signal/trap");
lf[171]=C_h_intern(&lf[171],11,"signal/tstp");
lf[172]=C_h_intern(&lf[172],10,"signal/urg");
lf[173]=C_h_intern(&lf[173],11,"signal/usr1");
lf[174]=C_h_intern(&lf[174],11,"signal/usr2");
lf[175]=C_h_intern(&lf[175],13,"signal/vtalrm");
lf[176]=C_h_intern(&lf[176],12,"signal/winch");
lf[177]=C_h_intern(&lf[177],11,"signal/xcpu");
lf[178]=C_h_intern(&lf[178],11,"signal/xfsz");
lf[179]=C_h_intern(&lf[179],12,"signals-list");
lf[180]=C_h_intern(&lf[180],18,"\003sysinterrupt-hook");
lf[181]=C_h_intern(&lf[181],14,"signal-handler");
lf[182]=C_h_intern(&lf[182],19,"set-signal-handler!");
lf[183]=C_h_intern(&lf[183],10,"errno/perm");
lf[184]=C_h_intern(&lf[184],11,"errno/noent");
lf[185]=C_h_intern(&lf[185],10,"errno/srch");
lf[186]=C_h_intern(&lf[186],10,"errno/intr");
lf[187]=C_h_intern(&lf[187],8,"errno/io");
lf[188]=C_h_intern(&lf[188],12,"errno/noexec");
lf[189]=C_h_intern(&lf[189],10,"errno/badf");
lf[190]=C_h_intern(&lf[190],11,"errno/child");
lf[191]=C_h_intern(&lf[191],11,"errno/nomem");
lf[192]=C_h_intern(&lf[192],11,"errno/acces");
lf[193]=C_h_intern(&lf[193],11,"errno/fault");
lf[194]=C_h_intern(&lf[194],10,"errno/busy");
lf[195]=C_h_intern(&lf[195],11,"errno/exist");
lf[196]=C_h_intern(&lf[196],12,"errno/notdir");
lf[197]=C_h_intern(&lf[197],11,"errno/isdir");
lf[198]=C_h_intern(&lf[198],11,"errno/inval");
lf[199]=C_h_intern(&lf[199],11,"errno/mfile");
lf[200]=C_h_intern(&lf[200],11,"errno/nospc");
lf[201]=C_h_intern(&lf[201],11,"errno/spipe");
lf[202]=C_h_intern(&lf[202],10,"errno/pipe");
lf[203]=C_h_intern(&lf[203],11,"errno/again");
lf[204]=C_h_intern(&lf[204],10,"errno/rofs");
lf[205]=C_h_intern(&lf[205],10,"errno/nxio");
lf[206]=C_h_intern(&lf[206],10,"errno/2big");
lf[207]=C_h_intern(&lf[207],10,"errno/xdev");
lf[208]=C_h_intern(&lf[208],11,"errno/nodev");
lf[209]=C_h_intern(&lf[209],11,"errno/nfile");
lf[210]=C_h_intern(&lf[210],11,"errno/notty");
lf[211]=C_h_intern(&lf[211],10,"errno/fbig");
lf[212]=C_h_intern(&lf[212],11,"errno/mlink");
lf[213]=C_h_intern(&lf[213],9,"errno/dom");
lf[214]=C_h_intern(&lf[214],11,"errno/range");
lf[215]=C_h_intern(&lf[215],12,"errno/deadlk");
lf[216]=C_h_intern(&lf[216],17,"errno/nametoolong");
lf[217]=C_h_intern(&lf[217],11,"errno/nolck");
lf[218]=C_h_intern(&lf[218],11,"errno/nosys");
lf[219]=C_h_intern(&lf[219],14,"errno/notempty");
lf[220]=C_h_intern(&lf[220],11,"errno/ilseq");
lf[221]=C_h_intern(&lf[221],16,"change-file-mode");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[223]=C_h_intern(&lf[223],17,"file-read-access\077");
lf[224]=C_h_intern(&lf[224],18,"file-write-access\077");
lf[225]=C_h_intern(&lf[225],20,"file-execute-access\077");
lf[226]=C_h_intern(&lf[226],12,"fileno/stdin");
lf[227]=C_h_intern(&lf[227],13,"fileno/stdout");
lf[228]=C_h_intern(&lf[228],13,"fileno/stderr");
lf[229]=C_h_intern(&lf[229],7,"\000append");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[237]=C_h_intern(&lf[237],16,"open-input-file*");
lf[238]=C_h_intern(&lf[238],17,"open-output-file*");
lf[239]=C_h_intern(&lf[239],12,"port->fileno");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[242]=C_h_intern(&lf[242],25,"\003syspeek-unsigned-integer");
lf[243]=C_h_intern(&lf[243],16,"duplicate-fileno");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[245]=C_h_intern(&lf[245],6,"setenv");
lf[246]=C_h_intern(&lf[246],8,"unsetenv");
lf[247]=C_h_intern(&lf[247],9,"substring");
lf[248]=C_h_intern(&lf[248],19,"current-environment");
lf[249]=C_h_intern(&lf[249],19,"seconds->local-time");
lf[250]=C_h_intern(&lf[250],18,"\003sysdecode-seconds");
lf[251]=C_h_intern(&lf[251],17,"seconds->utc-time");
lf[252]=C_h_intern(&lf[252],15,"seconds->string");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[254]=C_h_intern(&lf[254],12,"time->string");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[258]=C_h_intern(&lf[258],19,"local-time->seconds");
lf[259]=C_h_intern(&lf[259],15,"\003syscons-flonum");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[262]=C_h_intern(&lf[262],27,"local-timezone-abbreviation");
lf[263]=C_h_intern(&lf[263],5,"_exit");
lf[264]=C_h_intern(&lf[264],14,"terminal-port\077");
lf[265]=C_h_intern(&lf[265],19,"set-buffering-mode!");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[267]=C_h_intern(&lf[267],5,"\000full");
lf[268]=C_h_intern(&lf[268],5,"\000line");
lf[269]=C_h_intern(&lf[269],5,"\000none");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[271]=C_h_intern(&lf[271],6,"regexp");
lf[272]=C_h_intern(&lf[272],21,"make-anchored-pattern");
lf[273]=C_h_intern(&lf[273],12,"string-match");
lf[274]=C_h_intern(&lf[274],12,"glob->regexp");
lf[275]=C_h_intern(&lf[275],13,"make-pathname");
lf[276]=C_h_intern(&lf[276],18,"decompose-pathname");
lf[277]=C_h_intern(&lf[277],4,"glob");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[280]=C_h_intern(&lf[280],13,"spawn/overlay");
lf[281]=C_h_intern(&lf[281],10,"spawn/wait");
lf[282]=C_h_intern(&lf[282],12,"spawn/nowait");
lf[283]=C_h_intern(&lf[283],13,"spawn/nowaito");
lf[284]=C_h_intern(&lf[284],12,"spawn/detach");
lf[285]=C_h_intern(&lf[285],16,"char-whitespace\077");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[289]=C_h_intern(&lf[289],24,"pathname-strip-directory");
lf[292]=C_h_intern(&lf[292],15,"process-execute");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[294]=C_h_intern(&lf[294],13,"process-spawn");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[296]=C_h_intern(&lf[296],18,"current-process-id");
lf[297]=C_h_intern(&lf[297],17,"\003sysshell-command");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[299]=C_h_intern(&lf[299],6,"getenv");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[301]=C_h_intern(&lf[301],27,"\003sysshell-command-arguments");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[303]=C_h_intern(&lf[303],11,"process-run");
lf[305]=C_h_intern(&lf[305],11,"\003sysprocess");
lf[306]=C_h_intern(&lf[306],5,"g1636");
lf[307]=C_h_intern(&lf[307],5,"g1642");
lf[308]=C_h_intern(&lf[308],5,"g1648");
lf[309]=C_h_intern(&lf[309],5,"g1654");
lf[310]=C_h_intern(&lf[310],14,"\000process-error");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[312]=C_h_intern(&lf[312],17,"\003sysmake-locative");
lf[313]=C_h_intern(&lf[313],8,"location");
lf[314]=C_h_intern(&lf[314],7,"process");
lf[315]=C_h_intern(&lf[315],8,"process*");
lf[316]=C_h_intern(&lf[316],16,"\003sysprocess-wait");
lf[317]=C_h_intern(&lf[317],12,"process-wait");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[319]=C_h_intern(&lf[319],5,"sleep");
lf[320]=C_h_intern(&lf[320],13,"get-host-name");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[322]=C_h_intern(&lf[322],18,"system-information");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[326]=C_h_intern(&lf[326],10,"find-files");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[330]=C_h_intern(&lf[330],16,"\003sysdynamic-wind");
lf[331]=C_h_intern(&lf[331],13,"pathname-file");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[333]=C_h_intern(&lf[333],16,"errno/wouldblock");
lf[334]=C_h_intern(&lf[334],5,"fifo\077");
lf[335]=C_h_intern(&lf[335],19,"memory-mapped-file\077");
lf[336]=C_h_intern(&lf[336],13,"map/anonymous");
lf[337]=C_h_intern(&lf[337],8,"map/file");
lf[338]=C_h_intern(&lf[338],9,"map/fixed");
lf[339]=C_h_intern(&lf[339],11,"map/private");
lf[340]=C_h_intern(&lf[340],10,"map/shared");
lf[341]=C_h_intern(&lf[341],10,"open/fsync");
lf[342]=C_h_intern(&lf[342],11,"open/noctty");
lf[343]=C_h_intern(&lf[343],13,"open/nonblock");
lf[344]=C_h_intern(&lf[344],9,"open/sync");
lf[345]=C_h_intern(&lf[345],10,"perm/isgid");
lf[346]=C_h_intern(&lf[346],10,"perm/isuid");
lf[347]=C_h_intern(&lf[347],10,"perm/isvtx");
lf[348]=C_h_intern(&lf[348],9,"prot/exec");
lf[349]=C_h_intern(&lf[349],9,"prot/none");
lf[350]=C_h_intern(&lf[350],9,"prot/read");
lf[351]=C_h_intern(&lf[351],10,"prot/write");
lf[352]=C_h_intern(&lf[352],12,"string->time");
lf[353]=C_h_intern(&lf[353],17,"utc-time->seconds");
lf[354]=C_h_intern(&lf[354],16,"user-information");
lf[355]=C_h_intern(&lf[355],22,"unmap-file-from-memory");
lf[356]=C_h_intern(&lf[356],13,"terminal-size");
lf[357]=C_h_intern(&lf[357],13,"terminal-name");
lf[358]=C_h_intern(&lf[358],14,"signal-unmask!");
lf[359]=C_h_intern(&lf[359],14,"signal-masked\077");
lf[360]=C_h_intern(&lf[360],12,"signal-mask!");
lf[361]=C_h_intern(&lf[361],11,"signal-mask");
lf[362]=C_h_intern(&lf[362],12,"set-user-id!");
lf[363]=C_h_intern(&lf[363],16,"set-signal-mask!");
lf[364]=C_h_intern(&lf[364],19,"set-root-directory!");
lf[365]=C_h_intern(&lf[365],21,"set-process-group-id!");
lf[366]=C_h_intern(&lf[366],11,"set-groups!");
lf[367]=C_h_intern(&lf[367],13,"set-group-id!");
lf[368]=C_h_intern(&lf[368],10,"set-alarm!");
lf[369]=C_h_intern(&lf[369],18,"read-symbolic-link");
lf[370]=C_h_intern(&lf[370],14,"process-signal");
lf[371]=C_h_intern(&lf[371],16,"process-group-id");
lf[372]=C_h_intern(&lf[372],12,"process-fork");
lf[373]=C_h_intern(&lf[373],17,"parent-process-id");
lf[374]=C_h_intern(&lf[374],26,"memory-mapped-file-pointer");
lf[375]=C_h_intern(&lf[375],17,"initialize-groups");
lf[376]=C_h_intern(&lf[376],17,"group-information");
lf[377]=C_h_intern(&lf[377],10,"get-groups");
lf[378]=C_h_intern(&lf[378],11,"file-unlock");
lf[379]=C_h_intern(&lf[379],13,"file-truncate");
lf[380]=C_h_intern(&lf[380],14,"file-test-lock");
lf[381]=C_h_intern(&lf[381],11,"file-select");
lf[382]=C_h_intern(&lf[382],18,"file-lock/blocking");
lf[383]=C_h_intern(&lf[383],9,"file-lock");
lf[384]=C_h_intern(&lf[384],9,"file-link");
lf[385]=C_h_intern(&lf[385],18,"map-file-to-memory");
lf[386]=C_h_intern(&lf[386],15,"current-user-id");
lf[387]=C_h_intern(&lf[387],16,"current-group-id");
lf[388]=C_h_intern(&lf[388],27,"current-effective-user-name");
lf[389]=C_h_intern(&lf[389],25,"current-effective-user-id");
lf[390]=C_h_intern(&lf[390],26,"current-effective-group-id");
lf[391]=C_h_intern(&lf[391],20,"create-symbolic-link");
lf[392]=C_h_intern(&lf[392],14,"create-session");
lf[393]=C_h_intern(&lf[393],11,"create-fifo");
lf[394]=C_h_intern(&lf[394],17,"change-file-owner");
lf[395]=C_h_intern(&lf[395],11,"make-vector");
lf[396]=C_h_intern(&lf[396],17,"register-feature!");
lf[397]=C_h_intern(&lf[397],5,"posix");
C_register_lf2(lf,398,create_ptable());
t2=C_mutate(&lf[0] /* c2007 ...) */,lf[1]);
t3=C_mutate(&lf[2] /* c222 ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2657,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k2655 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2658 in k2655 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2661 in k2658 in k2655 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 929  register-feature!");
t3=*((C_word*)lf[396]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[397]);}

/* k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5] /* posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* posix-error ...) */,lf[5]);
t5=C_mutate((C_word*)lf[11]+1 /* pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1 /* open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1 /* open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1 /* open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1 /* open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1 /* open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1 /* open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1 /* open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1 /* open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1 /* open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1 /* open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1 /* open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1 /* open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1 /* perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1 /* perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1 /* perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1 /* perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1 /* perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1 /* perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1 /* perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1 /* perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1 /* perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1 /* perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1 /* perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1 /* perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1 /* file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2730,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[41]+1 /* file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2771,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1 /* file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2789,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[48]+1 /* file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1 /* file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2876,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[55]+1 /* seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1 /* seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1 /* seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58] /* stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1 /* file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1 /* file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1 /* file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[65]+1 /* file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1 /* file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1 /* file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1 /* file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3013,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1 /* regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1 /* symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3047,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[72]+1 /* stat-regular? ...) */,*((C_word*)lf[69]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1114 stat-type");
f_3047(t54,lf[73]);}

/* k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1115 stat-type");
f_3047(t3,lf[74]);}

/* k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* stat-char-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1116 stat-type");
f_3047(t3,lf[75]);}

/* k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1117 stat-type");
f_3047(t3,lf[76]);}

/* k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1118 stat-type");
f_3047(t3,lf[77]);}

/* k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1119 stat-type");
f_3047(t3,lf[78]);}

/* k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[121],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3078,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[79]+1 /* file-position ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[84]+1 /* set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3120,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[89]+1 /* create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[97]+1 /* change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3321,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[99]+1 /* delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3348,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[4]+1);
t9=*((C_word*)lf[43]+1);
t10=*((C_word*)lf[101]+1);
t11=C_mutate((C_word*)lf[102]+1 /* directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=t9,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[106]+1 /* directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[43]+1);
t14=C_mutate((C_word*)lf[105]+1 /* current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=t13,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[109]+1);
t16=*((C_word*)lf[110]+1);
t17=*((C_word*)lf[111]+1);
t18=*((C_word*)lf[112]+1);
t19=*((C_word*)lf[113]+1);
t20=*((C_word*)lf[4]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[116]+1);
t24=*((C_word*)lf[105]+1);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3629,a[2]=t24,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t26=C_mutate((C_word*)lf[96]+1 /* canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3685,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4042,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[138]+1 /* open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4078,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[140]+1 /* open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4114,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t32=C_mutate((C_word*)lf[141]+1 /* close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4150,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[144]+1 /* close-output-pipe ...) */,*((C_word*)lf[141]+1));
t34=*((C_word*)lf[138]+1);
t35=*((C_word*)lf[140]+1);
t36=*((C_word*)lf[141]+1);
t37=*((C_word*)lf[144]+1);
t38=C_mutate((C_word*)lf[145]+1 /* call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4169,a[2]=t34,a[3]=t36,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[146]+1 /* call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4193,a[2]=t35,a[3]=t37,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[147]+1 /* with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4217,a[2]=t34,a[3]=t36,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[149]+1 /* with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t35,a[3]=t37,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t42=C_mutate((C_word*)lf[151]+1 /* create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4257,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[153]+1 /* signal/term ...) */,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[154]+1 /* signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[155]+1 /* signal/fpe ...) */,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[156]+1 /* signal/ill ...) */,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[157]+1 /* signal/segv ...) */,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[158]+1 /* signal/abrt ...) */,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[159]+1 /* signal/break ...) */,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[160] /* signal/alrm */,0,C_fix(0));
t51=C_set_block_item(lf[161] /* signal/chld */,0,C_fix(0));
t52=C_set_block_item(lf[162] /* signal/cont */,0,C_fix(0));
t53=C_set_block_item(lf[163] /* signal/hup */,0,C_fix(0));
t54=C_set_block_item(lf[164] /* signal/io */,0,C_fix(0));
t55=C_set_block_item(lf[165] /* signal/kill */,0,C_fix(0));
t56=C_set_block_item(lf[166] /* signal/pipe */,0,C_fix(0));
t57=C_set_block_item(lf[167] /* signal/prof */,0,C_fix(0));
t58=C_set_block_item(lf[168] /* signal/quit */,0,C_fix(0));
t59=C_set_block_item(lf[169] /* signal/stop */,0,C_fix(0));
t60=C_set_block_item(lf[170] /* signal/trap */,0,C_fix(0));
t61=C_set_block_item(lf[171] /* signal/tstp */,0,C_fix(0));
t62=C_set_block_item(lf[172] /* signal/urg */,0,C_fix(0));
t63=C_set_block_item(lf[173] /* signal/usr1 */,0,C_fix(0));
t64=C_set_block_item(lf[174] /* signal/usr2 */,0,C_fix(0));
t65=C_set_block_item(lf[175] /* signal/vtalrm */,0,C_fix(0));
t66=C_set_block_item(lf[176] /* signal/winch */,0,C_fix(0));
t67=C_set_block_item(lf[177] /* signal/xcpu */,0,C_fix(0));
t68=C_set_block_item(lf[178] /* signal/xfsz */,0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1),*((C_word*)lf[158]+1),*((C_word*)lf[159]+1));
t70=C_mutate((C_word*)lf[179]+1 /* signals-list ...) */,t69);
t71=*((C_word*)lf[180]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1467 make-vector");
t73=*((C_word*)lf[395]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word ab[193],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=C_mutate((C_word*)lf[181]+1 /* signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4333,a[2]=t1,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[182]+1 /* set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=t1,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[180]+1 /* interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[183]+1 /* errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[184]+1 /* errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[185]+1 /* errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[186]+1 /* errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[187]+1 /* errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[188]+1 /* errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[189]+1 /* errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[190]+1 /* errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[191]+1 /* errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[192]+1 /* errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[193]+1 /* errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[194]+1 /* errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[195]+1 /* errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[196]+1 /* errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[197]+1 /* errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[198]+1 /* errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[199]+1 /* errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[200]+1 /* errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[201]+1 /* errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[202]+1 /* errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[203]+1 /* errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[204]+1 /* errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[205]+1 /* errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[206]+1 /* errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[207]+1 /* errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[208]+1 /* errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[209]+1 /* errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[210]+1 /* errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[211]+1 /* errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[212]+1 /* errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[213]+1 /* errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[214]+1 /* errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[215]+1 /* errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[216]+1 /* errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[217]+1 /* errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[218]+1 /* errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[219]+1 /* errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[220]+1 /* errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[221]+1 /* change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4411,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[223]+1 /* file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4465,a[2]=t44,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[224]+1 /* file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4471,a[2]=t44,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[225]+1 /* file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=t44,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[226]+1 /* fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[227]+1 /* fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[228]+1 /* fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[237]+1 /* open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4541,a[2]=t51,a[3]=t52,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[238]+1 /* open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4555,a[2]=t51,a[3]=t52,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[239]+1 /* port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[243]+1 /* duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4604,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[245]+1 /* setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4634,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[246]+1 /* unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4651,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[247]+1);
t60=C_mutate((C_word*)lf[248]+1 /* current-environment ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=t59,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[249]+1 /* seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4736,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[251]+1 /* seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[252]+1 /* seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4764,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[254]+1 /* time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[258]+1 /* local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4877,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[262]+1 /* local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4905,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[263]+1 /* _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4917,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[264]+1 /* terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4933,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[265]+1 /* set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4939,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t70=*((C_word*)lf[271]+1);
t71=*((C_word*)lf[272]+1);
t72=*((C_word*)lf[273]+1);
t73=*((C_word*)lf[274]+1);
t74=*((C_word*)lf[102]+1);
t75=*((C_word*)lf[275]+1);
t76=*((C_word*)lf[276]+1);
t77=C_mutate((C_word*)lf[277]+1 /* glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4998,a[2]=t73,a[3]=t71,a[4]=t70,a[5]=t74,a[6]=t72,a[7]=t75,a[8]=t76,a[9]=((C_word)li97),tmp=(C_word)a,a+=10,tmp));
t78=C_mutate((C_word*)lf[280]+1 /* spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t79=C_mutate((C_word*)lf[281]+1 /* spawn/wait ...) */,C_fix((C_word)P_WAIT));
t80=C_mutate((C_word*)lf[282]+1 /* spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t81=C_mutate((C_word*)lf[283]+1 /* spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t82=C_mutate((C_word*)lf[284]+1 /* spawn/detach ...) */,C_fix((C_word)P_DETACH));
t83=*((C_word*)lf[285]+1);
t84=*((C_word*)lf[51]+1);
t85=*((C_word*)lf[113]+1);
t86=*((C_word*)lf[4]+1);
t87=C_mutate(&lf[286] /* $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5113,a[2]=t86,a[3]=t84,a[4]=t85,a[5]=t83,a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5192,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
t89=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5209,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t90=*((C_word*)lf[289]+1);
t91=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t92=C_mutate(&lf[290] /* $exec-setup ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5276,a[2]=t90,a[3]=t88,a[4]=t89,a[5]=t91,a[6]=((C_word)li106),tmp=(C_word)a,a+=7,tmp));
t93=C_mutate(&lf[291] /* $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t94=C_mutate((C_word*)lf[292]+1 /* process-execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5324,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[294]+1 /* process-spawn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5411,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[296]+1 /* current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5498,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[297]+1 /* shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5501,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[301]+1 /* shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5522,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t99=*((C_word*)lf[294]+1);
t100=*((C_word*)lf[299]+1);
t101=C_mutate((C_word*)lf[303]+1 /* process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5528,a[2]=t99,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t102=C_mutate(&lf[304] /* close-handle ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5557,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t103=C_mutate((C_word*)lf[305]+1 /* process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[314]+1 /* process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5804,a[2]=t104,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[315]+1 /* process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=t104,a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp));
t107=C_mutate((C_word*)lf[316]+1 /* process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5964,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[317]+1 /* process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5976,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[319]+1 /* sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6036,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[320]+1 /* get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6039,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[322]+1 /* system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6051,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[116]+1 /* current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6082,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t113=*((C_word*)lf[277]+1);
t114=*((C_word*)lf[273]+1);
t115=*((C_word*)lf[275]+1);
t116=*((C_word*)lf[106]+1);
t117=C_mutate((C_word*)lf[326]+1 /* find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6097,a[2]=t116,a[3]=t115,a[4]=t113,a[5]=t114,a[6]=((C_word)li159),tmp=(C_word)a,a+=7,tmp));
t118=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t119=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6888,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t119+1)))(3,t119,t118,*((C_word*)lf[394]+1));}

/* f_6888 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6888,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6878,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[393]+1));}

/* f_6878 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6878,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6868,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[392]+1));}

/* f_6868 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6868,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6858,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[391]+1));}

/* f_6858 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6858,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6848,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[390]+1));}

/* f_6848 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6848,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6838,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[389]+1));}

/* f_6838 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6838,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6828,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[388]+1));}

/* f_6828 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6828,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6818,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[387]+1));}

/* f_6818 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6818,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6808,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[386]+1));}

/* f_6808 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6808,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6798,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[385]+1));}

/* f_6798 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6798,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6788,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[384]+1));}

/* f_6788 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6788,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6778,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[383]+1));}

/* f_6778 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6778,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6768,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[382]+1));}

/* f_6768 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6768,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6758,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[381]+1));}

/* f_6758 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6758,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6748,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[380]+1));}

/* f_6748 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6748,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6738,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[379]+1));}

/* f_6738 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6738,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6728,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[378]+1));}

/* f_6728 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6728,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6718,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[377]+1));}

/* f_6718 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6718,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6708,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[376]+1));}

/* f_6708 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6708,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6698,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[375]+1));}

/* f_6698 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6698,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6688,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[374]+1));}

/* f_6688 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6688,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6678,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[373]+1));}

/* f_6678 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6678,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6668,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[372]+1));}

/* f_6668 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6668,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[371]+1));}

/* f_6658 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6658,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6648,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[370]+1));}

/* f_6648 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6648,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6638,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[369]+1));}

/* f_6638 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6638,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6628,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[368]+1));}

/* f_6628 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6628,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6618,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[367]+1));}

/* f_6618 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6618,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6608,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[366]+1));}

/* f_6608 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6608,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6598,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[365]+1));}

/* f_6598 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6598,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6588,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[364]+1));}

/* f_6588 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6588,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6578,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[363]+1));}

/* f_6578 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6578,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6568,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[362]+1));}

/* f_6568 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6568,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6558,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[361]+1));}

/* f_6558 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6558,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6548,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[360]+1));}

/* f_6548 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6548,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6538,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[359]+1));}

/* f_6538 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6538,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6528,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[358]+1));}

/* f_6528 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6528,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6518,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[357]+1));}

/* f_6518 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6518,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6432,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6508,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[356]+1));}

/* f_6508 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6508,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6498,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[355]+1));}

/* f_6498 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6498,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6488,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[354]+1));}

/* f_6488 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6488,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6478,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[353]+1));}

/* f_6478 in k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6478,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6439 in k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6468,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[352]+1));}

/* f_6468 in k6439 in k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6468,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6442 in k6439 in k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
t2=C_set_block_item(lf[333] /* errno/wouldblock */,0,C_fix(0));
t3=C_mutate((C_word*)lf[334]+1 /* fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6447,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[335]+1 /* memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6450,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t5=C_set_block_item(lf[336] /* map/anonymous */,0,C_fix(0));
t6=C_set_block_item(lf[337] /* map/file */,0,C_fix(0));
t7=C_set_block_item(lf[338] /* map/fixed */,0,C_fix(0));
t8=C_set_block_item(lf[339] /* map/private */,0,C_fix(0));
t9=C_set_block_item(lf[340] /* map/shared */,0,C_fix(0));
t10=C_set_block_item(lf[341] /* open/fsync */,0,C_fix(0));
t11=C_set_block_item(lf[342] /* open/noctty */,0,C_fix(0));
t12=C_set_block_item(lf[343] /* open/nonblock */,0,C_fix(0));
t13=C_set_block_item(lf[344] /* open/sync */,0,C_fix(0));
t14=C_set_block_item(lf[345] /* perm/isgid */,0,C_fix(0));
t15=C_set_block_item(lf[346] /* perm/isuid */,0,C_fix(0));
t16=C_set_block_item(lf[347] /* perm/isvtx */,0,C_fix(0));
t17=C_set_block_item(lf[348] /* prot/exec */,0,C_fix(0));
t18=C_set_block_item(lf[349] /* prot/none */,0,C_fix(0));
t19=C_set_block_item(lf[350] /* prot/read */,0,C_fix(0));
t20=C_set_block_item(lf[351] /* prot/write */,0,C_fix(0));
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k6442 in k6439 in k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6450,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k6442 in k6439 in k6436 in k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6447,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6097r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6097r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6097r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li154),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6238,a[2]=t5,a[3]=((C_word)li155),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6243,a[2]=t6,a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6248,a[2]=t7,a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-action18931980");
t9=t8;
f_6248(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-id18941976");
t11=t7;
f_6243(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-limit18951971");
t13=t6;
f_6238(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("body18911901");
t15=t5;
f_6099(t15,t1,t9,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-action1893 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_6248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6254,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp);
C_trace("def-id18941976");
t3=((C_word*)t0)[2];
f_6243(t3,t1,t2);}

/* a6253 in def-action1893 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6254,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1894 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_6243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6243,NULL,3,t0,t1,t2);}
C_trace("def-limit18951971");
t3=((C_word*)t0)[2];
f_6238(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1895 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_6238(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6238,NULL,4,t0,t1,t2,t3);}
C_trace("body18911901");
t4=((C_word*)t0)[2];
f_6099(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_6099(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6099,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[326]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6106(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6233,a[2]=t4,a[3]=t7,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6106(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6225,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));}}

/* f_6225 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6233 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6233,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_6106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6106,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6217,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 2048 make-pathname");
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[332]);}

/* k6211 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2048 glob");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6118,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li151),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6118(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_6118(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6118,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
C_trace("posixwin.scm: 2054 directory?");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
C_trace("posixwin.scm: 2055 pathname-file");
t3=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
C_trace("posixwin.scm: 2061 pproc");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k6197 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6199,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 2061 action");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("posixwin.scm: 2062 loop");
t2=((C_word*)((C_word*)t0)[7])[1];
f_6118(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6204 in k6197 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2061 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_6118(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[327]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[328]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
C_trace("posixwin.scm: 2055 loop");
t2=((C_word*)((C_word*)t0)[10])[1];
f_6118(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("posixwin.scm: 2056 lproc");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6152,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6162,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6164,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li148),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li149),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#dynamic-wind");
t11=*((C_word*)lf[330]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
C_trace("posixwin.scm: 2060 loop");
t2=((C_word*)((C_word*)t0)[8])[1];
f_6118(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a6182 in k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6183,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a6168 in k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6181,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 2059 make-pathname");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[329]);}

/* k6179 in a6168 in k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2059 glob");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6175 in a6168 in k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2059 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_6118(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6163 in k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k6160 in k6150 in k6191 in k6135 in loop in k6114 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2057 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_6118(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6217 in k6104 in body1891 in find-files in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6217,3,t0,t1,t2);}
C_trace("posixwin.scm: 2046 string-match");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6082,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
C_trace("##sys#peek-c-string");
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 2022 ##sys#update-errno");
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6090 in current-user-name in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2023 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[116],lf[325]);}

/* system-information in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6051,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6062,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6077,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 2013 ##sys#update-errno");
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6075 in system-information in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 2014 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[322],lf[324]);}

/* k6060 in system-information in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6066,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k6064 in k6060 in system-information in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6070,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k6068 in k6064 in k6060 in system-information in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6074,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k6072 in k6068 in k6064 in k6060 in system-information in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[323],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6039,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
C_trace("##sys#peek-c-string");
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
C_trace("posixwin.scm: 2003 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[320],lf[321]);}}

/* sleep in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6036,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_5976r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5976r(t0,t1,t2,t3);}}

static void C_ccall f_5976r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[317]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5997,a[2]=t5,a[3]=t2,a[4]=((C_word)li140),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6003,a[2]=t2,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t9,t10);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[2],t7);}}

/* a6002 in process-wait in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6003,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1985 ##sys#update-errno");
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
C_trace("posixwin.scm: 1987 values");
C_values(5,0,t1,t2,t3,t4);}}

/* k6011 in a6002 in process-wait in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1986 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[310],lf[317],lf[318],((C_word*)t0)[2]);}

/* a5996 in process-wait in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
C_trace("posixwin.scm: 1982 ##sys#process-wait");
t2=*((C_word*)lf[316]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5964,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
C_trace("posixwin.scm: 1975 values");
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
C_trace("posixwin.scm: 1976 values");
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5884r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5884r(t0,t1,t2,t3);}}

static void C_ccall f_5884r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5886,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5891,a[2]=t4,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5896,a[2]=t5,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5901,a[2]=t6,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-args17861809");
t8=t7;
f_5901(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-env17871805");
t10=t6;
f_5896(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("def-exactf17881800");
t12=t5;
f_5891(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
C_trace("body17841794");
t14=t4;
f_5886(t14,t1,t8,t10,t12);}
else{
C_trace("##sys#error");
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args1786 in process* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5901,NULL,2,t0,t1);}
C_trace("def-env17871805");
t2=((C_word*)t0)[2];
f_5896(t2,t1,C_SCHEME_FALSE);}

/* def-env1787 in process* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5896,NULL,3,t0,t1,t2);}
C_trace("def-exactf17881800");
t3=((C_word*)t0)[2];
f_5891(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1788 in process* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5891(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5891,NULL,4,t0,t1,t2,t3);}
C_trace("body17841794");
t4=((C_word*)t0)[2];
f_5886(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1784 in process* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5886(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5886,NULL,5,t0,t1,t2,t3,t4);}
C_trace("posixwin.scm: 1969 %process");
f_5742(t1,lf[315],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5804r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5804r(t0,t1,t2,t3);}}

static void C_ccall f_5804r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5806,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5811,a[2]=t4,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5816,a[2]=t5,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5821,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-args17311754");
t8=t7;
f_5821(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-env17321750");
t10=t6;
f_5816(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("def-exactf17331745");
t12=t5;
f_5811(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
C_trace("body17291739");
t14=t4;
f_5806(t14,t1,t8,t10,t12);}
else{
C_trace("##sys#error");
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args1731 in process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5821,NULL,2,t0,t1);}
C_trace("def-env17321750");
t2=((C_word*)t0)[2];
f_5816(t2,t1,C_SCHEME_FALSE);}

/* def-env1732 in process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5816,NULL,3,t0,t1,t2);}
C_trace("def-exactf17331745");
t3=((C_word*)t0)[2];
f_5811(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1733 in process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5811,NULL,4,t0,t1,t2,t3);}
C_trace("body17291739");
t4=((C_word*)t0)[2];
f_5806(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1729 in process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5806(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5806,NULL,5,t0,t1,t2,t3,t4);}
C_trace("posixwin.scm: 1966 %process");
f_5742(t1,lf[314],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5742(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5742,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5744,a[2]=t2,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5763,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
C_trace("posixwin.scm: 1954 chkstrlst");
t14=t11;
f_5744(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5798,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1957 ##sys#shell-command-arguments");
t16=*((C_word*)lf[301]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,((C_word*)t8)[1]);}}

/* k5796 in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1958 ##sys#shell-command");
t4=*((C_word*)lf[297]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5800 in k5796 in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5763(2,t3,t2);}

/* k5761 in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
C_trace("posixwin.scm: 1959 chkstrlst");
t3=((C_word*)t0)[2];
f_5744(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_5766(2,t3,C_SCHEME_UNDEFINED);}}

/* k5764 in k5761 in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li126),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5777,a[2]=((C_word*)t0)[4],a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5776 in k5764 in k5761 in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5777,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
C_trace("posixwin.scm: 1962 values");
C_values(6,0,t1,t2,t3,t4,t5);}
else{
C_trace("posixwin.scm: 1963 values");
C_values(5,0,t1,t2,t3,t4);}}

/* a5770 in k5764 in k5761 in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
C_trace("posixwin.scm: 1960 ##sys#process");
t2=*((C_word*)lf[305]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5744,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5753,a[2]=((C_word*)t0)[2],a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5752 in chkstrlst in %process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5753,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_5623r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_5623r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_5623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5627,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_5627(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_5627(2,t12,(C_word)C_i_car(t9));}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[2],t9);}}}

/* k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
C_trace("posixwin.scm: 1926 $quote-args-list");
t5=lf[286];
f_5113(t5,t3,t4,t1);}

/* k5716 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1926 string-intersperse");
t2=*((C_word*)lf[114]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5630,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(*((C_word*)lf[306]+1)))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(*((C_word*)lf[307]+1)))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(*((C_word*)lf[308]+1)))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(*((C_word*)lf[309]+1)))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
C_trace("##sys#make-locative");
t15=*((C_word*)lf[312]+1);
((C_proc6)C_retrieve_proc(t15))(6,t15,t14,t2,C_fix(0),C_SCHEME_FALSE,lf[313]);}

/* k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("##sys#make-locative");
t3=*((C_word*)lf[312]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[313]);}

/* k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("##sys#make-locative");
t3=*((C_word*)lf[312]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[313]);}

/* k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("##sys#make-locative");
t3=*((C_word*)lf[312]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[313]);}

/* k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
C_trace("posixwin.scm: 1933 +");
C_plus(5,0,t2,t3,t4,t5);}

/* k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5565,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
C_trace("##sys#make-c-string");
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5565(2,t9,C_SCHEME_FALSE);}}

/* k5563 in k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
C_trace("##sys#make-c-string");
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5569(2,t3,C_SCHEME_FALSE);}}

/* k5567 in k5563 in k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5569,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub1561(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("posixwin.scm: 1936 open-input-file*");
t8=*((C_word*)lf[237]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_5659(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1941 ##sys#update-errno");
t8=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5677 in k5567 in k5563 in k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1942 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[310],((C_word*)t0)[3],lf[311],((C_word*)t0)[2]);}

/* k5657 in k5567 in k5563 in k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("posixwin.scm: 1937 open-output-file*");
t3=*((C_word*)lf[238]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5663(2,t3,C_SCHEME_FALSE);}}

/* k5661 in k5657 in k5567 in k5563 in k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("posixwin.scm: 1939 open-input-file*");
t3=*((C_word*)lf[237]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5667(2,t3,C_SCHEME_FALSE);}}

/* k5665 in k5661 in k5657 in k5567 in k5563 in k5700 in k5696 in k5692 in k5688 in k5684 in k5628 in k5625 in ##sys#process in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1935 values");
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5557,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1547(C_SCHEME_UNDEFINED,t2));}

/* process-run in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5528r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5528r(t0,t1,t2,t3);}}

static void C_ccall f_5528r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
C_trace("posixwin.scm: 1894 process-spawn");
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[282]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5545,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1895 ##sys#shell-command");
t7=*((C_word*)lf[297]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k5543 in process-run in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5549,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1895 ##sys#shell-command-arguments");
t3=*((C_word*)lf[301]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5547 in k5543 in process-run in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1895 process-spawn");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[282]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5522,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[302],t2));}

/* ##sys#shell-command in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5505,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1878 getenv");
t3=*((C_word*)lf[299]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[300]);}

/* k5503 in ##sys#shell-command in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5505,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
C_trace("##sys#peek-c-string");
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1882 ##sys#update-errno");
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k5515 in k5503 in ##sys#shell-command in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1883 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[297],lf[298]);}

/* current-process-id in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1515(C_SCHEME_UNDEFINED));}

/* process-spawn in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5411r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5411r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5411r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5413,a[2]=t3,a[3]=t2,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5425,a[2]=t5,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5430,a[2]=t6,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5435,a[2]=t7,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-arglst14761501");
t9=t8;
f_5435(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-envlst14771497");
t11=t7;
f_5430(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-exactf14781492");
t13=t6;
f_5425(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("body14741484");
t15=t5;
f_5413(t15,t1,t9,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-arglst1476 in process-spawn in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5435,NULL,2,t0,t1);}
C_trace("def-envlst14771497");
t2=((C_word*)t0)[2];
f_5430(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1477 in process-spawn in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5430(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5430,NULL,3,t0,t1,t2);}
C_trace("def-exactf14781492");
t3=((C_word*)t0)[2];
f_5425(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1478 in process-spawn in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5425(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5425,NULL,4,t0,t1,t2,t3);}
C_trace("body14741484");
t4=((C_word*)t0)[2];
f_5413(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1474 in process-spawn in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5413(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5413,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5417,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1869 $exec-setup");
t6=lf[290];
f_5276(t6,t5,lf[294],((C_word*)t0)[2],t2,t3,t4);}

/* k5415 in body1474 in process-spawn in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
C_trace("posixwin.scm: 1870 $exec-teardown");
f_5309(((C_word*)t0)[3],lf[294],lf[295],((C_word*)t0)[2],t2);}

/* process-execute in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_5324r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5324r(t0,t1,t2,t3);}}

static void C_ccall f_5324r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5326,a[2]=t2,a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5338,a[2]=t4,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5343,a[2]=t5,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5348,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-arglst14161441");
t8=t7;
f_5348(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-envlst14171437");
t10=t6;
f_5343(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("def-exactf14181432");
t12=t5;
f_5338(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
C_trace("body14141424");
t14=t4;
f_5326(t14,t1,t8,t10,t12);}
else{
C_trace("##sys#error");
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-arglst1416 in process-execute in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5348,NULL,2,t0,t1);}
C_trace("def-envlst14171437");
t2=((C_word*)t0)[2];
f_5343(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1417 in process-execute in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5343,NULL,3,t0,t1,t2);}
C_trace("def-exactf14181432");
t3=((C_word*)t0)[2];
f_5338(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1418 in process-execute in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5338(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5338,NULL,4,t0,t1,t2,t3);}
C_trace("body14141424");
t4=((C_word*)t0)[2];
f_5326(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1414 in process-execute in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5326(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5326,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1864 $exec-setup");
t6=lf[290];
f_5276(t6,t5,lf[292],((C_word*)t0)[2],t2,t3,t4);}

/* k5328 in body1414 in process-execute in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
C_trace("posixwin.scm: 1865 $exec-teardown");
f_5309(((C_word*)t0)[3],lf[292],lf[293],((C_word*)t0)[2],t2);}

/* $exec-teardown in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5309(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5309,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5313,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("posixwin.scm: 1856 ##sys#update-errno");
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5311 in $exec-teardown in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
C_trace("posixwin.scm: 1860 ##sys#error");
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5276(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5276,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5283,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
C_trace("posixwin.scm: 1848 pathname-strip-directory");
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5281 in $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
C_trace("posixwin.scm: 1849 setarg");
t4=((C_word*)t0)[4];
f_5192(5,t4,t2,C_fix(0),t1,t3);}

/* k5284 in k5281 in $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1850 $quote-args-list");
t4=lf[286];
f_5113(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5301 in k5284 in k5281 in $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1850 build-exec-argvec");
f_5226(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k5287 in k5284 in k5281 in $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5292,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1851 build-exec-argvec");
f_5226(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k5290 in k5287 in k5284 in k5281 in $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5292,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1853 ##sys#expand-home-path");
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5297 in k5290 in k5287 in k5284 in k5281 in $exec-setup in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1853 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5226(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5226,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5238,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5238(t10,t1,t3,t5);}
else{
C_trace("posixwin.scm: 1845 argvec-setter");
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop1352 in build-exec-argvec in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5238(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5238,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("posixwin.scm: 1841 argvec-setter");
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5257,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
C_trace("posixwin.scm: 1844 argvec-setter");
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k5255 in doloop1352 in build-exec-argvec in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5238(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5209,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1338(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5192,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1326(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5113(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5113,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li99),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5156,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5156(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5156,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("posixwin.scm: 1822 reverse");
t4=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5184,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5187,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1827 needs-quoting?");
t8=((C_word*)t0)[2];
f_5118(t8,t7,t4);}}

/* k5185 in loop in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("posixwin.scm: 1827 string-append");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[287],((C_word*)t0)[2],lf[288]);}
else{
t2=((C_word*)t0)[3];
f_5184(2,t2,((C_word*)t0)[2]);}}

/* k5182 in loop in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5184,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
C_trace("posixwin.scm: 1824 loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_5156(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5118(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5118,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5122,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1814 string-length");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5120 in needs-quoting? in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li98),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5127(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5120 in needs-quoting? in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5127(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5127,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5151,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1818 string-ref");
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k5149 in loop in k5120 in needs-quoting? in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1818 char-whitespace?");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5138 in loop in k5120 in needs-quoting? in $quote-args-list in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("posixwin.scm: 1819 loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_5127(t3,((C_word*)t0)[4],t2);}}

/* glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4998r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4998r(t0,t1,t2);}}

static void C_ccall f_4998r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li96),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_5004(t6,t1,t2);}

/* conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5004(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5004,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5019,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li95),tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t4,t5);}}

/* a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5025,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5102,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[279]);
C_trace("posixwin.scm: 1775 make-pathname");
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5100 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1775 glob->regexp");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("posixwin.scm: 1776 make-anchored-pattern");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("posixwin.scm: 1777 regexp");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5033 in k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[278]);
C_trace("posixwin.scm: 1778 directory");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5040 in k5033 in k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5042,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li94),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5044(t5,((C_word*)t0)[2],t1);}

/* loop in k5040 in k5033 in k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_5044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5044,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
C_trace("posixwin.scm: 1779 conc-loop");
t4=((C_word*)((C_word*)t0)[7])[1];
f_5004(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5061,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
C_trace("posixwin.scm: 1780 string-match");
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5059 in loop in k5040 in k5033 in k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
C_trace("posixwin.scm: 1781 make-pathname");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("posixwin.scm: 1782 loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_5044(t3,((C_word*)t0)[6],t2);}}

/* k5069 in k5059 in loop in k5040 in k5033 in k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5075,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("posixwin.scm: 1781 loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5044(t4,t2,t3);}

/* k5073 in k5069 in k5059 in loop in k5040 in k5033 in k5030 in k5027 in a5024 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a5018 in conc-loop in glob in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
C_trace("posixwin.scm: 1774 decompose-pathname");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4939r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4939r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4939r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4943,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1745 ##sys#check-port");
t6=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[265]);}

/* k4941 in set-buffering-mode! in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4943,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[267]);
if(C_truep(t6)){
t7=t5;
f_4949(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t7)){
t8=t5;
f_4949(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[269]);
if(C_truep(t8)){
t9=t5;
f_4949(2,t9,C_fix((C_word)_IONBF));}
else{
C_trace("posixwin.scm: 1751 ##sys#error");
t9=*((C_word*)lf[62]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[265],lf[270],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4947 in k4941 in set-buffering-mode! in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[265]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[81],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
C_trace("posixwin.scm: 1757 ##sys#error");
t6=*((C_word*)lf[62]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[265],lf[266],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4933,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1735 ##sys#check-port");
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[264]);}

/* k4935 in terminal-port? in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4917r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4917r(t0,t1,t2);}}

static void C_ccall f_4917r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1152(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1144(t2),C_fix(0));}

/* local-time->seconds in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4877,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[258]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4884,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
C_trace("posixwin.scm: 1717 ##sys#error");
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[258],lf[261],t2);}
else{
t6=t4;
f_4884(2,t6,C_SCHEME_UNDEFINED);}}

/* k4882 in local-time->seconds in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
C_trace("posixwin.scm: 1719 ##sys#cons-flonum");
t2=*((C_word*)lf[259]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
C_trace("posixwin.scm: 1720 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[258],lf[260],((C_word*)t0)[3]);}}

/* time->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4797r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4797r(t0,t1,t2,t3);}}

static void C_ccall f_4797r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4801,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4801(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4801(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k4799 in time->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[254]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
C_trace("posixwin.scm: 1704 ##sys#error");
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[254],lf[257],((C_word*)t0)[3]);}
else{
t5=t3;
f_4807(2,t5,C_SCHEME_UNDEFINED);}}

/* k4805 in k4799 in time->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4807,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[254]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4826,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1708 ##sys#make-c-string");
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1087(t4,t3),C_fix(0));}}

/* k4827 in k4805 in k4799 in time->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
C_trace("posixwin.scm: 1712 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
C_trace("posixwin.scm: 1713 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[254],lf[256],((C_word*)t0)[2]);}}

/* k4824 in k4805 in k4799 in time->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1095(t3,t2,t1),C_fix(0));}

/* k4814 in k4805 in k4799 in time->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
C_trace("posixwin.scm: 1709 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[254],lf[255],((C_word*)t0)[2]);}}

/* seconds->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4764,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4768,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub1072(t5,t6);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4766 in seconds->string in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
C_trace("posixwin.scm: 1696 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
C_trace("posixwin.scm: 1697 ##sys#error");
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[252],lf[253],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4745,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[251]);
C_trace("posixwin.scm: 1689 ##sys#decode-seconds");
t4=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4736,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[249]);
C_trace("posixwin.scm: 1685 ##sys#decode-seconds");
t4=*((C_word*)lf[250]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4677(t5,t1,C_fix(0));}

/* loop in current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4677(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4677,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4681,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1033(t5,t6);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4679 in loop in current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4689,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li81),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4689(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4679 in loop in current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4689,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("posixwin.scm: 1677 substring");
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
C_trace("posixwin.scm: 1678 scan");
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4713 in scan in k4679 in loop in current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
C_trace("posixwin.scm: 1677 substring");
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k4717 in k4713 in scan in k4679 in loop in current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4719,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4707,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("posixwin.scm: 1677 loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_4677(t5,t3,t4);}

/* k4705 in k4717 in k4713 in scan in k4679 in loop in current-environment in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4651,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[246]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1665 ##sys#make-c-string");
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4657 in unsetenv in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4634,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[245]);
t5=(C_word)C_i_check_string_2(t3,lf[245]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1660 ##sys#make-c-string");
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4643 in setenv in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1660 ##sys#make-c-string");
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4647 in k4643 in setenv in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4604r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4604r(t0,t1,t2,t3);}}

static void C_ccall f_4604r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[243]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4611,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4611(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[243]);
t8=t5;
f_4611(t8,(C_word)C_dup2(t2,t6));}}

/* k4609 in duplicate-fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4614,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1650 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4614(2,t3,C_SCHEME_UNDEFINED);}}

/* k4618 in k4609 in duplicate-fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1651 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[243],lf[244],((C_word*)t0)[2]);}

/* k4612 in k4609 in duplicate-fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4569,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1632 ##sys#check-port");
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[239]);}

/* k4571 in port->fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1633 ##sys#peek-unsigned-integer");
t3=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4600 in k4571 in port->fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
C_trace("posixwin.scm: 1639 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[239],lf[240],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1636 ##sys#update-errno");
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4582(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4586 in k4600 in k4571 in port->fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1637 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[239],lf[241],((C_word*)t0)[2]);}

/* k4580 in k4600 in k4571 in port->fileno in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4555r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4555r(t0,t1,t2,t3);}}

static void C_ccall f_4555r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[238]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4567,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1628 mode");
f_4486(t5,C_SCHEME_FALSE,t3);}

/* k4565 in open-output-file* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
C_trace("posixwin.scm: 1628 check");
f_4523(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4541r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4541r(t0,t1,t2,t3);}}

static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[237]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4553,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1624 mode");
f_4486(t5,C_SCHEME_TRUE,t3);}

/* k4551 in open-input-file* in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
C_trace("posixwin.scm: 1624 check");
f_4523(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4523(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4523,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4527,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1615 ##sys#update-errno");
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4525 in check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4527,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
C_trace("posixwin.scm: 1617 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[235],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1618 ##sys#make-port");
t3=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[136]+1),lf[236],lf[81]);}}

/* k4537 in k4525 in check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4486(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4486,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[229]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
C_trace("posixwin.scm: 1610 ##sys#error");
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[230],t5);}
else{
t8=t4;
f_4494(2,t8,lf[231]);}}
else{
C_trace("posixwin.scm: 1611 ##sys#error");
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[232],t5);}}
else{
t5=t4;
f_4494(2,t5,(C_truep(t2)?lf[233]:lf[234]));}}

/* k4492 in mode in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1606 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4477,3,t0,t1,t2);}
C_trace("posixwin.scm: 1590 check");
f_4441(t1,t2,C_fix((C_word)2),lf[225]);}

/* file-write-access? in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4471,3,t0,t1,t2);}
C_trace("posixwin.scm: 1589 check");
f_4441(t1,t2,C_fix((C_word)4),lf[224]);}

/* file-read-access? in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4465,3,t0,t1,t2);}
C_trace("posixwin.scm: 1588 check");
f_4441(t1,t2,C_fix((C_word)2),lf[223]);}

/* check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4441(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4441,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4459,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4463,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1585 ##sys#expand-home-path");
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k4461 in check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1585 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4457 in check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4451,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4451(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("posixwin.scm: 1586 ##sys#update-errno");
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4449 in k4457 in check in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4411,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[221]);
t5=(C_word)C_i_check_exact_2(t3,lf[221]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4435,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4439,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1574 ##sys#expand-home-path");
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k4437 in change-file-mode in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1574 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4433 in change-file-mode in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1575 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4425 in k4433 in change-file-mode in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1576 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[221],lf[222],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4355,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4365,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1482 h");
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
C_trace("posixwin.scm: 1484 oldhook");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4363 in ##sys#interrupt-hook in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1483 ##sys#context-switch");
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4342,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[182]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4329 in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4333,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[181]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4257r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4257r(t0,t1,t2);}}

static void C_ccall f_4257r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4261,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4261(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4261(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k4259 in create-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1419 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4264(2,t3,C_SCHEME_UNDEFINED);}}

/* k4271 in k4259 in create-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1420 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[151],lf[152]);}

/* k4262 in k4259 in create-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1421 values");
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4237r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4237r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4237r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[150]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4241,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4239 in with-output-to-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=C_mutate((C_word*)lf[150]+1 /* standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4247,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1404 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4246 in k4239 in with-output-to-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4247r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4247r(t0,t1,t2);}}

static void C_ccall f_4247r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4251,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1406 close-output-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4249 in a4246 in k4239 in with-output-to-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[150]+1 /* standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4217r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4217r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4217r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[148]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4221,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4219 in with-input-from-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1 /* standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4227,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1394 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4226 in k4219 in with-input-from-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4227r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4227r(t0,t1,t2);}}

static void C_ccall f_4227r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4231,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1396 close-input-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4229 in a4226 in k4219 in with-input-from-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[148]+1 /* standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4193r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4193r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4193r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4197,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4195 in call-with-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4202,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4208,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1384 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4207 in k4195 in call-with-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4208r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4208r(t0,t1,t2);}}

static void C_ccall f_4208r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4212,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1387 close-output-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4210 in a4207 in k4195 in call-with-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4201 in k4195 in call-with-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
C_trace("posixwin.scm: 1385 proc");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4169r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4169r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4169r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4173,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4171 in call-with-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4178,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4184,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1376 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4183 in k4171 in call-with-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4184r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4184r(t0,t1,t2);}}

static void C_ccall f_4184r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4188,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1379 close-input-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4186 in a4183 in k4171 in call-with-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4177 in k4171 in call-with-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
C_trace("posixwin.scm: 1377 proc");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4150,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4154,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1363 ##sys#check-port");
t4=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[141]);}

/* k4152 in close-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1365 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4155 in k4152 in close-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
C_trace("posixwin.scm: 1366 ##sys#signal-hook");
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[141],lf[142],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4114r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4114r(t0,t1,t2,t3);}}

static void C_ccall f_4114r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[140]);
t5=f_4042(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4128,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[132]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1358 ##sys#make-c-string");
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4145,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1359 ##sys#make-c-string");
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
C_trace("posixwin.scm: 1360 badmode");
f_4054(t6,t5);}}}

/* k4143 in open-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4128(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4133 in open-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4128(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4126 in open-output-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1355 check");
f_4060(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4078r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4078r(t0,t1,t2,t3);}}

static void C_ccall f_4078r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[138]);
t5=f_4042(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4092,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[132]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1348 ##sys#make-c-string");
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1349 ##sys#make-c-string");
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
C_trace("posixwin.scm: 1350 badmode");
f_4054(t6,t5);}}}

/* k4107 in open-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4109,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4092(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4097 in open-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4092(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4090 in open-input-pipe in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1345 check");
f_4060(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4060(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4060,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1335 ##sys#update-errno");
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4062 in check in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
C_trace("posixwin.scm: 1337 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[134],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1338 ##sys#make-port");
t3=*((C_word*)lf[135]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[136]+1),lf[137],lf[81]);}}

/* k4074 in k4062 in check in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_4054(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4054,NULL,2,t1,t2);}
C_trace("posixwin.scm: 1333 ##sys#error");
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[133],t2);}

/* mode in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static C_word C_fcall f_4042(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[132]));}

/* canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3685,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3692,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3825,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1272 cwd");
t8=((C_word*)t0)[5];
f_3629(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1274 sref");
t10=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3831(t9,C_SCHEME_FALSE);}}}

/* k4030 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1274 sep?");
t2=((C_word*)t0)[3];
f_3831(t2,f_3618(t1));}

/* k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3831,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3838,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1276 cwd");
t4=((C_word*)t0)[7];
f_3629(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1279 cwd");
t5=((C_word*)t0)[7];
f_3629(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4018,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1280 sref");
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k4016 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1280 char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4005 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1281 sref");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3861(t2,C_SCHEME_FALSE);}}

/* k4012 in k4005 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1281 sep?");
t2=((C_word*)t0)[3];
f_3861(t2,f_3618(t1));}

/* k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3884,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1283 cwd");
t4=((C_word*)t0)[6];
f_3629(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1289 cwd");
t5=((C_word*)t0)[6];
f_3629(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1290 sref");
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3998 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1290 alpha?");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3977 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3979,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3996,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1291 sref");
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_3903(t2,C_SCHEME_FALSE);}}

/* k3994 in k3977 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1291 char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3983 in k3977 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1292 sref");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_3903(t2,C_SCHEME_FALSE);}}

/* k3990 in k3983 in k3977 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1292 sep?");
t2=((C_word*)t0)[3];
f_3903(t2,f_3618(t1));}

/* k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3903,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_3692(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3976,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1294 sref");
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3974 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1294 char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3953 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3972,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1295 sref");
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3909(2,t2,C_SCHEME_FALSE);}}

/* k3970 in k3953 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1295 alpha?");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3959 in k3953 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1296 sref");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3909(2,t2,C_SCHEME_FALSE);}}

/* k3966 in k3959 in k3953 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1296 char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1298 ##sys#substring");
t3=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("posixwin.scm: 1302 sref");
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k3950 in k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=f_3618(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3941,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1304 cwd");
t5=((C_word*)t0)[2];
f_3629(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1307 cwd");
t4=((C_word*)t0)[2];
f_3629(t4,t3);}}

/* k3946 in k3950 in k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1307 sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[131],((C_word*)t0)[2]);}

/* k3939 in k3950 in k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1304 ##sys#substring");
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3935 in k3950 in k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1303 sappend");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3914 in k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3920,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
C_trace("posixwin.scm: 1300 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3918 in k3914 in k3907 in k3901 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1297 sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[130],t1);}

/* k3895 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1289 sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[129],((C_word*)t0)[2]);}

/* k3882 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1283 ##sys#substring");
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3866 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1285 user");
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3870 in k3866 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3876,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
C_trace("posixwin.scm: 1286 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3874 in k3870 in k3866 in k3859 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1282 sappend");
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],t1);}

/* k3853 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1279 sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[127],((C_word*)t0)[2]);}

/* k3840 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1276 ##sys#substring");
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3836 in k3829 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1275 sappend");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3823 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1272 sappend");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[126]);}

/* k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
C_trace("posixwin.scm: 1308 ##sys#substring");
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t1,C_fix(3),t4);}

/* k3809 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-split");
t2=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[125]);}

/* k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3699,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3701(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3701(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3701,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
C_trace("posixwin.scm: 1310 null?");
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3708,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
C_trace("posixwin.scm: 1311 null?");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3780,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("posixwin.scm: 1322 string=?");
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[124],t5);}}

/* k3781 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3780(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("posixwin.scm: 1324 string=?");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[123],t3);}}

/* k3790 in k3781 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3780(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3780(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3778 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1320 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_3701(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
if(C_truep(t1)){
C_trace("posixwin.scm: 1312 ##sys#substring");
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
C_trace("posixwin.scm: 1313 sref");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
t2=f_3618(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1315 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1318 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k3747 in k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3753,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3757,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1319 reverse");
t4=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3755 in k3747 in k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1319 isperse");
f_3613(((C_word*)t0)[2],t1);}

/* k3751 in k3747 in k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1317 sappend");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3728 in k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3738,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[121],((C_word*)t0)[2]);
C_trace("posixwin.scm: 1316 reverse");
t5=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3736 in k3728 in k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1316 isperse");
f_3613(((C_word*)t0)[2],t1);}

/* k3732 in k3728 in k3759 in k3712 in k3706 in loop in k3697 in k3690 in canonical-path in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1314 sappend");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3629,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
C_trace("call-with-current-continuation");
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3638,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3644,a[2]=t2,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3662,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
t5=*((C_word*)lf[119]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3661 in a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[3],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3674,a[2]=((C_word*)t0)[2],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a3673 in a3661 in a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3674r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3674r(t0,t1,t2);}}

static void C_ccall f_3674r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3680,a[2]=t2,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
C_trace("k574580");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3679 in a3673 in a3661 in a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3667 in a3661 in a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
C_trace("posixwin.scm: 1267 cw");
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3643 in a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3644,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3650,a[2]=t2,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
C_trace("k574580");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3649 in a3643 in a3637 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[117]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[118]);}

/* k3634 in cwd in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static C_word C_fcall f_3618(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3613(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3613,NULL,2,t1,t2);}
C_trace("string-intersperse");
t3=*((C_word*)lf[114]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[115]);}

/* current-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3562r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3562r(t0,t1,t2);}}

static void C_ccall f_3562r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3566(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3566(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k3564 in current-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3566,2,t0,t1);}
if(C_truep(t1)){
C_trace("posixwin.scm: 1245 change-directory");
t2=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1246 make-string");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3573 in k3564 in current-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3575,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3578,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1248 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3576 in k3573 in k3564 in current-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("posixwin.scm: 1250 ##sys#substring");
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
C_trace("posixwin.scm: 1251 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[105],lf[108]);}}

/* directory? in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3535,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3542,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3560,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1238 ##sys#expand-home-path");
t7=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k3558 in directory? in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1238 ##sys#platform-fixup-pathname");
t2=*((C_word*)lf[107]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3554 in directory? in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1237 ##sys#file-info");
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3540 in directory? in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_3375r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3375r(t0,t1,t2);}}

static void C_ccall f_3375r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=t3,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3483,a[2]=t4,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("def-spec419479");
t6=t5;
f_3483(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
C_trace("def-show-dotfiles?420475");
t8=t4;
f_3478(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("body417426");
t10=t3;
f_3377(t10,t1,t6,t8);}
else{
C_trace("##sys#error");
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[2],t9);}}}}

/* def-spec419 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3483,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1208 current-directory");
t3=*((C_word*)lf[105]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3489 in def-spec419 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("def-show-dotfiles?420475");
t2=((C_word*)t0)[3];
f_3478(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?420 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3478,NULL,3,t0,t1,t2);}
C_trace("body417426");
t3=((C_word*)t0)[2];
f_3377(t3,t1,t2,C_SCHEME_FALSE);}

/* body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3377(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3377,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3384,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1210 make-string");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1211 ##sys#make-pointer");
t3=*((C_word*)lf[104]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("posixwin.scm: 1212 ##sys#make-pointer");
t3=*((C_word*)lf[104]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1213 ##sys#expand-home-path");
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3475 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1213 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3392 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1216 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li29),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3411(t6,((C_word*)t0)[6]);}}

/* loop in k3392 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3411,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1225 ##sys#substring");
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k3419 in loop in k3392 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3433,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_3433(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_3433(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_3433(t7,C_SCHEME_FALSE);}}

/* k3431 in k3419 in loop in k3392 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3433,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("posixwin.scm: 1232 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_3411(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1233 loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3411(t3,t2);}}

/* k3441 in k3431 in k3419 in loop in k3392 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3401 in k3392 in k3388 in k3385 in k3382 in body417 in directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1217 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[102],lf[103],((C_word*)t0)[2]);}

/* delete-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3348,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[99]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3369,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1200 ##sys#expand-home-path");
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3371 in delete-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1200 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3367 in delete-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1201 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3359 in k3367 in delete-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1202 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[99],lf[100],((C_word*)t0)[2]);}

/* change-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3321,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1193 ##sys#expand-home-path");
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3344 in change-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1193 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3340 in change-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3342,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1194 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3332 in k3340 in change-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1195 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[97],lf[98],((C_word*)t0)[2]);}

/* create-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3181r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3181r(t0,t1,t2,t3);}}

static void C_ccall f_3181r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3185,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3185(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3185(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k3183 in create-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[89]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1181 canonical-path");
t4=*((C_word*)lf[96]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1182 canonical-path");
t4=*((C_word*)lf[96]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}

/* k3279 in k3183 in create-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3282,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3282 in k3279 in k3183 in create-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3282,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3300,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1152 ##sys#make-c-string");
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3298 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1153 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3290 in k3298 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1154 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* k3196 in k3183 in create-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3199 in k3196 in k3183 in create-directory in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3199,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3203,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1169 string-split");
t4=*((C_word*)lf[94]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[95]);}

/* k3201 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3211,a[2]=t4,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t1);
C_trace("for-each");
t7=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a3210 in k3201 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3211,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3216,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1173 string-append");
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[92],t2);}

/* k3214 in a3210 in k3201 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_3220 in k3214 in a3210 in k3201 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3220,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3227,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3250 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3250,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3257,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1158 file-exists?");
t4=*((C_word*)lf[91]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3255 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1159 ##sys#file-info");
t3=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3258 in k3255 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3225 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3231,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_3231 in k3225 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3231,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3249,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1152 ##sys#make-c-string");
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3247 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1153 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3239 in k3247 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1154 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* set-file-position! in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3120r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3120r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3120r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[84]);
t8=(C_word)C_i_check_exact_2(t6,lf[84]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3133,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
C_trace("posixwin.scm: 1139 ##sys#signal-hook");
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[87],lf[84],lf[88],t3,t2);}
else{
t10=t9;
f_3133(2,t10,C_SCHEME_UNDEFINED);}}

/* k3131 in set-file-position! in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1140 port?");
t4=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3146 in k3131 in set-file-position! in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[4];
f_3139(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3139(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
C_trace("posixwin.scm: 1144 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[84],lf[86],((C_word*)t0)[5]);}}}

/* k3137 in k3131 in set-file-position! in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1145 ##sys#update-errno");
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3140 in k3137 in k3131 in set-file-position! in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1146 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[84],lf[85],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3080,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3084,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3099,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1123 port?");
t5=*((C_word*)lf[83]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3097 in file-position in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[81]);
t4=((C_word*)t0)[2];
f_3084(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_3084(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
C_trace("posixwin.scm: 1128 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[79],lf[82],((C_word*)t0)[3]);}}}

/* k3082 in file-position in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3087,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1130 ##sys#update-errno");
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3087(2,t3,C_SCHEME_UNDEFINED);}}

/* k3091 in k3082 in file-position in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1131 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[79],lf[80],((C_word*)t0)[2]);}

/* k3085 in k3082 in file-position in k3076 in k3072 in k3068 in k3064 in k3060 in k3056 in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_3047(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3047,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));}

/* f_3049 in stat-type in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3049,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3042,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3019,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1101 ##sys#expand-home-path");
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3038 in regular-file? in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1101 ##sys#file-info");
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3024 in regular-file? in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3013,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1097 ##sys#stat");
f_2914(t3,t2);}

/* k3015 in file-permissions in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3007,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3011,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1096 ##sys#stat");
f_2914(t3,t2);}

/* k3009 in file-owner in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3001,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1095 ##sys#stat");
f_2914(t3,t2);}

/* k3003 in file-change-time in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2995,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1094 ##sys#stat");
f_2914(t3,t2);}

/* k2997 in file-access-time in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2989,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1093 ##sys#stat");
f_2914(t3,t2);}

/* k2991 in file-modification-time in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2983,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1092 ##sys#stat");
f_2914(t3,t2);}

/* k2985 in file-size in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2952r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2952r(t0,t1,t2,t3);}}

static void C_ccall f_2952r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2956,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2956(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2956(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k2954 in file-stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1086 ##sys#stat");
f_2914(t2,((C_word*)t0)[2]);}

/* k2957 in k2954 in file-stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_fcall f_2914(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2914,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2918(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1079 ##sys#expand-home-path");
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
C_trace("posixwin.scm: 1080 ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k2945 in ##sys#stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1079 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2941 in ##sys#stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2918(2,t2,(C_word)C_stat(t1));}

/* k2916 in ##sys#stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1082 ##sys#update-errno");
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2925 in k2916 in ##sys#stat in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1083 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2876,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1048 ##sys#make-c-string");
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2881 in file-mkstemp in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1050 string-length");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2884 in k2881 in file-mkstemp in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1052 ##sys#update-errno");
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2889(2,t4,C_SCHEME_UNDEFINED);}}

/* k2904 in k2884 in k2881 in file-mkstemp in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1053 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k2887 in k2884 in k2881 in file-mkstemp in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
C_trace("posixwin.scm: 1054 ##sys#substring");
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2894 in k2887 in k2884 in k2881 in file-mkstemp in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1054 values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2834r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2834r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2841,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2841(2,t8,C_SCHEME_UNDEFINED);}
else{
C_trace("posixwin.scm: 1035 ##sys#signal-hook");
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k2839 in file-write in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2856,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1040 ##sys#update-errno");
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2850(2,t8,C_SCHEME_UNDEFINED);}}

/* k2854 in k2839 in file-write in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1041 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2848 in k2839 in file-write in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2789r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2789r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2789r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2799,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2799(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
C_trace("posixwin.scm: 1022 make-string");
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2797 in file-read in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2802(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("posixwin.scm: 1024 ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k2800 in k2797 in file-read in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2805,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("posixwin.scm: 1027 ##sys#update-errno");
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2805(2,t5,C_SCHEME_UNDEFINED);}}

/* k2812 in k2800 in k2797 in file-read in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1028 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2803 in k2800 in k2797 in file-read in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2771,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixwin.scm: 1014 ##sys#update-errno");
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2782 in file-close in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1015 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2730r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2730r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2730r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2747,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
C_trace("posixwin.scm: 1004 ##sys#expand-home-path");
t12=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k2761 in file-open in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1004 ##sys#make-c-string");
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2745 in file-open in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2750,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("posixwin.scm: 1006 ##sys#update-errno");
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2750(2,t5,C_SCHEME_UNDEFINED);}}

/* k2754 in k2745 in file-open in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 1007 ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2748 in k2745 in file-open in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2684r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2684r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2688,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("posixwin.scm: 935  ##sys#update-errno");
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2686 in posix-error in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2699,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2697 in k2686 in posix-error in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixwin.scm: 936  string-append");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k2693 in k2686 in posix-error in k2670 in k2667 in k2664 in k2661 in k2658 in k2655 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[508] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_2657posixwin.scm",(void*)f_2657},
{"f_2660posixwin.scm",(void*)f_2660},
{"f_2663posixwin.scm",(void*)f_2663},
{"f_2666posixwin.scm",(void*)f_2666},
{"f_2669posixwin.scm",(void*)f_2669},
{"f_2672posixwin.scm",(void*)f_2672},
{"f_3058posixwin.scm",(void*)f_3058},
{"f_3062posixwin.scm",(void*)f_3062},
{"f_3066posixwin.scm",(void*)f_3066},
{"f_3070posixwin.scm",(void*)f_3070},
{"f_3074posixwin.scm",(void*)f_3074},
{"f_3078posixwin.scm",(void*)f_3078},
{"f_4331posixwin.scm",(void*)f_4331},
{"f_6888posixwin.scm",(void*)f_6888},
{"f_6318posixwin.scm",(void*)f_6318},
{"f_6878posixwin.scm",(void*)f_6878},
{"f_6321posixwin.scm",(void*)f_6321},
{"f_6868posixwin.scm",(void*)f_6868},
{"f_6324posixwin.scm",(void*)f_6324},
{"f_6858posixwin.scm",(void*)f_6858},
{"f_6327posixwin.scm",(void*)f_6327},
{"f_6848posixwin.scm",(void*)f_6848},
{"f_6330posixwin.scm",(void*)f_6330},
{"f_6838posixwin.scm",(void*)f_6838},
{"f_6333posixwin.scm",(void*)f_6333},
{"f_6828posixwin.scm",(void*)f_6828},
{"f_6336posixwin.scm",(void*)f_6336},
{"f_6818posixwin.scm",(void*)f_6818},
{"f_6339posixwin.scm",(void*)f_6339},
{"f_6808posixwin.scm",(void*)f_6808},
{"f_6342posixwin.scm",(void*)f_6342},
{"f_6798posixwin.scm",(void*)f_6798},
{"f_6345posixwin.scm",(void*)f_6345},
{"f_6788posixwin.scm",(void*)f_6788},
{"f_6348posixwin.scm",(void*)f_6348},
{"f_6778posixwin.scm",(void*)f_6778},
{"f_6351posixwin.scm",(void*)f_6351},
{"f_6768posixwin.scm",(void*)f_6768},
{"f_6354posixwin.scm",(void*)f_6354},
{"f_6758posixwin.scm",(void*)f_6758},
{"f_6357posixwin.scm",(void*)f_6357},
{"f_6748posixwin.scm",(void*)f_6748},
{"f_6360posixwin.scm",(void*)f_6360},
{"f_6738posixwin.scm",(void*)f_6738},
{"f_6363posixwin.scm",(void*)f_6363},
{"f_6728posixwin.scm",(void*)f_6728},
{"f_6366posixwin.scm",(void*)f_6366},
{"f_6718posixwin.scm",(void*)f_6718},
{"f_6369posixwin.scm",(void*)f_6369},
{"f_6708posixwin.scm",(void*)f_6708},
{"f_6372posixwin.scm",(void*)f_6372},
{"f_6698posixwin.scm",(void*)f_6698},
{"f_6375posixwin.scm",(void*)f_6375},
{"f_6688posixwin.scm",(void*)f_6688},
{"f_6378posixwin.scm",(void*)f_6378},
{"f_6678posixwin.scm",(void*)f_6678},
{"f_6381posixwin.scm",(void*)f_6381},
{"f_6668posixwin.scm",(void*)f_6668},
{"f_6384posixwin.scm",(void*)f_6384},
{"f_6658posixwin.scm",(void*)f_6658},
{"f_6387posixwin.scm",(void*)f_6387},
{"f_6648posixwin.scm",(void*)f_6648},
{"f_6390posixwin.scm",(void*)f_6390},
{"f_6638posixwin.scm",(void*)f_6638},
{"f_6393posixwin.scm",(void*)f_6393},
{"f_6628posixwin.scm",(void*)f_6628},
{"f_6396posixwin.scm",(void*)f_6396},
{"f_6618posixwin.scm",(void*)f_6618},
{"f_6399posixwin.scm",(void*)f_6399},
{"f_6608posixwin.scm",(void*)f_6608},
{"f_6402posixwin.scm",(void*)f_6402},
{"f_6598posixwin.scm",(void*)f_6598},
{"f_6405posixwin.scm",(void*)f_6405},
{"f_6588posixwin.scm",(void*)f_6588},
{"f_6408posixwin.scm",(void*)f_6408},
{"f_6578posixwin.scm",(void*)f_6578},
{"f_6411posixwin.scm",(void*)f_6411},
{"f_6568posixwin.scm",(void*)f_6568},
{"f_6414posixwin.scm",(void*)f_6414},
{"f_6558posixwin.scm",(void*)f_6558},
{"f_6417posixwin.scm",(void*)f_6417},
{"f_6548posixwin.scm",(void*)f_6548},
{"f_6420posixwin.scm",(void*)f_6420},
{"f_6538posixwin.scm",(void*)f_6538},
{"f_6423posixwin.scm",(void*)f_6423},
{"f_6528posixwin.scm",(void*)f_6528},
{"f_6426posixwin.scm",(void*)f_6426},
{"f_6518posixwin.scm",(void*)f_6518},
{"f_6429posixwin.scm",(void*)f_6429},
{"f_6508posixwin.scm",(void*)f_6508},
{"f_6432posixwin.scm",(void*)f_6432},
{"f_6498posixwin.scm",(void*)f_6498},
{"f_6435posixwin.scm",(void*)f_6435},
{"f_6488posixwin.scm",(void*)f_6488},
{"f_6438posixwin.scm",(void*)f_6438},
{"f_6478posixwin.scm",(void*)f_6478},
{"f_6441posixwin.scm",(void*)f_6441},
{"f_6468posixwin.scm",(void*)f_6468},
{"f_6444posixwin.scm",(void*)f_6444},
{"f_6450posixwin.scm",(void*)f_6450},
{"f_6447posixwin.scm",(void*)f_6447},
{"f_6097posixwin.scm",(void*)f_6097},
{"f_6248posixwin.scm",(void*)f_6248},
{"f_6254posixwin.scm",(void*)f_6254},
{"f_6243posixwin.scm",(void*)f_6243},
{"f_6238posixwin.scm",(void*)f_6238},
{"f_6099posixwin.scm",(void*)f_6099},
{"f_6225posixwin.scm",(void*)f_6225},
{"f_6233posixwin.scm",(void*)f_6233},
{"f_6106posixwin.scm",(void*)f_6106},
{"f_6213posixwin.scm",(void*)f_6213},
{"f_6116posixwin.scm",(void*)f_6116},
{"f_6118posixwin.scm",(void*)f_6118},
{"f_6137posixwin.scm",(void*)f_6137},
{"f_6199posixwin.scm",(void*)f_6199},
{"f_6206posixwin.scm",(void*)f_6206},
{"f_6193posixwin.scm",(void*)f_6193},
{"f_6152posixwin.scm",(void*)f_6152},
{"f_6183posixwin.scm",(void*)f_6183},
{"f_6169posixwin.scm",(void*)f_6169},
{"f_6181posixwin.scm",(void*)f_6181},
{"f_6177posixwin.scm",(void*)f_6177},
{"f_6164posixwin.scm",(void*)f_6164},
{"f_6162posixwin.scm",(void*)f_6162},
{"f_6217posixwin.scm",(void*)f_6217},
{"f_6082posixwin.scm",(void*)f_6082},
{"f_6092posixwin.scm",(void*)f_6092},
{"f_6051posixwin.scm",(void*)f_6051},
{"f_6077posixwin.scm",(void*)f_6077},
{"f_6062posixwin.scm",(void*)f_6062},
{"f_6066posixwin.scm",(void*)f_6066},
{"f_6070posixwin.scm",(void*)f_6070},
{"f_6074posixwin.scm",(void*)f_6074},
{"f_6039posixwin.scm",(void*)f_6039},
{"f_6036posixwin.scm",(void*)f_6036},
{"f_5976posixwin.scm",(void*)f_5976},
{"f_6003posixwin.scm",(void*)f_6003},
{"f_6013posixwin.scm",(void*)f_6013},
{"f_5997posixwin.scm",(void*)f_5997},
{"f_5964posixwin.scm",(void*)f_5964},
{"f_5884posixwin.scm",(void*)f_5884},
{"f_5901posixwin.scm",(void*)f_5901},
{"f_5896posixwin.scm",(void*)f_5896},
{"f_5891posixwin.scm",(void*)f_5891},
{"f_5886posixwin.scm",(void*)f_5886},
{"f_5804posixwin.scm",(void*)f_5804},
{"f_5821posixwin.scm",(void*)f_5821},
{"f_5816posixwin.scm",(void*)f_5816},
{"f_5811posixwin.scm",(void*)f_5811},
{"f_5806posixwin.scm",(void*)f_5806},
{"f_5742posixwin.scm",(void*)f_5742},
{"f_5798posixwin.scm",(void*)f_5798},
{"f_5802posixwin.scm",(void*)f_5802},
{"f_5763posixwin.scm",(void*)f_5763},
{"f_5766posixwin.scm",(void*)f_5766},
{"f_5777posixwin.scm",(void*)f_5777},
{"f_5771posixwin.scm",(void*)f_5771},
{"f_5744posixwin.scm",(void*)f_5744},
{"f_5753posixwin.scm",(void*)f_5753},
{"f_5623posixwin.scm",(void*)f_5623},
{"f_5627posixwin.scm",(void*)f_5627},
{"f_5718posixwin.scm",(void*)f_5718},
{"f_5630posixwin.scm",(void*)f_5630},
{"f_5686posixwin.scm",(void*)f_5686},
{"f_5690posixwin.scm",(void*)f_5690},
{"f_5694posixwin.scm",(void*)f_5694},
{"f_5698posixwin.scm",(void*)f_5698},
{"f_5702posixwin.scm",(void*)f_5702},
{"f_5565posixwin.scm",(void*)f_5565},
{"f_5569posixwin.scm",(void*)f_5569},
{"f_5679posixwin.scm",(void*)f_5679},
{"f_5659posixwin.scm",(void*)f_5659},
{"f_5663posixwin.scm",(void*)f_5663},
{"f_5667posixwin.scm",(void*)f_5667},
{"f_5557posixwin.scm",(void*)f_5557},
{"f_5528posixwin.scm",(void*)f_5528},
{"f_5545posixwin.scm",(void*)f_5545},
{"f_5549posixwin.scm",(void*)f_5549},
{"f_5522posixwin.scm",(void*)f_5522},
{"f_5501posixwin.scm",(void*)f_5501},
{"f_5505posixwin.scm",(void*)f_5505},
{"f_5517posixwin.scm",(void*)f_5517},
{"f_5498posixwin.scm",(void*)f_5498},
{"f_5411posixwin.scm",(void*)f_5411},
{"f_5435posixwin.scm",(void*)f_5435},
{"f_5430posixwin.scm",(void*)f_5430},
{"f_5425posixwin.scm",(void*)f_5425},
{"f_5413posixwin.scm",(void*)f_5413},
{"f_5417posixwin.scm",(void*)f_5417},
{"f_5324posixwin.scm",(void*)f_5324},
{"f_5348posixwin.scm",(void*)f_5348},
{"f_5343posixwin.scm",(void*)f_5343},
{"f_5338posixwin.scm",(void*)f_5338},
{"f_5326posixwin.scm",(void*)f_5326},
{"f_5330posixwin.scm",(void*)f_5330},
{"f_5309posixwin.scm",(void*)f_5309},
{"f_5313posixwin.scm",(void*)f_5313},
{"f_5276posixwin.scm",(void*)f_5276},
{"f_5283posixwin.scm",(void*)f_5283},
{"f_5286posixwin.scm",(void*)f_5286},
{"f_5303posixwin.scm",(void*)f_5303},
{"f_5289posixwin.scm",(void*)f_5289},
{"f_5292posixwin.scm",(void*)f_5292},
{"f_5299posixwin.scm",(void*)f_5299},
{"f_5226posixwin.scm",(void*)f_5226},
{"f_5238posixwin.scm",(void*)f_5238},
{"f_5257posixwin.scm",(void*)f_5257},
{"f_5209posixwin.scm",(void*)f_5209},
{"f_5192posixwin.scm",(void*)f_5192},
{"f_5113posixwin.scm",(void*)f_5113},
{"f_5156posixwin.scm",(void*)f_5156},
{"f_5187posixwin.scm",(void*)f_5187},
{"f_5184posixwin.scm",(void*)f_5184},
{"f_5118posixwin.scm",(void*)f_5118},
{"f_5122posixwin.scm",(void*)f_5122},
{"f_5127posixwin.scm",(void*)f_5127},
{"f_5151posixwin.scm",(void*)f_5151},
{"f_5140posixwin.scm",(void*)f_5140},
{"f_4998posixwin.scm",(void*)f_4998},
{"f_5004posixwin.scm",(void*)f_5004},
{"f_5025posixwin.scm",(void*)f_5025},
{"f_5102posixwin.scm",(void*)f_5102},
{"f_5029posixwin.scm",(void*)f_5029},
{"f_5032posixwin.scm",(void*)f_5032},
{"f_5035posixwin.scm",(void*)f_5035},
{"f_5042posixwin.scm",(void*)f_5042},
{"f_5044posixwin.scm",(void*)f_5044},
{"f_5061posixwin.scm",(void*)f_5061},
{"f_5071posixwin.scm",(void*)f_5071},
{"f_5075posixwin.scm",(void*)f_5075},
{"f_5019posixwin.scm",(void*)f_5019},
{"f_4939posixwin.scm",(void*)f_4939},
{"f_4943posixwin.scm",(void*)f_4943},
{"f_4949posixwin.scm",(void*)f_4949},
{"f_4933posixwin.scm",(void*)f_4933},
{"f_4937posixwin.scm",(void*)f_4937},
{"f_4917posixwin.scm",(void*)f_4917},
{"f_4905posixwin.scm",(void*)f_4905},
{"f_4877posixwin.scm",(void*)f_4877},
{"f_4884posixwin.scm",(void*)f_4884},
{"f_4797posixwin.scm",(void*)f_4797},
{"f_4801posixwin.scm",(void*)f_4801},
{"f_4807posixwin.scm",(void*)f_4807},
{"f_4829posixwin.scm",(void*)f_4829},
{"f_4826posixwin.scm",(void*)f_4826},
{"f_4816posixwin.scm",(void*)f_4816},
{"f_4764posixwin.scm",(void*)f_4764},
{"f_4768posixwin.scm",(void*)f_4768},
{"f_4745posixwin.scm",(void*)f_4745},
{"f_4736posixwin.scm",(void*)f_4736},
{"f_4671posixwin.scm",(void*)f_4671},
{"f_4677posixwin.scm",(void*)f_4677},
{"f_4681posixwin.scm",(void*)f_4681},
{"f_4689posixwin.scm",(void*)f_4689},
{"f_4715posixwin.scm",(void*)f_4715},
{"f_4719posixwin.scm",(void*)f_4719},
{"f_4707posixwin.scm",(void*)f_4707},
{"f_4651posixwin.scm",(void*)f_4651},
{"f_4659posixwin.scm",(void*)f_4659},
{"f_4634posixwin.scm",(void*)f_4634},
{"f_4645posixwin.scm",(void*)f_4645},
{"f_4649posixwin.scm",(void*)f_4649},
{"f_4604posixwin.scm",(void*)f_4604},
{"f_4611posixwin.scm",(void*)f_4611},
{"f_4620posixwin.scm",(void*)f_4620},
{"f_4614posixwin.scm",(void*)f_4614},
{"f_4569posixwin.scm",(void*)f_4569},
{"f_4573posixwin.scm",(void*)f_4573},
{"f_4602posixwin.scm",(void*)f_4602},
{"f_4588posixwin.scm",(void*)f_4588},
{"f_4582posixwin.scm",(void*)f_4582},
{"f_4555posixwin.scm",(void*)f_4555},
{"f_4567posixwin.scm",(void*)f_4567},
{"f_4541posixwin.scm",(void*)f_4541},
{"f_4553posixwin.scm",(void*)f_4553},
{"f_4523posixwin.scm",(void*)f_4523},
{"f_4527posixwin.scm",(void*)f_4527},
{"f_4539posixwin.scm",(void*)f_4539},
{"f_4486posixwin.scm",(void*)f_4486},
{"f_4494posixwin.scm",(void*)f_4494},
{"f_4477posixwin.scm",(void*)f_4477},
{"f_4471posixwin.scm",(void*)f_4471},
{"f_4465posixwin.scm",(void*)f_4465},
{"f_4441posixwin.scm",(void*)f_4441},
{"f_4463posixwin.scm",(void*)f_4463},
{"f_4459posixwin.scm",(void*)f_4459},
{"f_4451posixwin.scm",(void*)f_4451},
{"f_4411posixwin.scm",(void*)f_4411},
{"f_4439posixwin.scm",(void*)f_4439},
{"f_4435posixwin.scm",(void*)f_4435},
{"f_4427posixwin.scm",(void*)f_4427},
{"f_4355posixwin.scm",(void*)f_4355},
{"f_4365posixwin.scm",(void*)f_4365},
{"f_4342posixwin.scm",(void*)f_4342},
{"f_4333posixwin.scm",(void*)f_4333},
{"f_4257posixwin.scm",(void*)f_4257},
{"f_4261posixwin.scm",(void*)f_4261},
{"f_4273posixwin.scm",(void*)f_4273},
{"f_4264posixwin.scm",(void*)f_4264},
{"f_4237posixwin.scm",(void*)f_4237},
{"f_4241posixwin.scm",(void*)f_4241},
{"f_4247posixwin.scm",(void*)f_4247},
{"f_4251posixwin.scm",(void*)f_4251},
{"f_4217posixwin.scm",(void*)f_4217},
{"f_4221posixwin.scm",(void*)f_4221},
{"f_4227posixwin.scm",(void*)f_4227},
{"f_4231posixwin.scm",(void*)f_4231},
{"f_4193posixwin.scm",(void*)f_4193},
{"f_4197posixwin.scm",(void*)f_4197},
{"f_4208posixwin.scm",(void*)f_4208},
{"f_4212posixwin.scm",(void*)f_4212},
{"f_4202posixwin.scm",(void*)f_4202},
{"f_4169posixwin.scm",(void*)f_4169},
{"f_4173posixwin.scm",(void*)f_4173},
{"f_4184posixwin.scm",(void*)f_4184},
{"f_4188posixwin.scm",(void*)f_4188},
{"f_4178posixwin.scm",(void*)f_4178},
{"f_4150posixwin.scm",(void*)f_4150},
{"f_4154posixwin.scm",(void*)f_4154},
{"f_4157posixwin.scm",(void*)f_4157},
{"f_4114posixwin.scm",(void*)f_4114},
{"f_4145posixwin.scm",(void*)f_4145},
{"f_4135posixwin.scm",(void*)f_4135},
{"f_4128posixwin.scm",(void*)f_4128},
{"f_4078posixwin.scm",(void*)f_4078},
{"f_4109posixwin.scm",(void*)f_4109},
{"f_4099posixwin.scm",(void*)f_4099},
{"f_4092posixwin.scm",(void*)f_4092},
{"f_4060posixwin.scm",(void*)f_4060},
{"f_4064posixwin.scm",(void*)f_4064},
{"f_4076posixwin.scm",(void*)f_4076},
{"f_4054posixwin.scm",(void*)f_4054},
{"f_4042posixwin.scm",(void*)f_4042},
{"f_3685posixwin.scm",(void*)f_3685},
{"f_4032posixwin.scm",(void*)f_4032},
{"f_3831posixwin.scm",(void*)f_3831},
{"f_4018posixwin.scm",(void*)f_4018},
{"f_4007posixwin.scm",(void*)f_4007},
{"f_4014posixwin.scm",(void*)f_4014},
{"f_3861posixwin.scm",(void*)f_3861},
{"f_4000posixwin.scm",(void*)f_4000},
{"f_3979posixwin.scm",(void*)f_3979},
{"f_3996posixwin.scm",(void*)f_3996},
{"f_3985posixwin.scm",(void*)f_3985},
{"f_3992posixwin.scm",(void*)f_3992},
{"f_3903posixwin.scm",(void*)f_3903},
{"f_3976posixwin.scm",(void*)f_3976},
{"f_3955posixwin.scm",(void*)f_3955},
{"f_3972posixwin.scm",(void*)f_3972},
{"f_3961posixwin.scm",(void*)f_3961},
{"f_3968posixwin.scm",(void*)f_3968},
{"f_3909posixwin.scm",(void*)f_3909},
{"f_3952posixwin.scm",(void*)f_3952},
{"f_3948posixwin.scm",(void*)f_3948},
{"f_3941posixwin.scm",(void*)f_3941},
{"f_3937posixwin.scm",(void*)f_3937},
{"f_3916posixwin.scm",(void*)f_3916},
{"f_3920posixwin.scm",(void*)f_3920},
{"f_3897posixwin.scm",(void*)f_3897},
{"f_3884posixwin.scm",(void*)f_3884},
{"f_3868posixwin.scm",(void*)f_3868},
{"f_3872posixwin.scm",(void*)f_3872},
{"f_3876posixwin.scm",(void*)f_3876},
{"f_3855posixwin.scm",(void*)f_3855},
{"f_3842posixwin.scm",(void*)f_3842},
{"f_3838posixwin.scm",(void*)f_3838},
{"f_3825posixwin.scm",(void*)f_3825},
{"f_3692posixwin.scm",(void*)f_3692},
{"f_3811posixwin.scm",(void*)f_3811},
{"f_3699posixwin.scm",(void*)f_3699},
{"f_3701posixwin.scm",(void*)f_3701},
{"f_3708posixwin.scm",(void*)f_3708},
{"f_3783posixwin.scm",(void*)f_3783},
{"f_3792posixwin.scm",(void*)f_3792},
{"f_3780posixwin.scm",(void*)f_3780},
{"f_3714posixwin.scm",(void*)f_3714},
{"f_3761posixwin.scm",(void*)f_3761},
{"f_3749posixwin.scm",(void*)f_3749},
{"f_3757posixwin.scm",(void*)f_3757},
{"f_3753posixwin.scm",(void*)f_3753},
{"f_3730posixwin.scm",(void*)f_3730},
{"f_3738posixwin.scm",(void*)f_3738},
{"f_3734posixwin.scm",(void*)f_3734},
{"f_3629posixwin.scm",(void*)f_3629},
{"f_3638posixwin.scm",(void*)f_3638},
{"f_3662posixwin.scm",(void*)f_3662},
{"f_3674posixwin.scm",(void*)f_3674},
{"f_3680posixwin.scm",(void*)f_3680},
{"f_3668posixwin.scm",(void*)f_3668},
{"f_3644posixwin.scm",(void*)f_3644},
{"f_3650posixwin.scm",(void*)f_3650},
{"f_3636posixwin.scm",(void*)f_3636},
{"f_3618posixwin.scm",(void*)f_3618},
{"f_3613posixwin.scm",(void*)f_3613},
{"f_3562posixwin.scm",(void*)f_3562},
{"f_3566posixwin.scm",(void*)f_3566},
{"f_3575posixwin.scm",(void*)f_3575},
{"f_3578posixwin.scm",(void*)f_3578},
{"f_3535posixwin.scm",(void*)f_3535},
{"f_3560posixwin.scm",(void*)f_3560},
{"f_3556posixwin.scm",(void*)f_3556},
{"f_3542posixwin.scm",(void*)f_3542},
{"f_3375posixwin.scm",(void*)f_3375},
{"f_3483posixwin.scm",(void*)f_3483},
{"f_3491posixwin.scm",(void*)f_3491},
{"f_3478posixwin.scm",(void*)f_3478},
{"f_3377posixwin.scm",(void*)f_3377},
{"f_3384posixwin.scm",(void*)f_3384},
{"f_3387posixwin.scm",(void*)f_3387},
{"f_3390posixwin.scm",(void*)f_3390},
{"f_3477posixwin.scm",(void*)f_3477},
{"f_3394posixwin.scm",(void*)f_3394},
{"f_3411posixwin.scm",(void*)f_3411},
{"f_3421posixwin.scm",(void*)f_3421},
{"f_3433posixwin.scm",(void*)f_3433},
{"f_3443posixwin.scm",(void*)f_3443},
{"f_3403posixwin.scm",(void*)f_3403},
{"f_3348posixwin.scm",(void*)f_3348},
{"f_3373posixwin.scm",(void*)f_3373},
{"f_3369posixwin.scm",(void*)f_3369},
{"f_3361posixwin.scm",(void*)f_3361},
{"f_3321posixwin.scm",(void*)f_3321},
{"f_3346posixwin.scm",(void*)f_3346},
{"f_3342posixwin.scm",(void*)f_3342},
{"f_3334posixwin.scm",(void*)f_3334},
{"f_3181posixwin.scm",(void*)f_3181},
{"f_3185posixwin.scm",(void*)f_3185},
{"f_3281posixwin.scm",(void*)f_3281},
{"f_3282posixwin.scm",(void*)f_3282},
{"f_3300posixwin.scm",(void*)f_3300},
{"f_3292posixwin.scm",(void*)f_3292},
{"f_3198posixwin.scm",(void*)f_3198},
{"f_3199posixwin.scm",(void*)f_3199},
{"f_3203posixwin.scm",(void*)f_3203},
{"f_3211posixwin.scm",(void*)f_3211},
{"f_3216posixwin.scm",(void*)f_3216},
{"f_3220posixwin.scm",(void*)f_3220},
{"f_3250posixwin.scm",(void*)f_3250},
{"f_3257posixwin.scm",(void*)f_3257},
{"f_3260posixwin.scm",(void*)f_3260},
{"f_3227posixwin.scm",(void*)f_3227},
{"f_3231posixwin.scm",(void*)f_3231},
{"f_3249posixwin.scm",(void*)f_3249},
{"f_3241posixwin.scm",(void*)f_3241},
{"f_3120posixwin.scm",(void*)f_3120},
{"f_3133posixwin.scm",(void*)f_3133},
{"f_3148posixwin.scm",(void*)f_3148},
{"f_3139posixwin.scm",(void*)f_3139},
{"f_3142posixwin.scm",(void*)f_3142},
{"f_3080posixwin.scm",(void*)f_3080},
{"f_3099posixwin.scm",(void*)f_3099},
{"f_3084posixwin.scm",(void*)f_3084},
{"f_3093posixwin.scm",(void*)f_3093},
{"f_3087posixwin.scm",(void*)f_3087},
{"f_3047posixwin.scm",(void*)f_3047},
{"f_3049posixwin.scm",(void*)f_3049},
{"f_3042posixwin.scm",(void*)f_3042},
{"f_3019posixwin.scm",(void*)f_3019},
{"f_3040posixwin.scm",(void*)f_3040},
{"f_3026posixwin.scm",(void*)f_3026},
{"f_3013posixwin.scm",(void*)f_3013},
{"f_3017posixwin.scm",(void*)f_3017},
{"f_3007posixwin.scm",(void*)f_3007},
{"f_3011posixwin.scm",(void*)f_3011},
{"f_3001posixwin.scm",(void*)f_3001},
{"f_3005posixwin.scm",(void*)f_3005},
{"f_2995posixwin.scm",(void*)f_2995},
{"f_2999posixwin.scm",(void*)f_2999},
{"f_2989posixwin.scm",(void*)f_2989},
{"f_2993posixwin.scm",(void*)f_2993},
{"f_2983posixwin.scm",(void*)f_2983},
{"f_2987posixwin.scm",(void*)f_2987},
{"f_2952posixwin.scm",(void*)f_2952},
{"f_2956posixwin.scm",(void*)f_2956},
{"f_2959posixwin.scm",(void*)f_2959},
{"f_2914posixwin.scm",(void*)f_2914},
{"f_2947posixwin.scm",(void*)f_2947},
{"f_2943posixwin.scm",(void*)f_2943},
{"f_2918posixwin.scm",(void*)f_2918},
{"f_2927posixwin.scm",(void*)f_2927},
{"f_2876posixwin.scm",(void*)f_2876},
{"f_2883posixwin.scm",(void*)f_2883},
{"f_2886posixwin.scm",(void*)f_2886},
{"f_2906posixwin.scm",(void*)f_2906},
{"f_2889posixwin.scm",(void*)f_2889},
{"f_2896posixwin.scm",(void*)f_2896},
{"f_2834posixwin.scm",(void*)f_2834},
{"f_2841posixwin.scm",(void*)f_2841},
{"f_2856posixwin.scm",(void*)f_2856},
{"f_2850posixwin.scm",(void*)f_2850},
{"f_2789posixwin.scm",(void*)f_2789},
{"f_2799posixwin.scm",(void*)f_2799},
{"f_2802posixwin.scm",(void*)f_2802},
{"f_2814posixwin.scm",(void*)f_2814},
{"f_2805posixwin.scm",(void*)f_2805},
{"f_2771posixwin.scm",(void*)f_2771},
{"f_2784posixwin.scm",(void*)f_2784},
{"f_2730posixwin.scm",(void*)f_2730},
{"f_2763posixwin.scm",(void*)f_2763},
{"f_2747posixwin.scm",(void*)f_2747},
{"f_2756posixwin.scm",(void*)f_2756},
{"f_2750posixwin.scm",(void*)f_2750},
{"f_2684posixwin.scm",(void*)f_2684},
{"f_2688posixwin.scm",(void*)f_2688},
{"f_2699posixwin.scm",(void*)f_2699},
{"f_2695posixwin.scm",(void*)f_2695},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
