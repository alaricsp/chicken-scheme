/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-08 10:27
   Version 4.0.0x4 - SVN rev. 12690
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-12-01 on dill (Linux)
   command line: posixwin.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[392];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,56,57,32,102,108,97,103,115,57,48,32,46,32,109,111,100,101,57,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,49,52,32,115,105,122,101,49,49,53,32,46,32,98,117,102,102,101,114,49,49,54,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,49,51,52,32,98,117,102,102,101,114,49,51,53,32,46,32,115,105,122,101,49,51,54,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,20),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,56,56,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,115,116,97,116,32,102,50,49,48,32,46,32,116,109,112,50,48,57,50,49,49,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,50,55,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,50,51,50,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,51,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,52,50,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,50,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,50,53,55,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,102,95,51,48,51,49,32,102,110,97,109,101,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,115,116,97,116,45,116,121,112,101,32,110,97,109,101,50,55,49,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,50,56,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,48,48,32,112,111,115,51,48,49,32,46,32,119,104,101,110,99,101,51,48,50,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,49,51,32,110,97,109,101,51,55,49,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,51,50,32,110,97,109,101,51,54,53,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,48,50,32,110,97,109,101,51,54,49,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,51,49,57,50,32,120,51,53,57,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,102,95,51,49,56,49,32,110,97,109,101,51,53,49,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,54,52,32,110,97,109,101,51,55,55,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,51,56,32,46,32,116,109,112,51,51,55,51,51,57,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,49,55,32,115,112,101,99,52,50,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,56,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,48,32,37,115,112,101,99,52,49,53,52,55,52,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,49,57,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,48,55,52,48,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,56,57,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,53,48,52,53,48,53,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,53,53,48,53,53,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,51,54,51,49,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,97,51,54,50,53,32,101,120,118,97,114,53,54,52,53,56,48,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,51,54,52,57,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,51,54,54,49,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,97,51,54,53,53,32,46,32,97,114,103,115,53,55,51,53,57,56,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,51,54,52,51,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,97,51,54,49,57,32,107,53,55,50,53,55,56,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,54,50,55,32,114,54,50,56,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,54,48,50,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,54,52,48,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,54,52,50,32,105,110,112,54,52,51,32,114,54,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,53,48,32,46,32,109,54,53,49,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,54,51,32,46,32,109,54,54,52,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,57,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,97,52,49,54,53,32,46,32,114,101,115,117,108,116,115,55,48,51,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,57,54,32,112,114,111,99,54,57,55,32,46,32,109,111,100,101,54,57,56,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,49,56,51,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,20),40,97,52,49,56,57,32,46,32,114,101,115,117,108,116,115,55,49,51,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,55,48,54,32,112,114,111,99,55,48,55,32,46,32,109,111,100,101,55,48,56,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,97,52,50,48,56,32,46,32,114,101,115,117,108,116,115,55,50,51,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,55,49,54,32,116,104,117,110,107,55,49,55,32,46,32,109,111,100,101,55,49,56,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,52,50,50,56,32,46,32,114,101,115,117,108,116,115,55,51,53,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,55,50,56,32,116,104,117,110,107,55,50,57,32,46,32,109,111,100,101,55,51,48,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,116,109,112,55,53,49,55,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,56,48,55,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,56,49,48,32,112,114,111,99,56,49,49,41,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,56,49,55,32,115,116,97,116,101,56,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,57,48,51,32,109,57,48,52,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,57,49,55,32,97,99,99,57,49,56,32,108,111,99,57,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,50,55,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,50,57,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,57,52,55,32,109,57,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,57,54,54,32,105,110,112,57,54,55,32,114,57,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,57,55,52,32,46,32,109,57,55,53,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,57,55,56,32,46,32,109,57,55,57,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,57,56,54,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,57,57,54,32,46,32,110,101,119,57,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,48,49,48,32,118,97,108,49,48,49,49,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,48,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,48,52,50,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,48,51,54,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,49,48,53,49,32,116,109,49,48,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,49,48,53,57,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,49,48,54,52,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,49,48,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,49,48,55,32,46,32,116,109,112,49,49,48,54,49,49,48,56,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,49,51,50,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,49,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,49,54,49,32,109,111,100,101,49,49,54,50,32,46,32,115,105,122,101,49,49,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,52,57,57,52,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,50,50,57,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,55),40,97,53,48,48,48,32,100,105,114,49,49,57,55,49,49,57,56,49,50,48,53,32,102,105,108,49,49,57,57,49,50,48,48,49,50,48,54,32,101,120,116,49,50,48,49,49,50,48,50,49,50,48,55,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,49,57,50,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,49,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,56,48,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,49,50,55,52,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,108,115,116,49,50,57,52,32,111,108,115,116,49,50,57,53,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,37),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,49,50,55,48,32,101,120,97,99,116,102,49,50,55,49,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,38),40,115,101,116,97,114,103,32,97,49,51,48,56,49,51,49,50,32,97,49,51,48,55,49,51,49,51,32,97,49,51,48,54,49,51,49,52,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,38),40,115,101,116,101,110,118,32,97,49,51,50,48,49,51,50,52,32,97,49,51,49,57,49,51,50,53,32,97,49,51,49,56,49,51,50,54,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,51,53,32,108,49,51,52,49,32,105,49,51,52,50,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,61),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,49,51,51,48,32,108,115,116,49,51,51,49,32,97,114,103,118,101,99,45,115,101,116,116,101,114,49,51,51,50,32,105,100,120,49,51,51,51,41,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,67),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,49,51,53,51,32,102,105,108,101,110,97,109,101,49,51,53,52,32,97,114,103,108,115,116,49,51,53,53,32,101,110,118,108,115,116,49,51,53,54,32,101,120,97,99,116,102,49,51,53,55,41,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,53),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,49,51,54,56,32,109,115,103,49,51,54,57,32,102,105,108,101,110,97,109,101,49,51,55,48,32,114,101,115,49,51,55,49,41,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,51,57,53,32,97,114,103,108,115,116,49,52,48,54,32,101,110,118,108,115,116,49,52,48,55,32,101,120,97,99,116,102,49,52,48,56,41,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,51,57,57,32,37,97,114,103,108,115,116,49,51,57,50,49,52,49,52,32,37,101,110,118,108,115,116,49,51,57,51,49,52,49,53,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,51,57,56,32,37,97,114,103,108,115,116,49,51,57,50,49,52,49,57,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,51,57,55,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,51,56,52,32,46,32,116,109,112,49,51,56,51,49,51,56,53,41,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,52,53,53,32,97,114,103,108,115,116,49,52,54,54,32,101,110,118,108,115,116,49,52,54,55,32,101,120,97,99,116,102,49,52,54,56,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,53,57,32,37,97,114,103,108,115,116,49,52,53,50,49,52,55,52,32,37,101,110,118,108,115,116,49,52,53,51,49,52,55,53,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,53,56,32,37,97,114,103,108,115,116,49,52,53,50,49,52,55,57,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,52,53,55,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,51),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,49,52,52,51,32,102,105,108,101,110,97,109,101,49,52,52,52,32,46,32,116,109,112,49,52,52,50,49,52,52,53,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,53,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,53,49,56,32,46,32,97,114,103,115,49,53,49,57,41,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,97),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,53,55,53,32,99,109,100,49,53,55,54,32,97,114,103,115,49,53,55,55,32,101,110,118,49,53,55,56,32,115,116,100,111,117,116,102,49,53,55,57,32,115,116,100,105,110,102,49,53,56,48,32,115,116,100,101,114,114,102,49,53,56,49,32,46,32,116,109,112,49,53,55,52,49,53,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,21),40,97,53,55,50,53,32,103,49,54,55,51,49,54,55,52,49,54,55,53,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,54,54,54,41,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,7),40,97,53,55,52,51,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,38),40,97,53,55,52,57,32,105,110,49,54,56,54,32,111,117,116,49,54,56,55,32,112,105,100,49,54,56,56,32,101,114,114,49,54,56,57,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,63),40,37,112,114,111,99,101,115,115,32,108,111,99,49,54,53,56,32,101,114,114,63,49,54,53,57,32,99,109,100,49,54,54,48,32,97,114,103,115,49,54,54,49,32,101,110,118,49,54,54,50,32,101,120,97,99,116,102,49,54,54,51,41,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,49,50,32,97,114,103,115,49,55,50,51,32,101,110,118,49,55,50,52,32,101,120,97,99,116,102,49,55,50,53,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,49,54,32,37,97,114,103,115,49,55,48,57,49,55,50,57,32,37,101,110,118,49,55,49,48,49,55,51,48,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,49,53,32,37,97,114,103,115,49,55,48,57,49,55,51,52,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,49,52,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,49,55,48,49,32,46,32,116,109,112,49,55,48,48,49,55,48,50,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,54,55,32,97,114,103,115,49,55,55,56,32,101,110,118,49,55,55,57,32,101,120,97,99,116,102,49,55,56,48,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,55,49,32,37,97,114,103,115,49,55,54,52,49,55,56,52,32,37,101,110,118,49,55,54,53,49,55,56,53,41,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,55,48,32,37,97,114,103,115,49,55,54,52,49,55,56,57,41,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,54,57,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,49,55,53,54,32,46,32,116,109,112,49,55,53,53,49,55,53,55,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,48,57,32,110,111,104,97,110,103,49,56,49,48,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,53,57,54,57,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,97,53,57,55,53,32,101,112,105,100,49,56,51,50,32,101,110,111,114,109,49,56,51,51,32,101,99,111,100,101,49,56,51,52,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,49,51,32,46,32,97,114,103,115,49,56,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,13),40,115,108,101,101,112,32,116,49,56,51,57,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,14),40,102,95,54,49,57,48,32,120,49,57,48,54,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,7),40,97,54,49,51,54,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,7),40,97,54,49,52,49,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,7),40,97,54,49,53,53,41,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,57,49,50,32,114,49,57,49,51,41,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,48,54,32,46,32,95,49,57,48,50,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,16),40,102,95,54,49,57,56,32,46,32,95,49,57,48,48,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,56,55,52,32,97,99,116,105,111,110,49,56,56,53,32,105,100,49,56,56,54,32,108,105,109,105,116,49,56,56,55,41,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,56,55,56,32,37,97,99,116,105,111,110,49,56,55,49,49,57,53,51,32,37,105,100,49,56,55,50,49,57,53,52,41,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,56,55,55,32,37,97,99,116,105,111,110,49,56,55,49,49,57,53,56,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,19),40,97,54,50,50,54,32,120,49,57,54,51,32,121,49,57,54,52,41,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,56,55,54,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,56,54,50,32,112,114,101,100,49,56,54,51,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,56,54,52,41,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,13),40,102,105,102,111,63,32,95,50,51,55,48,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,50,51,55,52,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,52,49,32,110,97,109,101,50,51,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,53,49,32,110,97,109,101,50,51,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,54,49,32,110,97,109,101,50,51,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,55,49,32,110,97,109,101,50,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,56,49,32,110,97,109,101,50,51,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,57,49,32,110,97,109,101,50,51,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,48,49,32,110,97,109,101,50,51,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,49,49,32,110,97,109,101,50,50,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,50,49,32,110,97,109,101,50,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,51,49,32,110,97,109,101,50,50,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,52,49,32,110,97,109,101,50,50,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,53,49,32,110,97,109,101,50,50,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,54,49,32,110,97,109,101,50,50,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,55,49,32,110,97,109,101,50,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,56,49,32,110,97,109,101,50,50,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,57,49,32,110,97,109,101,50,50,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,48,49,32,110,97,109,101,50,50,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,49,49,32,110,97,109,101,50,50,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,50,49,32,110,97,109,101,50,49,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,51,49,32,110,97,109,101,50,49,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,52,49,32,110,97,109,101,50,49,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,53,49,32,110,97,109,101,50,49,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,54,49,32,110,97,109,101,50,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,55,49,32,110,97,109,101,50,49,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,56,49,32,110,97,109,101,50,49,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,57,49,32,110,97,109,101,50,49,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,48,49,32,110,97,109,101,50,49,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,49,49,32,110,97,109,101,50,49,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,50,49,32,110,97,109,101,50,49,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,51,49,32,110,97,109,101,50,48,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,52,49,32,110,97,109,101,50,48,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,53,49,32,110,97,109,101,50,48,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,54,49,32,110,97,109,101,50,48,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,55,49,32,110,97,109,101,50,48,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,56,49,32,110,97,109,101,50,48,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,57,49,32,110,97,109,101,50,48,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,48,49,32,110,97,109,101,50,48,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,49,49,32,110,97,109,101,50,48,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,50,49,32,110,97,109,101,50,48,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,51,49,32,110,97,109,101,50,48,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,52,49,32,110,97,109,101,49,57,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,53,49,32,110,97,109,101,49,57,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,54,49,32,110,97,109,101,49,57,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k5564 */
static C_word C_fcall stub1536(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1536(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from current-process-id in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static C_word C_fcall stub1496(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1496(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k5196 */
static C_word C_fcall stub1321(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1321(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k5179 */
static C_word C_fcall stub1309(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1309(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k4890 */
static C_word C_fcall stub1144(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1144(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1136(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1136(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (_daylight ? _tzname[1] : _tzname[0]);
return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub1093(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1093(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1085(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1085(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k4763 */
static C_word C_fcall stub1070(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1070(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4650 */
static C_word C_fcall stub1026(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1026(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2663 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6821)
static void C_ccall f_6821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6811)
static void C_ccall f_6811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6731)
static void C_ccall f_6731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6681)
static void C_ccall f_6681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6360)
static void C_ccall f_6360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6591)
static void C_ccall f_6591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6402)
static void C_ccall f_6402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6221)
static void C_fcall f_6221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6216)
static void C_fcall f_6216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6211)
static void C_fcall f_6211(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6072)
static void C_fcall f_6072(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6079)
static void C_fcall f_6079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6091)
static void C_fcall f_6091(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6142)
static void C_ccall f_6142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5874)
static void C_fcall f_5874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_fcall f_5869(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5864)
static void C_fcall f_5864(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5859)
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5794)
static void C_fcall f_5794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5784)
static void C_fcall f_5784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5779)
static void C_fcall f_5779(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5715)
static void C_fcall f_5715(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5717)
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5411)
static void C_fcall f_5411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_fcall f_5406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5401)
static void C_fcall f_5401(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5389)
static void C_fcall f_5389(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5324)
static void C_fcall f_5324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_fcall f_5319(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5314)
static void C_fcall f_5314(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5302)
static void C_fcall f_5302(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_fcall f_5285(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_fcall f_5252(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_fcall f_5202(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5214)
static void C_fcall f_5214(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5089)
static void C_fcall f_5089(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5132)
static void C_fcall f_5132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_fcall f_5094(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_fcall f_5103(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4980)
static void C_fcall f_4980(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_fcall f_5020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4719)
static void C_fcall f_4719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_fcall f_4659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_fcall f_4671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4593)
static void C_fcall f_4593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_fcall f_4505(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4423)
static void C_fcall f_4423(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_fcall f_4042(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_fcall f_4036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static C_word C_fcall f_4024(C_word t0);
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_fcall f_3813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_fcall f_3843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_fcall f_3885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_fcall f_3762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_fcall f_3611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static C_word C_fcall f_3600(C_word t0);
C_noret_decl(f_3595)
static void C_fcall f_3595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3465)
static void C_fcall f_3465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_fcall f_3460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_fcall f_3393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_fcall f_3415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_fcall f_3029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_fcall f_2896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6221)
static void C_fcall trf_6221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6221(t0,t1);}

C_noret_decl(trf_6216)
static void C_fcall trf_6216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6216(t0,t1,t2);}

C_noret_decl(trf_6211)
static void C_fcall trf_6211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6211(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6211(t0,t1,t2,t3);}

C_noret_decl(trf_6072)
static void C_fcall trf_6072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6072(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6072(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6079)
static void C_fcall trf_6079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6079(t0,t1);}

C_noret_decl(trf_6091)
static void C_fcall trf_6091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6091(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6091(t0,t1,t2,t3);}

C_noret_decl(trf_5874)
static void C_fcall trf_5874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5874(t0,t1);}

C_noret_decl(trf_5869)
static void C_fcall trf_5869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5869(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5869(t0,t1,t2);}

C_noret_decl(trf_5864)
static void C_fcall trf_5864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5864(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5864(t0,t1,t2,t3);}

C_noret_decl(trf_5859)
static void C_fcall trf_5859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5859(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5859(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5794)
static void C_fcall trf_5794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5794(t0,t1);}

C_noret_decl(trf_5789)
static void C_fcall trf_5789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5789(t0,t1,t2);}

C_noret_decl(trf_5784)
static void C_fcall trf_5784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5784(t0,t1,t2,t3);}

C_noret_decl(trf_5779)
static void C_fcall trf_5779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5779(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5779(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5715)
static void C_fcall trf_5715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5715(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5715(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5717)
static void C_fcall trf_5717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5717(t0,t1,t2);}

C_noret_decl(trf_5411)
static void C_fcall trf_5411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5411(t0,t1);}

C_noret_decl(trf_5406)
static void C_fcall trf_5406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5406(t0,t1,t2);}

C_noret_decl(trf_5401)
static void C_fcall trf_5401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5401(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5401(t0,t1,t2,t3);}

C_noret_decl(trf_5389)
static void C_fcall trf_5389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5389(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5389(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5324)
static void C_fcall trf_5324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5324(t0,t1);}

C_noret_decl(trf_5319)
static void C_fcall trf_5319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5319(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5319(t0,t1,t2);}

C_noret_decl(trf_5314)
static void C_fcall trf_5314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5314(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5314(t0,t1,t2,t3);}

C_noret_decl(trf_5302)
static void C_fcall trf_5302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5302(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5302(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5285)
static void C_fcall trf_5285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5285(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5285(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5252)
static void C_fcall trf_5252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5252(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5252(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5202)
static void C_fcall trf_5202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5202(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5202(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5214)
static void C_fcall trf_5214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5214(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5214(t0,t1,t2,t3);}

C_noret_decl(trf_5089)
static void C_fcall trf_5089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5089(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5089(t0,t1,t2,t3);}

C_noret_decl(trf_5132)
static void C_fcall trf_5132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5132(t0,t1,t2,t3);}

C_noret_decl(trf_5094)
static void C_fcall trf_5094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5094(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5094(t0,t1,t2);}

C_noret_decl(trf_5103)
static void C_fcall trf_5103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5103(t0,t1,t2);}

C_noret_decl(trf_4980)
static void C_fcall trf_4980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4980(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4980(t0,t1,t2);}

C_noret_decl(trf_5020)
static void C_fcall trf_5020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5020(t0,t1,t2);}

C_noret_decl(trf_4719)
static void C_fcall trf_4719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4719(t0,t1,t2);}

C_noret_decl(trf_4659)
static void C_fcall trf_4659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4659(t0,t1,t2);}

C_noret_decl(trf_4671)
static void C_fcall trf_4671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4671(t0,t1,t2);}

C_noret_decl(trf_4593)
static void C_fcall trf_4593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4593(t0,t1);}

C_noret_decl(trf_4505)
static void C_fcall trf_4505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4505(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4505(t0,t1,t2,t3);}

C_noret_decl(trf_4468)
static void C_fcall trf_4468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4468(t0,t1,t2);}

C_noret_decl(trf_4423)
static void C_fcall trf_4423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4423(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4423(t0,t1,t2,t3);}

C_noret_decl(trf_4042)
static void C_fcall trf_4042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4042(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4042(t0,t1,t2,t3);}

C_noret_decl(trf_4036)
static void C_fcall trf_4036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4036(t0,t1);}

C_noret_decl(trf_3813)
static void C_fcall trf_3813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3813(t0,t1);}

C_noret_decl(trf_3843)
static void C_fcall trf_3843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3843(t0,t1);}

C_noret_decl(trf_3885)
static void C_fcall trf_3885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3885(t0,t1);}

C_noret_decl(trf_3683)
static void C_fcall trf_3683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3683(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3683(t0,t1,t2,t3);}

C_noret_decl(trf_3762)
static void C_fcall trf_3762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3762(t0,t1);}

C_noret_decl(trf_3611)
static void C_fcall trf_3611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3611(t0,t1);}

C_noret_decl(trf_3595)
static void C_fcall trf_3595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3595(t0,t1);}

C_noret_decl(trf_3465)
static void C_fcall trf_3465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3465(t0,t1);}

C_noret_decl(trf_3460)
static void C_fcall trf_3460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3460(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3460(t0,t1,t2);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3359(t0,t1,t2,t3);}

C_noret_decl(trf_3393)
static void C_fcall trf_3393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3393(t0,t1);}

C_noret_decl(trf_3415)
static void C_fcall trf_3415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3415(t0,t1);}

C_noret_decl(trf_3029)
static void C_fcall trf_3029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3029(t0,t1);}

C_noret_decl(trf_2896)
static void C_fcall trf_2896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2896(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3080)){
C_save(t1);
C_rereclaim2(3080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,392);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"open/rdonly");
lf[11]=C_h_intern(&lf[11],11,"open/wronly");
lf[12]=C_h_intern(&lf[12],9,"open/rdwr");
lf[13]=C_h_intern(&lf[13],9,"open/read");
lf[14]=C_h_intern(&lf[14],10,"open/write");
lf[15]=C_h_intern(&lf[15],10,"open/creat");
lf[16]=C_h_intern(&lf[16],11,"open/append");
lf[17]=C_h_intern(&lf[17],9,"open/excl");
lf[18]=C_h_intern(&lf[18],10,"open/trunc");
lf[19]=C_h_intern(&lf[19],11,"open/binary");
lf[20]=C_h_intern(&lf[20],9,"open/text");
lf[21]=C_h_intern(&lf[21],14,"open/noinherit");
lf[22]=C_h_intern(&lf[22],10,"perm/irusr");
lf[23]=C_h_intern(&lf[23],10,"perm/iwusr");
lf[24]=C_h_intern(&lf[24],10,"perm/ixusr");
lf[25]=C_h_intern(&lf[25],10,"perm/irgrp");
lf[26]=C_h_intern(&lf[26],10,"perm/iwgrp");
lf[27]=C_h_intern(&lf[27],10,"perm/ixgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iroth");
lf[29]=C_h_intern(&lf[29],10,"perm/iwoth");
lf[30]=C_h_intern(&lf[30],10,"perm/ixoth");
lf[31]=C_h_intern(&lf[31],10,"perm/irwxu");
lf[32]=C_h_intern(&lf[32],10,"perm/irwxg");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxo");
lf[34]=C_h_intern(&lf[34],9,"file-open");
lf[35]=C_h_intern(&lf[35],11,"\000file-error");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[37]=C_h_intern(&lf[37],17,"\003sysmake-c-string");
lf[38]=C_h_intern(&lf[38],20,"\003sysexpand-home-path");
lf[39]=C_h_intern(&lf[39],10,"file-close");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[41]=C_h_intern(&lf[41],11,"make-string");
lf[42]=C_h_intern(&lf[42],9,"file-read");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[44]=C_h_intern(&lf[44],11,"\000type-error");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[46]=C_h_intern(&lf[46],10,"file-write");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[49]=C_h_intern(&lf[49],13,"string-length");
lf[50]=C_h_intern(&lf[50],12,"file-mkstemp");
lf[51]=C_h_intern(&lf[51],13,"\003syssubstring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[53]=C_h_intern(&lf[53],8,"seek/set");
lf[54]=C_h_intern(&lf[54],8,"seek/end");
lf[55]=C_h_intern(&lf[55],8,"seek/cur");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[59]=C_h_intern(&lf[59],9,"file-stat");
lf[60]=C_h_intern(&lf[60],9,"\003syserror");
lf[61]=C_h_intern(&lf[61],9,"file-size");
lf[62]=C_h_intern(&lf[62],22,"file-modification-time");
lf[63]=C_h_intern(&lf[63],16,"file-access-time");
lf[64]=C_h_intern(&lf[64],16,"file-change-time");
lf[65]=C_h_intern(&lf[65],10,"file-owner");
lf[66]=C_h_intern(&lf[66],16,"file-permissions");
lf[67]=C_h_intern(&lf[67],13,"regular-file\077");
lf[68]=C_h_intern(&lf[68],13,"\003sysfile-info");
lf[69]=C_h_intern(&lf[69],14,"symbolic-link\077");
lf[70]=C_h_intern(&lf[70],13,"stat-regular\077");
lf[71]=C_h_intern(&lf[71],15,"stat-directory\077");
lf[72]=C_h_intern(&lf[72],17,"stat-char-device\077");
lf[73]=C_h_intern(&lf[73],18,"stat-block-device\077");
lf[74]=C_h_intern(&lf[74],10,"stat-fifo\077");
lf[75]=C_h_intern(&lf[75],13,"stat-symlink\077");
lf[76]=C_h_intern(&lf[76],12,"stat-socket\077");
lf[77]=C_h_intern(&lf[77],13,"file-position");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[79]=C_h_intern(&lf[79],6,"stream");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[81]=C_h_intern(&lf[81],5,"port\077");
lf[82]=C_h_intern(&lf[82],18,"set-file-position!");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[85]=C_h_intern(&lf[85],13,"\000bounds-error");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[87]=C_h_intern(&lf[87],16,"create-directory");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[89]=C_h_intern(&lf[89],12,"file-exists\077");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[91]=C_h_intern(&lf[91],12,"\003sysfor-each");
lf[92]=C_h_intern(&lf[92],12,"string-split");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[94]=C_h_intern(&lf[94],14,"canonical-path");
lf[95]=C_h_intern(&lf[95],16,"change-directory");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[97]=C_h_intern(&lf[97],16,"delete-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[99]=C_h_intern(&lf[99],6,"string");
lf[100]=C_h_intern(&lf[100],9,"directory");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[102]=C_h_intern(&lf[102],16,"\003sysmake-pointer");
lf[103]=C_h_intern(&lf[103],17,"current-directory");
lf[104]=C_h_intern(&lf[104],10,"directory\077");
lf[105]=C_h_intern(&lf[105],27,"\003sysplatform-fixup-pathname");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[107]=C_h_intern(&lf[107],5,"null\077");
lf[108]=C_h_intern(&lf[108],6,"char=\077");
lf[109]=C_h_intern(&lf[109],8,"string=\077");
lf[110]=C_h_intern(&lf[110],16,"char-alphabetic\077");
lf[111]=C_h_intern(&lf[111],10,"string-ref");
lf[112]=C_h_intern(&lf[112],18,"string-intersperse");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[114]=C_h_intern(&lf[114],17,"current-user-name");
lf[115]=C_h_intern(&lf[115],9,"condition");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[117]=C_h_intern(&lf[117],22,"with-exception-handler");
lf[118]=C_h_intern(&lf[118],30,"call-with-current-continuation");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_h_intern(&lf[120],7,"reverse");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[130]=C_h_intern(&lf[130],5,"\000text");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[133]=C_h_intern(&lf[133],13,"\003sysmake-port");
lf[134]=C_h_intern(&lf[134],21,"\003sysstream-port-class");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[136]=C_h_intern(&lf[136],15,"open-input-pipe");
lf[137]=C_h_intern(&lf[137],7,"\000binary");
lf[138]=C_h_intern(&lf[138],16,"open-output-pipe");
lf[139]=C_h_intern(&lf[139],16,"close-input-pipe");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[141]=C_h_intern(&lf[141],14,"\003syscheck-port");
lf[142]=C_h_intern(&lf[142],17,"close-output-pipe");
lf[143]=C_h_intern(&lf[143],20,"call-with-input-pipe");
lf[144]=C_h_intern(&lf[144],21,"call-with-output-pipe");
lf[145]=C_h_intern(&lf[145],20,"with-input-from-pipe");
lf[146]=C_h_intern(&lf[146],18,"\003sysstandard-input");
lf[147]=C_h_intern(&lf[147],19,"with-output-to-pipe");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],11,"create-pipe");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[151]=C_h_intern(&lf[151],11,"signal/term");
lf[152]=C_h_intern(&lf[152],10,"signal/int");
lf[153]=C_h_intern(&lf[153],10,"signal/fpe");
lf[154]=C_h_intern(&lf[154],10,"signal/ill");
lf[155]=C_h_intern(&lf[155],11,"signal/segv");
lf[156]=C_h_intern(&lf[156],11,"signal/abrt");
lf[157]=C_h_intern(&lf[157],12,"signal/break");
lf[158]=C_h_intern(&lf[158],11,"signal/alrm");
lf[159]=C_h_intern(&lf[159],11,"signal/chld");
lf[160]=C_h_intern(&lf[160],11,"signal/cont");
lf[161]=C_h_intern(&lf[161],10,"signal/hup");
lf[162]=C_h_intern(&lf[162],9,"signal/io");
lf[163]=C_h_intern(&lf[163],11,"signal/kill");
lf[164]=C_h_intern(&lf[164],11,"signal/pipe");
lf[165]=C_h_intern(&lf[165],11,"signal/prof");
lf[166]=C_h_intern(&lf[166],11,"signal/quit");
lf[167]=C_h_intern(&lf[167],11,"signal/stop");
lf[168]=C_h_intern(&lf[168],11,"signal/trap");
lf[169]=C_h_intern(&lf[169],11,"signal/tstp");
lf[170]=C_h_intern(&lf[170],10,"signal/urg");
lf[171]=C_h_intern(&lf[171],11,"signal/usr1");
lf[172]=C_h_intern(&lf[172],11,"signal/usr2");
lf[173]=C_h_intern(&lf[173],13,"signal/vtalrm");
lf[174]=C_h_intern(&lf[174],12,"signal/winch");
lf[175]=C_h_intern(&lf[175],11,"signal/xcpu");
lf[176]=C_h_intern(&lf[176],11,"signal/xfsz");
lf[177]=C_h_intern(&lf[177],12,"signals-list");
lf[178]=C_h_intern(&lf[178],18,"\003sysinterrupt-hook");
lf[179]=C_h_intern(&lf[179],14,"signal-handler");
lf[180]=C_h_intern(&lf[180],19,"set-signal-handler!");
lf[181]=C_h_intern(&lf[181],10,"errno/perm");
lf[182]=C_h_intern(&lf[182],11,"errno/noent");
lf[183]=C_h_intern(&lf[183],10,"errno/srch");
lf[184]=C_h_intern(&lf[184],10,"errno/intr");
lf[185]=C_h_intern(&lf[185],8,"errno/io");
lf[186]=C_h_intern(&lf[186],12,"errno/noexec");
lf[187]=C_h_intern(&lf[187],10,"errno/badf");
lf[188]=C_h_intern(&lf[188],11,"errno/child");
lf[189]=C_h_intern(&lf[189],11,"errno/nomem");
lf[190]=C_h_intern(&lf[190],11,"errno/acces");
lf[191]=C_h_intern(&lf[191],11,"errno/fault");
lf[192]=C_h_intern(&lf[192],10,"errno/busy");
lf[193]=C_h_intern(&lf[193],11,"errno/exist");
lf[194]=C_h_intern(&lf[194],12,"errno/notdir");
lf[195]=C_h_intern(&lf[195],11,"errno/isdir");
lf[196]=C_h_intern(&lf[196],11,"errno/inval");
lf[197]=C_h_intern(&lf[197],11,"errno/mfile");
lf[198]=C_h_intern(&lf[198],11,"errno/nospc");
lf[199]=C_h_intern(&lf[199],11,"errno/spipe");
lf[200]=C_h_intern(&lf[200],10,"errno/pipe");
lf[201]=C_h_intern(&lf[201],11,"errno/again");
lf[202]=C_h_intern(&lf[202],10,"errno/rofs");
lf[203]=C_h_intern(&lf[203],10,"errno/nxio");
lf[204]=C_h_intern(&lf[204],10,"errno/2big");
lf[205]=C_h_intern(&lf[205],10,"errno/xdev");
lf[206]=C_h_intern(&lf[206],11,"errno/nodev");
lf[207]=C_h_intern(&lf[207],11,"errno/nfile");
lf[208]=C_h_intern(&lf[208],11,"errno/notty");
lf[209]=C_h_intern(&lf[209],10,"errno/fbig");
lf[210]=C_h_intern(&lf[210],11,"errno/mlink");
lf[211]=C_h_intern(&lf[211],9,"errno/dom");
lf[212]=C_h_intern(&lf[212],11,"errno/range");
lf[213]=C_h_intern(&lf[213],12,"errno/deadlk");
lf[214]=C_h_intern(&lf[214],17,"errno/nametoolong");
lf[215]=C_h_intern(&lf[215],11,"errno/nolck");
lf[216]=C_h_intern(&lf[216],11,"errno/nosys");
lf[217]=C_h_intern(&lf[217],14,"errno/notempty");
lf[218]=C_h_intern(&lf[218],11,"errno/ilseq");
lf[219]=C_h_intern(&lf[219],16,"change-file-mode");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[221]=C_h_intern(&lf[221],17,"file-read-access\077");
lf[222]=C_h_intern(&lf[222],18,"file-write-access\077");
lf[223]=C_h_intern(&lf[223],20,"file-execute-access\077");
lf[224]=C_h_intern(&lf[224],12,"fileno/stdin");
lf[225]=C_h_intern(&lf[225],13,"fileno/stdout");
lf[226]=C_h_intern(&lf[226],13,"fileno/stderr");
lf[227]=C_h_intern(&lf[227],7,"\000append");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[235]=C_h_intern(&lf[235],16,"open-input-file*");
lf[236]=C_h_intern(&lf[236],17,"open-output-file*");
lf[237]=C_h_intern(&lf[237],12,"port->fileno");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[240]=C_h_intern(&lf[240],25,"\003syspeek-unsigned-integer");
lf[241]=C_h_intern(&lf[241],16,"duplicate-fileno");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[243]=C_h_intern(&lf[243],6,"setenv");
lf[244]=C_h_intern(&lf[244],8,"unsetenv");
lf[245]=C_h_intern(&lf[245],9,"substring");
lf[246]=C_h_intern(&lf[246],25,"get-environment-variables");
lf[247]=C_h_intern(&lf[247],19,"current-environment");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[250]=C_h_intern(&lf[250],19,"seconds->local-time");
lf[251]=C_h_intern(&lf[251],18,"\003sysdecode-seconds");
lf[252]=C_h_intern(&lf[252],17,"seconds->utc-time");
lf[253]=C_h_intern(&lf[253],15,"seconds->string");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[255]=C_h_intern(&lf[255],12,"time->string");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[258]=C_h_intern(&lf[258],19,"local-time->seconds");
lf[259]=C_h_intern(&lf[259],15,"\003syscons-flonum");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[261]=C_h_intern(&lf[261],27,"local-timezone-abbreviation");
lf[262]=C_h_intern(&lf[262],5,"_exit");
lf[263]=C_h_intern(&lf[263],14,"terminal-port\077");
lf[264]=C_h_intern(&lf[264],19,"set-buffering-mode!");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[266]=C_h_intern(&lf[266],5,"\000full");
lf[267]=C_h_intern(&lf[267],5,"\000line");
lf[268]=C_h_intern(&lf[268],5,"\000none");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[270]=C_h_intern(&lf[270],6,"regexp");
lf[271]=C_h_intern(&lf[271],21,"make-anchored-pattern");
lf[272]=C_h_intern(&lf[272],12,"string-match");
lf[273]=C_h_intern(&lf[273],12,"glob->regexp");
lf[274]=C_h_intern(&lf[274],13,"make-pathname");
lf[275]=C_h_intern(&lf[275],18,"decompose-pathname");
lf[276]=C_h_intern(&lf[276],4,"glob");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[279]=C_h_intern(&lf[279],13,"spawn/overlay");
lf[280]=C_h_intern(&lf[280],10,"spawn/wait");
lf[281]=C_h_intern(&lf[281],12,"spawn/nowait");
lf[282]=C_h_intern(&lf[282],13,"spawn/nowaito");
lf[283]=C_h_intern(&lf[283],12,"spawn/detach");
lf[284]=C_h_intern(&lf[284],16,"char-whitespace\077");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[288]=C_h_intern(&lf[288],24,"pathname-strip-directory");
lf[291]=C_h_intern(&lf[291],15,"process-execute");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[293]=C_h_intern(&lf[293],13,"process-spawn");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[295]=C_h_intern(&lf[295],18,"current-process-id");
lf[296]=C_h_intern(&lf[296],17,"\003sysshell-command");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[298]=C_h_intern(&lf[298],6,"getenv");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[300]=C_h_intern(&lf[300],27,"\003sysshell-command-arguments");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[302]=C_h_intern(&lf[302],11,"process-run");
lf[303]=C_h_intern(&lf[303],11,"\003sysprocess");
lf[304]=C_h_intern(&lf[304],14,"\000process-error");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[306]=C_h_intern(&lf[306],17,"\003sysmake-locative");
lf[307]=C_h_intern(&lf[307],8,"location");
lf[308]=C_h_intern(&lf[308],7,"process");
lf[309]=C_h_intern(&lf[309],8,"process*");
lf[310]=C_h_intern(&lf[310],16,"\003sysprocess-wait");
lf[311]=C_h_intern(&lf[311],12,"process-wait");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[313]=C_h_intern(&lf[313],5,"sleep");
lf[314]=C_h_intern(&lf[314],13,"get-host-name");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[316]=C_h_intern(&lf[316],18,"system-information");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[320]=C_h_intern(&lf[320],10,"find-files");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[324]=C_h_intern(&lf[324],16,"\003sysdynamic-wind");
lf[325]=C_h_intern(&lf[325],13,"pathname-file");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[327]=C_h_intern(&lf[327],16,"errno/wouldblock");
lf[328]=C_h_intern(&lf[328],5,"fifo\077");
lf[329]=C_h_intern(&lf[329],19,"memory-mapped-file\077");
lf[330]=C_h_intern(&lf[330],13,"map/anonymous");
lf[331]=C_h_intern(&lf[331],8,"map/file");
lf[332]=C_h_intern(&lf[332],9,"map/fixed");
lf[333]=C_h_intern(&lf[333],11,"map/private");
lf[334]=C_h_intern(&lf[334],10,"map/shared");
lf[335]=C_h_intern(&lf[335],10,"open/fsync");
lf[336]=C_h_intern(&lf[336],11,"open/noctty");
lf[337]=C_h_intern(&lf[337],13,"open/nonblock");
lf[338]=C_h_intern(&lf[338],9,"open/sync");
lf[339]=C_h_intern(&lf[339],10,"perm/isgid");
lf[340]=C_h_intern(&lf[340],10,"perm/isuid");
lf[341]=C_h_intern(&lf[341],10,"perm/isvtx");
lf[342]=C_h_intern(&lf[342],9,"prot/exec");
lf[343]=C_h_intern(&lf[343],9,"prot/none");
lf[344]=C_h_intern(&lf[344],9,"prot/read");
lf[345]=C_h_intern(&lf[345],10,"prot/write");
lf[346]=C_h_intern(&lf[346],12,"string->time");
lf[347]=C_h_intern(&lf[347],17,"utc-time->seconds");
lf[348]=C_h_intern(&lf[348],16,"user-information");
lf[349]=C_h_intern(&lf[349],22,"unmap-file-from-memory");
lf[350]=C_h_intern(&lf[350],13,"terminal-size");
lf[351]=C_h_intern(&lf[351],13,"terminal-name");
lf[352]=C_h_intern(&lf[352],14,"signal-unmask!");
lf[353]=C_h_intern(&lf[353],14,"signal-masked\077");
lf[354]=C_h_intern(&lf[354],12,"signal-mask!");
lf[355]=C_h_intern(&lf[355],11,"signal-mask");
lf[356]=C_h_intern(&lf[356],12,"set-user-id!");
lf[357]=C_h_intern(&lf[357],16,"set-signal-mask!");
lf[358]=C_h_intern(&lf[358],19,"set-root-directory!");
lf[359]=C_h_intern(&lf[359],21,"set-process-group-id!");
lf[360]=C_h_intern(&lf[360],11,"set-groups!");
lf[361]=C_h_intern(&lf[361],13,"set-group-id!");
lf[362]=C_h_intern(&lf[362],10,"set-alarm!");
lf[363]=C_h_intern(&lf[363],18,"read-symbolic-link");
lf[364]=C_h_intern(&lf[364],14,"process-signal");
lf[365]=C_h_intern(&lf[365],16,"process-group-id");
lf[366]=C_h_intern(&lf[366],12,"process-fork");
lf[367]=C_h_intern(&lf[367],17,"parent-process-id");
lf[368]=C_h_intern(&lf[368],26,"memory-mapped-file-pointer");
lf[369]=C_h_intern(&lf[369],17,"initialize-groups");
lf[370]=C_h_intern(&lf[370],17,"group-information");
lf[371]=C_h_intern(&lf[371],10,"get-groups");
lf[372]=C_h_intern(&lf[372],11,"file-unlock");
lf[373]=C_h_intern(&lf[373],13,"file-truncate");
lf[374]=C_h_intern(&lf[374],14,"file-test-lock");
lf[375]=C_h_intern(&lf[375],11,"file-select");
lf[376]=C_h_intern(&lf[376],18,"file-lock/blocking");
lf[377]=C_h_intern(&lf[377],9,"file-lock");
lf[378]=C_h_intern(&lf[378],9,"file-link");
lf[379]=C_h_intern(&lf[379],18,"map-file-to-memory");
lf[380]=C_h_intern(&lf[380],15,"current-user-id");
lf[381]=C_h_intern(&lf[381],16,"current-group-id");
lf[382]=C_h_intern(&lf[382],27,"current-effective-user-name");
lf[383]=C_h_intern(&lf[383],25,"current-effective-user-id");
lf[384]=C_h_intern(&lf[384],26,"current-effective-group-id");
lf[385]=C_h_intern(&lf[385],20,"create-symbolic-link");
lf[386]=C_h_intern(&lf[386],14,"create-session");
lf[387]=C_h_intern(&lf[387],11,"create-fifo");
lf[388]=C_h_intern(&lf[388],17,"change-file-owner");
lf[389]=C_h_intern(&lf[389],11,"make-vector");
lf[390]=C_h_intern(&lf[390],17,"register-feature!");
lf[391]=C_h_intern(&lf[391],5,"posix");
C_register_lf2(lf,392,create_ptable());
t2=C_mutate(&lf[0] /* (set! c222 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2637 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2640 in k2637 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2643 in k2640 in k2637 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 930  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[390]+1)))(3,*((C_word*)lf[390]+1),t2,lf[391]);}

/* k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[10]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[11]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[12]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[13]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[14]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[15]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[16]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[22]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[23]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[24]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[25]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[26]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[27]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[29]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[30]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[31]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[34]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[39]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2753,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[41]+1);
t35=C_mutate((C_word*)lf[42]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[46]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2816,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[49]+1);
t38=C_mutate((C_word*)lf[50]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[53]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[54]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[55]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[56] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[59]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[61]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[62]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[63]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2977,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[64]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[65]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[66]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[67]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[69]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3024,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3029,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[70]+1 /* (set! stat-regular? ...) */,*((C_word*)lf[67]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1115 stat-type */
f_3029(t54,lf[71]);}

/* k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1116 stat-type */
f_3029(t3,lf[72]);}

/* k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! stat-char-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1117 stat-type */
f_3029(t3,lf[73]);}

/* k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1118 stat-type */
f_3029(t3,lf[74]);}

/* k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1119 stat-type */
f_3029(t3,lf[75]);}

/* k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1120 stat-type */
f_3029(t3,lf[76]);}

/* k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[121],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[77]+1 /* (set! file-position ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[82]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3102,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[87]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[95]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3330,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[2]+1);
t9=*((C_word*)lf[41]+1);
t10=*((C_word*)lf[99]+1);
t11=C_mutate((C_word*)lf[100]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3357,a[2]=t9,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[104]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[41]+1);
t14=C_mutate((C_word*)lf[103]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=t13,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[107]+1);
t16=*((C_word*)lf[108]+1);
t17=*((C_word*)lf[109]+1);
t18=*((C_word*)lf[110]+1);
t19=*((C_word*)lf[111]+1);
t20=*((C_word*)lf[2]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[114]+1);
t24=*((C_word*)lf[103]+1);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3611,a[2]=t24,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t26=C_mutate((C_word*)lf[94]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3667,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4042,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[136]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4060,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[138]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4096,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t32=C_mutate((C_word*)lf[139]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4132,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[142]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[139]+1));
t34=*((C_word*)lf[136]+1);
t35=*((C_word*)lf[138]+1);
t36=*((C_word*)lf[139]+1);
t37=*((C_word*)lf[142]+1);
t38=C_mutate((C_word*)lf[143]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4151,a[2]=t34,a[3]=t36,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[144]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4175,a[2]=t35,a[3]=t37,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[145]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4199,a[2]=t34,a[3]=t36,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[147]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4219,a[2]=t35,a[3]=t37,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t42=C_mutate((C_word*)lf[149]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[151]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[152]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[153]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[154]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[155]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[156]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[157]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[158] /* signal/alrm */,0,C_fix(0));
t51=C_set_block_item(lf[159] /* signal/chld */,0,C_fix(0));
t52=C_set_block_item(lf[160] /* signal/cont */,0,C_fix(0));
t53=C_set_block_item(lf[161] /* signal/hup */,0,C_fix(0));
t54=C_set_block_item(lf[162] /* signal/io */,0,C_fix(0));
t55=C_set_block_item(lf[163] /* signal/kill */,0,C_fix(0));
t56=C_set_block_item(lf[164] /* signal/pipe */,0,C_fix(0));
t57=C_set_block_item(lf[165] /* signal/prof */,0,C_fix(0));
t58=C_set_block_item(lf[166] /* signal/quit */,0,C_fix(0));
t59=C_set_block_item(lf[167] /* signal/stop */,0,C_fix(0));
t60=C_set_block_item(lf[168] /* signal/trap */,0,C_fix(0));
t61=C_set_block_item(lf[169] /* signal/tstp */,0,C_fix(0));
t62=C_set_block_item(lf[170] /* signal/urg */,0,C_fix(0));
t63=C_set_block_item(lf[171] /* signal/usr1 */,0,C_fix(0));
t64=C_set_block_item(lf[172] /* signal/usr2 */,0,C_fix(0));
t65=C_set_block_item(lf[173] /* signal/vtalrm */,0,C_fix(0));
t66=C_set_block_item(lf[174] /* signal/winch */,0,C_fix(0));
t67=C_set_block_item(lf[175] /* signal/xcpu */,0,C_fix(0));
t68=C_set_block_item(lf[176] /* signal/xfsz */,0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1));
t70=C_mutate((C_word*)lf[177]+1 /* (set! signals-list ...) */,t69);
t71=*((C_word*)lf[178]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1468 make-vector */
t73=*((C_word*)lf[389]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word ab[193],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=C_mutate((C_word*)lf[179]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4315,a[2]=t1,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[180]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4324,a[2]=t1,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[178]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[181]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[182]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[183]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[184]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[185]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[186]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[187]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[188]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[189]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[190]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[191]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[192]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[193]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[194]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[195]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[196]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[197]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[198]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[199]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[200]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[201]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[202]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[203]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[204]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[205]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[206]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[207]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[208]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[209]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[210]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[211]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[212]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[213]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[214]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[215]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[216]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[217]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[218]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[219]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4393,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4423,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[221]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4447,a[2]=t44,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[222]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4453,a[2]=t44,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[223]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4459,a[2]=t44,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[224]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[225]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[226]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4468,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4505,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[235]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4523,a[2]=t51,a[3]=t52,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[236]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4537,a[2]=t51,a[3]=t52,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[237]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4551,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[241]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[243]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4616,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[244]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4633,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[245]+1);
t60=C_mutate((C_word*)lf[246]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4653,a[2]=t59,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[247]+1 /* (set! current-environment ...) */,*((C_word*)lf[246]+1));
t62=C_mutate(&lf[248] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4719,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[250]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4738,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[252]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4747,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[253]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4766,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[255]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4799,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[258]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4866,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[261]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4881,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[262]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4893,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[263]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[264]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4915,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t72=*((C_word*)lf[270]+1);
t73=*((C_word*)lf[271]+1);
t74=*((C_word*)lf[272]+1);
t75=*((C_word*)lf[273]+1);
t76=*((C_word*)lf[100]+1);
t77=*((C_word*)lf[274]+1);
t78=*((C_word*)lf[275]+1);
t79=C_mutate((C_word*)lf[276]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4974,a[2]=t75,a[3]=t73,a[4]=t72,a[5]=t76,a[6]=t74,a[7]=t77,a[8]=t78,a[9]=((C_word)li98),tmp=(C_word)a,a+=10,tmp));
t80=C_mutate((C_word*)lf[279]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t81=C_mutate((C_word*)lf[280]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t82=C_mutate((C_word*)lf[281]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t83=C_mutate((C_word*)lf[282]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t84=C_mutate((C_word*)lf[283]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t85=*((C_word*)lf[284]+1);
t86=*((C_word*)lf[49]+1);
t87=*((C_word*)lf[111]+1);
t88=*((C_word*)lf[2]+1);
t89=C_mutate(&lf[285] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5089,a[2]=t88,a[3]=t86,a[4]=t87,a[5]=t85,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t91=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5185,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
t92=*((C_word*)lf[288]+1);
t93=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5202,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t94=C_mutate(&lf[289] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5252,a[2]=t92,a[3]=t90,a[4]=t91,a[5]=t93,a[6]=((C_word)li107),tmp=(C_word)a,a+=7,tmp));
t95=C_mutate(&lf[290] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5285,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[291]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5300,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[293]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5387,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[295]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5474,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[296]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5477,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t100=C_mutate((C_word*)lf[300]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5498,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t101=*((C_word*)lf[293]+1);
t102=*((C_word*)lf[298]+1);
t103=C_mutate((C_word*)lf[302]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5504,a[2]=t101,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp));
t104=C_mutate((C_word*)lf[303]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t105=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5715,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
t106=C_mutate((C_word*)lf[308]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5777,a[2]=t105,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp));
t107=C_mutate((C_word*)lf[309]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5857,a[2]=t105,a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp));
t108=C_mutate((C_word*)lf[310]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5937,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[311]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[313]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6009,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[314]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6012,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[316]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6024,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t113=C_mutate((C_word*)lf[114]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6055,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t114=*((C_word*)lf[276]+1);
t115=*((C_word*)lf[272]+1);
t116=*((C_word*)lf[274]+1);
t117=*((C_word*)lf[104]+1);
t118=C_mutate((C_word*)lf[320]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6070,a[2]=t117,a[3]=t116,a[4]=t114,a[5]=t115,a[6]=((C_word)li159),tmp=(C_word)a,a+=7,tmp));
t119=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t120=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6861,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t120+1)))(3,t120,t119,*((C_word*)lf[388]+1));}

/* f_6861 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6861,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[387]+1));}

/* f_6851 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6851,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6841,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[386]+1));}

/* f_6841 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6841,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6831,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[385]+1));}

/* f_6831 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6831,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6821,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[384]+1));}

/* f_6821 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6821,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6811,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[383]+1));}

/* f_6811 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6811,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6801,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[382]+1));}

/* f_6801 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6801,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6791,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[381]+1));}

/* f_6791 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6791,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6781,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[380]+1));}

/* f_6781 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6781,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6771,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[379]+1));}

/* f_6771 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6771,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6761,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[378]+1));}

/* f_6761 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6761,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6751,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[377]+1));}

/* f_6751 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6751,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6741,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[376]+1));}

/* f_6741 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6741,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6731,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[375]+1));}

/* f_6731 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6731,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6721,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[374]+1));}

/* f_6721 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6721,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6711,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[373]+1));}

/* f_6711 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6711,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6701,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[372]+1));}

/* f_6701 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6701,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6691,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[371]+1));}

/* f_6691 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6691,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6681,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[370]+1));}

/* f_6681 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6681,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6671,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[369]+1));}

/* f_6671 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6671,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6661,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[368]+1));}

/* f_6661 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6661,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6651,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[367]+1));}

/* f_6651 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6651,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6641,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[366]+1));}

/* f_6641 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6641,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6631,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[365]+1));}

/* f_6631 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6631,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6621,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[364]+1));}

/* f_6621 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6621,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6611,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[363]+1));}

/* f_6611 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6611,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6601,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[362]+1));}

/* f_6601 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6601,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6372,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6591,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[361]+1));}

/* f_6591 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6591,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6581,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[360]+1));}

/* f_6581 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6581,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6571,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[359]+1));}

/* f_6571 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6571,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6561,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[358]+1));}

/* f_6561 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6561,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6551,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[357]+1));}

/* f_6551 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6551,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6541,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[356]+1));}

/* f_6541 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6541,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6531,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[355]+1));}

/* f_6531 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6531,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6521,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[354]+1));}

/* f_6521 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6521,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6511,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[353]+1));}

/* f_6511 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6511,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6501,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[352]+1));}

/* f_6501 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6501,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6491,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[351]+1));}

/* f_6491 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6491,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6481,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[350]+1));}

/* f_6481 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6481,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6471,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[349]+1));}

/* f_6471 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6471,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6461,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[348]+1));}

/* f_6461 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6461,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6451,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[347]+1));}

/* f_6451 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6451,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6441,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[346]+1));}

/* f_6441 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6441,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=C_set_block_item(lf[327] /* errno/wouldblock */,0,C_fix(0));
t3=C_mutate((C_word*)lf[328]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6420,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[329]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6423,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t5=C_set_block_item(lf[330] /* map/anonymous */,0,C_fix(0));
t6=C_set_block_item(lf[331] /* map/file */,0,C_fix(0));
t7=C_set_block_item(lf[332] /* map/fixed */,0,C_fix(0));
t8=C_set_block_item(lf[333] /* map/private */,0,C_fix(0));
t9=C_set_block_item(lf[334] /* map/shared */,0,C_fix(0));
t10=C_set_block_item(lf[335] /* open/fsync */,0,C_fix(0));
t11=C_set_block_item(lf[336] /* open/noctty */,0,C_fix(0));
t12=C_set_block_item(lf[337] /* open/nonblock */,0,C_fix(0));
t13=C_set_block_item(lf[338] /* open/sync */,0,C_fix(0));
t14=C_set_block_item(lf[339] /* perm/isgid */,0,C_fix(0));
t15=C_set_block_item(lf[340] /* perm/isuid */,0,C_fix(0));
t16=C_set_block_item(lf[341] /* perm/isvtx */,0,C_fix(0));
t17=C_set_block_item(lf[342] /* prot/exec */,0,C_fix(0));
t18=C_set_block_item(lf[343] /* prot/none */,0,C_fix(0));
t19=C_set_block_item(lf[344] /* prot/read */,0,C_fix(0));
t20=C_set_block_item(lf[345] /* prot/write */,0,C_fix(0));
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6423,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k6415 in k6412 in k6409 in k6406 in k6403 in k6400 in k6397 in k6394 in k6391 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in k6370 in k6367 in k6364 in k6361 in k6358 in k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6292 in k6289 in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6420,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6070r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6070r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6070r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li154),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6211,a[2]=t5,a[3]=((C_word)li155),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6216,a[2]=t6,a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6221,a[2]=t7,a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action18761961 */
t9=t8;
f_6221(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id18771957 */
t11=t7;
f_6216(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit18781952 */
t13=t6;
f_6211(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body18741884 */
t15=t5;
f_6072(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action1876 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_6221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6221,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6227,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp);
/* def-id18771957 */
t3=((C_word*)t0)[2];
f_6216(t3,t1,t2);}

/* a6226 in def-action1876 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6227,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1877 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_6216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6216,NULL,3,t0,t1,t2);}
/* def-limit18781952 */
t3=((C_word*)t0)[2];
f_6211(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1878 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_6211(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6211,NULL,4,t0,t1,t2,t3);}
/* body18741884 */
t4=((C_word*)t0)[2];
f_6072(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_6072(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6072,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[320]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6079,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6079(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6206,a[2]=t4,a[3]=t7,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6079(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6198,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));}}

/* f_6198 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6206 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_6079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6079,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6190,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6186,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2052 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[326]);}

/* k6184 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2052 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6089,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li151),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6091(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_6091(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6091,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2058 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6110,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2059 pathname-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[325]+1)))(3,*((C_word*)lf[325]+1),t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2065 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k6170 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2065 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2066 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6091(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6177 in k6170 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2065 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6091(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[321]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[322]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2059 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_6091(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2060 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6137,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li148),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li149),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6156,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[324]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2064 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_6091(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a6155 in k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6156,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a6141 in k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6154,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2063 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[323]);}

/* k6152 in a6141 in k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2063 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6148 in a6141 in k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2063 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6091(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6136 in k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k6133 in k6123 in k6164 in k6108 in loop in k6087 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2061 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6091(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6190 in k6077 in body1874 in find-files in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6190,3,t0,t1,t2);}
/* posixwin.scm: 2050 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2026 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6063 in current-user-name in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2027 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[114],lf[319]);}

/* system-information in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6024,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6035,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6050,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2017 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6048 in system-information in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2018 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[316],lf[318]);}

/* k6033 in system-information in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6039,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k6037 in k6033 in system-information in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6043,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k6041 in k6037 in k6033 in system-information in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6047,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k6045 in k6041 in k6037 in k6033 in system-information in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[317],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2007 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[314],lf[315]);}}

/* sleep in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6009,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_5949r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5949r(t0,t1,t2,t3);}}

static void C_ccall f_5949r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[311]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5970,a[2]=t5,a[3]=t2,a[4]=((C_word)li140),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5976,a[2]=t2,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[0],t7);}}

/* a5975 in process-wait in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5976,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1989 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1991 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5984 in a5975 in process-wait in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1990 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[304],lf[311],lf[312],((C_word*)t0)[2]);}

/* a5969 in process-wait in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5970,2,t0,t1);}
/* posixwin.scm: 1986 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[310]+1)))(4,*((C_word*)lf[310]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5937,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1979 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1980 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5857r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5857r(t0,t1,t2,t3);}}

static void C_ccall f_5857r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5859,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5864,a[2]=t4,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5869,a[2]=t5,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5874,a[2]=t6,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17691792 */
t8=t7;
f_5874(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17701788 */
t10=t6;
f_5869(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17711783 */
t12=t5;
f_5864(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17671777 */
t14=t4;
f_5859(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-args1769 in process* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5874,NULL,2,t0,t1);}
/* def-env17701788 */
t2=((C_word*)t0)[2];
f_5869(t2,t1,C_SCHEME_FALSE);}

/* def-env1770 in process* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5869(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5869,NULL,3,t0,t1,t2);}
/* def-exactf17711783 */
t3=((C_word*)t0)[2];
f_5864(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1771 in process* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5864(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5864,NULL,4,t0,t1,t2,t3);}
/* body17671777 */
t4=((C_word*)t0)[2];
f_5859(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1767 in process* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5859,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1973 %process */
f_5715(t1,lf[309],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5777r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5777r(t0,t1,t2,t3);}}

static void C_ccall f_5777r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5779,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5784,a[2]=t4,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=t5,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5794,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17141737 */
t8=t7;
f_5794(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17151733 */
t10=t6;
f_5789(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17161728 */
t12=t5;
f_5784(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17121722 */
t14=t4;
f_5779(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-args1714 in process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5794,NULL,2,t0,t1);}
/* def-env17151733 */
t2=((C_word*)t0)[2];
f_5789(t2,t1,C_SCHEME_FALSE);}

/* def-env1715 in process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5789,NULL,3,t0,t1,t2);}
/* def-exactf17161728 */
t3=((C_word*)t0)[2];
f_5784(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1716 in process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5784,NULL,4,t0,t1,t2,t3);}
/* body17121722 */
t4=((C_word*)t0)[2];
f_5779(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1712 in process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5779(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5779,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1970 %process */
f_5715(t1,lf[308],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5715(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5715,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5717,a[2]=t2,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5736,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1958 chkstrlst */
t14=t11;
f_5717(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5771,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1961 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[300]+1)))(3,*((C_word*)lf[300]+1),t15,((C_word*)t8)[1]);}}

/* k5769 in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1962 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[296]+1)))(2,*((C_word*)lf[296]+1),t3);}

/* k5773 in k5769 in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5736(2,t3,t2);}

/* k5734 in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1963 chkstrlst */
t3=((C_word*)t0)[2];
f_5717(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_5739(2,t3,C_SCHEME_UNDEFINED);}}

/* k5737 in k5734 in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li126),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5750,a[2]=((C_word*)t0)[4],a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5749 in k5737 in k5734 in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5750,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1966 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1967 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5743 in k5737 in k5734 in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
/* posixwin.scm: 1964 ##sys#process */
t2=*((C_word*)lf[303]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5717,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5726,a[2]=((C_word*)t0)[2],a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5725 in chkstrlst in %process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5726,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_5596r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_5596r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_5596r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5600,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_5600(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_5600(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[0],t9);}}}

/* k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5691,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1930 $quote-args-list */
t5=lf[285];
f_5089(t5,t3,t4,t1);}

/* k5689 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1930 string-intersperse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(t2))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(t5))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(t8))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(t11))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[306]+1)))(6,*((C_word*)lf[306]+1),t14,t2,C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[306]+1)))(6,*((C_word*)lf[306]+1),t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[306]+1)))(6,*((C_word*)lf[306]+1),t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[306]+1)))(6,*((C_word*)lf[306]+1),t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1937 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5538,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5538(2,t9,C_SCHEME_FALSE);}}

/* k5536 in k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5542(2,t3,C_SCHEME_FALSE);}}

/* k5540 in k5536 in k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub1536(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1940 open-input-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[235]+1)))(3,*((C_word*)lf[235]+1),t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_5632(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1945 ##sys#update-errno */
t8=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5650 in k5540 in k5536 in k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1946 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[304],((C_word*)t0)[3],lf[305],((C_word*)t0)[2]);}

/* k5630 in k5540 in k5536 in k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1941 open-output-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[236]+1)))(3,*((C_word*)lf[236]+1),t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5636(2,t3,C_SCHEME_FALSE);}}

/* k5634 in k5630 in k5540 in k5536 in k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1943 open-input-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[235]+1)))(3,*((C_word*)lf[235]+1),t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5640(2,t3,C_SCHEME_FALSE);}}

/* k5638 in k5634 in k5630 in k5540 in k5536 in k5673 in k5669 in k5665 in k5661 in k5657 in k5601 in k5598 in ##sys#process in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1939 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* process-run in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5504r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5504r(t0,t1,t2,t3);}}

static void C_ccall f_5504r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1901 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[281]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5521,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1902 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[296]+1)))(2,*((C_word*)lf[296]+1),t6);}}

/* k5519 in process-run in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5525,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1902 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[300]+1)))(3,*((C_word*)lf[300]+1),t2,((C_word*)t0)[2]);}

/* k5523 in k5519 in process-run in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1902 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[281]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5498,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[301],t2));}

/* ##sys#shell-command in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5481,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1885 getenv */
((C_proc3)C_retrieve_proc(*((C_word*)lf[298]+1)))(3,*((C_word*)lf[298]+1),t2,lf[299]);}

/* k5479 in ##sys#shell-command in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1889 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k5491 in k5479 in ##sys#shell-command in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1890 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[296],lf[297]);}

/* current-process-id in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1496(C_SCHEME_UNDEFINED));}

/* process-spawn in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5387r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5387r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5387r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5389,a[2]=t3,a[3]=t2,a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5401,a[2]=t5,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5406,a[2]=t6,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5411,a[2]=t7,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst14571482 */
t9=t8;
f_5411(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst14581478 */
t11=t7;
f_5406(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf14591473 */
t13=t6;
f_5401(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body14551465 */
t15=t5;
f_5389(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-arglst1457 in process-spawn in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5411,NULL,2,t0,t1);}
/* def-envlst14581478 */
t2=((C_word*)t0)[2];
f_5406(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1458 in process-spawn in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5406(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5406,NULL,3,t0,t1,t2);}
/* def-exactf14591473 */
t3=((C_word*)t0)[2];
f_5401(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1459 in process-spawn in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5401(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5401,NULL,4,t0,t1,t2,t3);}
/* body14551465 */
t4=((C_word*)t0)[2];
f_5389(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1455 in process-spawn in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5389(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5389,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1876 $exec-setup */
t6=lf[289];
f_5252(t6,t5,lf[293],((C_word*)t0)[2],t2,t3,t4);}

/* k5391 in body1455 in process-spawn in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1877 $exec-teardown */
f_5285(((C_word*)t0)[3],lf[293],lf[294],((C_word*)t0)[2],t2);}

/* process-execute in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_5300r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5300r(t0,t1,t2,t3);}}

static void C_ccall f_5300r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5302,a[2]=t2,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5314,a[2]=t4,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5319,a[2]=t5,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5324,a[2]=t6,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst13971422 */
t8=t7;
f_5324(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst13981418 */
t10=t6;
f_5319(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf13991413 */
t12=t5;
f_5314(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body13951405 */
t14=t4;
f_5302(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-arglst1397 in process-execute in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5324,NULL,2,t0,t1);}
/* def-envlst13981418 */
t2=((C_word*)t0)[2];
f_5319(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1398 in process-execute in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5319(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5319,NULL,3,t0,t1,t2);}
/* def-exactf13991413 */
t3=((C_word*)t0)[2];
f_5314(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1399 in process-execute in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5314(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5314,NULL,4,t0,t1,t2,t3);}
/* body13951405 */
t4=((C_word*)t0)[2];
f_5302(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1395 in process-execute in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5302(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5302,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1871 $exec-setup */
t6=lf[289];
f_5252(t6,t5,lf[291],((C_word*)t0)[2],t2,t3,t4);}

/* k5304 in body1395 in process-execute in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1872 $exec-teardown */
f_5285(((C_word*)t0)[3],lf[291],lf[292],((C_word*)t0)[2],t2);}

/* $exec-teardown in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5285(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5285,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5289,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1863 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5287 in $exec-teardown in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1867 ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5252(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5252,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5259,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1855 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5257 in $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1856 setarg */
t4=((C_word*)t0)[4];
f_5168(5,t4,t2,C_fix(0),t1,t3);}

/* k5260 in k5257 in $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1857 $quote-args-list */
t4=lf[285];
f_5089(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5277 in k5260 in k5257 in $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1857 build-exec-argvec */
f_5202(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k5263 in k5260 in k5257 in $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1858 build-exec-argvec */
f_5202(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k5266 in k5263 in k5260 in k5257 in $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1860 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t3,((C_word*)t0)[2]);}

/* k5273 in k5266 in k5263 in k5260 in k5257 in $exec-setup in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1860 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5202(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5202,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5214,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5214(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1852 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop1335 in build-exec-argvec in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5214(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5214,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1848 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5233,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1851 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k5231 in doloop1335 in build-exec-argvec in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5214(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5185,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1321(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5168,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1309(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5089(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5089,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5132,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5132(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5132,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1829 reverse */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5160,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5163,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1834 needs-quoting? */
t8=((C_word*)t0)[2];
f_5094(t8,t7,t4);}}

/* k5161 in loop in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1834 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[286],((C_word*)t0)[2],lf[287]);}
else{
t2=((C_word*)t0)[3];
f_5160(2,t2,((C_word*)t0)[2]);}}

/* k5158 in loop in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1831 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5132(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5094(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5094,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5098,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1821 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5096 in needs-quoting? in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5098,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li99),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5103(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5096 in needs-quoting? in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5103,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1825 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k5125 in loop in k5096 in needs-quoting? in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1825 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5114 in loop in k5096 in needs-quoting? in $quote-args-list in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1826 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5103(t3,((C_word*)t0)[4],t2);}}

/* glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4974r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4974r(t0,t1,t2);}}

static void C_ccall f_4974r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li97),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_4980(t6,t1,t2);}

/* conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4980(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4980,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4995,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li96),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5001,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5078,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[278]);
/* posixwin.scm: 1782 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5076 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1782 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1783 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1784 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5009 in k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[277]);
/* posixwin.scm: 1785 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5016 in k5009 in k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li95),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5020(t5,((C_word*)t0)[2],t1);}

/* loop in k5016 in k5009 in k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_5020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5020,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1786 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4980(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1787 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5035 in loop in k5016 in k5009 in k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5037,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1788 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1789 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5020(t3,((C_word*)t0)[6],t2);}}

/* k5045 in k5035 in loop in k5016 in k5009 in k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1788 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5020(t4,t2,t3);}

/* k5049 in k5045 in k5035 in loop in k5016 in k5009 in k5006 in k5003 in a5000 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4994 in conc-loop in glob in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
/* posixwin.scm: 1781 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4915r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4915r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4915r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4919,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1752 ##sys#check-port */
t6=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[264]);}

/* k4917 in set-buffering-mode! in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[266]);
if(C_truep(t6)){
t7=t5;
f_4925(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[267]);
if(C_truep(t7)){
t8=t5;
f_4925(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t8)){
t9=t5;
f_4925(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1758 ##sys#error */
t9=*((C_word*)lf[60]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[264],lf[269],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4923 in k4917 in set-buffering-mode! in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[264]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[79],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1764 ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[264],lf[265],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4909,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1742 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[263]);}

/* k4911 in terminal-port? in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4893r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4893r(t0,t1,t2);}}

static void C_ccall f_4893r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1144(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1136(t2),C_fix(0));}

/* local-time->seconds in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4866,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4870,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1724 check-time-vector */
f_4719(t3,lf[258],t2);}

/* k4868 in local-time->seconds in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1726 ##sys#cons-flonum */
((C_proc2)C_retrieve_proc(*((C_word*)lf[259]+1)))(2,*((C_word*)lf[259]+1),((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1727 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[258],lf[260],((C_word*)t0)[3]);}}

/* time->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4799r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4799r(t0,t1,t2,t3);}}

static void C_ccall f_4799r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4803,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4803(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4803(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4801 in time->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1712 check-time-vector */
f_4719(t2,lf[255],((C_word*)t0)[2]);}

/* k4804 in k4801 in time->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[255]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1716 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1085(t4,t3),C_fix(0));}}

/* k4826 in k4804 in k4801 in time->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1720 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1721 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[257],((C_word*)t0)[2]);}}

/* k4823 in k4804 in k4801 in time->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1093(t3,t2,t1),C_fix(0));}

/* k4813 in k4804 in k4801 in time->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1717 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[255],lf[256],((C_word*)t0)[2]);}}

/* seconds->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4766,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4770,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub1070(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4768 in seconds->string in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1705 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1706 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[253],lf[254],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4747,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[252]);
/* posixwin.scm: 1698 ##sys#decode-seconds */
((C_proc4)C_retrieve_proc(*((C_word*)lf[251]+1)))(4,*((C_word*)lf[251]+1),t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4738,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[250]);
/* posixwin.scm: 1694 ##sys#decode-seconds */
((C_proc4)C_retrieve_proc(*((C_word*)lf[251]+1)))(4,*((C_word*)lf[251]+1),t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4719(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4719,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1690 ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[249],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4659(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4659,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4663,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1026(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4661 in loop in get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4671,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li81),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4671(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4661 in loop in get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4671,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1679 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1680 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4695 in scan in k4661 in loop in get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1679 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k4699 in k4695 in scan in k4661 in loop in get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4689,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1679 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4659(t5,t3,t4);}

/* k4687 in k4699 in k4695 in scan in k4661 in loop in get-environment-variables in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4633,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[244]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1667 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4639 in unsetenv in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4616,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[243]);
t5=(C_word)C_i_check_string_2(t3,lf[243]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1662 ##sys#make-c-string */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4625 in setenv in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1662 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4629 in k4625 in setenv in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4586r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4586r(t0,t1,t2,t3);}}

static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[241]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4593,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4593(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[241]);
t8=t5;
f_4593(t8,(C_word)C_dup2(t2,t6));}}

/* k4591 in duplicate-fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4593,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4596,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1651 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4596(2,t3,C_SCHEME_UNDEFINED);}}

/* k4600 in k4591 in duplicate-fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1652 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[241],lf[242],((C_word*)t0)[2]);}

/* k4594 in k4591 in duplicate-fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4551,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4555,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1633 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[237]);}

/* k4553 in port->fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1634 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4582 in k4553 in port->fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1640 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[44],lf[237],lf[238],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1637 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4564(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4568 in k4582 in k4553 in port->fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1638 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[237],lf[239],((C_word*)t0)[2]);}

/* k4562 in k4582 in k4553 in port->fileno in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4537r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4537r(t0,t1,t2,t3);}}

static void C_ccall f_4537r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4549,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1629 mode */
f_4468(t5,C_SCHEME_FALSE,t3);}

/* k4547 in open-output-file* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4549,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1629 check */
f_4505(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4523r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4523r(t0,t1,t2,t3);}}

static void C_ccall f_4523r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[235]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4535,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1625 mode */
f_4468(t5,C_SCHEME_TRUE,t3);}

/* k4533 in open-input-file* in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1625 check */
f_4505(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4505(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4505,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4509,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1616 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4507 in check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1618 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[233],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1619 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[234],lf[79]);}}

/* k4519 in k4507 in check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4468(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4468,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4476,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[227]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1611 ##sys#error */
t8=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[228],t5);}
else{
t8=t4;
f_4476(2,t8,lf[229]);}}
else{
/* posixwin.scm: 1612 ##sys#error */
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[230],t5);}}
else{
t5=t4;
f_4476(2,t5,(C_truep(t2)?lf[231]:lf[232]));}}

/* k4474 in mode in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1607 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4459,3,t0,t1,t2);}
/* posixwin.scm: 1591 check */
f_4423(t1,t2,C_fix((C_word)2),lf[223]);}

/* file-write-access? in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4453,3,t0,t1,t2);}
/* posixwin.scm: 1590 check */
f_4423(t1,t2,C_fix((C_word)4),lf[222]);}

/* file-read-access? in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4447,3,t0,t1,t2);}
/* posixwin.scm: 1589 check */
f_4423(t1,t2,C_fix((C_word)2),lf[221]);}

/* check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4423(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4423,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4441,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1586 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t7,t2);}

/* k4443 in check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1586 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4439 in check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4433,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4433(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1587 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4431 in k4439 in check in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4393,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[219]);
t5=(C_word)C_i_check_exact_2(t3,lf[219]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4417,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4421,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1575 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t7,t2);}

/* k4419 in change-file-mode in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1575 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4415 in change-file-mode in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1576 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4407 in k4415 in change-file-mode in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1577 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[219],lf[220],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4337,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4347,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1483 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1485 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4345 in ##sys#interrupt-hook in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1484 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4324,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[180]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4311 in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4315,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[179]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4239r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4239r(t0,t1,t2);}}

static void C_ccall f_4239r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4243,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4243(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[19]+1),*((C_word*)lf[21]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4243(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4241 in create-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4255,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1420 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4246(2,t3,C_SCHEME_UNDEFINED);}}

/* k4253 in k4241 in create-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1421 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[35],lf[149],lf[150]);}

/* k4244 in k4241 in create-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1422 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4219r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4219r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4219r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[148]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4223,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4221 in with-output-to-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4229,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1405 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4228 in k4221 in with-output-to-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4229r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4229r(t0,t1,t2);}}

static void C_ccall f_4229r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4233,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1407 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4231 in a4228 in k4221 in with-output-to-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4199r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4199r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4199r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[146]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4203,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4201 in with-input-from-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4209,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1395 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4208 in k4201 in with-input-from-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4209r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4209r(t0,t1,t2);}}

static void C_ccall f_4209r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4213,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1397 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4211 in a4208 in k4201 in with-input-from-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[146]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4175r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4175r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4175r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4179,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4177 in call-with-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4184,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4190,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1385 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4189 in k4177 in call-with-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4190r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4190r(t0,t1,t2);}}

static void C_ccall f_4190r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4194,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1388 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4192 in a4189 in k4177 in call-with-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4183 in k4177 in call-with-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
/* posixwin.scm: 1386 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4151r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4151r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4151r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4155,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4153 in call-with-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4160,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1377 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4165 in k4153 in call-with-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4166r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4166r(t0,t1,t2);}}

static void C_ccall f_4166r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1380 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4168 in a4165 in k4153 in call-with-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4159 in k4153 in call-with-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
/* posixwin.scm: 1378 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4132,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4136,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1364 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[139]);}

/* k4134 in close-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4136,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1366 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4137 in k4134 in close-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1367 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[35],lf[139],lf[140],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4096r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4096r(t0,t1,t2,t3);}}

static void C_ccall f_4096r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[138]);
t5=f_4024(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4110,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[130]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1359 ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4127,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1360 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1361 badmode */
f_4036(t6,t5);}}}

/* k4125 in open-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4127,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4110(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4115 in open-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4110(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4108 in open-output-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1356 check */
f_4042(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4060r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4060r(t0,t1,t2,t3);}}

static void C_ccall f_4060r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[136]);
t5=f_4024(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4074,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[130]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4081,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1349 ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1350 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1351 badmode */
f_4036(t6,t5);}}}

/* k4089 in open-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4074(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4079 in open-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4074(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4072 in open-input-pipe in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1346 check */
f_4042(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4042(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4042,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4046,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1336 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4044 in check in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1338 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[132],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1339 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[135],lf[79]);}}

/* k4056 in k4044 in check in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_4036(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4036,NULL,2,t1,t2);}
/* posixwin.scm: 1334 ##sys#error */
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[131],t2);}

/* mode in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static C_word C_fcall f_4024(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[130]));}

/* canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3667,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3674,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3807,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1273 cwd */
t8=((C_word*)t0)[5];
f_3611(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1275 sref */
t10=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3813(t9,C_SCHEME_FALSE);}}}

/* k4012 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 sep? */
t2=((C_word*)t0)[3];
f_3813(t2,f_3600(t1));}

/* k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3824,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1277 cwd */
t4=((C_word*)t0)[7];
f_3611(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1280 cwd */
t5=((C_word*)t0)[7];
f_3611(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1281 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3998 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1281 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3987 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1282 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3843(t2,C_SCHEME_FALSE);}}

/* k3994 in k3987 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1282 sep? */
t2=((C_word*)t0)[3];
f_3843(t2,f_3600(t1));}

/* k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3843,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1284 cwd */
t4=((C_word*)t0)[6];
f_3611(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1290 cwd */
t5=((C_word*)t0)[6];
f_3611(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3982,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1291 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3980 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1291 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3959 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3978,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1292 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_3885(t2,C_SCHEME_FALSE);}}

/* k3976 in k3959 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1292 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3965 in k3959 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1293 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_3885(t2,C_SCHEME_FALSE);}}

/* k3972 in k3965 in k3959 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1293 sep? */
t2=((C_word*)t0)[3];
f_3885(t2,f_3600(t1));}

/* k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3885,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_3674(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3958,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1295 sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3956 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1295 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3935 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1296 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3891(2,t2,C_SCHEME_FALSE);}}

/* k3952 in k3935 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3941 in k3935 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3943,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1297 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3891(2,t2,C_SCHEME_FALSE);}}

/* k3948 in k3941 in k3935 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1299 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1303 sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k3932 in k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=f_3600(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3923,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1305 cwd */
t5=((C_word*)t0)[2];
f_3611(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1308 cwd */
t4=((C_word*)t0)[2];
f_3611(t4,t3);}}

/* k3928 in k3932 in k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1308 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[129],((C_word*)t0)[2]);}

/* k3921 in k3932 in k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1305 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3917 in k3932 in k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3896 in k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3902,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1301 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3900 in k3896 in k3889 in k3883 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1298 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k3877 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[127],((C_word*)t0)[2]);}

/* k3864 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1284 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3848 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1286 user */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3852 in k3848 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3858,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1287 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3856 in k3852 in k3848 in k3841 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 sappend */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[126],((C_word*)t0)[2],t1);}

/* k3835 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1280 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[125],((C_word*)t0)[2]);}

/* k3822 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1277 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3818 in k3811 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1276 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3805 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1273 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[124]);}

/* k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1309 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,t1,C_fix(3),t4);}

/* k3791 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[92]+1)))(4,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1,lf[123]);}

/* k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3683(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3683(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3683,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1311 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1312 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3762,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1323 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[122],t5);}}

/* k3763 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3762(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1325 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[121],t3);}}

/* k3772 in k3763 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3774,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3762(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3762(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3760 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1321 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3683(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1313 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1314 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=f_3600(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1316 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1319 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k3729 in k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3735,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3739,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1320 reverse */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3737 in k3729 in k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1320 isperse */
f_3595(((C_word*)t0)[2],t1);}

/* k3733 in k3729 in k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1318 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3710 in k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3716,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3720,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[119],((C_word*)t0)[2]);
/* posixwin.scm: 1317 reverse */
t5=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3718 in k3710 in k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1317 isperse */
f_3595(((C_word*)t0)[2],t1);}

/* k3714 in k3710 in k3741 in k3694 in k3688 in loop in k3679 in k3672 in canonical-path in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1315 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3620,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3626,a[2]=t2,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3644,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t1,t3,t4);}

/* a3643 in a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3650,a[2]=((C_word*)t0)[3],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3655 in a3643 in a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3656r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3656r(t0,t1,t2);}}

static void C_ccall f_3656r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3662,a[2]=t2,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* k572578 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3661 in a3655 in a3643 in a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3649 in a3643 in a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
/* posixwin.scm: 1268 cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3625 in a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3626,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3632,a[2]=t2,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* k572578 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3631 in a3625 in a3619 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3632,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[115]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[116]);}

/* k3616 in cwd in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static C_word C_fcall f_3600(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3595(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3595,NULL,2,t1,t2);}
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t1,t2,lf[113]);}

/* current-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3544r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3544r(t0,t1,t2);}}

static void C_ccall f_3544r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3548(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3548(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3546 in current-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3548,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1246 change-directory */
((C_proc3)C_retrieve_proc(*((C_word*)lf[95]+1)))(3,*((C_word*)lf[95]+1),((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1247 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3555 in k3546 in current-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3557,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3558 in k3555 in k3546 in current-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1251 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1252 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[103],lf[106]);}}

/* directory? in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3517,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3524,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3542,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1239 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t6,t2);}

/* k3540 in directory? in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1239 ##sys#platform-fixup-pathname */
((C_proc3)C_retrieve_proc(*((C_word*)lf[105]+1)))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* k3536 in directory? in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1238 ##sys#file-info */
t2=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3522 in directory? in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_3357r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3357r(t0,t1,t2);}}

static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3460,a[2]=t3,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=t4,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec419477 */
t6=t5;
f_3465(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?420473 */
t8=t4;
f_3460(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body417426 */
t10=t3;
f_3359(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec419 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3465,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3473,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1209 current-directory */
((C_proc2)C_retrieve_proc(*((C_word*)lf[103]+1)))(2,*((C_word*)lf[103]+1),t2);}

/* k3471 in def-spec419 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?420473 */
t2=((C_word*)t0)[3];
f_3460(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?420 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3460,NULL,3,t0,t1,t2);}
/* body417426 */
t3=((C_word*)t0)[2];
f_3359(t3,t1,t2,C_SCHEME_FALSE);}

/* body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[100]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3366,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1211 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1212 ##sys#make-pointer */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t2);}

/* k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1213 ##sys#make-pointer */
((C_proc2)C_retrieve_proc(*((C_word*)lf[102]+1)))(2,*((C_word*)lf[102]+1),t2);}

/* k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3459,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1214 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t3,((C_word*)t0)[4]);}

/* k3457 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1214 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3374 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1217 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li29),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3393(t6,((C_word*)t0)[6]);}}

/* loop in k3374 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3393,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1226 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k3401 in loop in k3374 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3415,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_3415(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_3415(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_3415(t7,C_SCHEME_FALSE);}}

/* k3413 in k3401 in loop in k3374 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3415,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1233 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3393(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1234 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3393(t3,t2);}}

/* k3423 in k3413 in k3401 in loop in k3374 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3383 in k3374 in k3370 in k3367 in k3364 in body417 in directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1218 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[100],lf[101],((C_word*)t0)[2]);}

/* delete-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3330,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1201 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t5,t2);}

/* k3353 in delete-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1201 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3349 in delete-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1202 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3341 in k3349 in delete-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1203 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[97],lf[98],((C_word*)t0)[2]);}

/* change-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3303,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[95]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3324,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3328,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1194 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t5,t2);}

/* k3326 in change-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1194 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3322 in change-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1195 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3314 in k3322 in change-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1196 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[95],lf[96],((C_word*)t0)[2]);}

/* create-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3163r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3163r(t0,t1,t2,t3);}}

static void C_ccall f_3163r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3167(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3167(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3165 in create-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[87]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1182 canonical-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1183 canonical-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t3,((C_word*)t0)[3]);}}

/* k3261 in k3165 in create-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3264,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3264 in k3261 in k3165 in create-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3264,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3282,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3280 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3282,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1154 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3272 in k3280 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1155 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[87],lf[88],((C_word*)t0)[2]);}

/* k3178 in k3165 in create-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3181 in k3178 in k3165 in create-directory in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3181,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3185,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1170 string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[92]+1)))(4,*((C_word*)lf[92]+1),t3,t2,lf[93]);}

/* k3183 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3193,a[2]=t4,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t1);
/* for-each */
t7=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a3192 in k3183 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3193,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3198,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1174 string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[90],t2);}

/* k3196 in a3192 in k3183 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3198,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_3202 in k3196 in a3192 in k3183 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3209,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3232 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3232,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3239,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1159 file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),t3,t2);}

/* k3237 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1160 ##sys#file-info */
t3=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3240 in k3237 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3207 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_3213 in k3207 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3213,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3231,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3229 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1154 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3221 in k3229 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1155 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[87],lf[88],((C_word*)t0)[2]);}

/* set-file-position! in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3102r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3102r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3102r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[82]);
t8=(C_word)C_i_check_exact_2(t6,lf[82]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3115,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1140 ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[85],lf[82],lf[86],t3,t2);}
else{
t10=t9;
f_3115(2,t10,C_SCHEME_UNDEFINED);}}

/* k3113 in set-file-position! in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1141 port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[81]+1)))(3,*((C_word*)lf[81]+1),t3,((C_word*)t0)[4]);}

/* k3128 in k3113 in set-file-position! in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[79]);
t4=((C_word*)t0)[4];
f_3121(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3121(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1145 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[44],lf[82],lf[84],((C_word*)t0)[5]);}}}

/* k3119 in k3113 in set-file-position! in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1146 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3122 in k3119 in k3113 in set-file-position! in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1147 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[82],lf[83],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3062,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3081,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1124 port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[81]+1)))(3,*((C_word*)lf[81]+1),t4,t2);}

/* k3079 in file-position in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[79]);
t4=((C_word*)t0)[2];
f_3066(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_3066(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1129 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[44],lf[77],lf[80],((C_word*)t0)[3]);}}}

/* k3064 in file-position in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3069,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1131 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3069(2,t3,C_SCHEME_UNDEFINED);}}

/* k3073 in k3064 in file-position in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1132 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[77],lf[78],((C_word*)t0)[2]);}

/* k3067 in k3064 in file-position in k3058 in k3054 in k3050 in k3046 in k3042 in k3038 in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_3029(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3029,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3031,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));}

/* f_3031 in stat-type in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3031,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3024,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3001,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[67]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3008,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1102 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t5,t2);}

/* k3020 in regular-file? in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1102 ##sys#file-info */
t2=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3006 in regular-file? in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2995,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1098 ##sys#stat */
f_2896(t3,t2);}

/* k2997 in file-permissions in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2989,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_2896(t3,t2);}

/* k2991 in file-owner in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2983,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2896(t3,t2);}

/* k2985 in file-change-time in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2977,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_2896(t3,t2);}

/* k2979 in file-access-time in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2971,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2975,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_2896(t3,t2);}

/* k2973 in file-modification-time in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2965,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1093 ##sys#stat */
f_2896(t3,t2);}

/* k2967 in file-size in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2934r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2934r(t0,t1,t2,t3);}}

static void C_ccall f_2934r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2938,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2938(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2938(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2936 in file-stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1087 ##sys#stat */
f_2896(t2,((C_word*)t0)[2]);}

/* k2939 in k2936 in file-stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_fcall f_2896(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2896,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2900,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2900(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2929,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1080 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t5,t2);}
else{
/* posixwin.scm: 1081 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[44],lf[58],t2);}}}

/* k2927 in ##sys#stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1080 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2923 in ##sys#stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2900(2,t2,(C_word)C_stat(t1));}

/* k2898 in ##sys#stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1083 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2907 in k2898 in ##sys#stat in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1084 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[57],((C_word*)t0)[2]);}

/* file-mkstemp in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2858,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[50]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1049 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2863 in file-mkstemp in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1051 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2866 in k2863 in file-mkstemp in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1053 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2871(2,t4,C_SCHEME_UNDEFINED);}}

/* k2886 in k2866 in k2863 in file-mkstemp in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1054 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[50],lf[52],((C_word*)t0)[2]);}

/* k2869 in k2866 in k2863 in file-mkstemp in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1055 ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2876 in k2869 in k2866 in k2863 in file-mkstemp in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1055 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2816r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2816r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2816r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[46]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2823,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2823(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1036 ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[44],lf[46],lf[48],t3);}}

/* k2821 in file-write in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[46]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2832,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2838,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1041 ##sys#update-errno */
t9=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2832(2,t8,C_SCHEME_UNDEFINED);}}

/* k2836 in k2821 in file-write in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1042 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[46],lf[47],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2830 in k2821 in file-write in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2771r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2771r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[42]);
t6=(C_word)C_i_check_exact_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2781,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2781(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1023 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2779 in file-read in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2784(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1025 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[44],lf[42],lf[45],t1);}}

/* k2782 in k2779 in file-read in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2787,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1028 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2787(2,t5,C_SCHEME_UNDEFINED);}}

/* k2794 in k2782 in k2779 in file-read in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1029 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[42],lf[43],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2785 in k2782 in k2779 in file-read in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2753,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[39]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2766,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1015 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2764 in file-close in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1016 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[39],lf[40],((C_word*)t0)[2]);}

/* file-open in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2712r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2712r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2712r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[34]);
t8=(C_word)C_i_check_exact_2(t3,lf[34]);
t9=(C_word)C_i_check_exact_2(t6,lf[34]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2729,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1005 ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t11,t2);}

/* k2743 in file-open in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1005 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2727 in file-open in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2732,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1007 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2732(2,t5,C_SCHEME_UNDEFINED);}}

/* k2736 in k2727 in file-open in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1008 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[35],lf[34],lf[36],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2730 in k2727 in file-open in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2666r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2666r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2670,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 936  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2668 in posix-error in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2679 in k2668 in posix-error in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 937  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k2675 in k2668 in posix-error in k2652 in k2649 in k2646 in k2643 in k2640 in k2637 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[508] = {
{"toplevel:posixwin_scm",(void*)C_posix_toplevel},
{"f_2639:posixwin_scm",(void*)f_2639},
{"f_2642:posixwin_scm",(void*)f_2642},
{"f_2645:posixwin_scm",(void*)f_2645},
{"f_2648:posixwin_scm",(void*)f_2648},
{"f_2651:posixwin_scm",(void*)f_2651},
{"f_2654:posixwin_scm",(void*)f_2654},
{"f_3040:posixwin_scm",(void*)f_3040},
{"f_3044:posixwin_scm",(void*)f_3044},
{"f_3048:posixwin_scm",(void*)f_3048},
{"f_3052:posixwin_scm",(void*)f_3052},
{"f_3056:posixwin_scm",(void*)f_3056},
{"f_3060:posixwin_scm",(void*)f_3060},
{"f_4313:posixwin_scm",(void*)f_4313},
{"f_6861:posixwin_scm",(void*)f_6861},
{"f_6291:posixwin_scm",(void*)f_6291},
{"f_6851:posixwin_scm",(void*)f_6851},
{"f_6294:posixwin_scm",(void*)f_6294},
{"f_6841:posixwin_scm",(void*)f_6841},
{"f_6297:posixwin_scm",(void*)f_6297},
{"f_6831:posixwin_scm",(void*)f_6831},
{"f_6300:posixwin_scm",(void*)f_6300},
{"f_6821:posixwin_scm",(void*)f_6821},
{"f_6303:posixwin_scm",(void*)f_6303},
{"f_6811:posixwin_scm",(void*)f_6811},
{"f_6306:posixwin_scm",(void*)f_6306},
{"f_6801:posixwin_scm",(void*)f_6801},
{"f_6309:posixwin_scm",(void*)f_6309},
{"f_6791:posixwin_scm",(void*)f_6791},
{"f_6312:posixwin_scm",(void*)f_6312},
{"f_6781:posixwin_scm",(void*)f_6781},
{"f_6315:posixwin_scm",(void*)f_6315},
{"f_6771:posixwin_scm",(void*)f_6771},
{"f_6318:posixwin_scm",(void*)f_6318},
{"f_6761:posixwin_scm",(void*)f_6761},
{"f_6321:posixwin_scm",(void*)f_6321},
{"f_6751:posixwin_scm",(void*)f_6751},
{"f_6324:posixwin_scm",(void*)f_6324},
{"f_6741:posixwin_scm",(void*)f_6741},
{"f_6327:posixwin_scm",(void*)f_6327},
{"f_6731:posixwin_scm",(void*)f_6731},
{"f_6330:posixwin_scm",(void*)f_6330},
{"f_6721:posixwin_scm",(void*)f_6721},
{"f_6333:posixwin_scm",(void*)f_6333},
{"f_6711:posixwin_scm",(void*)f_6711},
{"f_6336:posixwin_scm",(void*)f_6336},
{"f_6701:posixwin_scm",(void*)f_6701},
{"f_6339:posixwin_scm",(void*)f_6339},
{"f_6691:posixwin_scm",(void*)f_6691},
{"f_6342:posixwin_scm",(void*)f_6342},
{"f_6681:posixwin_scm",(void*)f_6681},
{"f_6345:posixwin_scm",(void*)f_6345},
{"f_6671:posixwin_scm",(void*)f_6671},
{"f_6348:posixwin_scm",(void*)f_6348},
{"f_6661:posixwin_scm",(void*)f_6661},
{"f_6351:posixwin_scm",(void*)f_6351},
{"f_6651:posixwin_scm",(void*)f_6651},
{"f_6354:posixwin_scm",(void*)f_6354},
{"f_6641:posixwin_scm",(void*)f_6641},
{"f_6357:posixwin_scm",(void*)f_6357},
{"f_6631:posixwin_scm",(void*)f_6631},
{"f_6360:posixwin_scm",(void*)f_6360},
{"f_6621:posixwin_scm",(void*)f_6621},
{"f_6363:posixwin_scm",(void*)f_6363},
{"f_6611:posixwin_scm",(void*)f_6611},
{"f_6366:posixwin_scm",(void*)f_6366},
{"f_6601:posixwin_scm",(void*)f_6601},
{"f_6369:posixwin_scm",(void*)f_6369},
{"f_6591:posixwin_scm",(void*)f_6591},
{"f_6372:posixwin_scm",(void*)f_6372},
{"f_6581:posixwin_scm",(void*)f_6581},
{"f_6375:posixwin_scm",(void*)f_6375},
{"f_6571:posixwin_scm",(void*)f_6571},
{"f_6378:posixwin_scm",(void*)f_6378},
{"f_6561:posixwin_scm",(void*)f_6561},
{"f_6381:posixwin_scm",(void*)f_6381},
{"f_6551:posixwin_scm",(void*)f_6551},
{"f_6384:posixwin_scm",(void*)f_6384},
{"f_6541:posixwin_scm",(void*)f_6541},
{"f_6387:posixwin_scm",(void*)f_6387},
{"f_6531:posixwin_scm",(void*)f_6531},
{"f_6390:posixwin_scm",(void*)f_6390},
{"f_6521:posixwin_scm",(void*)f_6521},
{"f_6393:posixwin_scm",(void*)f_6393},
{"f_6511:posixwin_scm",(void*)f_6511},
{"f_6396:posixwin_scm",(void*)f_6396},
{"f_6501:posixwin_scm",(void*)f_6501},
{"f_6399:posixwin_scm",(void*)f_6399},
{"f_6491:posixwin_scm",(void*)f_6491},
{"f_6402:posixwin_scm",(void*)f_6402},
{"f_6481:posixwin_scm",(void*)f_6481},
{"f_6405:posixwin_scm",(void*)f_6405},
{"f_6471:posixwin_scm",(void*)f_6471},
{"f_6408:posixwin_scm",(void*)f_6408},
{"f_6461:posixwin_scm",(void*)f_6461},
{"f_6411:posixwin_scm",(void*)f_6411},
{"f_6451:posixwin_scm",(void*)f_6451},
{"f_6414:posixwin_scm",(void*)f_6414},
{"f_6441:posixwin_scm",(void*)f_6441},
{"f_6417:posixwin_scm",(void*)f_6417},
{"f_6423:posixwin_scm",(void*)f_6423},
{"f_6420:posixwin_scm",(void*)f_6420},
{"f_6070:posixwin_scm",(void*)f_6070},
{"f_6221:posixwin_scm",(void*)f_6221},
{"f_6227:posixwin_scm",(void*)f_6227},
{"f_6216:posixwin_scm",(void*)f_6216},
{"f_6211:posixwin_scm",(void*)f_6211},
{"f_6072:posixwin_scm",(void*)f_6072},
{"f_6198:posixwin_scm",(void*)f_6198},
{"f_6206:posixwin_scm",(void*)f_6206},
{"f_6079:posixwin_scm",(void*)f_6079},
{"f_6186:posixwin_scm",(void*)f_6186},
{"f_6089:posixwin_scm",(void*)f_6089},
{"f_6091:posixwin_scm",(void*)f_6091},
{"f_6110:posixwin_scm",(void*)f_6110},
{"f_6172:posixwin_scm",(void*)f_6172},
{"f_6179:posixwin_scm",(void*)f_6179},
{"f_6166:posixwin_scm",(void*)f_6166},
{"f_6125:posixwin_scm",(void*)f_6125},
{"f_6156:posixwin_scm",(void*)f_6156},
{"f_6142:posixwin_scm",(void*)f_6142},
{"f_6154:posixwin_scm",(void*)f_6154},
{"f_6150:posixwin_scm",(void*)f_6150},
{"f_6137:posixwin_scm",(void*)f_6137},
{"f_6135:posixwin_scm",(void*)f_6135},
{"f_6190:posixwin_scm",(void*)f_6190},
{"f_6055:posixwin_scm",(void*)f_6055},
{"f_6065:posixwin_scm",(void*)f_6065},
{"f_6024:posixwin_scm",(void*)f_6024},
{"f_6050:posixwin_scm",(void*)f_6050},
{"f_6035:posixwin_scm",(void*)f_6035},
{"f_6039:posixwin_scm",(void*)f_6039},
{"f_6043:posixwin_scm",(void*)f_6043},
{"f_6047:posixwin_scm",(void*)f_6047},
{"f_6012:posixwin_scm",(void*)f_6012},
{"f_6009:posixwin_scm",(void*)f_6009},
{"f_5949:posixwin_scm",(void*)f_5949},
{"f_5976:posixwin_scm",(void*)f_5976},
{"f_5986:posixwin_scm",(void*)f_5986},
{"f_5970:posixwin_scm",(void*)f_5970},
{"f_5937:posixwin_scm",(void*)f_5937},
{"f_5857:posixwin_scm",(void*)f_5857},
{"f_5874:posixwin_scm",(void*)f_5874},
{"f_5869:posixwin_scm",(void*)f_5869},
{"f_5864:posixwin_scm",(void*)f_5864},
{"f_5859:posixwin_scm",(void*)f_5859},
{"f_5777:posixwin_scm",(void*)f_5777},
{"f_5794:posixwin_scm",(void*)f_5794},
{"f_5789:posixwin_scm",(void*)f_5789},
{"f_5784:posixwin_scm",(void*)f_5784},
{"f_5779:posixwin_scm",(void*)f_5779},
{"f_5715:posixwin_scm",(void*)f_5715},
{"f_5771:posixwin_scm",(void*)f_5771},
{"f_5775:posixwin_scm",(void*)f_5775},
{"f_5736:posixwin_scm",(void*)f_5736},
{"f_5739:posixwin_scm",(void*)f_5739},
{"f_5750:posixwin_scm",(void*)f_5750},
{"f_5744:posixwin_scm",(void*)f_5744},
{"f_5717:posixwin_scm",(void*)f_5717},
{"f_5726:posixwin_scm",(void*)f_5726},
{"f_5596:posixwin_scm",(void*)f_5596},
{"f_5600:posixwin_scm",(void*)f_5600},
{"f_5691:posixwin_scm",(void*)f_5691},
{"f_5603:posixwin_scm",(void*)f_5603},
{"f_5659:posixwin_scm",(void*)f_5659},
{"f_5663:posixwin_scm",(void*)f_5663},
{"f_5667:posixwin_scm",(void*)f_5667},
{"f_5671:posixwin_scm",(void*)f_5671},
{"f_5675:posixwin_scm",(void*)f_5675},
{"f_5538:posixwin_scm",(void*)f_5538},
{"f_5542:posixwin_scm",(void*)f_5542},
{"f_5652:posixwin_scm",(void*)f_5652},
{"f_5632:posixwin_scm",(void*)f_5632},
{"f_5636:posixwin_scm",(void*)f_5636},
{"f_5640:posixwin_scm",(void*)f_5640},
{"f_5504:posixwin_scm",(void*)f_5504},
{"f_5521:posixwin_scm",(void*)f_5521},
{"f_5525:posixwin_scm",(void*)f_5525},
{"f_5498:posixwin_scm",(void*)f_5498},
{"f_5477:posixwin_scm",(void*)f_5477},
{"f_5481:posixwin_scm",(void*)f_5481},
{"f_5493:posixwin_scm",(void*)f_5493},
{"f_5474:posixwin_scm",(void*)f_5474},
{"f_5387:posixwin_scm",(void*)f_5387},
{"f_5411:posixwin_scm",(void*)f_5411},
{"f_5406:posixwin_scm",(void*)f_5406},
{"f_5401:posixwin_scm",(void*)f_5401},
{"f_5389:posixwin_scm",(void*)f_5389},
{"f_5393:posixwin_scm",(void*)f_5393},
{"f_5300:posixwin_scm",(void*)f_5300},
{"f_5324:posixwin_scm",(void*)f_5324},
{"f_5319:posixwin_scm",(void*)f_5319},
{"f_5314:posixwin_scm",(void*)f_5314},
{"f_5302:posixwin_scm",(void*)f_5302},
{"f_5306:posixwin_scm",(void*)f_5306},
{"f_5285:posixwin_scm",(void*)f_5285},
{"f_5289:posixwin_scm",(void*)f_5289},
{"f_5252:posixwin_scm",(void*)f_5252},
{"f_5259:posixwin_scm",(void*)f_5259},
{"f_5262:posixwin_scm",(void*)f_5262},
{"f_5279:posixwin_scm",(void*)f_5279},
{"f_5265:posixwin_scm",(void*)f_5265},
{"f_5268:posixwin_scm",(void*)f_5268},
{"f_5275:posixwin_scm",(void*)f_5275},
{"f_5202:posixwin_scm",(void*)f_5202},
{"f_5214:posixwin_scm",(void*)f_5214},
{"f_5233:posixwin_scm",(void*)f_5233},
{"f_5185:posixwin_scm",(void*)f_5185},
{"f_5168:posixwin_scm",(void*)f_5168},
{"f_5089:posixwin_scm",(void*)f_5089},
{"f_5132:posixwin_scm",(void*)f_5132},
{"f_5163:posixwin_scm",(void*)f_5163},
{"f_5160:posixwin_scm",(void*)f_5160},
{"f_5094:posixwin_scm",(void*)f_5094},
{"f_5098:posixwin_scm",(void*)f_5098},
{"f_5103:posixwin_scm",(void*)f_5103},
{"f_5127:posixwin_scm",(void*)f_5127},
{"f_5116:posixwin_scm",(void*)f_5116},
{"f_4974:posixwin_scm",(void*)f_4974},
{"f_4980:posixwin_scm",(void*)f_4980},
{"f_5001:posixwin_scm",(void*)f_5001},
{"f_5078:posixwin_scm",(void*)f_5078},
{"f_5005:posixwin_scm",(void*)f_5005},
{"f_5008:posixwin_scm",(void*)f_5008},
{"f_5011:posixwin_scm",(void*)f_5011},
{"f_5018:posixwin_scm",(void*)f_5018},
{"f_5020:posixwin_scm",(void*)f_5020},
{"f_5037:posixwin_scm",(void*)f_5037},
{"f_5047:posixwin_scm",(void*)f_5047},
{"f_5051:posixwin_scm",(void*)f_5051},
{"f_4995:posixwin_scm",(void*)f_4995},
{"f_4915:posixwin_scm",(void*)f_4915},
{"f_4919:posixwin_scm",(void*)f_4919},
{"f_4925:posixwin_scm",(void*)f_4925},
{"f_4909:posixwin_scm",(void*)f_4909},
{"f_4913:posixwin_scm",(void*)f_4913},
{"f_4893:posixwin_scm",(void*)f_4893},
{"f_4881:posixwin_scm",(void*)f_4881},
{"f_4866:posixwin_scm",(void*)f_4866},
{"f_4870:posixwin_scm",(void*)f_4870},
{"f_4799:posixwin_scm",(void*)f_4799},
{"f_4803:posixwin_scm",(void*)f_4803},
{"f_4806:posixwin_scm",(void*)f_4806},
{"f_4828:posixwin_scm",(void*)f_4828},
{"f_4825:posixwin_scm",(void*)f_4825},
{"f_4815:posixwin_scm",(void*)f_4815},
{"f_4766:posixwin_scm",(void*)f_4766},
{"f_4770:posixwin_scm",(void*)f_4770},
{"f_4747:posixwin_scm",(void*)f_4747},
{"f_4738:posixwin_scm",(void*)f_4738},
{"f_4719:posixwin_scm",(void*)f_4719},
{"f_4653:posixwin_scm",(void*)f_4653},
{"f_4659:posixwin_scm",(void*)f_4659},
{"f_4663:posixwin_scm",(void*)f_4663},
{"f_4671:posixwin_scm",(void*)f_4671},
{"f_4697:posixwin_scm",(void*)f_4697},
{"f_4701:posixwin_scm",(void*)f_4701},
{"f_4689:posixwin_scm",(void*)f_4689},
{"f_4633:posixwin_scm",(void*)f_4633},
{"f_4641:posixwin_scm",(void*)f_4641},
{"f_4616:posixwin_scm",(void*)f_4616},
{"f_4627:posixwin_scm",(void*)f_4627},
{"f_4631:posixwin_scm",(void*)f_4631},
{"f_4586:posixwin_scm",(void*)f_4586},
{"f_4593:posixwin_scm",(void*)f_4593},
{"f_4602:posixwin_scm",(void*)f_4602},
{"f_4596:posixwin_scm",(void*)f_4596},
{"f_4551:posixwin_scm",(void*)f_4551},
{"f_4555:posixwin_scm",(void*)f_4555},
{"f_4584:posixwin_scm",(void*)f_4584},
{"f_4570:posixwin_scm",(void*)f_4570},
{"f_4564:posixwin_scm",(void*)f_4564},
{"f_4537:posixwin_scm",(void*)f_4537},
{"f_4549:posixwin_scm",(void*)f_4549},
{"f_4523:posixwin_scm",(void*)f_4523},
{"f_4535:posixwin_scm",(void*)f_4535},
{"f_4505:posixwin_scm",(void*)f_4505},
{"f_4509:posixwin_scm",(void*)f_4509},
{"f_4521:posixwin_scm",(void*)f_4521},
{"f_4468:posixwin_scm",(void*)f_4468},
{"f_4476:posixwin_scm",(void*)f_4476},
{"f_4459:posixwin_scm",(void*)f_4459},
{"f_4453:posixwin_scm",(void*)f_4453},
{"f_4447:posixwin_scm",(void*)f_4447},
{"f_4423:posixwin_scm",(void*)f_4423},
{"f_4445:posixwin_scm",(void*)f_4445},
{"f_4441:posixwin_scm",(void*)f_4441},
{"f_4433:posixwin_scm",(void*)f_4433},
{"f_4393:posixwin_scm",(void*)f_4393},
{"f_4421:posixwin_scm",(void*)f_4421},
{"f_4417:posixwin_scm",(void*)f_4417},
{"f_4409:posixwin_scm",(void*)f_4409},
{"f_4337:posixwin_scm",(void*)f_4337},
{"f_4347:posixwin_scm",(void*)f_4347},
{"f_4324:posixwin_scm",(void*)f_4324},
{"f_4315:posixwin_scm",(void*)f_4315},
{"f_4239:posixwin_scm",(void*)f_4239},
{"f_4243:posixwin_scm",(void*)f_4243},
{"f_4255:posixwin_scm",(void*)f_4255},
{"f_4246:posixwin_scm",(void*)f_4246},
{"f_4219:posixwin_scm",(void*)f_4219},
{"f_4223:posixwin_scm",(void*)f_4223},
{"f_4229:posixwin_scm",(void*)f_4229},
{"f_4233:posixwin_scm",(void*)f_4233},
{"f_4199:posixwin_scm",(void*)f_4199},
{"f_4203:posixwin_scm",(void*)f_4203},
{"f_4209:posixwin_scm",(void*)f_4209},
{"f_4213:posixwin_scm",(void*)f_4213},
{"f_4175:posixwin_scm",(void*)f_4175},
{"f_4179:posixwin_scm",(void*)f_4179},
{"f_4190:posixwin_scm",(void*)f_4190},
{"f_4194:posixwin_scm",(void*)f_4194},
{"f_4184:posixwin_scm",(void*)f_4184},
{"f_4151:posixwin_scm",(void*)f_4151},
{"f_4155:posixwin_scm",(void*)f_4155},
{"f_4166:posixwin_scm",(void*)f_4166},
{"f_4170:posixwin_scm",(void*)f_4170},
{"f_4160:posixwin_scm",(void*)f_4160},
{"f_4132:posixwin_scm",(void*)f_4132},
{"f_4136:posixwin_scm",(void*)f_4136},
{"f_4139:posixwin_scm",(void*)f_4139},
{"f_4096:posixwin_scm",(void*)f_4096},
{"f_4127:posixwin_scm",(void*)f_4127},
{"f_4117:posixwin_scm",(void*)f_4117},
{"f_4110:posixwin_scm",(void*)f_4110},
{"f_4060:posixwin_scm",(void*)f_4060},
{"f_4091:posixwin_scm",(void*)f_4091},
{"f_4081:posixwin_scm",(void*)f_4081},
{"f_4074:posixwin_scm",(void*)f_4074},
{"f_4042:posixwin_scm",(void*)f_4042},
{"f_4046:posixwin_scm",(void*)f_4046},
{"f_4058:posixwin_scm",(void*)f_4058},
{"f_4036:posixwin_scm",(void*)f_4036},
{"f_4024:posixwin_scm",(void*)f_4024},
{"f_3667:posixwin_scm",(void*)f_3667},
{"f_4014:posixwin_scm",(void*)f_4014},
{"f_3813:posixwin_scm",(void*)f_3813},
{"f_4000:posixwin_scm",(void*)f_4000},
{"f_3989:posixwin_scm",(void*)f_3989},
{"f_3996:posixwin_scm",(void*)f_3996},
{"f_3843:posixwin_scm",(void*)f_3843},
{"f_3982:posixwin_scm",(void*)f_3982},
{"f_3961:posixwin_scm",(void*)f_3961},
{"f_3978:posixwin_scm",(void*)f_3978},
{"f_3967:posixwin_scm",(void*)f_3967},
{"f_3974:posixwin_scm",(void*)f_3974},
{"f_3885:posixwin_scm",(void*)f_3885},
{"f_3958:posixwin_scm",(void*)f_3958},
{"f_3937:posixwin_scm",(void*)f_3937},
{"f_3954:posixwin_scm",(void*)f_3954},
{"f_3943:posixwin_scm",(void*)f_3943},
{"f_3950:posixwin_scm",(void*)f_3950},
{"f_3891:posixwin_scm",(void*)f_3891},
{"f_3934:posixwin_scm",(void*)f_3934},
{"f_3930:posixwin_scm",(void*)f_3930},
{"f_3923:posixwin_scm",(void*)f_3923},
{"f_3919:posixwin_scm",(void*)f_3919},
{"f_3898:posixwin_scm",(void*)f_3898},
{"f_3902:posixwin_scm",(void*)f_3902},
{"f_3879:posixwin_scm",(void*)f_3879},
{"f_3866:posixwin_scm",(void*)f_3866},
{"f_3850:posixwin_scm",(void*)f_3850},
{"f_3854:posixwin_scm",(void*)f_3854},
{"f_3858:posixwin_scm",(void*)f_3858},
{"f_3837:posixwin_scm",(void*)f_3837},
{"f_3824:posixwin_scm",(void*)f_3824},
{"f_3820:posixwin_scm",(void*)f_3820},
{"f_3807:posixwin_scm",(void*)f_3807},
{"f_3674:posixwin_scm",(void*)f_3674},
{"f_3793:posixwin_scm",(void*)f_3793},
{"f_3681:posixwin_scm",(void*)f_3681},
{"f_3683:posixwin_scm",(void*)f_3683},
{"f_3690:posixwin_scm",(void*)f_3690},
{"f_3765:posixwin_scm",(void*)f_3765},
{"f_3774:posixwin_scm",(void*)f_3774},
{"f_3762:posixwin_scm",(void*)f_3762},
{"f_3696:posixwin_scm",(void*)f_3696},
{"f_3743:posixwin_scm",(void*)f_3743},
{"f_3731:posixwin_scm",(void*)f_3731},
{"f_3739:posixwin_scm",(void*)f_3739},
{"f_3735:posixwin_scm",(void*)f_3735},
{"f_3712:posixwin_scm",(void*)f_3712},
{"f_3720:posixwin_scm",(void*)f_3720},
{"f_3716:posixwin_scm",(void*)f_3716},
{"f_3611:posixwin_scm",(void*)f_3611},
{"f_3620:posixwin_scm",(void*)f_3620},
{"f_3644:posixwin_scm",(void*)f_3644},
{"f_3656:posixwin_scm",(void*)f_3656},
{"f_3662:posixwin_scm",(void*)f_3662},
{"f_3650:posixwin_scm",(void*)f_3650},
{"f_3626:posixwin_scm",(void*)f_3626},
{"f_3632:posixwin_scm",(void*)f_3632},
{"f_3618:posixwin_scm",(void*)f_3618},
{"f_3600:posixwin_scm",(void*)f_3600},
{"f_3595:posixwin_scm",(void*)f_3595},
{"f_3544:posixwin_scm",(void*)f_3544},
{"f_3548:posixwin_scm",(void*)f_3548},
{"f_3557:posixwin_scm",(void*)f_3557},
{"f_3560:posixwin_scm",(void*)f_3560},
{"f_3517:posixwin_scm",(void*)f_3517},
{"f_3542:posixwin_scm",(void*)f_3542},
{"f_3538:posixwin_scm",(void*)f_3538},
{"f_3524:posixwin_scm",(void*)f_3524},
{"f_3357:posixwin_scm",(void*)f_3357},
{"f_3465:posixwin_scm",(void*)f_3465},
{"f_3473:posixwin_scm",(void*)f_3473},
{"f_3460:posixwin_scm",(void*)f_3460},
{"f_3359:posixwin_scm",(void*)f_3359},
{"f_3366:posixwin_scm",(void*)f_3366},
{"f_3369:posixwin_scm",(void*)f_3369},
{"f_3372:posixwin_scm",(void*)f_3372},
{"f_3459:posixwin_scm",(void*)f_3459},
{"f_3376:posixwin_scm",(void*)f_3376},
{"f_3393:posixwin_scm",(void*)f_3393},
{"f_3403:posixwin_scm",(void*)f_3403},
{"f_3415:posixwin_scm",(void*)f_3415},
{"f_3425:posixwin_scm",(void*)f_3425},
{"f_3385:posixwin_scm",(void*)f_3385},
{"f_3330:posixwin_scm",(void*)f_3330},
{"f_3355:posixwin_scm",(void*)f_3355},
{"f_3351:posixwin_scm",(void*)f_3351},
{"f_3343:posixwin_scm",(void*)f_3343},
{"f_3303:posixwin_scm",(void*)f_3303},
{"f_3328:posixwin_scm",(void*)f_3328},
{"f_3324:posixwin_scm",(void*)f_3324},
{"f_3316:posixwin_scm",(void*)f_3316},
{"f_3163:posixwin_scm",(void*)f_3163},
{"f_3167:posixwin_scm",(void*)f_3167},
{"f_3263:posixwin_scm",(void*)f_3263},
{"f_3264:posixwin_scm",(void*)f_3264},
{"f_3282:posixwin_scm",(void*)f_3282},
{"f_3274:posixwin_scm",(void*)f_3274},
{"f_3180:posixwin_scm",(void*)f_3180},
{"f_3181:posixwin_scm",(void*)f_3181},
{"f_3185:posixwin_scm",(void*)f_3185},
{"f_3193:posixwin_scm",(void*)f_3193},
{"f_3198:posixwin_scm",(void*)f_3198},
{"f_3202:posixwin_scm",(void*)f_3202},
{"f_3232:posixwin_scm",(void*)f_3232},
{"f_3239:posixwin_scm",(void*)f_3239},
{"f_3242:posixwin_scm",(void*)f_3242},
{"f_3209:posixwin_scm",(void*)f_3209},
{"f_3213:posixwin_scm",(void*)f_3213},
{"f_3231:posixwin_scm",(void*)f_3231},
{"f_3223:posixwin_scm",(void*)f_3223},
{"f_3102:posixwin_scm",(void*)f_3102},
{"f_3115:posixwin_scm",(void*)f_3115},
{"f_3130:posixwin_scm",(void*)f_3130},
{"f_3121:posixwin_scm",(void*)f_3121},
{"f_3124:posixwin_scm",(void*)f_3124},
{"f_3062:posixwin_scm",(void*)f_3062},
{"f_3081:posixwin_scm",(void*)f_3081},
{"f_3066:posixwin_scm",(void*)f_3066},
{"f_3075:posixwin_scm",(void*)f_3075},
{"f_3069:posixwin_scm",(void*)f_3069},
{"f_3029:posixwin_scm",(void*)f_3029},
{"f_3031:posixwin_scm",(void*)f_3031},
{"f_3024:posixwin_scm",(void*)f_3024},
{"f_3001:posixwin_scm",(void*)f_3001},
{"f_3022:posixwin_scm",(void*)f_3022},
{"f_3008:posixwin_scm",(void*)f_3008},
{"f_2995:posixwin_scm",(void*)f_2995},
{"f_2999:posixwin_scm",(void*)f_2999},
{"f_2989:posixwin_scm",(void*)f_2989},
{"f_2993:posixwin_scm",(void*)f_2993},
{"f_2983:posixwin_scm",(void*)f_2983},
{"f_2987:posixwin_scm",(void*)f_2987},
{"f_2977:posixwin_scm",(void*)f_2977},
{"f_2981:posixwin_scm",(void*)f_2981},
{"f_2971:posixwin_scm",(void*)f_2971},
{"f_2975:posixwin_scm",(void*)f_2975},
{"f_2965:posixwin_scm",(void*)f_2965},
{"f_2969:posixwin_scm",(void*)f_2969},
{"f_2934:posixwin_scm",(void*)f_2934},
{"f_2938:posixwin_scm",(void*)f_2938},
{"f_2941:posixwin_scm",(void*)f_2941},
{"f_2896:posixwin_scm",(void*)f_2896},
{"f_2929:posixwin_scm",(void*)f_2929},
{"f_2925:posixwin_scm",(void*)f_2925},
{"f_2900:posixwin_scm",(void*)f_2900},
{"f_2909:posixwin_scm",(void*)f_2909},
{"f_2858:posixwin_scm",(void*)f_2858},
{"f_2865:posixwin_scm",(void*)f_2865},
{"f_2868:posixwin_scm",(void*)f_2868},
{"f_2888:posixwin_scm",(void*)f_2888},
{"f_2871:posixwin_scm",(void*)f_2871},
{"f_2878:posixwin_scm",(void*)f_2878},
{"f_2816:posixwin_scm",(void*)f_2816},
{"f_2823:posixwin_scm",(void*)f_2823},
{"f_2838:posixwin_scm",(void*)f_2838},
{"f_2832:posixwin_scm",(void*)f_2832},
{"f_2771:posixwin_scm",(void*)f_2771},
{"f_2781:posixwin_scm",(void*)f_2781},
{"f_2784:posixwin_scm",(void*)f_2784},
{"f_2796:posixwin_scm",(void*)f_2796},
{"f_2787:posixwin_scm",(void*)f_2787},
{"f_2753:posixwin_scm",(void*)f_2753},
{"f_2766:posixwin_scm",(void*)f_2766},
{"f_2712:posixwin_scm",(void*)f_2712},
{"f_2745:posixwin_scm",(void*)f_2745},
{"f_2729:posixwin_scm",(void*)f_2729},
{"f_2738:posixwin_scm",(void*)f_2738},
{"f_2732:posixwin_scm",(void*)f_2732},
{"f_2666:posixwin_scm",(void*)f_2666},
{"f_2670:posixwin_scm",(void*)f_2670},
{"f_2681:posixwin_scm",(void*)f_2681},
{"f_2677:posixwin_scm",(void*)f_2677},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
