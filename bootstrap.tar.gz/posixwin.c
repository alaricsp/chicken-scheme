/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-05 08:25
   Version 3.0.1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on tablet (Linux)
   SVN rev. 8281
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[365];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,51,32,102,108,97,103,115,49,52,32,46,32,109,111,100,101,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,50,51,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,50,55,32,115,105,122,101,50,56,32,46,32,98,117,102,102,101,114,50,57,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,51,55,32,98,117,102,102,101,114,51,56,32,46,32,115,105,122,101,51,57,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,52,56,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,53,53,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,115,116,97,116,32,102,53,57,32,46,32,103,53,56,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,102,105,108,101,45,115,105,122,101,32,102,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,54,56,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,111,119,110,101,114,32,102,55,52,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,23),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,24),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,56,49,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,44),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,56,55,32,112,111,115,56,56,32,46,32,119,104,101,110,99,101,56,57,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,57,53,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,57,56,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,48,49,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,49,49,32,115,112,101,99,49,49,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,49,56,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,49,52,32,37,115,112,101,99,49,48,57,49,51,56,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,49,49,51,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,49,48,55,49,48,56,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,49,52,52,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,49,52,56,49,52,57,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,49,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,49,54,49,32,105,110,112,49,54,50,32,114,49,54,51,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,49,54,55,32,46,32,109,49,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,49,55,51,32,46,32,109,49,55,52,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,49,55,57,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,50,48,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,20),40,97,50,48,49,56,32,46,32,114,101,115,117,108,116,115,49,57,55,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,49,57,51,32,112,114,111,99,49,57,52,32,46,32,109,111,100,101,49,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,50,48,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,20),40,97,50,48,52,50,32,46,32,114,101,115,117,108,116,115,50,48,51,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,49,57,57,32,112,114,111,99,50,48,48,32,46,32,109,111,100,101,50,48,49,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,20),40,97,50,48,54,49,32,46,32,114,101,115,117,108,116,115,50,49,48,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,50,48,53,32,116,104,117,110,107,50,48,54,32,46,32,109,111,100,101,50,48,55,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,97,50,48,56,49,32,46,32,114,101,115,117,108,116,115,50,49,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,50,49,52,32,116,104,117,110,107,50,49,53,32,46,32,109,111,100,101,50,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,23),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,103,50,50,54,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,50,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,50,51,55,32,112,114,111,99,50,51,56,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,50,52,49,32,115,116,97,116,101,50,52,50,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,50,52,55,32,109,50,52,56,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,50,53,51,32,97,99,99,50,53,52,32,108,111,99,50,53,53,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,54,48,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,54,49,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,50,54,55,32,109,50,54,56,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,50,55,50,32,105,110,112,50,55,51,32,114,50,55,52,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,50,55,56,32,46,32,109,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,50,56,49,32,46,32,109,50,56,50,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,50,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,50,57,50,32,46,32,110,101,119,50,57,51,41,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,51,48,48,32,118,97,108,51,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,51,48,53,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,51,49,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,49,54,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,51,50,50,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,51,50,52,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,51,51,50,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,30),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,51,52,57,32,46,32,103,51,52,56,51,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,51,54,48,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,51,55,49,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,51,55,50,32,109,111,100,101,51,55,51,32,46,32,115,105,122,101,51,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,97,50,56,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,52,48,55,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,37),40,97,50,56,53,51,32,100,105,114,51,57,50,51,57,53,32,102,105,108,51,57,51,51,57,54,32,101,120,116,51,57,52,51,57,55,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,51,57,48,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,51,56,56,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,50,53,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,52,50,50,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,105,108,115,116,52,50,56,32,111,108,115,116,52,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,35),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,52,49,57,32,101,120,97,99,116,102,52,50,48,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,32),40,115,101,116,97,114,103,32,97,52,51,56,52,52,50,32,97,52,51,55,52,52,51,32,97,52,51,54,52,52,52,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,32),40,115,101,116,101,110,118,32,97,52,52,56,52,53,50,32,97,52,52,55,52,53,51,32,97,52,52,54,52,53,52,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,17),40,100,111,52,54,48,32,108,52,54,50,32,105,52,54,51,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,57),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,52,53,54,32,108,115,116,52,53,55,32,97,114,103,118,101,99,45,115,101,116,116,101,114,52,53,56,32,105,100,120,52,53,57,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,62),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,52,54,57,32,102,105,108,101,110,97,109,101,52,55,48,32,97,114,103,108,115,116,52,55,49,32,101,110,118,108,115,116,52,55,50,32,101,120,97,99,116,102,52,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,49),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,52,56,48,32,109,115,103,52,56,49,32,102,105,108,101,110,97,109,101,52,56,50,32,114,101,115,52,56,51,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,39),40,98,111,100,121,52,57,51,32,97,114,103,108,115,116,53,48,48,32,101,110,118,108,115,116,53,48,49,32,101,120,97,99,116,102,53,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,52,57,55,32,37,97,114,103,108,115,116,52,57,48,53,48,53,32,37,101,110,118,108,115,116,52,57,49,53,48,54,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,101,110,118,108,115,116,52,57,54,32,37,97,114,103,108,115,116,52,57,48,53,48,56,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,114,103,108,115,116,52,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,39),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,52,56,56,32,46,32,103,52,56,55,52,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,39),40,98,111,100,121,53,50,51,32,97,114,103,108,115,116,53,51,48,32,101,110,118,108,115,116,53,51,49,32,101,120,97,99,116,102,53,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,53,50,55,32,37,97,114,103,108,115,116,53,50,48,53,51,53,32,37,101,110,118,108,115,116,53,50,49,53,51,54,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,101,110,118,108,115,116,53,50,54,32,37,97,114,103,108,115,116,53,50,48,53,51,56,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,114,103,108,115,116,53,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,45),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,53,49,55,32,102,105,108,101,110,97,109,101,53,49,56,32,46,32,103,53,49,54,53,49,57,41,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,53,53,49,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,28),40,112,114,111,99,101,115,115,45,114,117,110,32,102,53,53,52,32,46,32,97,114,103,115,53,53,53,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,22),40,99,108,111,115,101,45,104,97,110,100,108,101,32,97,53,53,55,53,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,53,57,53,32,99,109,100,53,57,54,32,97,114,103,115,53,57,55,32,101,110,118,53,57,56,32,115,116,100,111,117,116,102,53,57,57,32,115,116,100,105,110,102,54,48,48,32,115,116,100,101,114,114,102,54,48,49,32,46,32,103,53,57,52,54,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,15),40,97,51,53,56,49,32,103,54,52,50,54,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,18),40,99,104,107,115,116,114,108,115,116,32,108,115,116,54,52,49,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,7),40,97,51,53,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,34),40,97,51,54,48,53,32,105,110,54,52,55,32,111,117,116,54,52,56,32,112,105,100,54,52,57,32,101,114,114,54,53,48,41,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,57),40,37,112,114,111,99,101,115,115,32,108,111,99,54,51,52,32,101,114,114,63,54,51,53,32,99,109,100,54,51,54,32,97,114,103,115,54,51,55,32,101,110,118,54,51,56,32,101,120,97,99,116,102,54,51,57,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,54,54,48,32,97,114,103,115,54,54,55,32,101,110,118,54,54,56,32,101,120,97,99,116,102,54,54,57,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,101,120,97,99,116,102,54,54,52,32,37,97,114,103,115,54,53,55,54,55,49,32,37,101,110,118,54,53,56,54,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,101,110,118,54,54,51,32,37,97,114,103,115,54,53,55,54,55,52,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,97,114,103,115,54,54,50,41,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,32,99,109,100,54,53,53,32,46,32,103,54,53,52,54,53,54,41,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,54,56,56,32,97,114,103,115,54,57,53,32,101,110,118,54,57,54,32,101,120,97,99,116,102,54,57,55,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,101,120,97,99,116,102,54,57,50,32,37,97,114,103,115,54,56,53,54,57,57,32,37,101,110,118,54,56,54,55,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,101,110,118,54,57,49,32,37,97,114,103,115,54,56,53,55,48,50,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,97,114,103,115,54,57,48,41,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,27),40,112,114,111,99,101,115,115,42,32,99,109,100,54,56,51,32,46,32,103,54,56,50,54,56,52,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,55,49,49,32,110,111,104,97,110,103,55,49,50,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,97,51,56,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,97,51,56,51,49,32,101,112,105,100,55,50,48,32,101,110,111,114,109,55,50,49,32,101,99,111,100,101,55,50,50,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,55,49,51,32,46,32,97,114,103,115,55,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,12),40,115,108,101,101,112,32,116,55,50,53,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,13),40,102,95,52,48,53,50,32,120,55,53,52,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,7),40,97,51,57,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,7),40,97,52,48,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,7),40,97,52,48,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,102,115,55,53,54,32,114,55,53,55,41,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,15),40,102,95,52,48,54,56,32,46,32,95,55,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,15),40,102,95,52,48,54,48,32,46,32,95,55,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,55,51,57,32,97,99,116,105,111,110,55,52,54,32,105,100,55,52,55,32,108,105,109,105,116,55,52,56,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,108,105,109,105,116,55,52,51,32,37,97,99,116,105,111,110,55,51,54,55,55,49,32,37,105,100,55,51,55,55,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,105,100,55,52,50,32,37,97,99,116,105,111,110,55,51,54,55,55,52,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,17),40,97,52,48,56,56,32,120,55,55,54,32,121,55,55,55,41,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,99,116,105,111,110,55,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,48),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,55,51,51,32,112,114,101,100,55,51,52,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,55,51,53,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,46,32,95,55,56,52,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,20),40,99,114,101,97,116,101,45,102,105,102,111,32,46,32,95,55,56,54,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,23),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,32,46,32,95,55,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,29),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,55,56,56,41,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,35),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,103,114,111,117,112,45,105,100,32,46,32,95,55,56,57,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,34),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,105,100,32,46,32,95,55,57,48,41,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,36),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,32,46,32,95,55,57,49,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,25),40,99,117,114,114,101,110,116,45,103,114,111,117,112,45,105,100,32,46,32,95,55,57,50,41,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,24),40,99,117,114,114,101,110,116,45,117,115,101,114,45,105,100,32,46,32,95,55,57,51,41};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,27),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,46,32,95,55,57,52,41,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,108,105,110,107,32,46,32,95,55,57,53,41,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,108,111,99,107,32,46,32,95,55,57,54,41,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,46,32,95,55,57,55,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,102,105,108,101,45,115,101,108,101,99,116,32,46,32,95,55,57,56,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,46,32,95,55,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,46,32,95,56,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,20),40,102,105,108,101,45,117,110,108,111,99,107,32,46,32,95,56,48,49,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,19),40,103,101,116,45,103,114,111,117,112,115,32,46,32,95,56,48,50,41,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,26),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,56,48,51,41,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,26),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,46,32,95,56,48,52,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,35),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,46,32,95,56,48,53,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,26),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,32,46,32,95,56,48,54,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,95,56,48,55,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,32,46,32,95,56,48,56,41,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,23),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,46,32,95,56,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,27),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,56,49,48,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,19),40,115,101,116,45,97,108,97,114,109,33,32,46,32,95,56,49,49,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,46,32,95,56,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,103,114,111,117,112,115,33,32,46,32,95,56,49,51,41,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,30),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,46,32,95,56,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,28),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,46,32,95,56,49,53,41,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,25),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,56,49,54,41,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,117,115,101,114,45,105,100,33,32,46,32,95,56,49,55,41,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,20),40,115,105,103,110,97,108,45,109,97,115,107,32,46,32,95,56,49,56,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,56,49,57,41,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,46,32,95,56,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,46,32,95,56,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,22),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,46,32,95,56,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,46,32,95,56,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,22),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,46,32,95,56,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,31),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,46,32,95,56,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,25),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,56,50,54,41,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,46,32,95,56,50,55,41,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,21),40,115,116,114,105,110,103,45,62,116,105,109,101,32,46,32,95,56,50,56,41,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,12),40,102,105,102,111,63,32,95,56,50,57,41,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,56,51,48,41,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


/* from k3420 */
static C_word C_fcall stub570(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub570(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static C_word C_fcall stub558(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub558(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static C_word C_fcall stub546(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub546(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k3049 */
static C_word C_fcall stub449(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub449(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k3032 */
static C_word C_fcall stub439(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub439(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k2749 */
static C_word C_fcall stub368(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub368(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub363(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub363(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub343(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub343(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub337(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub337(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k2596 */
static C_word C_fcall stub328(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub328(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k2503 */
static C_word C_fcall stub311(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub311(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k1095 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4083)
static void C_fcall f_4083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4078)
static void C_fcall f_4078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4073)
static void C_fcall f_4073(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3928)
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3935)
static void C_fcall f_3935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_fcall f_3947(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3730)
static void C_fcall f_3730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_fcall f_3725(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3720)
static void C_fcall f_3720(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3715)
static void C_fcall f_3715(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3650)
static void C_fcall f_3650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3640)
static void C_fcall f_3640(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3635)
static void C_fcall f_3635(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3571)
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_fcall f_3573(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3264)
static void C_fcall f_3264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_fcall f_3259(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3254)
static void C_fcall f_3254(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3242)
static void C_fcall f_3242(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3177)
static void C_fcall f_3177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_fcall f_3172(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3167)
static void C_fcall f_3167(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3155)
static void C_fcall f_3155(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_fcall f_3138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_fcall f_3105(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_fcall f_3055(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3067)
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2942)
static void C_fcall f_2942(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_fcall f_2947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_fcall f_2956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2833)
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_fcall f_2873(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_fcall f_2512(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_fcall f_2524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2446)
static void C_fcall f_2446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_fcall f_2358(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_fcall f_2321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_fcall f_1895(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_fcall f_1889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static C_word C_fcall f_1877(C_word t0);
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1752)
static void C_fcall f_1752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_fcall f_1747(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1646)
static void C_fcall f_1646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_fcall f_1680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_fcall f_1702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_fcall f_1328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1170)
static void C_ccall f_1170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4083)
static void C_fcall trf_4083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4083(t0,t1);}

C_noret_decl(trf_4078)
static void C_fcall trf_4078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4078(t0,t1,t2);}

C_noret_decl(trf_4073)
static void C_fcall trf_4073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4073(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4073(t0,t1,t2,t3);}

C_noret_decl(trf_3928)
static void C_fcall trf_3928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3928(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3928(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3935)
static void C_fcall trf_3935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3935(t0,t1);}

C_noret_decl(trf_3947)
static void C_fcall trf_3947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3947(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3947(t0,t1,t2,t3);}

C_noret_decl(trf_3730)
static void C_fcall trf_3730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3730(t0,t1);}

C_noret_decl(trf_3725)
static void C_fcall trf_3725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3725(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3725(t0,t1,t2);}

C_noret_decl(trf_3720)
static void C_fcall trf_3720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3720(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3720(t0,t1,t2,t3);}

C_noret_decl(trf_3715)
static void C_fcall trf_3715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3715(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3715(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3650)
static void C_fcall trf_3650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3650(t0,t1);}

C_noret_decl(trf_3645)
static void C_fcall trf_3645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3645(t0,t1,t2);}

C_noret_decl(trf_3640)
static void C_fcall trf_3640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3640(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3640(t0,t1,t2,t3);}

C_noret_decl(trf_3635)
static void C_fcall trf_3635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3635(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3635(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3571)
static void C_fcall trf_3571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3571(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3571(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3573)
static void C_fcall trf_3573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3573(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3573(t0,t1,t2);}

C_noret_decl(trf_3264)
static void C_fcall trf_3264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3264(t0,t1);}

C_noret_decl(trf_3259)
static void C_fcall trf_3259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3259(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3259(t0,t1,t2);}

C_noret_decl(trf_3254)
static void C_fcall trf_3254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3254(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3254(t0,t1,t2,t3);}

C_noret_decl(trf_3242)
static void C_fcall trf_3242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3242(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3242(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3177)
static void C_fcall trf_3177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3177(t0,t1);}

C_noret_decl(trf_3172)
static void C_fcall trf_3172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3172(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3172(t0,t1,t2);}

C_noret_decl(trf_3167)
static void C_fcall trf_3167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3167(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3167(t0,t1,t2,t3);}

C_noret_decl(trf_3155)
static void C_fcall trf_3155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3155(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3155(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3138)
static void C_fcall trf_3138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3138(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3138(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3105)
static void C_fcall trf_3105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3105(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3105(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3055)
static void C_fcall trf_3055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3055(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3055(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3067)
static void C_fcall trf_3067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3067(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3067(t0,t1,t2,t3);}

C_noret_decl(trf_2942)
static void C_fcall trf_2942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2942(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2942(t0,t1,t2,t3);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2985(t0,t1,t2,t3);}

C_noret_decl(trf_2947)
static void C_fcall trf_2947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2947(t0,t1,t2);}

C_noret_decl(trf_2956)
static void C_fcall trf_2956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2956(t0,t1,t2);}

C_noret_decl(trf_2833)
static void C_fcall trf_2833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2833(t0,t1,t2);}

C_noret_decl(trf_2873)
static void C_fcall trf_2873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2873(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2873(t0,t1,t2);}

C_noret_decl(trf_2512)
static void C_fcall trf_2512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2512(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2512(t0,t1,t2);}

C_noret_decl(trf_2524)
static void C_fcall trf_2524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2524(t0,t1,t2);}

C_noret_decl(trf_2446)
static void C_fcall trf_2446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2446(t0,t1);}

C_noret_decl(trf_2358)
static void C_fcall trf_2358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2358(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2358(t0,t1,t2,t3);}

C_noret_decl(trf_2321)
static void C_fcall trf_2321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2321(t0,t1,t2);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2276(t0,t1,t2,t3);}

C_noret_decl(trf_1895)
static void C_fcall trf_1895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1895(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1895(t0,t1,t2,t3);}

C_noret_decl(trf_1889)
static void C_fcall trf_1889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1889(t0,t1);}

C_noret_decl(trf_1752)
static void C_fcall trf_1752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1752(t0,t1);}

C_noret_decl(trf_1747)
static void C_fcall trf_1747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1747(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1747(t0,t1,t2);}

C_noret_decl(trf_1646)
static void C_fcall trf_1646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1646(t0,t1,t2,t3);}

C_noret_decl(trf_1680)
static void C_fcall trf_1680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1680(t0,t1);}

C_noret_decl(trf_1702)
static void C_fcall trf_1702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1702(t0,t1);}

C_noret_decl(trf_1328)
static void C_fcall trf_1328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1328(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2920)){
C_save(t1);
C_rereclaim2(2920*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,365);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"\003syserror");
lf[63]=C_h_intern(&lf[63],9,"file-size");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],16,"file-access-time");
lf[66]=C_h_intern(&lf[66],16,"file-change-time");
lf[67]=C_h_intern(&lf[67],10,"file-owner");
lf[68]=C_h_intern(&lf[68],16,"file-permissions");
lf[69]=C_h_intern(&lf[69],13,"regular-file\077");
lf[70]=C_h_intern(&lf[70],13,"\003sysfile-info");
lf[71]=C_h_intern(&lf[71],14,"symbolic-link\077");
lf[72]=C_h_intern(&lf[72],13,"file-position");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[74]=C_h_intern(&lf[74],6,"stream");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[76]=C_h_intern(&lf[76],5,"port\077");
lf[77]=C_h_intern(&lf[77],18,"set-file-position!");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[80]=C_h_intern(&lf[80],13,"\000bounds-error");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[82]=C_h_intern(&lf[82],16,"create-directory");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[84]=C_h_intern(&lf[84],16,"change-directory");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[86]=C_h_intern(&lf[86],16,"delete-directory");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[88]=C_h_intern(&lf[88],6,"string");
lf[89]=C_h_intern(&lf[89],9,"directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[91]=C_h_intern(&lf[91],16,"\003sysmake-pointer");
lf[92]=C_h_intern(&lf[92],17,"current-directory");
lf[93]=C_h_intern(&lf[93],10,"directory\077");
lf[94]=C_h_intern(&lf[94],27,"\003sysplatform-fixup-pathname");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[96]=C_h_intern(&lf[96],5,"\000text");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[99]=C_h_intern(&lf[99],13,"\003sysmake-port");
lf[100]=C_h_intern(&lf[100],21,"\003sysstream-port-class");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[102]=C_h_intern(&lf[102],15,"open-input-pipe");
lf[103]=C_h_intern(&lf[103],7,"\000binary");
lf[104]=C_h_intern(&lf[104],16,"open-output-pipe");
lf[105]=C_h_intern(&lf[105],16,"close-input-pipe");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[107]=C_h_intern(&lf[107],14,"\003syscheck-port");
lf[108]=C_h_intern(&lf[108],17,"close-output-pipe");
lf[109]=C_h_intern(&lf[109],20,"call-with-input-pipe");
lf[110]=C_h_intern(&lf[110],21,"call-with-output-pipe");
lf[111]=C_h_intern(&lf[111],20,"with-input-from-pipe");
lf[112]=C_h_intern(&lf[112],18,"\003sysstandard-input");
lf[113]=C_h_intern(&lf[113],19,"with-output-to-pipe");
lf[114]=C_h_intern(&lf[114],19,"\003sysstandard-output");
lf[115]=C_h_intern(&lf[115],11,"create-pipe");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[117]=C_h_intern(&lf[117],11,"signal/term");
lf[118]=C_h_intern(&lf[118],10,"signal/int");
lf[119]=C_h_intern(&lf[119],10,"signal/fpe");
lf[120]=C_h_intern(&lf[120],10,"signal/ill");
lf[121]=C_h_intern(&lf[121],11,"signal/segv");
lf[122]=C_h_intern(&lf[122],11,"signal/abrt");
lf[123]=C_h_intern(&lf[123],12,"signal/break");
lf[124]=C_h_intern(&lf[124],11,"signal/alrm");
lf[125]=C_h_intern(&lf[125],11,"signal/chld");
lf[126]=C_h_intern(&lf[126],11,"signal/cont");
lf[127]=C_h_intern(&lf[127],10,"signal/hup");
lf[128]=C_h_intern(&lf[128],9,"signal/io");
lf[129]=C_h_intern(&lf[129],11,"signal/kill");
lf[130]=C_h_intern(&lf[130],11,"signal/pipe");
lf[131]=C_h_intern(&lf[131],11,"signal/prof");
lf[132]=C_h_intern(&lf[132],11,"signal/quit");
lf[133]=C_h_intern(&lf[133],11,"signal/stop");
lf[134]=C_h_intern(&lf[134],11,"signal/trap");
lf[135]=C_h_intern(&lf[135],11,"signal/tstp");
lf[136]=C_h_intern(&lf[136],10,"signal/urg");
lf[137]=C_h_intern(&lf[137],11,"signal/usr1");
lf[138]=C_h_intern(&lf[138],11,"signal/usr2");
lf[139]=C_h_intern(&lf[139],13,"signal/vtalrm");
lf[140]=C_h_intern(&lf[140],12,"signal/winch");
lf[141]=C_h_intern(&lf[141],11,"signal/xcpu");
lf[142]=C_h_intern(&lf[142],11,"signal/xfsz");
lf[143]=C_h_intern(&lf[143],12,"signals-list");
lf[144]=C_h_intern(&lf[144],18,"\003sysinterrupt-hook");
lf[145]=C_h_intern(&lf[145],14,"signal-handler");
lf[146]=C_h_intern(&lf[146],19,"set-signal-handler!");
lf[147]=C_h_intern(&lf[147],10,"errno/perm");
lf[148]=C_h_intern(&lf[148],11,"errno/noent");
lf[149]=C_h_intern(&lf[149],10,"errno/srch");
lf[150]=C_h_intern(&lf[150],10,"errno/intr");
lf[151]=C_h_intern(&lf[151],8,"errno/io");
lf[152]=C_h_intern(&lf[152],12,"errno/noexec");
lf[153]=C_h_intern(&lf[153],10,"errno/badf");
lf[154]=C_h_intern(&lf[154],11,"errno/child");
lf[155]=C_h_intern(&lf[155],11,"errno/nomem");
lf[156]=C_h_intern(&lf[156],11,"errno/acces");
lf[157]=C_h_intern(&lf[157],11,"errno/fault");
lf[158]=C_h_intern(&lf[158],10,"errno/busy");
lf[159]=C_h_intern(&lf[159],11,"errno/exist");
lf[160]=C_h_intern(&lf[160],12,"errno/notdir");
lf[161]=C_h_intern(&lf[161],11,"errno/isdir");
lf[162]=C_h_intern(&lf[162],11,"errno/inval");
lf[163]=C_h_intern(&lf[163],11,"errno/mfile");
lf[164]=C_h_intern(&lf[164],11,"errno/nospc");
lf[165]=C_h_intern(&lf[165],11,"errno/spipe");
lf[166]=C_h_intern(&lf[166],10,"errno/pipe");
lf[167]=C_h_intern(&lf[167],11,"errno/again");
lf[168]=C_h_intern(&lf[168],10,"errno/rofs");
lf[169]=C_h_intern(&lf[169],10,"errno/nxio");
lf[170]=C_h_intern(&lf[170],10,"errno/2big");
lf[171]=C_h_intern(&lf[171],10,"errno/xdev");
lf[172]=C_h_intern(&lf[172],11,"errno/nodev");
lf[173]=C_h_intern(&lf[173],11,"errno/nfile");
lf[174]=C_h_intern(&lf[174],11,"errno/notty");
lf[175]=C_h_intern(&lf[175],10,"errno/fbig");
lf[176]=C_h_intern(&lf[176],11,"errno/mlink");
lf[177]=C_h_intern(&lf[177],9,"errno/dom");
lf[178]=C_h_intern(&lf[178],11,"errno/range");
lf[179]=C_h_intern(&lf[179],12,"errno/deadlk");
lf[180]=C_h_intern(&lf[180],17,"errno/nametoolong");
lf[181]=C_h_intern(&lf[181],11,"errno/nolck");
lf[182]=C_h_intern(&lf[182],11,"errno/nosys");
lf[183]=C_h_intern(&lf[183],14,"errno/notempty");
lf[184]=C_h_intern(&lf[184],11,"errno/ilseq");
lf[185]=C_h_intern(&lf[185],16,"change-file-mode");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[187]=C_h_intern(&lf[187],17,"file-read-access\077");
lf[188]=C_h_intern(&lf[188],18,"file-write-access\077");
lf[189]=C_h_intern(&lf[189],20,"file-execute-access\077");
lf[190]=C_h_intern(&lf[190],12,"fileno/stdin");
lf[191]=C_h_intern(&lf[191],13,"fileno/stdout");
lf[192]=C_h_intern(&lf[192],13,"fileno/stderr");
lf[193]=C_h_intern(&lf[193],7,"\000append");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[201]=C_h_intern(&lf[201],16,"open-input-file*");
lf[202]=C_h_intern(&lf[202],17,"open-output-file*");
lf[203]=C_h_intern(&lf[203],12,"port->fileno");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[206]=C_h_intern(&lf[206],25,"\003syspeek-unsigned-integer");
lf[207]=C_h_intern(&lf[207],16,"duplicate-fileno");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[209]=C_h_intern(&lf[209],6,"setenv");
lf[210]=C_h_intern(&lf[210],8,"unsetenv");
lf[211]=C_h_intern(&lf[211],9,"substring");
lf[212]=C_h_intern(&lf[212],19,"current-environment");
lf[213]=C_h_intern(&lf[213],19,"seconds->local-time");
lf[214]=C_h_intern(&lf[214],18,"\003sysdecode-seconds");
lf[215]=C_h_intern(&lf[215],17,"seconds->utc-time");
lf[216]=C_h_intern(&lf[216],15,"seconds->string");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[218]=C_h_intern(&lf[218],12,"time->string");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[222]=C_h_intern(&lf[222],19,"local-time->seconds");
lf[223]=C_h_intern(&lf[223],15,"\003syscons-flonum");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[226]=C_h_intern(&lf[226],27,"local-timezone-abbreviation");
lf[227]=C_h_intern(&lf[227],5,"_exit");
lf[228]=C_h_intern(&lf[228],19,"set-buffering-mode!");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[230]=C_h_intern(&lf[230],5,"\000full");
lf[231]=C_h_intern(&lf[231],5,"\000line");
lf[232]=C_h_intern(&lf[232],5,"\000none");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[234]=C_h_intern(&lf[234],6,"regexp");
lf[235]=C_h_intern(&lf[235],21,"make-anchored-pattern");
lf[236]=C_h_intern(&lf[236],12,"string-match");
lf[237]=C_h_intern(&lf[237],12,"glob->regexp");
lf[238]=C_h_intern(&lf[238],13,"make-pathname");
lf[239]=C_h_intern(&lf[239],18,"decompose-pathname");
lf[240]=C_h_intern(&lf[240],4,"glob");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[243]=C_h_intern(&lf[243],13,"spawn/overlay");
lf[244]=C_h_intern(&lf[244],10,"spawn/wait");
lf[245]=C_h_intern(&lf[245],12,"spawn/nowait");
lf[246]=C_h_intern(&lf[246],13,"spawn/nowaito");
lf[247]=C_h_intern(&lf[247],12,"spawn/detach");
lf[248]=C_h_intern(&lf[248],16,"char-whitespace\077");
lf[249]=C_h_intern(&lf[249],10,"string-ref");
lf[251]=C_h_intern(&lf[251],7,"reverse");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[254]=C_h_intern(&lf[254],24,"pathname-strip-directory");
lf[257]=C_h_intern(&lf[257],15,"process-execute");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[259]=C_h_intern(&lf[259],13,"process-spawn");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[261]=C_h_intern(&lf[261],18,"current-process-id");
lf[262]=C_h_intern(&lf[262],17,"\003sysshell-command");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[264]=C_h_intern(&lf[264],6,"getenv");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[266]=C_h_intern(&lf[266],27,"\003sysshell-command-arguments");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[268]=C_h_intern(&lf[268],11,"process-run");
lf[270]=C_h_intern(&lf[270],11,"\003sysprocess");
lf[271]=C_h_intern(&lf[271],14,"\000process-error");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[273]=C_h_intern(&lf[273],17,"\003sysmake-locative");
lf[274]=C_h_intern(&lf[274],8,"location");
lf[275]=C_h_intern(&lf[275],18,"string-intersperse");
lf[276]=C_h_intern(&lf[276],12,"\003sysfor-each");
lf[277]=C_h_intern(&lf[277],7,"process");
lf[278]=C_h_intern(&lf[278],8,"process*");
lf[279]=C_h_intern(&lf[279],16,"\003sysprocess-wait");
lf[280]=C_h_intern(&lf[280],12,"process-wait");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[282]=C_h_intern(&lf[282],5,"sleep");
lf[283]=C_h_intern(&lf[283],13,"get-host-name");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[285]=C_h_intern(&lf[285],18,"system-information");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[288]=C_h_intern(&lf[288],17,"current-user-name");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[290]=C_h_intern(&lf[290],10,"find-files");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[293]=C_h_intern(&lf[293],19,"\003sysundefined-value");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[295]=C_h_intern(&lf[295],16,"\003sysdynamic-wind");
lf[296]=C_h_intern(&lf[296],13,"pathname-file");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[298]=C_h_intern(&lf[298],17,"change-file-owner");
lf[299]=C_h_intern(&lf[299],5,"error");
lf[300]=C_h_intern(&lf[300],11,"create-fifo");
lf[301]=C_h_intern(&lf[301],14,"create-session");
lf[302]=C_h_intern(&lf[302],20,"create-symbolic-link");
lf[303]=C_h_intern(&lf[303],26,"current-effective-group-id");
lf[304]=C_h_intern(&lf[304],25,"current-effective-user-id");
lf[305]=C_h_intern(&lf[305],27,"current-effective-user-name");
lf[306]=C_h_intern(&lf[306],16,"current-group-id");
lf[307]=C_h_intern(&lf[307],15,"current-user-id");
lf[308]=C_h_intern(&lf[308],18,"map-file-to-memory");
lf[309]=C_h_intern(&lf[309],9,"file-link");
lf[310]=C_h_intern(&lf[310],9,"file-lock");
lf[311]=C_h_intern(&lf[311],18,"file-lock/blocking");
lf[312]=C_h_intern(&lf[312],11,"file-select");
lf[313]=C_h_intern(&lf[313],14,"file-test-lock");
lf[314]=C_h_intern(&lf[314],13,"file-truncate");
lf[315]=C_h_intern(&lf[315],11,"file-unlock");
lf[316]=C_h_intern(&lf[316],10,"get-groups");
lf[317]=C_h_intern(&lf[317],17,"group-information");
lf[318]=C_h_intern(&lf[318],17,"initialize-groups");
lf[319]=C_h_intern(&lf[319],26,"memory-mapped-file-pointer");
lf[320]=C_h_intern(&lf[320],17,"parent-process-id");
lf[321]=C_h_intern(&lf[321],12,"process-fork");
lf[322]=C_h_intern(&lf[322],16,"process-group-id");
lf[323]=C_h_intern(&lf[323],14,"process-signal");
lf[324]=C_h_intern(&lf[324],18,"read-symbolic-link");
lf[325]=C_h_intern(&lf[325],10,"set-alarm!");
lf[326]=C_h_intern(&lf[326],13,"set-group-id!");
lf[327]=C_h_intern(&lf[327],11,"set-groups!");
lf[328]=C_h_intern(&lf[328],21,"set-process-group-id!");
lf[329]=C_h_intern(&lf[329],19,"set-root-directory!");
lf[330]=C_h_intern(&lf[330],16,"set-signal-mask!");
lf[331]=C_h_intern(&lf[331],12,"set-user-id!");
lf[332]=C_h_intern(&lf[332],11,"signal-mask");
lf[333]=C_h_intern(&lf[333],12,"signal-mask!");
lf[334]=C_h_intern(&lf[334],14,"signal-masked\077");
lf[335]=C_h_intern(&lf[335],14,"signal-unmask!");
lf[336]=C_h_intern(&lf[336],13,"terminal-name");
lf[337]=C_h_intern(&lf[337],14,"terminal-port\077");
lf[338]=C_h_intern(&lf[338],13,"terminal-size");
lf[339]=C_h_intern(&lf[339],22,"unmap-file-from-memory");
lf[340]=C_h_intern(&lf[340],16,"user-information");
lf[341]=C_h_intern(&lf[341],17,"utc-time->seconds");
lf[342]=C_h_intern(&lf[342],12,"string->time");
lf[343]=C_h_intern(&lf[343],16,"errno/wouldblock");
lf[344]=C_h_intern(&lf[344],5,"fifo\077");
lf[345]=C_h_intern(&lf[345],19,"memory-mapped-file\077");
lf[346]=C_h_intern(&lf[346],13,"map/anonymous");
lf[347]=C_h_intern(&lf[347],8,"map/file");
lf[348]=C_h_intern(&lf[348],9,"map/fixed");
lf[349]=C_h_intern(&lf[349],11,"map/private");
lf[350]=C_h_intern(&lf[350],10,"map/shared");
lf[351]=C_h_intern(&lf[351],10,"open/fsync");
lf[352]=C_h_intern(&lf[352],11,"open/noctty");
lf[353]=C_h_intern(&lf[353],13,"open/nonblock");
lf[354]=C_h_intern(&lf[354],9,"open/sync");
lf[355]=C_h_intern(&lf[355],10,"perm/isgid");
lf[356]=C_h_intern(&lf[356],10,"perm/isuid");
lf[357]=C_h_intern(&lf[357],10,"perm/isvtx");
lf[358]=C_h_intern(&lf[358],9,"prot/exec");
lf[359]=C_h_intern(&lf[359],9,"prot/none");
lf[360]=C_h_intern(&lf[360],9,"prot/read");
lf[361]=C_h_intern(&lf[361],10,"prot/write");
lf[362]=C_h_intern(&lf[362],11,"make-vector");
lf[363]=C_h_intern(&lf[363],17,"register-feature!");
lf[364]=C_h_intern(&lf[364],5,"posix");
C_register_lf2(lf,365,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1074,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k1072 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1075 in k1072 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1078 in k1075 in k1072 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 944  register-feature! */
t3=*((C_word*)lf[363]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[364]);}

/* k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[154],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1098,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[10]+1,lf[5]);
t5=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1144,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1203,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1248,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1290,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[55]+1,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1433,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1456,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1462,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1563,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t57=*((C_word*)lf[4]+1);
t58=*((C_word*)lf[43]+1);
t59=*((C_word*)lf[88]+1);
t60=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=t58,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1804,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t62=*((C_word*)lf[43]+1);
t63=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=t62,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp));
t64=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
t65=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
t66=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t67=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1913,a[2]=t65,a[3]=t66,a[4]=t64,a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp));
t68=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1949,a[2]=t65,a[3]=t66,a[4]=t64,a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp));
t69=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1985,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[108]+1,*((C_word*)lf[105]+1));
t71=*((C_word*)lf[102]+1);
t72=*((C_word*)lf[104]+1);
t73=*((C_word*)lf[105]+1);
t74=*((C_word*)lf[108]+1);
t75=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=t71,a[3]=t73,a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp));
t76=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=t72,a[3]=t74,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp));
t77=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2052,a[2]=t71,a[3]=t73,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp));
t78=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2072,a[2]=t72,a[3]=t74,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t79=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[117]+1,C_fix((C_word)SIGTERM));
t81=C_mutate((C_word*)lf[118]+1,C_fix((C_word)SIGINT));
t82=C_mutate((C_word*)lf[119]+1,C_fix((C_word)SIGFPE));
t83=C_mutate((C_word*)lf[120]+1,C_fix((C_word)SIGILL));
t84=C_mutate((C_word*)lf[121]+1,C_fix((C_word)SIGSEGV));
t85=C_mutate((C_word*)lf[122]+1,C_fix((C_word)SIGABRT));
t86=C_mutate((C_word*)lf[123]+1,C_fix((C_word)SIGBREAK));
t87=C_set_block_item(lf[124],0,C_fix(0));
t88=C_set_block_item(lf[125],0,C_fix(0));
t89=C_set_block_item(lf[126],0,C_fix(0));
t90=C_set_block_item(lf[127],0,C_fix(0));
t91=C_set_block_item(lf[128],0,C_fix(0));
t92=C_set_block_item(lf[129],0,C_fix(0));
t93=C_set_block_item(lf[130],0,C_fix(0));
t94=C_set_block_item(lf[131],0,C_fix(0));
t95=C_set_block_item(lf[132],0,C_fix(0));
t96=C_set_block_item(lf[133],0,C_fix(0));
t97=C_set_block_item(lf[134],0,C_fix(0));
t98=C_set_block_item(lf[135],0,C_fix(0));
t99=C_set_block_item(lf[136],0,C_fix(0));
t100=C_set_block_item(lf[137],0,C_fix(0));
t101=C_set_block_item(lf[138],0,C_fix(0));
t102=C_set_block_item(lf[139],0,C_fix(0));
t103=C_set_block_item(lf[140],0,C_fix(0));
t104=C_set_block_item(lf[141],0,C_fix(0));
t105=C_set_block_item(lf[142],0,C_fix(0));
t106=(C_word)C_a_i_list(&a,7,*((C_word*)lf[117]+1),*((C_word*)lf[118]+1),*((C_word*)lf[119]+1),*((C_word*)lf[120]+1),*((C_word*)lf[121]+1),*((C_word*)lf[122]+1),*((C_word*)lf[123]+1));
t107=C_mutate((C_word*)lf[143]+1,t106);
t108=*((C_word*)lf[144]+1);
t109=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[2],a[3]=t108,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1362 make-vector */
t110=*((C_word*)lf[362]+1);
((C_proc4)(void*)(*((C_word*)t110+1)))(4,t110,t109,C_fix(256),C_SCHEME_FALSE);}

/* k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word ab[322],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t1,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=t1,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[147]+1,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[148]+1,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[149]+1,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[150]+1,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[151]+1,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[152]+1,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[153]+1,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[154]+1,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[155]+1,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[156]+1,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[157]+1,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[158]+1,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[159]+1,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[160]+1,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[161]+1,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[162]+1,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[163]+1,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[164]+1,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[165]+1,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[166]+1,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[167]+1,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[168]+1,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[169]+1,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[170]+1,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[171]+1,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[172]+1,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[173]+1,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[174]+1,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[175]+1,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[176]+1,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[177]+1,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[178]+1,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[179]+1,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[180]+1,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[181]+1,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[182]+1,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[183]+1,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[184]+1,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=t44,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t44,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=t44,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[190]+1,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[191]+1,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[192]+1,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2358,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[201]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2376,a[2]=t51,a[3]=t52,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2390,a[2]=t51,a[3]=t52,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2469,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[211]+1);
t60=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=t59,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2571,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[216]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2752,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t69=*((C_word*)lf[234]+1);
t70=*((C_word*)lf[235]+1);
t71=*((C_word*)lf[236]+1);
t72=*((C_word*)lf[237]+1);
t73=*((C_word*)lf[89]+1);
t74=*((C_word*)lf[238]+1);
t75=*((C_word*)lf[239]+1);
t76=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2827,a[2]=t72,a[3]=t70,a[4]=t69,a[5]=t73,a[6]=t71,a[7]=t74,a[8]=t75,a[9]=((C_word)li76),tmp=(C_word)a,a+=10,tmp));
t77=C_mutate((C_word*)lf[243]+1,C_fix((C_word)P_OVERLAY));
t78=C_mutate((C_word*)lf[244]+1,C_fix((C_word)P_WAIT));
t79=C_mutate((C_word*)lf[245]+1,C_fix((C_word)P_NOWAIT));
t80=C_mutate((C_word*)lf[246]+1,C_fix((C_word)P_NOWAITO));
t81=C_mutate((C_word*)lf[247]+1,C_fix((C_word)P_DETACH));
t82=*((C_word*)lf[248]+1);
t83=*((C_word*)lf[51]+1);
t84=*((C_word*)lf[249]+1);
t85=*((C_word*)lf[4]+1);
t86=C_mutate(&lf[250],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2942,a[2]=t85,a[3]=t83,a[4]=t84,a[5]=t82,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t87=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3021,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3038,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
t89=*((C_word*)lf[254]+1);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
t91=C_mutate(&lf[255],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3105,a[2]=t89,a[3]=t87,a[4]=t88,a[5]=t90,a[6]=((C_word)li85),tmp=(C_word)a,a+=7,tmp));
t92=C_mutate(&lf[256],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[257]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t94=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[261]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3327,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3330,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[266]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3351,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t98=*((C_word*)lf[259]+1);
t99=*((C_word*)lf[264]+1);
t100=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3357,a[2]=t98,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t101=C_mutate(&lf[269],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t102=C_mutate((C_word*)lf[270]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3452,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t103=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
t104=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3633,a[2]=t103,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t105=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t103,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[280]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3805,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3865,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3880,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3911,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t112=*((C_word*)lf[240]+1);
t113=*((C_word*)lf[236]+1);
t114=*((C_word*)lf[238]+1);
t115=*((C_word*)lf[93]+1);
t116=C_mutate((C_word*)lf[290]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3926,a[2]=t115,a[3]=t114,a[4]=t112,a[5]=t113,a[6]=((C_word)li138),tmp=(C_word)a,a+=7,tmp));
t117=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t118=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t119=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4164,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t120=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4170,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t121=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t122=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4182,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t123=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4188,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t124=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4194,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t125=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4200,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t126=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t127=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4212,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t128=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t129=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4224,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t130=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4230,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t131=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4236,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t132=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t133=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t134=C_mutate((C_word*)lf[316]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4254,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t135=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4260,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t136=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4266,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t137=C_mutate((C_word*)lf[319]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4272,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t138=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4278,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t139=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4284,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t140=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4290,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t141=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t142=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t143=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4308,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t144=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4314,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t145=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4320,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t146=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4326,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t147=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t148=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t149=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t150=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4350,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t151=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4356,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t152=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4362,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t153=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4368,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t154=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4374,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t155=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4380,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t156=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4386,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t157=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4392,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t158=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4398,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t159=C_mutate((C_word*)lf[341]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4404,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t160=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4410,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t161=C_set_block_item(lf[343],0,C_fix(0));
t162=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t163=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4420,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp));
t164=C_set_block_item(lf[346],0,C_fix(0));
t165=C_set_block_item(lf[347],0,C_fix(0));
t166=C_set_block_item(lf[348],0,C_fix(0));
t167=C_set_block_item(lf[349],0,C_fix(0));
t168=C_set_block_item(lf[350],0,C_fix(0));
t169=C_set_block_item(lf[351],0,C_fix(0));
t170=C_set_block_item(lf[352],0,C_fix(0));
t171=C_set_block_item(lf[353],0,C_fix(0));
t172=C_set_block_item(lf[354],0,C_fix(0));
t173=C_set_block_item(lf[355],0,C_fix(0));
t174=C_set_block_item(lf[356],0,C_fix(0));
t175=C_set_block_item(lf[357],0,C_fix(0));
t176=C_set_block_item(lf[358],0,C_fix(0));
t177=C_set_block_item(lf[359],0,C_fix(0));
t178=C_set_block_item(lf[360],0,C_fix(0));
t179=C_set_block_item(lf[361],0,C_fix(0));
t180=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t180+1)))(2,t180,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4420,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4417,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
/* posixwin.scm: 2004 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* utc-time->seconds in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
/* posixwin.scm: 2003 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* user-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
/* posixwin.scm: 2002 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* unmap-file-from-memory in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
/* posixwin.scm: 2001 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* terminal-size in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
/* posixwin.scm: 2000 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* terminal-port? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4380,2,t0,t1);}
/* posixwin.scm: 1999 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* terminal-name in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4374,2,t0,t1);}
/* posixwin.scm: 1998 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* signal-unmask! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4368,2,t0,t1);}
/* posixwin.scm: 1997 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* signal-masked? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4362,2,t0,t1);}
/* posixwin.scm: 1996 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* signal-mask! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
/* posixwin.scm: 1995 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* signal-mask in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
/* posixwin.scm: 1994 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* set-user-id! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
/* posixwin.scm: 1993 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* set-signal-mask! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
/* posixwin.scm: 1992 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* set-root-directory! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4332,2,t0,t1);}
/* posixwin.scm: 1991 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* set-process-group-id! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
/* posixwin.scm: 1990 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* set-groups! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
/* posixwin.scm: 1989 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[327],lf[0]);}

/* set-group-id! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
/* posixwin.scm: 1988 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* set-alarm! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
/* posixwin.scm: 1987 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[325],lf[0]);}

/* read-symbolic-link in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
/* posixwin.scm: 1986 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[324],lf[0]);}

/* process-signal in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
/* posixwin.scm: 1985 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[323],lf[0]);}

/* process-group-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
/* posixwin.scm: 1984 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[322],lf[0]);}

/* process-fork in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
/* posixwin.scm: 1983 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[321],lf[0]);}

/* parent-process-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
/* posixwin.scm: 1982 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[320],lf[0]);}

/* memory-mapped-file-pointer in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
/* posixwin.scm: 1981 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[319],lf[0]);}

/* initialize-groups in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
/* posixwin.scm: 1980 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[318],lf[0]);}

/* group-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4260,2,t0,t1);}
/* posixwin.scm: 1979 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[317],lf[0]);}

/* get-groups in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4254(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4254,2,t0,t1);}
/* posixwin.scm: 1978 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[316],lf[0]);}

/* file-unlock in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
/* posixwin.scm: 1977 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[315],lf[0]);}

/* file-truncate in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
/* posixwin.scm: 1976 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[314],lf[0]);}

/* file-test-lock in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
/* posixwin.scm: 1975 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[313],lf[0]);}

/* file-select in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
/* posixwin.scm: 1974 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[312],lf[0]);}

/* file-lock/blocking in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
/* posixwin.scm: 1973 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[311],lf[0]);}

/* file-lock in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
/* posixwin.scm: 1972 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[310],lf[0]);}

/* file-link in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
/* posixwin.scm: 1971 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[309],lf[0]);}

/* map-file-to-memory in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
/* posixwin.scm: 1970 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[308],lf[0]);}

/* current-user-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
/* posixwin.scm: 1969 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[307],lf[0]);}

/* current-group-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
/* posixwin.scm: 1968 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[306],lf[0]);}

/* current-effective-user-name in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
/* posixwin.scm: 1967 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[305],lf[0]);}

/* current-effective-user-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
/* posixwin.scm: 1966 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[304],lf[0]);}

/* current-effective-group-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
/* posixwin.scm: 1965 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[303],lf[0]);}

/* create-symbolic-link in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
/* posixwin.scm: 1964 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[302],lf[0]);}

/* create-session in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
/* posixwin.scm: 1963 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[301],lf[0]);}

/* create-fifo in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
/* posixwin.scm: 1962 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[300],lf[0]);}

/* change-file-owner in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
/* posixwin.scm: 1961 error */
t2=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[298],lf[0]);}

/* find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_3926r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3926r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3926r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li133),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4073,a[2]=t5,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4078,a[2]=t6,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t7,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action741775 */
t9=t8;
f_4083(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id742773 */
t11=t7;
f_4078(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit743770 */
t13=t6;
f_4073(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body739745 */
t15=t5;
f_3928(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-action741 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4083,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
/* def-id742773 */
t3=((C_word*)t0)[2];
f_4078(t3,t1,t2);}

/* a4088 in def-action741 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4089,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id742 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4078,NULL,3,t0,t1,t2);}
/* def-limit743770 */
t3=((C_word*)t0)[2];
f_4073(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit743 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_4073(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4073,NULL,4,t0,t1,t2,t3);}
/* body739745 */
t4=((C_word*)t0)[2];
f_3928(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3928,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[290]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_3935(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4068,a[2]=t4,a[3]=t7,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_3935(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));}}

/* f_4060 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4068 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3935,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4048,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1939 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[297]);}

/* k4046 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1939 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li130),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3947(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3947(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3947,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1945 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1946 pathname-file */
t3=*((C_word*)lf[296]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1952 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k4032 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1952 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1953 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3947(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4039 in k4032 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1952 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3947(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[291]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[292]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 1946 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_3947(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1947 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3993,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li127),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li128),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4015,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1949 ##sys#dynamic-wind */
t11=*((C_word*)lf[295]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 1951 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3947(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a4014 in k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[293]+1));}

/* a4000 in k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4013,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1950 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[294]);}

/* k4011 in a4000 in k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1950 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4007 in a4000 in k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1950 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3947(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3992 in k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[293]+1));}

/* k3989 in k3979 in k4026 in k3964 in loop in k3943 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1948 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3947(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4052 in k3933 in body739 in find-files in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4052,3,t0,t1,t2);}
/* posixwin.scm: 1937 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3921,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1913 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3919 in current-user-name in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1914 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[288],lf[289]);}

/* system-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3891,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3906,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1904 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3904 in system-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1905 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[285],lf[287]);}

/* k3889 in system-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3895,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k3893 in k3889 in system-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3899,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k3897 in k3893 in k3889 in system-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3903,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k3901 in k3897 in k3893 in k3889 in system-information in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[286],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1894 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[283],lf[284]);}}

/* sleep in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3865,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3805r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3805r(t0,t1,t2,t3);}}

static void C_ccall f_3805r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[280]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3826,a[2]=t5,a[3]=t2,a[4]=((C_word)li119),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3832,a[2]=t2,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1873 ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[2],t7);}}

/* a3831 in process-wait in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3832,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1876 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1878 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k3840 in a3831 in process-wait in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1877 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[271],lf[280],lf[281],((C_word*)t0)[2]);}

/* a3825 in process-wait in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
/* posixwin.scm: 1873 ##sys#process-wait */
t2=*((C_word*)lf[279]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3793,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1866 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1867 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3713r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3713r(t0,t1,t2,t3);}}

static void C_ccall f_3713r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3715,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3720,a[2]=t4,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3725,a[2]=t5,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3730,a[2]=t6,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args690703 */
t8=t7;
f_3730(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env691701 */
t10=t6;
f_3725(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf692698 */
t12=t5;
f_3720(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body688694 */
t14=t4;
f_3715(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args690 in process* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3730,NULL,2,t0,t1);}
/* def-env691701 */
t2=((C_word*)t0)[2];
f_3725(t2,t1,C_SCHEME_FALSE);}

/* def-env691 in process* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3725(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3725,NULL,3,t0,t1,t2);}
/* def-exactf692698 */
t3=((C_word*)t0)[2];
f_3720(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf692 in process* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3720(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3720,NULL,4,t0,t1,t2,t3);}
/* body688694 */
t4=((C_word*)t0)[2];
f_3715(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body688 in process* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3715(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3715,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1860 %process */
f_3571(t1,lf[278],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3633r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3633r(t0,t1,t2,t3);}}

static void C_ccall f_3633r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3635,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3640,a[2]=t4,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3645,a[2]=t5,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3650,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args662675 */
t8=t7;
f_3650(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env663673 */
t10=t6;
f_3645(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf664670 */
t12=t5;
f_3640(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body660666 */
t14=t4;
f_3635(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args662 in process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3650,NULL,2,t0,t1);}
/* def-env663673 */
t2=((C_word*)t0)[2];
f_3645(t2,t1,C_SCHEME_FALSE);}

/* def-env663 in process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3645,NULL,3,t0,t1,t2);}
/* def-exactf664670 */
t3=((C_word*)t0)[2];
f_3640(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf664 in process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3640(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3640,NULL,4,t0,t1,t2,t3);}
/* body660666 */
t4=((C_word*)t0)[2];
f_3635(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body660 in process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3635(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3635,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1857 %process */
f_3571(t1,lf[277],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3571(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3571,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3573,a[2]=t2,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3592,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1845 chkstrlst */
t14=t11;
f_3573(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3627,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1848 ##sys#shell-command-arguments */
t16=*((C_word*)lf[266]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,((C_word*)t8)[1]);}}

/* k3625 in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1849 ##sys#shell-command */
t4=*((C_word*)lf[262]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3629 in k3625 in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3592(2,t3,t2);}

/* k3590 in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1850 chkstrlst */
t3=((C_word*)t0)[2];
f_3573(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3595(2,t3,C_SCHEME_UNDEFINED);}}

/* k3593 in k3590 in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li105),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[4],a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1851 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3605 in k3593 in k3590 in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3606,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1853 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1854 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a3599 in k3593 in k3590 in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
/* posixwin.scm: 1851 ##sys#process */
t2=*((C_word*)lf[270]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3573(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3573,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3582,a[2]=((C_word*)t0)[2],a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3581 in chkstrlst in %process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3582,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_3452r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_3452r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_3452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3456,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_3456(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_3456(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[2],t9);}}}

/* k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1817 $quote-args-list */
t5=lf[250];
f_2942(t5,t3,t4,t1);}

/* k3545 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1817 string-intersperse */
t2=*((C_word*)lf[275]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(t2))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(t5))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(t8))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(t11))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t15=*((C_word*)lf[273]+1);
((C_proc6)C_retrieve_proc(t15))(6,t15,t14,t2,C_fix(0),C_SCHEME_FALSE,lf[274]);}

/* k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[273]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[274]);}

/* k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[273]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[274]);}

/* k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[273]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[274]);}

/* k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1824 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3394,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3394(2,t9,C_SCHEME_FALSE);}}

/* k3392 in k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_3398(2,t3,C_SCHEME_FALSE);}}

/* k3396 in k3392 in k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub570(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1827 open-input-file* */
t8=*((C_word*)lf[201]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_3488(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1832 ##sys#update-errno */
t8=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k3506 in k3396 in k3392 in k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1833 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[271],((C_word*)t0)[3],lf[272],((C_word*)t0)[2]);}

/* k3486 in k3396 in k3392 in k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1828 open-output-file* */
t3=*((C_word*)lf[202]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3492(2,t3,C_SCHEME_FALSE);}}

/* k3490 in k3486 in k3396 in k3392 in k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1830 open-input-file* */
t3=*((C_word*)lf[201]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3496(2,t3,C_SCHEME_FALSE);}}

/* k3494 in k3490 in k3486 in k3396 in k3392 in k3529 in k3525 in k3521 in k3517 in k3513 in k3457 in k3454 in ##sys#process in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1826 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3386,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub558(C_SCHEME_UNDEFINED,t2));}

/* process-run in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3357r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3357r(t0,t1,t2,t3);}}

static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1785 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[245]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3374,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1786 ##sys#shell-command */
t7=*((C_word*)lf[262]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k3372 in process-run in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3378,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1786 ##sys#shell-command-arguments */
t3=*((C_word*)lf[266]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3376 in k3372 in process-run in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1786 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[245]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3351,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[267],t2));}

/* ##sys#shell-command in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1769 getenv */
t3=*((C_word*)lf[264]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k3332 in ##sys#shell-command in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1773 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k3344 in k3332 in ##sys#shell-command in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1774 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[262],lf[263]);}

/* current-process-id in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub546(C_SCHEME_UNDEFINED));}

/* process-spawn in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3240r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3240r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3240r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=t3,a[3]=t2,a[4]=((C_word)li92),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3254,a[2]=t5,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3259,a[2]=t6,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3264,a[2]=t7,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst525539 */
t9=t8;
f_3264(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst526537 */
t11=t7;
f_3259(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf527534 */
t13=t6;
f_3254(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body523529 */
t15=t5;
f_3242(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-arglst525 in process-spawn in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3264,NULL,2,t0,t1);}
/* def-envlst526537 */
t2=((C_word*)t0)[2];
f_3259(t2,t1,C_SCHEME_FALSE);}

/* def-envlst526 in process-spawn in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3259(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3259,NULL,3,t0,t1,t2);}
/* def-exactf527534 */
t3=((C_word*)t0)[2];
f_3254(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf527 in process-spawn in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3254(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3254,NULL,4,t0,t1,t2,t3);}
/* body523529 */
t4=((C_word*)t0)[2];
f_3242(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body523 in process-spawn in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3242(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3242,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1760 $exec-setup */
t6=lf[255];
f_3105(t6,t5,lf[259],((C_word*)t0)[2],t2,t3,t4);}

/* k3244 in body523 in process-spawn in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1761 $exec-teardown */
f_3138(((C_word*)t0)[3],lf[259],lf[260],((C_word*)t0)[2],t2);}

/* process-execute in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_3153r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3153r(t0,t1,t2,t3);}}

static void C_ccall f_3153r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=t2,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=t4,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3172,a[2]=t5,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3177,a[2]=t6,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst495509 */
t8=t7;
f_3177(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst496507 */
t10=t6;
f_3172(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf497504 */
t12=t5;
f_3167(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body493499 */
t14=t4;
f_3155(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-arglst495 in process-execute in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3177,NULL,2,t0,t1);}
/* def-envlst496507 */
t2=((C_word*)t0)[2];
f_3172(t2,t1,C_SCHEME_FALSE);}

/* def-envlst496 in process-execute in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3172(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3172,NULL,3,t0,t1,t2);}
/* def-exactf497504 */
t3=((C_word*)t0)[2];
f_3167(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf497 in process-execute in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3167(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3167,NULL,4,t0,t1,t2,t3);}
/* body493499 */
t4=((C_word*)t0)[2];
f_3155(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body493 in process-execute in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3155(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3155,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1755 $exec-setup */
t6=lf[255];
f_3105(t6,t5,lf[257],((C_word*)t0)[2],t2,t3,t4);}

/* k3157 in body493 in process-execute in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1756 $exec-teardown */
f_3138(((C_word*)t0)[3],lf[257],lf[258],((C_word*)t0)[2],t2);}

/* $exec-teardown in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3138(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3138,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3142,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1747 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3140 in $exec-teardown in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1751 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3105(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3105,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3112,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1739 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k3110 in $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1740 setarg */
t4=((C_word*)t0)[4];
f_3021(5,t4,t2,C_fix(0),t1,t3);}

/* k3113 in k3110 in $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1741 $quote-args-list */
t4=lf[250];
f_2942(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3130 in k3113 in k3110 in $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1741 build-exec-argvec */
f_3055(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k3116 in k3113 in k3110 in $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1742 build-exec-argvec */
f_3055(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k3119 in k3116 in k3113 in k3110 in $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3128,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1744 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3126 in k3119 in k3116 in k3113 in k3110 in $exec-setup in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1744 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3055(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3055,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3067,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3067(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1736 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* do460 in build-exec-argvec in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3067,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1732 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3086,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1735 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k3084 in do460 in build-exec-argvec in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3067(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3038,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub449(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3021,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub439(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2942(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2942,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2985,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2985(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1713 reverse */
t4=*((C_word*)lf[251]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3013,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3016,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1718 needs-quoting? */
t8=((C_word*)t0)[2];
f_2947(t8,t7,t4);}}

/* k3014 in loop in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1718 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[252],((C_word*)t0)[2],lf[253]);}
else{
t2=((C_word*)t0)[3];
f_3013(2,t2,((C_word*)t0)[2]);}}

/* k3011 in loop in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3013,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1715 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2985(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2947,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2951,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1705 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2949 in needs-quoting? in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li77),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2956(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2949 in needs-quoting? in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2956,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2980,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1709 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k2978 in loop in k2949 in needs-quoting? in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1709 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2967 in loop in k2949 in needs-quoting? in $quote-args-list in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1710 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2956(t3,((C_word*)t0)[4],t2);}}

/* glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2827r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2827r(t0,t1,t2);}}

static void C_ccall f_2827r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li75),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2833(t6,t1,t2);}

/* conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2833,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2848,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li74),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2854,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2931,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[242]);
/* posixwin.scm: 1666 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k2929 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1666 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1667 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1668 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2862 in k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[241]);
/* posixwin.scm: 1669 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k2869 in k2862 in k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li73),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2873(t5,((C_word*)t0)[2],t1);}

/* loop in k2869 in k2862 in k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2873(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2873,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1670 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2833(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1671 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k2888 in loop in k2869 in k2862 in k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1672 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1673 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2873(t3,((C_word*)t0)[6],t2);}}

/* k2898 in k2888 in loop in k2869 in k2862 in k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2904,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1672 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2873(t4,t2,t3);}

/* k2902 in k2898 in k2888 in loop in k2869 in k2862 in k2859 in k2856 in a2853 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a2847 in conc-loop in glob in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
/* posixwin.scm: 1665 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2768r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2768r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2768r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2772,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1636 ##sys#check-port */
t6=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[228]);}

/* k2770 in set-buffering-mode! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t6)){
t7=t5;
f_2778(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[231]);
if(C_truep(t7)){
t8=t5;
f_2778(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[232]);
if(C_truep(t8)){
t9=t5;
f_2778(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1642 ##sys#error */
t9=*((C_word*)lf[62]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[228],lf[233],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k2776 in k2770 in set-buffering-mode! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[228]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[74],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1648 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[228],lf[229],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* _exit in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2752r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2752r(t0,t1,t2);}}

static void C_ccall f_2752r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub368(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub363(t2),C_fix(0));}

/* local-time->seconds in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2712,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[222]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2719,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1612 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[222],lf[225],t2);}
else{
t6=t4;
f_2719(2,t6,C_SCHEME_UNDEFINED);}}

/* k2717 in local-time->seconds in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1614 ##sys#cons-flonum */
t2=*((C_word*)lf[223]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1615 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[222],lf[224],((C_word*)t0)[3]);}}

/* time->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2632r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2632r(t0,t1,t2,t3);}}

static void C_ccall f_2632r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2636,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2636(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2636(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k2634 in time->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[218]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixwin.scm: 1599 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[218],lf[221],((C_word*)t0)[3]);}
else{
t5=t3;
f_2642(2,t5,C_SCHEME_UNDEFINED);}}

/* k2640 in k2634 in time->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[218]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2661,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1603 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub337(t4,t3),C_fix(0));}}

/* k2662 in k2640 in k2634 in time->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1607 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1608 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[218],lf[220],((C_word*)t0)[2]);}}

/* k2659 in k2640 in k2634 in time->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub343(t3,t2,t1),C_fix(0));}

/* k2649 in k2640 in k2634 in time->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1604 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[218],lf[219],((C_word*)t0)[2]);}}

/* seconds->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2599,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub328(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k2601 in seconds->string in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1591 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1592 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[216],lf[217],((C_word*)t0)[2]);}}

/* seconds->utc-time in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2580,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[215]);
/* posixwin.scm: 1584 ##sys#decode-seconds */
t4=*((C_word*)lf[214]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2571,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[213]);
/* posixwin.scm: 1580 ##sys#decode-seconds */
t4=*((C_word*)lf[214]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2512(t5,t1,C_fix(0));}

/* loop in current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2512(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2512,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2516,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub311(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k2514 in loop in current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2524,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li61),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2524(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k2514 in loop in current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2524(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2524,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1572 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1573 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k2548 in scan in k2514 in loop in current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1572 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k2552 in k2548 in scan in k2514 in loop in current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2542,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1572 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2512(t5,t3,t4);}

/* k2540 in k2552 in k2548 in scan in k2514 in loop in current-environment in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2486,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[210]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1560 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2492 in unsetenv in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2469,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[209]);
t5=(C_word)C_i_check_string_2(t3,lf[209]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1555 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2478 in setenv in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1555 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2482 in k2478 in setenv in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2439r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2439r(t0,t1,t2,t3);}}

static void C_ccall f_2439r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[207]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_2446(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[207]);
t8=t5;
f_2446(t8,(C_word)C_dup2(t2,t6));}}

/* k2444 in duplicate-fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2446,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2449,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1545 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2449(2,t3,C_SCHEME_UNDEFINED);}}

/* k2453 in k2444 in duplicate-fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1546 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[207],lf[208],((C_word*)t0)[2]);}

/* k2447 in k2444 in duplicate-fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2404,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2408,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1527 ##sys#check-port */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[203]);}

/* k2406 in port->fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1528 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2435 in k2406 in port->fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1534 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[203],lf[204],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2417,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1531 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2417(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2421 in k2435 in k2406 in port->fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1532 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[203],lf[205],((C_word*)t0)[2]);}

/* k2415 in k2435 in k2406 in port->fileno in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2390r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2390r(t0,t1,t2,t3);}}

static void C_ccall f_2390r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[202]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2402,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1523 mode */
f_2321(t5,C_SCHEME_FALSE,t3);}

/* k2400 in open-output-file* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1523 check */
f_2358(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2376r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2376r(t0,t1,t2,t3);}}

static void C_ccall f_2376r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[201]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2388,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1519 mode */
f_2321(t5,C_SCHEME_TRUE,t3);}

/* k2386 in open-input-file* in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1519 check */
f_2358(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2358(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2358,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2362,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1510 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2360 in check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1512 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[199],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1513 ##sys#make-port */
t3=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[100]+1),lf[200],lf[74]);}}

/* k2372 in k2360 in check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2321(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2321,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[193]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1505 ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[194],t5);}
else{
t8=t4;
f_2329(2,t8,lf[195]);}}
else{
/* posixwin.scm: 1506 ##sys#error */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[196],t5);}}
else{
t5=t4;
f_2329(2,t5,(C_truep(t2)?lf[197]:lf[198]));}}

/* k2327 in mode in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1501 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2312,3,t0,t1,t2);}
/* posixwin.scm: 1485 check */
f_2276(t1,t2,C_fix((C_word)2),lf[189]);}

/* file-write-access? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2306,3,t0,t1,t2);}
/* posixwin.scm: 1484 check */
f_2276(t1,t2,C_fix((C_word)4),lf[188]);}

/* file-read-access? in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2300,3,t0,t1,t2);}
/* posixwin.scm: 1483 check */
f_2276(t1,t2,C_fix((C_word)2),lf[187]);}

/* check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_2276(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2276,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2294,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1480 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2296 in check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1480 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2292 in check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2294,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2286(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1481 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2284 in k2292 in check in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2246,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[185]);
t5=(C_word)C_i_check_exact_2(t3,lf[185]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2270,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1469 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2272 in change-file-mode in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1469 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2268 in change-file-mode in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2270,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1470 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2260 in k2268 in change-file-mode in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1471 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[185],lf[186],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2190,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2200,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1377 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1379 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2198 in ##sys#interrupt-hook in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1378 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2177,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[146]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2164 in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2168,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[145]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2092r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2092r(t0,t1,t2);}}

static void C_ccall f_2092r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2096,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2096(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2096(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k2094 in create-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2108,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1314 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2099(2,t3,C_SCHEME_UNDEFINED);}}

/* k2106 in k2094 in create-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1315 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[115],lf[116]);}

/* k2097 in k2094 in create-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1316 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2072r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2072r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2072r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[114]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2076,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2074 in with-output-to-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2082,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1299 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2081 in k2074 in with-output-to-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2082r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2082r(t0,t1,t2);}}

static void C_ccall f_2082r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2086,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1301 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2084 in a2081 in k2074 in with-output-to-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[114]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2052r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2052r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2052r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[112]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2056,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2054 in with-input-from-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2062,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1289 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2061 in k2054 in with-input-from-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2062r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2062r(t0,t1,t2);}}

static void C_ccall f_2062r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2066,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1291 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2064 in a2061 in k2054 in with-input-from-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[112]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2028r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2028r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2028r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2030 in call-with-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2037,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2043,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1279 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2042 in k2030 in call-with-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2043r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2043r(t0,t1,t2);}}

static void C_ccall f_2043r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2047,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1282 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2045 in a2042 in k2030 in call-with-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2036 in k2030 in call-with-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
/* posixwin.scm: 1280 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2004r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2004r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2004r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2008,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2006 in call-with-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2013,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2019,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1271 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2018 in k2006 in call-with-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2019r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2019r(t0,t1,t2);}}

static void C_ccall f_2019r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1274 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2021 in a2018 in k2006 in call-with-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2012 in k2006 in call-with-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
/* posixwin.scm: 1272 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1258 ##sys#check-port */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[105]);}

/* k1987 in close-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1260 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1990 in k1987 in close-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1261 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[105],lf[106],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1949r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1949r(t0,t1,t2,t3);}}

static void C_ccall f_1949r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[104]);
t5=f_1877(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1963,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[96]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1253 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[103]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1980,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1254 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1255 badmode */
f_1889(t6,t5);}}}

/* k1978 in open-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1963(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k1968 in open-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1963(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k1961 in open-output-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1250 check */
f_1895(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1913r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1913r(t0,t1,t2,t3);}}

static void C_ccall f_1913r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=f_1877(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[96]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1934,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1243 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[103]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1944,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1244 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1245 badmode */
f_1889(t6,t5);}}}

/* k1942 in open-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1927(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k1932 in open-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1927(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k1925 in open-input-pipe in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1240 check */
f_1895(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1895(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1895,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1230 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1897 in check in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1232 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[98],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1233 ##sys#make-port */
t3=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[100]+1),lf[101],lf[74]);}}

/* k1909 in k1897 in check in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1889(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1889,NULL,2,t1,t2);}
/* posixwin.scm: 1228 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[97],t2);}

/* mode in k1084 in k1081 in k1078 in k1075 in k1072 */
static C_word C_fcall f_1877(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[96]));}

/* current-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1831r(t0,t1,t2);}}

static void C_ccall f_1831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1835(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1835(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k1833 in current-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1215 change-directory */
t2=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1216 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k1842 in k1833 in current-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1218 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1845 in k1842 in k1833 in current-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1220 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1221 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[92],lf[95]);}}

/* directory? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1804,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[93]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1811,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1825,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1829,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1208 ##sys#expand-home-path */
t7=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k1827 in directory? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1208 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1823 in directory? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1207 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1809 in directory? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1644r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1644r(t0,t1,t2);}}

static void C_ccall f_1644r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1747,a[2]=t3,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1752,a[2]=t4,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec113139 */
t6=t5;
f_1752(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?114137 */
t8=t4;
f_1747(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body111116 */
t10=t3;
f_1646(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[2],t9);}}}}

/* def-spec113 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1752,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1760,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1178 current-directory */
t3=*((C_word*)lf[92]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1758 in def-spec113 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?114137 */
t2=((C_word*)t0)[3];
f_1747(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?114 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1747(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1747,NULL,3,t0,t1,t2);}
/* body111116 */
t3=((C_word*)t0)[2];
f_1646(t3,t1,t2,C_SCHEME_FALSE);}

/* body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1646,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1653,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1180 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1181 ##sys#make-pointer */
t3=*((C_word*)lf[91]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1182 ##sys#make-pointer */
t3=*((C_word*)lf[91]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1746,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1183 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1744 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1183 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1661 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1186 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1680,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1680(t6,((C_word*)t0)[6]);}}

/* loop in k1661 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1680,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1195 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1688 in loop in k1661 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1702,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_1702(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_1702(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_1702(t7,C_SCHEME_FALSE);}}

/* k1700 in k1688 in loop in k1661 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1702,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1202 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1680(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1203 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1680(t3,t2);}}

/* k1710 in k1700 in k1688 in loop in k1661 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1670 in k1661 in k1657 in k1654 in k1651 in body111 in directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1187 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* delete-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1617,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1638,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1170 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1640 in delete-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1170 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1636 in delete-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1171 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1628 in k1636 in delete-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1172 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[86],lf[87],((C_word*)t0)[2]);}

/* change-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1590,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1611,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1615,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1163 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1613 in change-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1163 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1609 in change-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1164 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1601 in k1609 in change-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1165 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[84],lf[85],((C_word*)t0)[2]);}

/* create-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1563,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1584,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1588,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1156 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1586 in create-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1156 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1582 in create-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1157 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1574 in k1582 in create-directory in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1158 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[82],lf[83],((C_word*)t0)[2]);}

/* set-file-position! in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1502r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1502r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1502r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[77]);
t8=(C_word)C_i_check_exact_2(t6,lf[77]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1515,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1141 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[80],lf[77],lf[81],t3,t2);}
else{
t10=t9;
f_1515(2,t10,C_SCHEME_UNDEFINED);}}

/* k1513 in set-file-position! in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1142 port? */
t4=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1528 in k1513 in set-file-position! in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[74]);
t4=((C_word*)t0)[4];
f_1521(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1521(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1146 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[77],lf[79],((C_word*)t0)[5]);}}}

/* k1519 in k1513 in set-file-position! in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1147 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1522 in k1519 in k1513 in set-file-position! in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1148 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[77],lf[78],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1462,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1481,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1125 port? */
t5=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1479 in file-position in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[74]);
t4=((C_word*)t0)[2];
f_1466(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1466(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1130 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[72],lf[75],((C_word*)t0)[3]);}}}

/* k1464 in file-position in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1132 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1469(2,t3,C_SCHEME_UNDEFINED);}}

/* k1473 in k1464 in file-position in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1133 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[72],lf[73],((C_word*)t0)[2]);}

/* k1467 in k1464 in file-position in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1456,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1433,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1116 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1452 in regular-file? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1116 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1438 in regular-file? in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1427,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1112 ##sys#stat */
f_1328(t3,t2);}

/* k1429 in file-permissions in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1421,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1425,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1111 ##sys#stat */
f_1328(t3,t2);}

/* k1423 in file-owner in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1415,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1110 ##sys#stat */
f_1328(t3,t2);}

/* k1417 in file-change-time in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1409,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1109 ##sys#stat */
f_1328(t3,t2);}

/* k1411 in file-access-time in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1403,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1407,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1108 ##sys#stat */
f_1328(t3,t2);}

/* k1405 in file-modification-time in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1397,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1107 ##sys#stat */
f_1328(t3,t2);}

/* k1399 in file-size in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1366r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1366r(t0,t1,t2,t3);}}

static void C_ccall f_1366r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1370(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1370(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k1368 in file-stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1101 ##sys#stat */
f_1328(t2,((C_word*)t0)[2]);}

/* k1371 in k1368 in file-stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_fcall f_1328(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1328,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1332,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_1332(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1095 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k1359 in ##sys#stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1094 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1355 in ##sys#stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1332(2,t2,(C_word)C_stat(t1));}

/* k1330 in ##sys#stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1097 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1339 in k1330 in ##sys#stat in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1098 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1290,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1063 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1295 in file-mkstemp in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1065 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1298 in k1295 in file-mkstemp in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1067 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1303(2,t4,C_SCHEME_UNDEFINED);}}

/* k1318 in k1298 in k1295 in file-mkstemp in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1068 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k1301 in k1298 in k1295 in file-mkstemp in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1069 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1308 in k1301 in k1298 in k1295 in file-mkstemp in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1069 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1248r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1248r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1248r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1255,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1255(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1050 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k1253 in file-write in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1264,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1270,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1055 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1264(2,t8,C_SCHEME_UNDEFINED);}}

/* k1268 in k1253 in file-write in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1056 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1262 in k1253 in file-write in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1203r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1203r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1213,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1213(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1037 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1211 in file-read in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1216(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1039 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k1214 in k1211 in file-read in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1216,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1219,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1042 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1219(2,t5,C_SCHEME_UNDEFINED);}}

/* k1226 in k1214 in k1211 in file-read in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1043 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1217 in k1214 in k1211 in file-read in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1219,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1185,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1029 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1196 in file-close in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1030 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1144r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1144r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1144r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1161,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1019 ##sys#expand-home-path */
t12=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k1175 in file-open in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1019 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1159 in file-open in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1164,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1021 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1164(2,t5,C_SCHEME_UNDEFINED);}}

/* k1168 in k1159 in file-open in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1022 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1162 in k1159 in file-open in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1098r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1098r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1098r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1102,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 950  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1100 in posix-error in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1111 in k1100 in posix-error in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 951  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k1107 in k1100 in posix-error in k1084 in k1081 in k1078 in k1075 in k1072 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[379] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_1074posixwin.scm",(void*)f_1074},
{"f_1077posixwin.scm",(void*)f_1077},
{"f_1080posixwin.scm",(void*)f_1080},
{"f_1083posixwin.scm",(void*)f_1083},
{"f_1086posixwin.scm",(void*)f_1086},
{"f_2166posixwin.scm",(void*)f_2166},
{"f_4420posixwin.scm",(void*)f_4420},
{"f_4417posixwin.scm",(void*)f_4417},
{"f_4410posixwin.scm",(void*)f_4410},
{"f_4404posixwin.scm",(void*)f_4404},
{"f_4398posixwin.scm",(void*)f_4398},
{"f_4392posixwin.scm",(void*)f_4392},
{"f_4386posixwin.scm",(void*)f_4386},
{"f_4380posixwin.scm",(void*)f_4380},
{"f_4374posixwin.scm",(void*)f_4374},
{"f_4368posixwin.scm",(void*)f_4368},
{"f_4362posixwin.scm",(void*)f_4362},
{"f_4356posixwin.scm",(void*)f_4356},
{"f_4350posixwin.scm",(void*)f_4350},
{"f_4344posixwin.scm",(void*)f_4344},
{"f_4338posixwin.scm",(void*)f_4338},
{"f_4332posixwin.scm",(void*)f_4332},
{"f_4326posixwin.scm",(void*)f_4326},
{"f_4320posixwin.scm",(void*)f_4320},
{"f_4314posixwin.scm",(void*)f_4314},
{"f_4308posixwin.scm",(void*)f_4308},
{"f_4302posixwin.scm",(void*)f_4302},
{"f_4296posixwin.scm",(void*)f_4296},
{"f_4290posixwin.scm",(void*)f_4290},
{"f_4284posixwin.scm",(void*)f_4284},
{"f_4278posixwin.scm",(void*)f_4278},
{"f_4272posixwin.scm",(void*)f_4272},
{"f_4266posixwin.scm",(void*)f_4266},
{"f_4260posixwin.scm",(void*)f_4260},
{"f_4254posixwin.scm",(void*)f_4254},
{"f_4248posixwin.scm",(void*)f_4248},
{"f_4242posixwin.scm",(void*)f_4242},
{"f_4236posixwin.scm",(void*)f_4236},
{"f_4230posixwin.scm",(void*)f_4230},
{"f_4224posixwin.scm",(void*)f_4224},
{"f_4218posixwin.scm",(void*)f_4218},
{"f_4212posixwin.scm",(void*)f_4212},
{"f_4206posixwin.scm",(void*)f_4206},
{"f_4200posixwin.scm",(void*)f_4200},
{"f_4194posixwin.scm",(void*)f_4194},
{"f_4188posixwin.scm",(void*)f_4188},
{"f_4182posixwin.scm",(void*)f_4182},
{"f_4176posixwin.scm",(void*)f_4176},
{"f_4170posixwin.scm",(void*)f_4170},
{"f_4164posixwin.scm",(void*)f_4164},
{"f_4158posixwin.scm",(void*)f_4158},
{"f_4152posixwin.scm",(void*)f_4152},
{"f_3926posixwin.scm",(void*)f_3926},
{"f_4083posixwin.scm",(void*)f_4083},
{"f_4089posixwin.scm",(void*)f_4089},
{"f_4078posixwin.scm",(void*)f_4078},
{"f_4073posixwin.scm",(void*)f_4073},
{"f_3928posixwin.scm",(void*)f_3928},
{"f_4060posixwin.scm",(void*)f_4060},
{"f_4068posixwin.scm",(void*)f_4068},
{"f_3935posixwin.scm",(void*)f_3935},
{"f_4048posixwin.scm",(void*)f_4048},
{"f_3945posixwin.scm",(void*)f_3945},
{"f_3947posixwin.scm",(void*)f_3947},
{"f_3966posixwin.scm",(void*)f_3966},
{"f_4034posixwin.scm",(void*)f_4034},
{"f_4041posixwin.scm",(void*)f_4041},
{"f_4028posixwin.scm",(void*)f_4028},
{"f_3981posixwin.scm",(void*)f_3981},
{"f_4015posixwin.scm",(void*)f_4015},
{"f_4001posixwin.scm",(void*)f_4001},
{"f_4013posixwin.scm",(void*)f_4013},
{"f_4009posixwin.scm",(void*)f_4009},
{"f_3993posixwin.scm",(void*)f_3993},
{"f_3991posixwin.scm",(void*)f_3991},
{"f_4052posixwin.scm",(void*)f_4052},
{"f_3911posixwin.scm",(void*)f_3911},
{"f_3921posixwin.scm",(void*)f_3921},
{"f_3880posixwin.scm",(void*)f_3880},
{"f_3906posixwin.scm",(void*)f_3906},
{"f_3891posixwin.scm",(void*)f_3891},
{"f_3895posixwin.scm",(void*)f_3895},
{"f_3899posixwin.scm",(void*)f_3899},
{"f_3903posixwin.scm",(void*)f_3903},
{"f_3868posixwin.scm",(void*)f_3868},
{"f_3865posixwin.scm",(void*)f_3865},
{"f_3805posixwin.scm",(void*)f_3805},
{"f_3832posixwin.scm",(void*)f_3832},
{"f_3842posixwin.scm",(void*)f_3842},
{"f_3826posixwin.scm",(void*)f_3826},
{"f_3793posixwin.scm",(void*)f_3793},
{"f_3713posixwin.scm",(void*)f_3713},
{"f_3730posixwin.scm",(void*)f_3730},
{"f_3725posixwin.scm",(void*)f_3725},
{"f_3720posixwin.scm",(void*)f_3720},
{"f_3715posixwin.scm",(void*)f_3715},
{"f_3633posixwin.scm",(void*)f_3633},
{"f_3650posixwin.scm",(void*)f_3650},
{"f_3645posixwin.scm",(void*)f_3645},
{"f_3640posixwin.scm",(void*)f_3640},
{"f_3635posixwin.scm",(void*)f_3635},
{"f_3571posixwin.scm",(void*)f_3571},
{"f_3627posixwin.scm",(void*)f_3627},
{"f_3631posixwin.scm",(void*)f_3631},
{"f_3592posixwin.scm",(void*)f_3592},
{"f_3595posixwin.scm",(void*)f_3595},
{"f_3606posixwin.scm",(void*)f_3606},
{"f_3600posixwin.scm",(void*)f_3600},
{"f_3573posixwin.scm",(void*)f_3573},
{"f_3582posixwin.scm",(void*)f_3582},
{"f_3452posixwin.scm",(void*)f_3452},
{"f_3456posixwin.scm",(void*)f_3456},
{"f_3547posixwin.scm",(void*)f_3547},
{"f_3459posixwin.scm",(void*)f_3459},
{"f_3515posixwin.scm",(void*)f_3515},
{"f_3519posixwin.scm",(void*)f_3519},
{"f_3523posixwin.scm",(void*)f_3523},
{"f_3527posixwin.scm",(void*)f_3527},
{"f_3531posixwin.scm",(void*)f_3531},
{"f_3394posixwin.scm",(void*)f_3394},
{"f_3398posixwin.scm",(void*)f_3398},
{"f_3508posixwin.scm",(void*)f_3508},
{"f_3488posixwin.scm",(void*)f_3488},
{"f_3492posixwin.scm",(void*)f_3492},
{"f_3496posixwin.scm",(void*)f_3496},
{"f_3386posixwin.scm",(void*)f_3386},
{"f_3357posixwin.scm",(void*)f_3357},
{"f_3374posixwin.scm",(void*)f_3374},
{"f_3378posixwin.scm",(void*)f_3378},
{"f_3351posixwin.scm",(void*)f_3351},
{"f_3330posixwin.scm",(void*)f_3330},
{"f_3334posixwin.scm",(void*)f_3334},
{"f_3346posixwin.scm",(void*)f_3346},
{"f_3327posixwin.scm",(void*)f_3327},
{"f_3240posixwin.scm",(void*)f_3240},
{"f_3264posixwin.scm",(void*)f_3264},
{"f_3259posixwin.scm",(void*)f_3259},
{"f_3254posixwin.scm",(void*)f_3254},
{"f_3242posixwin.scm",(void*)f_3242},
{"f_3246posixwin.scm",(void*)f_3246},
{"f_3153posixwin.scm",(void*)f_3153},
{"f_3177posixwin.scm",(void*)f_3177},
{"f_3172posixwin.scm",(void*)f_3172},
{"f_3167posixwin.scm",(void*)f_3167},
{"f_3155posixwin.scm",(void*)f_3155},
{"f_3159posixwin.scm",(void*)f_3159},
{"f_3138posixwin.scm",(void*)f_3138},
{"f_3142posixwin.scm",(void*)f_3142},
{"f_3105posixwin.scm",(void*)f_3105},
{"f_3112posixwin.scm",(void*)f_3112},
{"f_3115posixwin.scm",(void*)f_3115},
{"f_3132posixwin.scm",(void*)f_3132},
{"f_3118posixwin.scm",(void*)f_3118},
{"f_3121posixwin.scm",(void*)f_3121},
{"f_3128posixwin.scm",(void*)f_3128},
{"f_3055posixwin.scm",(void*)f_3055},
{"f_3067posixwin.scm",(void*)f_3067},
{"f_3086posixwin.scm",(void*)f_3086},
{"f_3038posixwin.scm",(void*)f_3038},
{"f_3021posixwin.scm",(void*)f_3021},
{"f_2942posixwin.scm",(void*)f_2942},
{"f_2985posixwin.scm",(void*)f_2985},
{"f_3016posixwin.scm",(void*)f_3016},
{"f_3013posixwin.scm",(void*)f_3013},
{"f_2947posixwin.scm",(void*)f_2947},
{"f_2951posixwin.scm",(void*)f_2951},
{"f_2956posixwin.scm",(void*)f_2956},
{"f_2980posixwin.scm",(void*)f_2980},
{"f_2969posixwin.scm",(void*)f_2969},
{"f_2827posixwin.scm",(void*)f_2827},
{"f_2833posixwin.scm",(void*)f_2833},
{"f_2854posixwin.scm",(void*)f_2854},
{"f_2931posixwin.scm",(void*)f_2931},
{"f_2858posixwin.scm",(void*)f_2858},
{"f_2861posixwin.scm",(void*)f_2861},
{"f_2864posixwin.scm",(void*)f_2864},
{"f_2871posixwin.scm",(void*)f_2871},
{"f_2873posixwin.scm",(void*)f_2873},
{"f_2890posixwin.scm",(void*)f_2890},
{"f_2900posixwin.scm",(void*)f_2900},
{"f_2904posixwin.scm",(void*)f_2904},
{"f_2848posixwin.scm",(void*)f_2848},
{"f_2768posixwin.scm",(void*)f_2768},
{"f_2772posixwin.scm",(void*)f_2772},
{"f_2778posixwin.scm",(void*)f_2778},
{"f_2752posixwin.scm",(void*)f_2752},
{"f_2740posixwin.scm",(void*)f_2740},
{"f_2712posixwin.scm",(void*)f_2712},
{"f_2719posixwin.scm",(void*)f_2719},
{"f_2632posixwin.scm",(void*)f_2632},
{"f_2636posixwin.scm",(void*)f_2636},
{"f_2642posixwin.scm",(void*)f_2642},
{"f_2664posixwin.scm",(void*)f_2664},
{"f_2661posixwin.scm",(void*)f_2661},
{"f_2651posixwin.scm",(void*)f_2651},
{"f_2599posixwin.scm",(void*)f_2599},
{"f_2603posixwin.scm",(void*)f_2603},
{"f_2580posixwin.scm",(void*)f_2580},
{"f_2571posixwin.scm",(void*)f_2571},
{"f_2506posixwin.scm",(void*)f_2506},
{"f_2512posixwin.scm",(void*)f_2512},
{"f_2516posixwin.scm",(void*)f_2516},
{"f_2524posixwin.scm",(void*)f_2524},
{"f_2550posixwin.scm",(void*)f_2550},
{"f_2554posixwin.scm",(void*)f_2554},
{"f_2542posixwin.scm",(void*)f_2542},
{"f_2486posixwin.scm",(void*)f_2486},
{"f_2494posixwin.scm",(void*)f_2494},
{"f_2469posixwin.scm",(void*)f_2469},
{"f_2480posixwin.scm",(void*)f_2480},
{"f_2484posixwin.scm",(void*)f_2484},
{"f_2439posixwin.scm",(void*)f_2439},
{"f_2446posixwin.scm",(void*)f_2446},
{"f_2455posixwin.scm",(void*)f_2455},
{"f_2449posixwin.scm",(void*)f_2449},
{"f_2404posixwin.scm",(void*)f_2404},
{"f_2408posixwin.scm",(void*)f_2408},
{"f_2437posixwin.scm",(void*)f_2437},
{"f_2423posixwin.scm",(void*)f_2423},
{"f_2417posixwin.scm",(void*)f_2417},
{"f_2390posixwin.scm",(void*)f_2390},
{"f_2402posixwin.scm",(void*)f_2402},
{"f_2376posixwin.scm",(void*)f_2376},
{"f_2388posixwin.scm",(void*)f_2388},
{"f_2358posixwin.scm",(void*)f_2358},
{"f_2362posixwin.scm",(void*)f_2362},
{"f_2374posixwin.scm",(void*)f_2374},
{"f_2321posixwin.scm",(void*)f_2321},
{"f_2329posixwin.scm",(void*)f_2329},
{"f_2312posixwin.scm",(void*)f_2312},
{"f_2306posixwin.scm",(void*)f_2306},
{"f_2300posixwin.scm",(void*)f_2300},
{"f_2276posixwin.scm",(void*)f_2276},
{"f_2298posixwin.scm",(void*)f_2298},
{"f_2294posixwin.scm",(void*)f_2294},
{"f_2286posixwin.scm",(void*)f_2286},
{"f_2246posixwin.scm",(void*)f_2246},
{"f_2274posixwin.scm",(void*)f_2274},
{"f_2270posixwin.scm",(void*)f_2270},
{"f_2262posixwin.scm",(void*)f_2262},
{"f_2190posixwin.scm",(void*)f_2190},
{"f_2200posixwin.scm",(void*)f_2200},
{"f_2177posixwin.scm",(void*)f_2177},
{"f_2168posixwin.scm",(void*)f_2168},
{"f_2092posixwin.scm",(void*)f_2092},
{"f_2096posixwin.scm",(void*)f_2096},
{"f_2108posixwin.scm",(void*)f_2108},
{"f_2099posixwin.scm",(void*)f_2099},
{"f_2072posixwin.scm",(void*)f_2072},
{"f_2076posixwin.scm",(void*)f_2076},
{"f_2082posixwin.scm",(void*)f_2082},
{"f_2086posixwin.scm",(void*)f_2086},
{"f_2052posixwin.scm",(void*)f_2052},
{"f_2056posixwin.scm",(void*)f_2056},
{"f_2062posixwin.scm",(void*)f_2062},
{"f_2066posixwin.scm",(void*)f_2066},
{"f_2028posixwin.scm",(void*)f_2028},
{"f_2032posixwin.scm",(void*)f_2032},
{"f_2043posixwin.scm",(void*)f_2043},
{"f_2047posixwin.scm",(void*)f_2047},
{"f_2037posixwin.scm",(void*)f_2037},
{"f_2004posixwin.scm",(void*)f_2004},
{"f_2008posixwin.scm",(void*)f_2008},
{"f_2019posixwin.scm",(void*)f_2019},
{"f_2023posixwin.scm",(void*)f_2023},
{"f_2013posixwin.scm",(void*)f_2013},
{"f_1985posixwin.scm",(void*)f_1985},
{"f_1989posixwin.scm",(void*)f_1989},
{"f_1992posixwin.scm",(void*)f_1992},
{"f_1949posixwin.scm",(void*)f_1949},
{"f_1980posixwin.scm",(void*)f_1980},
{"f_1970posixwin.scm",(void*)f_1970},
{"f_1963posixwin.scm",(void*)f_1963},
{"f_1913posixwin.scm",(void*)f_1913},
{"f_1944posixwin.scm",(void*)f_1944},
{"f_1934posixwin.scm",(void*)f_1934},
{"f_1927posixwin.scm",(void*)f_1927},
{"f_1895posixwin.scm",(void*)f_1895},
{"f_1899posixwin.scm",(void*)f_1899},
{"f_1911posixwin.scm",(void*)f_1911},
{"f_1889posixwin.scm",(void*)f_1889},
{"f_1877posixwin.scm",(void*)f_1877},
{"f_1831posixwin.scm",(void*)f_1831},
{"f_1835posixwin.scm",(void*)f_1835},
{"f_1844posixwin.scm",(void*)f_1844},
{"f_1847posixwin.scm",(void*)f_1847},
{"f_1804posixwin.scm",(void*)f_1804},
{"f_1829posixwin.scm",(void*)f_1829},
{"f_1825posixwin.scm",(void*)f_1825},
{"f_1811posixwin.scm",(void*)f_1811},
{"f_1644posixwin.scm",(void*)f_1644},
{"f_1752posixwin.scm",(void*)f_1752},
{"f_1760posixwin.scm",(void*)f_1760},
{"f_1747posixwin.scm",(void*)f_1747},
{"f_1646posixwin.scm",(void*)f_1646},
{"f_1653posixwin.scm",(void*)f_1653},
{"f_1656posixwin.scm",(void*)f_1656},
{"f_1659posixwin.scm",(void*)f_1659},
{"f_1746posixwin.scm",(void*)f_1746},
{"f_1663posixwin.scm",(void*)f_1663},
{"f_1680posixwin.scm",(void*)f_1680},
{"f_1690posixwin.scm",(void*)f_1690},
{"f_1702posixwin.scm",(void*)f_1702},
{"f_1712posixwin.scm",(void*)f_1712},
{"f_1672posixwin.scm",(void*)f_1672},
{"f_1617posixwin.scm",(void*)f_1617},
{"f_1642posixwin.scm",(void*)f_1642},
{"f_1638posixwin.scm",(void*)f_1638},
{"f_1630posixwin.scm",(void*)f_1630},
{"f_1590posixwin.scm",(void*)f_1590},
{"f_1615posixwin.scm",(void*)f_1615},
{"f_1611posixwin.scm",(void*)f_1611},
{"f_1603posixwin.scm",(void*)f_1603},
{"f_1563posixwin.scm",(void*)f_1563},
{"f_1588posixwin.scm",(void*)f_1588},
{"f_1584posixwin.scm",(void*)f_1584},
{"f_1576posixwin.scm",(void*)f_1576},
{"f_1502posixwin.scm",(void*)f_1502},
{"f_1515posixwin.scm",(void*)f_1515},
{"f_1530posixwin.scm",(void*)f_1530},
{"f_1521posixwin.scm",(void*)f_1521},
{"f_1524posixwin.scm",(void*)f_1524},
{"f_1462posixwin.scm",(void*)f_1462},
{"f_1481posixwin.scm",(void*)f_1481},
{"f_1466posixwin.scm",(void*)f_1466},
{"f_1475posixwin.scm",(void*)f_1475},
{"f_1469posixwin.scm",(void*)f_1469},
{"f_1456posixwin.scm",(void*)f_1456},
{"f_1433posixwin.scm",(void*)f_1433},
{"f_1454posixwin.scm",(void*)f_1454},
{"f_1440posixwin.scm",(void*)f_1440},
{"f_1427posixwin.scm",(void*)f_1427},
{"f_1431posixwin.scm",(void*)f_1431},
{"f_1421posixwin.scm",(void*)f_1421},
{"f_1425posixwin.scm",(void*)f_1425},
{"f_1415posixwin.scm",(void*)f_1415},
{"f_1419posixwin.scm",(void*)f_1419},
{"f_1409posixwin.scm",(void*)f_1409},
{"f_1413posixwin.scm",(void*)f_1413},
{"f_1403posixwin.scm",(void*)f_1403},
{"f_1407posixwin.scm",(void*)f_1407},
{"f_1397posixwin.scm",(void*)f_1397},
{"f_1401posixwin.scm",(void*)f_1401},
{"f_1366posixwin.scm",(void*)f_1366},
{"f_1370posixwin.scm",(void*)f_1370},
{"f_1373posixwin.scm",(void*)f_1373},
{"f_1328posixwin.scm",(void*)f_1328},
{"f_1361posixwin.scm",(void*)f_1361},
{"f_1357posixwin.scm",(void*)f_1357},
{"f_1332posixwin.scm",(void*)f_1332},
{"f_1341posixwin.scm",(void*)f_1341},
{"f_1290posixwin.scm",(void*)f_1290},
{"f_1297posixwin.scm",(void*)f_1297},
{"f_1300posixwin.scm",(void*)f_1300},
{"f_1320posixwin.scm",(void*)f_1320},
{"f_1303posixwin.scm",(void*)f_1303},
{"f_1310posixwin.scm",(void*)f_1310},
{"f_1248posixwin.scm",(void*)f_1248},
{"f_1255posixwin.scm",(void*)f_1255},
{"f_1270posixwin.scm",(void*)f_1270},
{"f_1264posixwin.scm",(void*)f_1264},
{"f_1203posixwin.scm",(void*)f_1203},
{"f_1213posixwin.scm",(void*)f_1213},
{"f_1216posixwin.scm",(void*)f_1216},
{"f_1228posixwin.scm",(void*)f_1228},
{"f_1219posixwin.scm",(void*)f_1219},
{"f_1185posixwin.scm",(void*)f_1185},
{"f_1198posixwin.scm",(void*)f_1198},
{"f_1144posixwin.scm",(void*)f_1144},
{"f_1177posixwin.scm",(void*)f_1177},
{"f_1161posixwin.scm",(void*)f_1161},
{"f_1170posixwin.scm",(void*)f_1170},
{"f_1164posixwin.scm",(void*)f_1164},
{"f_1098posixwin.scm",(void*)f_1098},
{"f_1102posixwin.scm",(void*)f_1102},
{"f_1113posixwin.scm",(void*)f_1113},
{"f_1109posixwin.scm",(void*)f_1109},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
