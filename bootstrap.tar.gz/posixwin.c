/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-30 15:51
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[392];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,56,57,32,102,108,97,103,115,57,48,32,46,32,109,111,100,101,57,49,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,49,52,32,115,105,122,101,49,49,53,32,46,32,98,117,102,102,101,114,49,49,54,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,49,51,52,32,98,117,102,102,101,114,49,51,53,32,46,32,115,105,122,101,49,51,54,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,20),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,56,56,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,115,116,97,116,32,102,50,49,48,32,46,32,116,109,112,50,48,57,50,49,49,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,50,55,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,50,51,50,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,51,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,52,50,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,50,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,50,53,55,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,102,95,51,48,51,53,32,102,110,97,109,101,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,19),40,115,116,97,116,45,116,121,112,101,32,110,97,109,101,50,55,49,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,50,56,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,48,48,32,112,111,115,51,48,49,32,46,32,119,104,101,110,99,101,51,48,50,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,49,55,32,110,97,109,101,51,55,49,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,51,54,32,110,97,109,101,51,54,53,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,48,54,32,110,97,109,101,51,54,49,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,51,49,57,54,32,120,51,53,57,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,102,95,51,49,56,53,32,110,97,109,101,51,53,49,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,102,95,51,50,54,56,32,110,97,109,101,51,55,55,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,51,56,32,46,32,116,109,112,51,51,55,51,51,57,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,49,55,32,115,112,101,99,52,50,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,56,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,50,48,32,37,115,112,101,99,52,49,53,52,55,52,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,49,57,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,48,55,52,48,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,56,57,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,53,48,52,53,48,53,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,53,53,48,53,53,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,51,54,51,53,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,19),40,97,51,54,50,57,32,101,120,118,97,114,53,54,52,53,56,48,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,51,54,53,51,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,51,54,54,53,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,97,51,54,53,57,32,46,32,97,114,103,115,53,55,51,53,57,56,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,51,54,52,55,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,97,51,54,50,51,32,107,53,55,50,53,55,56,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,54,50,55,32,114,54,50,56,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,54,48,50,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,54,52,48,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,54,52,50,32,105,110,112,54,52,51,32,114,54,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,53,48,32,46,32,109,54,53,49,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,54,51,32,46,32,109,54,54,52,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,49,54,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,20),40,97,52,49,54,57,32,46,32,114,101,115,117,108,116,115,55,48,51,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,57,54,32,112,114,111,99,54,57,55,32,46,32,109,111,100,101,54,57,56,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,49,56,55,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,20),40,97,52,49,57,51,32,46,32,114,101,115,117,108,116,115,55,49,51,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,55,48,54,32,112,114,111,99,55,48,55,32,46,32,109,111,100,101,55,48,56,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,97,52,50,49,50,32,46,32,114,101,115,117,108,116,115,55,50,51,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,55,49,54,32,116,104,117,110,107,55,49,55,32,46,32,109,111,100,101,55,49,56,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,52,50,51,50,32,46,32,114,101,115,117,108,116,115,55,51,53,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,55,50,56,32,116,104,117,110,107,55,50,57,32,46,32,109,111,100,101,55,51,48,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,116,109,112,55,53,49,55,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,56,48,55,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,56,49,48,32,112,114,111,99,56,49,49,41,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,56,49,55,32,115,116,97,116,101,56,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,57,48,51,32,109,57,48,52,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,57,49,55,32,97,99,99,57,49,56,32,108,111,99,57,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,50,55,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,50,57,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,57,52,55,32,109,57,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,57,54,54,32,105,110,112,57,54,55,32,114,57,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,57,55,52,32,46,32,109,57,55,53,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,57,55,56,32,46,32,109,57,55,57,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,57,56,54,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,57,57,54,32,46,32,110,101,119,57,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,48,49,48,32,118,97,108,49,48,49,49,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,48,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,48,52,50,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,48,51,54,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,49,48,53,49,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,49,48,53,54,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,49,48,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,48,57,57,32,46,32,116,109,112,49,48,57,56,49,49,48,48,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,49,50,55,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,49,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,49,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,49,53,57,32,109,111,100,101,49,49,54,48,32,46,32,115,105,122,101,49,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,7),40,97,53,48,48,53,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,50,50,55,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,55),40,97,53,48,49,49,32,100,105,114,49,49,57,53,49,49,57,54,49,50,48,51,32,102,105,108,49,49,57,55,49,49,57,56,49,50,48,52,32,101,120,116,49,49,57,57,49,50,48,48,49,50,48,53,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,49,57,48,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,49,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,55,56,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,49,50,55,50,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,108,115,116,49,50,57,50,32,111,108,115,116,49,50,57,51,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,37),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,49,50,54,56,32,101,120,97,99,116,102,49,50,54,57,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,38),40,115,101,116,97,114,103,32,97,49,51,48,54,49,51,49,48,32,97,49,51,48,53,49,51,49,49,32,97,49,51,48,52,49,51,49,50,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,38),40,115,101,116,101,110,118,32,97,49,51,49,56,49,51,50,50,32,97,49,51,49,55,49,51,50,51,32,97,49,51,49,54,49,51,50,52,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,51,51,51,32,108,49,51,51,57,32,105,49,51,52,48,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,61),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,49,51,50,56,32,108,115,116,49,51,50,57,32,97,114,103,118,101,99,45,115,101,116,116,101,114,49,51,51,48,32,105,100,120,49,51,51,49,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,67),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,49,51,53,49,32,102,105,108,101,110,97,109,101,49,51,53,50,32,97,114,103,108,115,116,49,51,53,51,32,101,110,118,108,115,116,49,51,53,52,32,101,120,97,99,116,102,49,51,53,53,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,53),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,49,51,54,54,32,109,115,103,49,51,54,55,32,102,105,108,101,110,97,109,101,49,51,54,56,32,114,101,115,49,51,54,57,41,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,51,57,51,32,97,114,103,108,115,116,49,52,48,52,32,101,110,118,108,115,116,49,52,48,53,32,101,120,97,99,116,102,49,52,48,54,41,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,51,57,55,32,37,97,114,103,108,115,116,49,51,57,48,49,52,49,50,32,37,101,110,118,108,115,116,49,51,57,49,49,52,49,51,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,51,57,54,32,37,97,114,103,108,115,116,49,51,57,48,49,52,49,55,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,51,57,53,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,51,56,50,32,46,32,116,109,112,49,51,56,49,49,51,56,51,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,43),40,98,111,100,121,49,52,53,51,32,97,114,103,108,115,116,49,52,54,52,32,101,110,118,108,115,116,49,52,54,53,32,101,120,97,99,116,102,49,52,54,54,41,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,101,120,97,99,116,102,49,52,53,55,32,37,97,114,103,108,115,116,49,52,53,48,49,52,55,50,32,37,101,110,118,108,115,116,49,52,53,49,49,52,55,51,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,115,116,49,52,53,54,32,37,97,114,103,108,115,116,49,52,53,48,49,52,55,55,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,115,116,49,52,53,53,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,51),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,49,52,52,49,32,102,105,108,101,110,97,109,101,49,52,52,50,32,46,32,116,109,112,49,52,52,48,49,52,52,51,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,53,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,53,49,54,32,46,32,97,114,103,115,49,53,49,55,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,97),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,53,55,57,32,99,109,100,49,53,56,48,32,97,114,103,115,49,53,56,49,32,101,110,118,49,53,56,50,32,115,116,100,111,117,116,102,49,53,56,51,32,115,116,100,105,110,102,49,53,56,52,32,115,116,100,101,114,114,102,49,53,56,53,32,46,32,116,109,112,49,53,55,56,49,53,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,21),40,97,53,55,51,57,32,103,49,54,55,55,49,54,55,56,49,54,55,57,41,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,54,55,48,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,7),40,97,53,55,53,55,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,38),40,97,53,55,54,51,32,105,110,49,54,57,48,32,111,117,116,49,54,57,49,32,112,105,100,49,54,57,50,32,101,114,114,49,54,57,51,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,63),40,37,112,114,111,99,101,115,115,32,108,111,99,49,54,54,50,32,101,114,114,63,49,54,54,51,32,99,109,100,49,54,54,52,32,97,114,103,115,49,54,54,53,32,101,110,118,49,54,54,54,32,101,120,97,99,116,102,49,54,54,55,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,49,54,32,97,114,103,115,49,55,50,55,32,101,110,118,49,55,50,56,32,101,120,97,99,116,102,49,55,50,57,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,50,48,32,37,97,114,103,115,49,55,49,51,49,55,51,51,32,37,101,110,118,49,55,49,52,49,55,51,52,41,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,49,57,32,37,97,114,103,115,49,55,49,51,49,55,51,56,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,49,56,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,49,55,48,53,32,46,32,116,109,112,49,55,48,52,49,55,48,54,41,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,55,55,49,32,97,114,103,115,49,55,56,50,32,101,110,118,49,55,56,51,32,101,120,97,99,116,102,49,55,56,52,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,49,55,55,53,32,37,97,114,103,115,49,55,54,56,49,55,56,56,32,37,101,110,118,49,55,54,57,49,55,56,57,41,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,55,55,52,32,37,97,114,103,115,49,55,54,56,49,55,57,51,41,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,55,55,51,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,49,55,54,48,32,46,32,116,109,112,49,55,53,57,49,55,54,49,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,49,51,32,110,111,104,97,110,103,49,56,49,52,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,7),40,97,53,57,56,51,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,36),40,97,53,57,56,57,32,101,112,105,100,49,56,51,54,32,101,110,111,114,109,49,56,51,55,32,101,99,111,100,101,49,56,51,56,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,49,55,32,46,32,97,114,103,115,49,56,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,13),40,115,108,101,101,112,32,116,49,56,52,51,41,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,14),40,102,95,54,50,48,52,32,120,49,57,49,48,41,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,7),40,97,54,49,53,48,41,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,7),40,97,54,49,53,53,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,7),40,97,54,49,54,57,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,57,49,54,32,114,49,57,49,55,41,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,50,48,32,46,32,95,49,57,48,54,41};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,16),40,102,95,54,50,49,50,32,46,32,95,49,57,48,52,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,56,55,56,32,97,99,116,105,111,110,49,56,56,57,32,105,100,49,56,57,48,32,108,105,109,105,116,49,56,57,49,41,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,56,56,50,32,37,97,99,116,105,111,110,49,56,55,53,49,57,53,55,32,37,105,100,49,56,55,54,49,57,53,56,41,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,56,56,49,32,37,97,99,116,105,111,110,49,56,55,53,49,57,54,50,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,19),40,97,54,50,52,48,32,120,49,57,54,55,32,121,49,57,54,56,41,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,56,56,48,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,56,54,54,32,112,114,101,100,49,56,54,55,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,56,54,56,41,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,13),40,102,105,102,111,63,32,95,50,51,55,52,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,50,51,55,56,41,0,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,53,53,32,110,97,109,101,50,51,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,54,53,32,110,97,109,101,50,51,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,55,53,32,110,97,109,101,50,51,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,56,53,32,110,97,109,101,50,51,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,17),40,102,95,54,52,57,53,32,110,97,109,101,50,51,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,48,53,32,110,97,109,101,50,51,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,49,53,32,110,97,109,101,50,51,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,50,53,32,110,97,109,101,50,51,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,51,53,32,110,97,109,101,50,50,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,52,53,32,110,97,109,101,50,50,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,53,53,32,110,97,109,101,50,50,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,54,53,32,110,97,109,101,50,50,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,55,53,32,110,97,109,101,50,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,56,53,32,110,97,109,101,50,50,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,17),40,102,95,54,53,57,53,32,110,97,109,101,50,50,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,48,53,32,110,97,109,101,50,50,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,49,53,32,110,97,109,101,50,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,50,53,32,110,97,109,101,50,50,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,51,53,32,110,97,109,101,50,50,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,52,53,32,110,97,109,101,50,49,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,53,53,32,110,97,109,101,50,49,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,54,53,32,110,97,109,101,50,49,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,55,53,32,110,97,109,101,50,49,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,56,53,32,110,97,109,101,50,49,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,17),40,102,95,54,54,57,53,32,110,97,109,101,50,49,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,48,53,32,110,97,109,101,50,49,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,49,53,32,110,97,109,101,50,49,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,50,53,32,110,97,109,101,50,49,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,51,53,32,110,97,109,101,50,49,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,52,53,32,110,97,109,101,50,49,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,53,53,32,110,97,109,101,50,48,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,54,53,32,110,97,109,101,50,48,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,55,53,32,110,97,109,101,50,48,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,56,53,32,110,97,109,101,50,48,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,17),40,102,95,54,55,57,53,32,110,97,109,101,50,48,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,48,53,32,110,97,109,101,50,48,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,49,53,32,110,97,109,101,50,48,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,50,53,32,110,97,109,101,50,48,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,51,53,32,110,97,109,101,50,48,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,52,53,32,110,97,109,101,50,48,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,53,53,32,110,97,109,101,50,48,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,54,53,32,110,97,109,101,49,57,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,17),40,102,95,54,56,55,53,32,110,97,109,101,49,57,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k5578 */
static C_word C_fcall stub1540(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1540(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle */
static C_word C_fcall stub1526(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1526(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static C_word C_fcall stub1494(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1494(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k5207 */
static C_word C_fcall stub1319(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1319(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k5190 */
static C_word C_fcall stub1307(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1307(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k4901 */
static C_word C_fcall stub1142(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1142(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1134(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1134(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub1085(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1085(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1077(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1077(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k4748 */
static C_word C_fcall stub1062(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1062(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4654 */
static C_word C_fcall stub1026(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1026(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2667 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6308)
static void C_ccall f_6308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6815)
static void C_ccall f_6815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6785)
static void C_ccall f_6785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6605)
static void C_ccall f_6605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6595)
static void C_ccall f_6595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6235)
static void C_fcall f_6235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6230)
static void C_fcall f_6230(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6225)
static void C_fcall f_6225(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6086)
static void C_fcall f_6086(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6093)
static void C_fcall f_6093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_fcall f_6105(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6156)
static void C_ccall f_6156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6061)
static void C_ccall f_6061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5888)
static void C_fcall f_5888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_fcall f_5883(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5878)
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5873)
static void C_fcall f_5873(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5808)
static void C_fcall f_5808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_fcall f_5803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5798)
static void C_fcall f_5798(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5793)
static void C_fcall f_5793(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5729)
static void C_fcall f_5729(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_ccall f_5753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5758)
static void C_ccall f_5758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5731)
static void C_fcall f_5731(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5422)
static void C_fcall f_5422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_fcall f_5417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5412)
static void C_fcall f_5412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5400)
static void C_fcall f_5400(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5335)
static void C_fcall f_5335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_fcall f_5330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5325)
static void C_fcall f_5325(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5313)
static void C_fcall f_5313(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_fcall f_5296(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_fcall f_5263(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5225)
static void C_fcall f_5225(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5100)
static void C_fcall f_5100(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5143)
static void C_fcall f_5143(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_fcall f_5105(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_fcall f_5114(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4991)
static void C_fcall f_4991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_fcall f_5031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_fcall f_4663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_fcall f_4675(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4597)
static void C_fcall f_4597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_fcall f_4509(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_fcall f_4472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4427)
static void C_fcall f_4427(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_fcall f_4046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_fcall f_4040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static C_word C_fcall f_4028(C_word t0);
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_fcall f_3817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_fcall f_3847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_fcall f_3889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_fcall f_3687(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_fcall f_3766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static C_word C_fcall f_3604(C_word t0);
C_noret_decl(f_3599)
static void C_fcall f_3599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3469)
static void C_fcall f_3469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3363)
static void C_fcall f_3363(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_fcall f_3397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_fcall f_3419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_fcall f_3033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_fcall f_2900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6235)
static void C_fcall trf_6235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6235(t0,t1);}

C_noret_decl(trf_6230)
static void C_fcall trf_6230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6230(t0,t1,t2);}

C_noret_decl(trf_6225)
static void C_fcall trf_6225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6225(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6225(t0,t1,t2,t3);}

C_noret_decl(trf_6086)
static void C_fcall trf_6086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6086(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6086(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6093)
static void C_fcall trf_6093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6093(t0,t1);}

C_noret_decl(trf_6105)
static void C_fcall trf_6105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6105(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6105(t0,t1,t2,t3);}

C_noret_decl(trf_5888)
static void C_fcall trf_5888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5888(t0,t1);}

C_noret_decl(trf_5883)
static void C_fcall trf_5883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5883(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5883(t0,t1,t2);}

C_noret_decl(trf_5878)
static void C_fcall trf_5878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5878(t0,t1,t2,t3);}

C_noret_decl(trf_5873)
static void C_fcall trf_5873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5873(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5873(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5808)
static void C_fcall trf_5808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5808(t0,t1);}

C_noret_decl(trf_5803)
static void C_fcall trf_5803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5803(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5803(t0,t1,t2);}

C_noret_decl(trf_5798)
static void C_fcall trf_5798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5798(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5798(t0,t1,t2,t3);}

C_noret_decl(trf_5793)
static void C_fcall trf_5793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5793(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5793(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5729)
static void C_fcall trf_5729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5729(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5729(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5731)
static void C_fcall trf_5731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5731(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5731(t0,t1,t2);}

C_noret_decl(trf_5422)
static void C_fcall trf_5422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5422(t0,t1);}

C_noret_decl(trf_5417)
static void C_fcall trf_5417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5417(t0,t1,t2);}

C_noret_decl(trf_5412)
static void C_fcall trf_5412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5412(t0,t1,t2,t3);}

C_noret_decl(trf_5400)
static void C_fcall trf_5400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5400(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5400(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5335)
static void C_fcall trf_5335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5335(t0,t1);}

C_noret_decl(trf_5330)
static void C_fcall trf_5330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5330(t0,t1,t2);}

C_noret_decl(trf_5325)
static void C_fcall trf_5325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5325(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5325(t0,t1,t2,t3);}

C_noret_decl(trf_5313)
static void C_fcall trf_5313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5313(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5313(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5296)
static void C_fcall trf_5296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5296(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5296(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5263)
static void C_fcall trf_5263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5263(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5263(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5213(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5225)
static void C_fcall trf_5225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5225(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5225(t0,t1,t2,t3);}

C_noret_decl(trf_5100)
static void C_fcall trf_5100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5100(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5100(t0,t1,t2,t3);}

C_noret_decl(trf_5143)
static void C_fcall trf_5143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5143(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5143(t0,t1,t2,t3);}

C_noret_decl(trf_5105)
static void C_fcall trf_5105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5105(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5105(t0,t1,t2);}

C_noret_decl(trf_5114)
static void C_fcall trf_5114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5114(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5114(t0,t1,t2);}

C_noret_decl(trf_4991)
static void C_fcall trf_4991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4991(t0,t1,t2);}

C_noret_decl(trf_5031)
static void C_fcall trf_5031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5031(t0,t1,t2);}

C_noret_decl(trf_4663)
static void C_fcall trf_4663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4663(t0,t1,t2);}

C_noret_decl(trf_4675)
static void C_fcall trf_4675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4675(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4675(t0,t1,t2);}

C_noret_decl(trf_4597)
static void C_fcall trf_4597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4597(t0,t1);}

C_noret_decl(trf_4509)
static void C_fcall trf_4509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4509(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4509(t0,t1,t2,t3);}

C_noret_decl(trf_4472)
static void C_fcall trf_4472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4472(t0,t1,t2);}

C_noret_decl(trf_4427)
static void C_fcall trf_4427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4427(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4427(t0,t1,t2,t3);}

C_noret_decl(trf_4046)
static void C_fcall trf_4046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4046(t0,t1,t2,t3);}

C_noret_decl(trf_4040)
static void C_fcall trf_4040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4040(t0,t1);}

C_noret_decl(trf_3817)
static void C_fcall trf_3817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3817(t0,t1);}

C_noret_decl(trf_3847)
static void C_fcall trf_3847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3847(t0,t1);}

C_noret_decl(trf_3889)
static void C_fcall trf_3889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3889(t0,t1);}

C_noret_decl(trf_3687)
static void C_fcall trf_3687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3687(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3687(t0,t1,t2,t3);}

C_noret_decl(trf_3766)
static void C_fcall trf_3766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3766(t0,t1);}

C_noret_decl(trf_3615)
static void C_fcall trf_3615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3615(t0,t1);}

C_noret_decl(trf_3599)
static void C_fcall trf_3599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3599(t0,t1);}

C_noret_decl(trf_3469)
static void C_fcall trf_3469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3469(t0,t1);}

C_noret_decl(trf_3464)
static void C_fcall trf_3464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3464(t0,t1,t2);}

C_noret_decl(trf_3363)
static void C_fcall trf_3363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3363(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3363(t0,t1,t2,t3);}

C_noret_decl(trf_3397)
static void C_fcall trf_3397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3397(t0,t1);}

C_noret_decl(trf_3419)
static void C_fcall trf_3419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3419(t0,t1);}

C_noret_decl(trf_3033)
static void C_fcall trf_3033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3033(t0,t1);}

C_noret_decl(trf_2900)
static void C_fcall trf_2900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2900(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3080)){
C_save(t1);
C_rereclaim2(3080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,392);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"open/rdonly");
lf[11]=C_h_intern(&lf[11],11,"open/wronly");
lf[12]=C_h_intern(&lf[12],9,"open/rdwr");
lf[13]=C_h_intern(&lf[13],9,"open/read");
lf[14]=C_h_intern(&lf[14],10,"open/write");
lf[15]=C_h_intern(&lf[15],10,"open/creat");
lf[16]=C_h_intern(&lf[16],11,"open/append");
lf[17]=C_h_intern(&lf[17],9,"open/excl");
lf[18]=C_h_intern(&lf[18],10,"open/trunc");
lf[19]=C_h_intern(&lf[19],11,"open/binary");
lf[20]=C_h_intern(&lf[20],9,"open/text");
lf[21]=C_h_intern(&lf[21],14,"open/noinherit");
lf[22]=C_h_intern(&lf[22],10,"perm/irusr");
lf[23]=C_h_intern(&lf[23],10,"perm/iwusr");
lf[24]=C_h_intern(&lf[24],10,"perm/ixusr");
lf[25]=C_h_intern(&lf[25],10,"perm/irgrp");
lf[26]=C_h_intern(&lf[26],10,"perm/iwgrp");
lf[27]=C_h_intern(&lf[27],10,"perm/ixgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iroth");
lf[29]=C_h_intern(&lf[29],10,"perm/iwoth");
lf[30]=C_h_intern(&lf[30],10,"perm/ixoth");
lf[31]=C_h_intern(&lf[31],10,"perm/irwxu");
lf[32]=C_h_intern(&lf[32],10,"perm/irwxg");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxo");
lf[34]=C_h_intern(&lf[34],9,"file-open");
lf[35]=C_h_intern(&lf[35],11,"\000file-error");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[37]=C_h_intern(&lf[37],17,"\003sysmake-c-string");
lf[38]=C_h_intern(&lf[38],20,"\003sysexpand-home-path");
lf[39]=C_h_intern(&lf[39],10,"file-close");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[41]=C_h_intern(&lf[41],11,"make-string");
lf[42]=C_h_intern(&lf[42],9,"file-read");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[44]=C_h_intern(&lf[44],11,"\000type-error");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[46]=C_h_intern(&lf[46],10,"file-write");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[49]=C_h_intern(&lf[49],13,"string-length");
lf[50]=C_h_intern(&lf[50],12,"file-mkstemp");
lf[51]=C_h_intern(&lf[51],13,"\003syssubstring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[53]=C_h_intern(&lf[53],8,"seek/set");
lf[54]=C_h_intern(&lf[54],8,"seek/end");
lf[55]=C_h_intern(&lf[55],8,"seek/cur");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[59]=C_h_intern(&lf[59],9,"file-stat");
lf[60]=C_h_intern(&lf[60],9,"\003syserror");
lf[61]=C_h_intern(&lf[61],9,"file-size");
lf[62]=C_h_intern(&lf[62],22,"file-modification-time");
lf[63]=C_h_intern(&lf[63],16,"file-access-time");
lf[64]=C_h_intern(&lf[64],16,"file-change-time");
lf[65]=C_h_intern(&lf[65],10,"file-owner");
lf[66]=C_h_intern(&lf[66],16,"file-permissions");
lf[67]=C_h_intern(&lf[67],13,"regular-file\077");
lf[68]=C_h_intern(&lf[68],13,"\003sysfile-info");
lf[69]=C_h_intern(&lf[69],14,"symbolic-link\077");
lf[70]=C_h_intern(&lf[70],13,"stat-regular\077");
lf[71]=C_h_intern(&lf[71],15,"stat-directory\077");
lf[72]=C_h_intern(&lf[72],17,"stat-char-device\077");
lf[73]=C_h_intern(&lf[73],18,"stat-block-device\077");
lf[74]=C_h_intern(&lf[74],10,"stat-fifo\077");
lf[75]=C_h_intern(&lf[75],13,"stat-symlink\077");
lf[76]=C_h_intern(&lf[76],12,"stat-socket\077");
lf[77]=C_h_intern(&lf[77],13,"file-position");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[79]=C_h_intern(&lf[79],6,"stream");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[81]=C_h_intern(&lf[81],5,"port\077");
lf[82]=C_h_intern(&lf[82],18,"set-file-position!");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[85]=C_h_intern(&lf[85],13,"\000bounds-error");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[87]=C_h_intern(&lf[87],16,"create-directory");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[89]=C_h_intern(&lf[89],12,"file-exists\077");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[91]=C_h_intern(&lf[91],12,"\003sysfor-each");
lf[92]=C_h_intern(&lf[92],12,"string-split");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[94]=C_h_intern(&lf[94],14,"canonical-path");
lf[95]=C_h_intern(&lf[95],16,"change-directory");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[97]=C_h_intern(&lf[97],16,"delete-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[99]=C_h_intern(&lf[99],6,"string");
lf[100]=C_h_intern(&lf[100],9,"directory");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[102]=C_h_intern(&lf[102],16,"\003sysmake-pointer");
lf[103]=C_h_intern(&lf[103],17,"current-directory");
lf[104]=C_h_intern(&lf[104],10,"directory\077");
lf[105]=C_h_intern(&lf[105],27,"\003sysplatform-fixup-pathname");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[107]=C_h_intern(&lf[107],5,"null\077");
lf[108]=C_h_intern(&lf[108],6,"char=\077");
lf[109]=C_h_intern(&lf[109],8,"string=\077");
lf[110]=C_h_intern(&lf[110],16,"char-alphabetic\077");
lf[111]=C_h_intern(&lf[111],10,"string-ref");
lf[112]=C_h_intern(&lf[112],18,"string-intersperse");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[114]=C_h_intern(&lf[114],17,"current-user-name");
lf[115]=C_h_intern(&lf[115],9,"condition");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[117]=C_h_intern(&lf[117],22,"with-exception-handler");
lf[118]=C_h_intern(&lf[118],30,"call-with-current-continuation");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_h_intern(&lf[120],7,"reverse");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[130]=C_h_intern(&lf[130],5,"\000text");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[133]=C_h_intern(&lf[133],13,"\003sysmake-port");
lf[134]=C_h_intern(&lf[134],21,"\003sysstream-port-class");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[136]=C_h_intern(&lf[136],15,"open-input-pipe");
lf[137]=C_h_intern(&lf[137],7,"\000binary");
lf[138]=C_h_intern(&lf[138],16,"open-output-pipe");
lf[139]=C_h_intern(&lf[139],16,"close-input-pipe");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[141]=C_h_intern(&lf[141],14,"\003syscheck-port");
lf[142]=C_h_intern(&lf[142],17,"close-output-pipe");
lf[143]=C_h_intern(&lf[143],20,"call-with-input-pipe");
lf[144]=C_h_intern(&lf[144],21,"call-with-output-pipe");
lf[145]=C_h_intern(&lf[145],20,"with-input-from-pipe");
lf[146]=C_h_intern(&lf[146],18,"\003sysstandard-input");
lf[147]=C_h_intern(&lf[147],19,"with-output-to-pipe");
lf[148]=C_h_intern(&lf[148],19,"\003sysstandard-output");
lf[149]=C_h_intern(&lf[149],11,"create-pipe");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[151]=C_h_intern(&lf[151],11,"signal/term");
lf[152]=C_h_intern(&lf[152],10,"signal/int");
lf[153]=C_h_intern(&lf[153],10,"signal/fpe");
lf[154]=C_h_intern(&lf[154],10,"signal/ill");
lf[155]=C_h_intern(&lf[155],11,"signal/segv");
lf[156]=C_h_intern(&lf[156],11,"signal/abrt");
lf[157]=C_h_intern(&lf[157],12,"signal/break");
lf[158]=C_h_intern(&lf[158],11,"signal/alrm");
lf[159]=C_h_intern(&lf[159],11,"signal/chld");
lf[160]=C_h_intern(&lf[160],11,"signal/cont");
lf[161]=C_h_intern(&lf[161],10,"signal/hup");
lf[162]=C_h_intern(&lf[162],9,"signal/io");
lf[163]=C_h_intern(&lf[163],11,"signal/kill");
lf[164]=C_h_intern(&lf[164],11,"signal/pipe");
lf[165]=C_h_intern(&lf[165],11,"signal/prof");
lf[166]=C_h_intern(&lf[166],11,"signal/quit");
lf[167]=C_h_intern(&lf[167],11,"signal/stop");
lf[168]=C_h_intern(&lf[168],11,"signal/trap");
lf[169]=C_h_intern(&lf[169],11,"signal/tstp");
lf[170]=C_h_intern(&lf[170],10,"signal/urg");
lf[171]=C_h_intern(&lf[171],11,"signal/usr1");
lf[172]=C_h_intern(&lf[172],11,"signal/usr2");
lf[173]=C_h_intern(&lf[173],13,"signal/vtalrm");
lf[174]=C_h_intern(&lf[174],12,"signal/winch");
lf[175]=C_h_intern(&lf[175],11,"signal/xcpu");
lf[176]=C_h_intern(&lf[176],11,"signal/xfsz");
lf[177]=C_h_intern(&lf[177],12,"signals-list");
lf[178]=C_h_intern(&lf[178],18,"\003sysinterrupt-hook");
lf[179]=C_h_intern(&lf[179],14,"signal-handler");
lf[180]=C_h_intern(&lf[180],19,"set-signal-handler!");
lf[181]=C_h_intern(&lf[181],10,"errno/perm");
lf[182]=C_h_intern(&lf[182],11,"errno/noent");
lf[183]=C_h_intern(&lf[183],10,"errno/srch");
lf[184]=C_h_intern(&lf[184],10,"errno/intr");
lf[185]=C_h_intern(&lf[185],8,"errno/io");
lf[186]=C_h_intern(&lf[186],12,"errno/noexec");
lf[187]=C_h_intern(&lf[187],10,"errno/badf");
lf[188]=C_h_intern(&lf[188],11,"errno/child");
lf[189]=C_h_intern(&lf[189],11,"errno/nomem");
lf[190]=C_h_intern(&lf[190],11,"errno/acces");
lf[191]=C_h_intern(&lf[191],11,"errno/fault");
lf[192]=C_h_intern(&lf[192],10,"errno/busy");
lf[193]=C_h_intern(&lf[193],11,"errno/exist");
lf[194]=C_h_intern(&lf[194],12,"errno/notdir");
lf[195]=C_h_intern(&lf[195],11,"errno/isdir");
lf[196]=C_h_intern(&lf[196],11,"errno/inval");
lf[197]=C_h_intern(&lf[197],11,"errno/mfile");
lf[198]=C_h_intern(&lf[198],11,"errno/nospc");
lf[199]=C_h_intern(&lf[199],11,"errno/spipe");
lf[200]=C_h_intern(&lf[200],10,"errno/pipe");
lf[201]=C_h_intern(&lf[201],11,"errno/again");
lf[202]=C_h_intern(&lf[202],10,"errno/rofs");
lf[203]=C_h_intern(&lf[203],10,"errno/nxio");
lf[204]=C_h_intern(&lf[204],10,"errno/2big");
lf[205]=C_h_intern(&lf[205],10,"errno/xdev");
lf[206]=C_h_intern(&lf[206],11,"errno/nodev");
lf[207]=C_h_intern(&lf[207],11,"errno/nfile");
lf[208]=C_h_intern(&lf[208],11,"errno/notty");
lf[209]=C_h_intern(&lf[209],10,"errno/fbig");
lf[210]=C_h_intern(&lf[210],11,"errno/mlink");
lf[211]=C_h_intern(&lf[211],9,"errno/dom");
lf[212]=C_h_intern(&lf[212],11,"errno/range");
lf[213]=C_h_intern(&lf[213],12,"errno/deadlk");
lf[214]=C_h_intern(&lf[214],17,"errno/nametoolong");
lf[215]=C_h_intern(&lf[215],11,"errno/nolck");
lf[216]=C_h_intern(&lf[216],11,"errno/nosys");
lf[217]=C_h_intern(&lf[217],14,"errno/notempty");
lf[218]=C_h_intern(&lf[218],11,"errno/ilseq");
lf[219]=C_h_intern(&lf[219],16,"change-file-mode");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[221]=C_h_intern(&lf[221],17,"file-read-access\077");
lf[222]=C_h_intern(&lf[222],18,"file-write-access\077");
lf[223]=C_h_intern(&lf[223],20,"file-execute-access\077");
lf[224]=C_h_intern(&lf[224],12,"fileno/stdin");
lf[225]=C_h_intern(&lf[225],13,"fileno/stdout");
lf[226]=C_h_intern(&lf[226],13,"fileno/stderr");
lf[227]=C_h_intern(&lf[227],7,"\000append");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[235]=C_h_intern(&lf[235],16,"open-input-file*");
lf[236]=C_h_intern(&lf[236],17,"open-output-file*");
lf[237]=C_h_intern(&lf[237],12,"port->fileno");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[240]=C_h_intern(&lf[240],25,"\003syspeek-unsigned-integer");
lf[241]=C_h_intern(&lf[241],16,"duplicate-fileno");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[243]=C_h_intern(&lf[243],6,"setenv");
lf[244]=C_h_intern(&lf[244],8,"unsetenv");
lf[245]=C_h_intern(&lf[245],9,"substring");
lf[246]=C_h_intern(&lf[246],25,"get-environment-variables");
lf[247]=C_h_intern(&lf[247],19,"current-environment");
lf[248]=C_h_intern(&lf[248],19,"seconds->local-time");
lf[249]=C_h_intern(&lf[249],18,"\003sysdecode-seconds");
lf[250]=C_h_intern(&lf[250],17,"seconds->utc-time");
lf[251]=C_h_intern(&lf[251],15,"seconds->string");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[253]=C_h_intern(&lf[253],12,"time->string");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[257]=C_h_intern(&lf[257],19,"local-time->seconds");
lf[258]=C_h_intern(&lf[258],15,"\003syscons-flonum");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[261]=C_h_intern(&lf[261],27,"local-timezone-abbreviation");
lf[262]=C_h_intern(&lf[262],5,"_exit");
lf[263]=C_h_intern(&lf[263],14,"terminal-port\077");
lf[264]=C_h_intern(&lf[264],19,"set-buffering-mode!");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[266]=C_h_intern(&lf[266],5,"\000full");
lf[267]=C_h_intern(&lf[267],5,"\000line");
lf[268]=C_h_intern(&lf[268],5,"\000none");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[270]=C_h_intern(&lf[270],6,"regexp");
lf[271]=C_h_intern(&lf[271],21,"make-anchored-pattern");
lf[272]=C_h_intern(&lf[272],12,"string-match");
lf[273]=C_h_intern(&lf[273],12,"glob->regexp");
lf[274]=C_h_intern(&lf[274],13,"make-pathname");
lf[275]=C_h_intern(&lf[275],18,"decompose-pathname");
lf[276]=C_h_intern(&lf[276],4,"glob");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[279]=C_h_intern(&lf[279],13,"spawn/overlay");
lf[280]=C_h_intern(&lf[280],10,"spawn/wait");
lf[281]=C_h_intern(&lf[281],12,"spawn/nowait");
lf[282]=C_h_intern(&lf[282],13,"spawn/nowaito");
lf[283]=C_h_intern(&lf[283],12,"spawn/detach");
lf[284]=C_h_intern(&lf[284],16,"char-whitespace\077");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[288]=C_h_intern(&lf[288],24,"pathname-strip-directory");
lf[291]=C_h_intern(&lf[291],15,"process-execute");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[293]=C_h_intern(&lf[293],13,"process-spawn");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[295]=C_h_intern(&lf[295],18,"current-process-id");
lf[296]=C_h_intern(&lf[296],17,"\003sysshell-command");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[298]=C_h_intern(&lf[298],6,"getenv");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[300]=C_h_intern(&lf[300],27,"\003sysshell-command-arguments");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[302]=C_h_intern(&lf[302],11,"process-run");
lf[303]=C_h_intern(&lf[303],11,"\003sysprocess");
lf[304]=C_h_intern(&lf[304],14,"\000process-error");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[306]=C_h_intern(&lf[306],17,"\003sysmake-locative");
lf[307]=C_h_intern(&lf[307],8,"location");
lf[308]=C_h_intern(&lf[308],7,"process");
lf[309]=C_h_intern(&lf[309],8,"process*");
lf[310]=C_h_intern(&lf[310],16,"\003sysprocess-wait");
lf[311]=C_h_intern(&lf[311],12,"process-wait");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[313]=C_h_intern(&lf[313],5,"sleep");
lf[314]=C_h_intern(&lf[314],13,"get-host-name");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[316]=C_h_intern(&lf[316],18,"system-information");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[320]=C_h_intern(&lf[320],10,"find-files");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[324]=C_h_intern(&lf[324],16,"\003sysdynamic-wind");
lf[325]=C_h_intern(&lf[325],13,"pathname-file");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[327]=C_h_intern(&lf[327],16,"errno/wouldblock");
lf[328]=C_h_intern(&lf[328],5,"fifo\077");
lf[329]=C_h_intern(&lf[329],19,"memory-mapped-file\077");
lf[330]=C_h_intern(&lf[330],13,"map/anonymous");
lf[331]=C_h_intern(&lf[331],8,"map/file");
lf[332]=C_h_intern(&lf[332],9,"map/fixed");
lf[333]=C_h_intern(&lf[333],11,"map/private");
lf[334]=C_h_intern(&lf[334],10,"map/shared");
lf[335]=C_h_intern(&lf[335],10,"open/fsync");
lf[336]=C_h_intern(&lf[336],11,"open/noctty");
lf[337]=C_h_intern(&lf[337],13,"open/nonblock");
lf[338]=C_h_intern(&lf[338],9,"open/sync");
lf[339]=C_h_intern(&lf[339],10,"perm/isgid");
lf[340]=C_h_intern(&lf[340],10,"perm/isuid");
lf[341]=C_h_intern(&lf[341],10,"perm/isvtx");
lf[342]=C_h_intern(&lf[342],9,"prot/exec");
lf[343]=C_h_intern(&lf[343],9,"prot/none");
lf[344]=C_h_intern(&lf[344],9,"prot/read");
lf[345]=C_h_intern(&lf[345],10,"prot/write");
lf[346]=C_h_intern(&lf[346],12,"string->time");
lf[347]=C_h_intern(&lf[347],17,"utc-time->seconds");
lf[348]=C_h_intern(&lf[348],16,"user-information");
lf[349]=C_h_intern(&lf[349],22,"unmap-file-from-memory");
lf[350]=C_h_intern(&lf[350],13,"terminal-size");
lf[351]=C_h_intern(&lf[351],13,"terminal-name");
lf[352]=C_h_intern(&lf[352],14,"signal-unmask!");
lf[353]=C_h_intern(&lf[353],14,"signal-masked\077");
lf[354]=C_h_intern(&lf[354],12,"signal-mask!");
lf[355]=C_h_intern(&lf[355],11,"signal-mask");
lf[356]=C_h_intern(&lf[356],12,"set-user-id!");
lf[357]=C_h_intern(&lf[357],16,"set-signal-mask!");
lf[358]=C_h_intern(&lf[358],19,"set-root-directory!");
lf[359]=C_h_intern(&lf[359],21,"set-process-group-id!");
lf[360]=C_h_intern(&lf[360],11,"set-groups!");
lf[361]=C_h_intern(&lf[361],13,"set-group-id!");
lf[362]=C_h_intern(&lf[362],10,"set-alarm!");
lf[363]=C_h_intern(&lf[363],18,"read-symbolic-link");
lf[364]=C_h_intern(&lf[364],14,"process-signal");
lf[365]=C_h_intern(&lf[365],16,"process-group-id");
lf[366]=C_h_intern(&lf[366],12,"process-fork");
lf[367]=C_h_intern(&lf[367],17,"parent-process-id");
lf[368]=C_h_intern(&lf[368],26,"memory-mapped-file-pointer");
lf[369]=C_h_intern(&lf[369],17,"initialize-groups");
lf[370]=C_h_intern(&lf[370],17,"group-information");
lf[371]=C_h_intern(&lf[371],10,"get-groups");
lf[372]=C_h_intern(&lf[372],11,"file-unlock");
lf[373]=C_h_intern(&lf[373],13,"file-truncate");
lf[374]=C_h_intern(&lf[374],14,"file-test-lock");
lf[375]=C_h_intern(&lf[375],11,"file-select");
lf[376]=C_h_intern(&lf[376],18,"file-lock/blocking");
lf[377]=C_h_intern(&lf[377],9,"file-lock");
lf[378]=C_h_intern(&lf[378],9,"file-link");
lf[379]=C_h_intern(&lf[379],18,"map-file-to-memory");
lf[380]=C_h_intern(&lf[380],15,"current-user-id");
lf[381]=C_h_intern(&lf[381],16,"current-group-id");
lf[382]=C_h_intern(&lf[382],27,"current-effective-user-name");
lf[383]=C_h_intern(&lf[383],25,"current-effective-user-id");
lf[384]=C_h_intern(&lf[384],26,"current-effective-group-id");
lf[385]=C_h_intern(&lf[385],20,"create-symbolic-link");
lf[386]=C_h_intern(&lf[386],14,"create-session");
lf[387]=C_h_intern(&lf[387],11,"create-fifo");
lf[388]=C_h_intern(&lf[388],17,"change-file-owner");
lf[389]=C_h_intern(&lf[389],11,"make-vector");
lf[390]=C_h_intern(&lf[390],17,"register-feature!");
lf[391]=C_h_intern(&lf[391],5,"posix");
C_register_lf2(lf,392,create_ptable());
t2=C_mutate(&lf[0] /* (set! c222 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2641 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2644 in k2641 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2647 in k2644 in k2641 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 929  register-feature! */
t3=*((C_word*)lf[390]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[391]);}

/* k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[10]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[11]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[12]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[13]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[14]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[15]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[16]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[22]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[23]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[24]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[25]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[26]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[27]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[29]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[30]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[31]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[34]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[39]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2757,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[41]+1);
t35=C_mutate((C_word*)lf[42]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[46]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[49]+1);
t38=C_mutate((C_word*)lf[50]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2862,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[53]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[54]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[55]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[56] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[59]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[61]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[62]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2975,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[63]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2981,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[64]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[65]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[66]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[67]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[69]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[70]+1 /* (set! stat-regular? ...) */,*((C_word*)lf[67]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1114 stat-type */
f_3033(t54,lf[71]);}

/* k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! stat-directory? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1115 stat-type */
f_3033(t3,lf[72]);}

/* k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! stat-char-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1116 stat-type */
f_3033(t3,lf[73]);}

/* k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! stat-block-device? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1117 stat-type */
f_3033(t3,lf[74]);}

/* k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! stat-fifo? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1118 stat-type */
f_3033(t3,lf[75]);}

/* k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! stat-symlink? ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1119 stat-type */
f_3033(t3,lf[76]);}

/* k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[121],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! stat-socket? ...) */,t1);
t3=C_mutate((C_word*)lf[77]+1 /* (set! file-position ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[82]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[87]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3167,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[95]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3307,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[2]+1);
t9=*((C_word*)lf[41]+1);
t10=*((C_word*)lf[99]+1);
t11=C_mutate((C_word*)lf[100]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3361,a[2]=t9,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[104]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[41]+1);
t14=C_mutate((C_word*)lf[103]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=t13,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[107]+1);
t16=*((C_word*)lf[108]+1);
t17=*((C_word*)lf[109]+1);
t18=*((C_word*)lf[110]+1);
t19=*((C_word*)lf[111]+1);
t20=*((C_word*)lf[2]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3599,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t23=*((C_word*)lf[114]+1);
t24=*((C_word*)lf[103]+1);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3615,a[2]=t24,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t26=C_mutate((C_word*)lf[94]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3671,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4040,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4046,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[136]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[138]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4100,a[2]=t28,a[3]=t29,a[4]=t27,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t32=C_mutate((C_word*)lf[139]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4136,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[142]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[139]+1));
t34=*((C_word*)lf[136]+1);
t35=*((C_word*)lf[138]+1);
t36=*((C_word*)lf[139]+1);
t37=*((C_word*)lf[142]+1);
t38=C_mutate((C_word*)lf[143]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4155,a[2]=t34,a[3]=t36,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[144]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4179,a[2]=t35,a[3]=t37,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[145]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=t34,a[3]=t36,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[147]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4223,a[2]=t35,a[3]=t37,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t42=C_mutate((C_word*)lf[149]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4243,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[151]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[152]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[153]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[154]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[155]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[156]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[157]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[158] /* signal/alrm */,0,C_fix(0));
t51=C_set_block_item(lf[159] /* signal/chld */,0,C_fix(0));
t52=C_set_block_item(lf[160] /* signal/cont */,0,C_fix(0));
t53=C_set_block_item(lf[161] /* signal/hup */,0,C_fix(0));
t54=C_set_block_item(lf[162] /* signal/io */,0,C_fix(0));
t55=C_set_block_item(lf[163] /* signal/kill */,0,C_fix(0));
t56=C_set_block_item(lf[164] /* signal/pipe */,0,C_fix(0));
t57=C_set_block_item(lf[165] /* signal/prof */,0,C_fix(0));
t58=C_set_block_item(lf[166] /* signal/quit */,0,C_fix(0));
t59=C_set_block_item(lf[167] /* signal/stop */,0,C_fix(0));
t60=C_set_block_item(lf[168] /* signal/trap */,0,C_fix(0));
t61=C_set_block_item(lf[169] /* signal/tstp */,0,C_fix(0));
t62=C_set_block_item(lf[170] /* signal/urg */,0,C_fix(0));
t63=C_set_block_item(lf[171] /* signal/usr1 */,0,C_fix(0));
t64=C_set_block_item(lf[172] /* signal/usr2 */,0,C_fix(0));
t65=C_set_block_item(lf[173] /* signal/vtalrm */,0,C_fix(0));
t66=C_set_block_item(lf[174] /* signal/winch */,0,C_fix(0));
t67=C_set_block_item(lf[175] /* signal/xcpu */,0,C_fix(0));
t68=C_set_block_item(lf[176] /* signal/xfsz */,0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1),*((C_word*)lf[156]+1),*((C_word*)lf[157]+1));
t70=C_mutate((C_word*)lf[177]+1 /* (set! signals-list ...) */,t69);
t71=*((C_word*)lf[178]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1467 make-vector */
t73=*((C_word*)lf[389]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word ab[190],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=C_mutate((C_word*)lf[179]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=t1,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[180]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4328,a[2]=t1,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[178]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[181]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[182]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[183]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[184]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[185]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[186]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[187]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[188]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[189]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[190]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[191]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[192]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[193]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[194]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[195]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[196]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[197]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[198]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[199]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[200]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[201]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[202]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[203]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[204]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[205]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[206]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[207]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[208]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[209]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[210]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[211]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[212]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[213]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[214]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[215]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[216]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[217]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[218]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[219]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4427,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[221]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4451,a[2]=t44,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[222]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4457,a[2]=t44,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[223]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4463,a[2]=t44,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[224]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[225]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[226]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4472,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4509,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[235]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4527,a[2]=t51,a[3]=t52,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[236]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4541,a[2]=t51,a[3]=t52,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[237]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4555,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[241]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4590,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[243]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[244]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[245]+1);
t60=C_mutate((C_word*)lf[246]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4657,a[2]=t59,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[247]+1 /* (set! current-environment ...) */,*((C_word*)lf[246]+1));
t62=C_mutate((C_word*)lf[248]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4723,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[250]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4732,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[251]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4751,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[253]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4784,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[257]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4864,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[261]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4892,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[262]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4904,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[263]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[264]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4926,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t71=*((C_word*)lf[270]+1);
t72=*((C_word*)lf[271]+1);
t73=*((C_word*)lf[272]+1);
t74=*((C_word*)lf[273]+1);
t75=*((C_word*)lf[100]+1);
t76=*((C_word*)lf[274]+1);
t77=*((C_word*)lf[275]+1);
t78=C_mutate((C_word*)lf[276]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4985,a[2]=t74,a[3]=t72,a[4]=t71,a[5]=t75,a[6]=t73,a[7]=t76,a[8]=t77,a[9]=((C_word)li97),tmp=(C_word)a,a+=10,tmp));
t79=C_mutate((C_word*)lf[279]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t80=C_mutate((C_word*)lf[280]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t81=C_mutate((C_word*)lf[281]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t82=C_mutate((C_word*)lf[282]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t83=C_mutate((C_word*)lf[283]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t84=*((C_word*)lf[284]+1);
t85=*((C_word*)lf[49]+1);
t86=*((C_word*)lf[111]+1);
t87=*((C_word*)lf[2]+1);
t88=C_mutate(&lf[285] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5100,a[2]=t87,a[3]=t85,a[4]=t86,a[5]=t84,a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t89=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5179,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5196,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t91=*((C_word*)lf[288]+1);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5213,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t93=C_mutate(&lf[289] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5263,a[2]=t91,a[3]=t89,a[4]=t90,a[5]=t92,a[6]=((C_word)li106),tmp=(C_word)a,a+=7,tmp));
t94=C_mutate(&lf[290] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5296,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[291]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[293]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5398,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[295]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5485,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[296]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5488,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[300]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t100=*((C_word*)lf[293]+1);
t101=*((C_word*)lf[298]+1);
t102=C_mutate((C_word*)lf[302]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=t100,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t103=C_mutate((C_word*)lf[303]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5610,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5729,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[308]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5791,a[2]=t104,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[309]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5871,a[2]=t104,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp));
t107=C_mutate((C_word*)lf[310]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5951,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[311]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5963,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[313]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6023,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[314]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[316]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[114]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6069,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t113=*((C_word*)lf[276]+1);
t114=*((C_word*)lf[272]+1);
t115=*((C_word*)lf[274]+1);
t116=*((C_word*)lf[104]+1);
t117=C_mutate((C_word*)lf[320]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6084,a[2]=t116,a[3]=t115,a[4]=t113,a[5]=t114,a[6]=((C_word)li158),tmp=(C_word)a,a+=7,tmp));
t118=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6305,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t119=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6875,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t119+1)))(3,t119,t118,*((C_word*)lf[388]+1));}

/* f_6875 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6875,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6865,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[387]+1));}

/* f_6865 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6865,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6855,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[386]+1));}

/* f_6855 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6855,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6845,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[385]+1));}

/* f_6845 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6845,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6835,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[384]+1));}

/* f_6835 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6835,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6825,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[383]+1));}

/* f_6825 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6825,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6815,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[382]+1));}

/* f_6815 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6815,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6805,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[381]+1));}

/* f_6805 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6805,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6795,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[380]+1));}

/* f_6795 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6795,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6785,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[379]+1));}

/* f_6785 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6785,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6775,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[378]+1));}

/* f_6775 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6775,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6765,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[377]+1));}

/* f_6765 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6765,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6755,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[376]+1));}

/* f_6755 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6755,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6745,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[375]+1));}

/* f_6745 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6745,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6735,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[374]+1));}

/* f_6735 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6735,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6725,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[373]+1));}

/* f_6725 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6725,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6715,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[372]+1));}

/* f_6715 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6715,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6705,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[371]+1));}

/* f_6705 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6705,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6695,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[370]+1));}

/* f_6695 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6695,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6685,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[369]+1));}

/* f_6685 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6685,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6675,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[368]+1));}

/* f_6675 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6675,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6665,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[367]+1));}

/* f_6665 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6665,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6655,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[366]+1));}

/* f_6655 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6655,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6645,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[365]+1));}

/* f_6645 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6645,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6635,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[364]+1));}

/* f_6635 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6635,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6625,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[363]+1));}

/* f_6625 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6625,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6615,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[362]+1));}

/* f_6615 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6615,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6605,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[361]+1));}

/* f_6605 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6605,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6595,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[360]+1));}

/* f_6595 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6595,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6585,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[359]+1));}

/* f_6585 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6585,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6575,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[358]+1));}

/* f_6575 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6575,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6565,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[357]+1));}

/* f_6565 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6565,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6555,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[356]+1));}

/* f_6555 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6555,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6545,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[355]+1));}

/* f_6545 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6545,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6535,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[354]+1));}

/* f_6535 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6535,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6525,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[353]+1));}

/* f_6525 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6525,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6515,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[352]+1));}

/* f_6515 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6515,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6505,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[351]+1));}

/* f_6505 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6505,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[350]+1));}

/* f_6495 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6495,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6485,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[349]+1));}

/* f_6485 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6485,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6425,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6475,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[348]+1));}

/* f_6475 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6475,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6465,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[347]+1));}

/* f_6465 in k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6465,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6426 in k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6455,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[346]+1));}

/* f_6455 in k6426 in k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6455,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6429 in k6426 in k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=C_set_block_item(lf[327] /* errno/wouldblock */,0,C_fix(0));
t3=C_mutate((C_word*)lf[328]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6434,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[329]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6437,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t5=C_set_block_item(lf[330] /* map/anonymous */,0,C_fix(0));
t6=C_set_block_item(lf[331] /* map/file */,0,C_fix(0));
t7=C_set_block_item(lf[332] /* map/fixed */,0,C_fix(0));
t8=C_set_block_item(lf[333] /* map/private */,0,C_fix(0));
t9=C_set_block_item(lf[334] /* map/shared */,0,C_fix(0));
t10=C_set_block_item(lf[335] /* open/fsync */,0,C_fix(0));
t11=C_set_block_item(lf[336] /* open/noctty */,0,C_fix(0));
t12=C_set_block_item(lf[337] /* open/nonblock */,0,C_fix(0));
t13=C_set_block_item(lf[338] /* open/sync */,0,C_fix(0));
t14=C_set_block_item(lf[339] /* perm/isgid */,0,C_fix(0));
t15=C_set_block_item(lf[340] /* perm/isuid */,0,C_fix(0));
t16=C_set_block_item(lf[341] /* perm/isvtx */,0,C_fix(0));
t17=C_set_block_item(lf[342] /* prot/exec */,0,C_fix(0));
t18=C_set_block_item(lf[343] /* prot/none */,0,C_fix(0));
t19=C_set_block_item(lf[344] /* prot/read */,0,C_fix(0));
t20=C_set_block_item(lf[345] /* prot/write */,0,C_fix(0));
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k6429 in k6426 in k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k6429 in k6426 in k6423 in k6420 in k6417 in k6414 in k6411 in k6408 in k6405 in k6402 in k6399 in k6396 in k6393 in k6390 in k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6324 in k6321 in k6318 in k6315 in k6312 in k6309 in k6306 in k6303 in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6084r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6084r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6084r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li153),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6225,a[2]=t5,a[3]=((C_word)li154),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6230,a[2]=t6,a[3]=((C_word)li155),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6235,a[2]=t7,a[3]=((C_word)li157),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action18801965 */
t9=t8;
f_6235(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id18811961 */
t11=t7;
f_6230(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit18821956 */
t13=t6;
f_6225(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body18781888 */
t15=t5;
f_6086(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action1880 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_6235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6235,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6241,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp);
/* def-id18811961 */
t3=((C_word*)t0)[2];
f_6230(t3,t1,t2);}

/* a6240 in def-action1880 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6241,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1881 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_6230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6230,NULL,3,t0,t1,t2);}
/* def-limit18821956 */
t3=((C_word*)t0)[2];
f_6225(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1882 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_6225(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6225,NULL,4,t0,t1,t2,t3);}
/* body18781888 */
t4=((C_word*)t0)[2];
f_6086(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_6086(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6086,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[320]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6093(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t4,a[3]=t7,a[4]=((C_word)li151),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6093(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6212,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));}}

/* f_6212 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6220 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6220,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_6093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6093,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6200,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2051 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[326]);}

/* k6198 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2051 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6103,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6105,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li150),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6105(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_6105(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6105,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6124,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2057 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6124,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2058 pathname-file */
t3=*((C_word*)lf[325]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6186,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2064 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k6184 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6186,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2064 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2065 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6105(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6191 in k6184 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2064 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6105(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6180,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[321]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[322]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2058 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_6105(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2059 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6139,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6151,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li147),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li148),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6170,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li149),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[324]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2063 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_6105(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a6169 in k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6170,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a6155 in k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6164,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6168,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2062 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[323]);}

/* k6166 in a6155 in k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2062 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6162 in a6155 in k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2062 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6105(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6150 in k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6151,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k6147 in k6137 in k6178 in k6122 in loop in k6101 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2060 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6105(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6204 in k6091 in body1878 in find-files in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6204,3,t0,t1,t2);}
/* posixwin.scm: 2049 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6069,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6079,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2025 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6077 in current-user-name in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2026 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[114],lf[319]);}

/* system-information in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6064,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2016 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6062 in system-information in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2017 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[316],lf[318]);}

/* k6047 in system-information in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6053,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k6051 in k6047 in system-information in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6057,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k6055 in k6051 in k6047 in system-information in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6061,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k6059 in k6055 in k6051 in k6047 in system-information in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6061,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[317],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6026,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2006 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[314],lf[315]);}}

/* sleep in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6023,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_5963r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5963r(t0,t1,t2,t3);}}

static void C_ccall f_5963r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[311]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5984,a[2]=t5,a[3]=t2,a[4]=((C_word)li139),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5990,a[2]=t2,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[0],t7);}}

/* a5989 in process-wait in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5990,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6000,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1988 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1990 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5998 in a5989 in process-wait in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1989 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[304],lf[311],lf[312],((C_word*)t0)[2]);}

/* a5983 in process-wait in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
/* posixwin.scm: 1985 ##sys#process-wait */
t2=*((C_word*)lf[310]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5951,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1978 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1979 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5871r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5871r(t0,t1,t2,t3);}}

static void C_ccall f_5871r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5873,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li133),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=t4,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5883,a[2]=t5,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5888,a[2]=t6,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17731796 */
t8=t7;
f_5888(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17741792 */
t10=t6;
f_5883(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17751787 */
t12=t5;
f_5878(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17711781 */
t14=t4;
f_5873(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-args1773 in process* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5888,NULL,2,t0,t1);}
/* def-env17741792 */
t2=((C_word*)t0)[2];
f_5883(t2,t1,C_SCHEME_FALSE);}

/* def-env1774 in process* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5883(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5883,NULL,3,t0,t1,t2);}
/* def-exactf17751787 */
t3=((C_word*)t0)[2];
f_5878(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1775 in process* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5878,NULL,4,t0,t1,t2,t3);}
/* body17711781 */
t4=((C_word*)t0)[2];
f_5873(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1771 in process* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5873(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5873,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1972 %process */
f_5729(t1,lf[309],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_5791r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5791r(t0,t1,t2,t3);}}

static void C_ccall f_5791r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5793,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li128),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5798,a[2]=t4,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=t5,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5808,a[2]=t6,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args17181741 */
t8=t7;
f_5808(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env17191737 */
t10=t6;
f_5803(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf17201732 */
t12=t5;
f_5798(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body17161726 */
t14=t4;
f_5793(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-args1718 in process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5808,NULL,2,t0,t1);}
/* def-env17191737 */
t2=((C_word*)t0)[2];
f_5803(t2,t1,C_SCHEME_FALSE);}

/* def-env1719 in process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5803,NULL,3,t0,t1,t2);}
/* def-exactf17201732 */
t3=((C_word*)t0)[2];
f_5798(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1720 in process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5798(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5798,NULL,4,t0,t1,t2,t3);}
/* body17161726 */
t4=((C_word*)t0)[2];
f_5793(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1716 in process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5793(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5793,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1969 %process */
f_5729(t1,lf[308],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5729(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5729,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5731,a[2]=t2,a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5750,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1957 chkstrlst */
t14=t11;
f_5731(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5785,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1960 ##sys#shell-command-arguments */
t16=*((C_word*)lf[300]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,((C_word*)t8)[1]);}}

/* k5783 in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5785,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1961 ##sys#shell-command */
t4=*((C_word*)lf[296]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5787 in k5783 in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5750(2,t3,t2);}

/* k5748 in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1962 chkstrlst */
t3=((C_word*)t0)[2];
f_5731(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_5753(2,t3,C_SCHEME_UNDEFINED);}}

/* k5751 in k5748 in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5758,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li125),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5764,a[2]=((C_word*)t0)[4],a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5763 in k5751 in k5748 in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5764,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1965 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1966 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5757 in k5751 in k5748 in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5758,2,t0,t1);}
/* posixwin.scm: 1963 ##sys#process */
t2=*((C_word*)lf[303]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5731(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5731,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[2],a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5739 in chkstrlst in %process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5740,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_5610r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_5610r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_5610r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5614,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_5614(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_5614(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[0],t9);}}}

/* k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5705,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1929 $quote-args-list */
t5=lf[285];
f_5100(t5,t3,t4,t1);}

/* k5703 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1929 string-intersperse */
t2=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(t2))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(t5))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(t8))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(t11))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t15=*((C_word*)lf[306]+1);
((C_proc6)C_retrieve_proc(t15))(6,t15,t14,t2,C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[306]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[306]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[306]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[307]);}

/* k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1936 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5689,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5552,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5552(2,t9,C_SCHEME_FALSE);}}

/* k5550 in k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5556(2,t3,C_SCHEME_FALSE);}}

/* k5554 in k5550 in k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub1540(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1939 open-input-file* */
t8=*((C_word*)lf[235]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_5646(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1944 ##sys#update-errno */
t8=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5664 in k5554 in k5550 in k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1945 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[304],((C_word*)t0)[3],lf[305],((C_word*)t0)[2]);}

/* k5644 in k5554 in k5550 in k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5650,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1940 open-output-file* */
t3=*((C_word*)lf[236]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5650(2,t3,C_SCHEME_FALSE);}}

/* k5648 in k5644 in k5554 in k5550 in k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5654,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1942 open-input-file* */
t3=*((C_word*)lf[235]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_5654(2,t3,C_SCHEME_FALSE);}}

/* k5652 in k5648 in k5644 in k5554 in k5550 in k5687 in k5683 in k5679 in k5675 in k5671 in k5615 in k5612 in ##sys#process in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1938 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* process-run in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5515r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5515r(t0,t1,t2,t3);}}

static void C_ccall f_5515r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1897 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[281]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5532,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1898 ##sys#shell-command */
t7=*((C_word*)lf[296]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k5530 in process-run in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5536,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1898 ##sys#shell-command-arguments */
t3=*((C_word*)lf[300]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5534 in k5530 in process-run in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1898 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[281]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5509,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[301],t2));}

/* ##sys#shell-command in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1881 getenv */
t3=*((C_word*)lf[298]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[299]);}

/* k5490 in ##sys#shell-command in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1885 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k5502 in k5490 in ##sys#shell-command in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1886 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[296],lf[297]);}

/* current-process-id in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5485,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1494(C_SCHEME_UNDEFINED));}

/* process-spawn in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_5398r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5398r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5398r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5400,a[2]=t3,a[3]=t2,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5412,a[2]=t5,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t6,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5422,a[2]=t7,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst14551480 */
t9=t8;
f_5422(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst14561476 */
t11=t7;
f_5417(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf14571471 */
t13=t6;
f_5412(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body14531463 */
t15=t5;
f_5400(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-arglst1455 in process-spawn in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5422,NULL,2,t0,t1);}
/* def-envlst14561476 */
t2=((C_word*)t0)[2];
f_5417(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1456 in process-spawn in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5417,NULL,3,t0,t1,t2);}
/* def-exactf14571471 */
t3=((C_word*)t0)[2];
f_5412(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1457 in process-spawn in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5412,NULL,4,t0,t1,t2,t3);}
/* body14531463 */
t4=((C_word*)t0)[2];
f_5400(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1453 in process-spawn in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5400(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5400,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1872 $exec-setup */
t6=lf[289];
f_5263(t6,t5,lf[293],((C_word*)t0)[2],t2,t3,t4);}

/* k5402 in body1453 in process-spawn in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1873 $exec-teardown */
f_5296(((C_word*)t0)[3],lf[293],lf[294],((C_word*)t0)[2],t2);}

/* process-execute in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_5311r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5311r(t0,t1,t2,t3);}}

static void C_ccall f_5311r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5313,a[2]=t2,a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5325,a[2]=t4,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5330,a[2]=t5,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst13951420 */
t8=t7;
f_5335(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst13961416 */
t10=t6;
f_5330(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf13971411 */
t12=t5;
f_5325(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body13931403 */
t14=t4;
f_5313(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-arglst1395 in process-execute in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5335,NULL,2,t0,t1);}
/* def-envlst13961416 */
t2=((C_word*)t0)[2];
f_5330(t2,t1,C_SCHEME_FALSE);}

/* def-envlst1396 in process-execute in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5330,NULL,3,t0,t1,t2);}
/* def-exactf13971411 */
t3=((C_word*)t0)[2];
f_5325(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1397 in process-execute in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5325(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5325,NULL,4,t0,t1,t2,t3);}
/* body13931403 */
t4=((C_word*)t0)[2];
f_5313(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1393 in process-execute in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5313(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5313,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5317,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1867 $exec-setup */
t6=lf[289];
f_5263(t6,t5,lf[291],((C_word*)t0)[2],t2,t3,t4);}

/* k5315 in body1393 in process-execute in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1868 $exec-teardown */
f_5296(((C_word*)t0)[3],lf[291],lf[292],((C_word*)t0)[2],t2);}

/* $exec-teardown in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5296(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5296,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5300,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1859 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5298 in $exec-teardown in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1863 ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5263(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5263,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5270,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1851 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k5268 in $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1852 setarg */
t4=((C_word*)t0)[4];
f_5179(5,t4,t2,C_fix(0),t1,t3);}

/* k5271 in k5268 in $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5276,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1853 $quote-args-list */
t4=lf[285];
f_5100(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5288 in k5271 in k5268 in $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1853 build-exec-argvec */
f_5213(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k5274 in k5271 in k5268 in $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1854 build-exec-argvec */
f_5213(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k5277 in k5274 in k5271 in k5268 in $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1856 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5284 in k5277 in k5274 in k5271 in k5268 in $exec-setup in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1856 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5213(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5213,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5225,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5225(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1848 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop1333 in build-exec-argvec in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5225(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5225,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1844 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5244,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1847 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k5242 in doloop1333 in build-exec-argvec in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5225(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5196,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1319(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5179,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub1307(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5100(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5100,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li99),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5143,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5143(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5143(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5143,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1825 reverse */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5171,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5174,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1830 needs-quoting? */
t8=((C_word*)t0)[2];
f_5105(t8,t7,t4);}}

/* k5172 in loop in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1830 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[286],((C_word*)t0)[2],lf[287]);}
else{
t2=((C_word*)t0)[3];
f_5171(2,t2,((C_word*)t0)[2]);}}

/* k5169 in loop in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5171,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1827 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5143(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5105(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5105,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5109,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1817 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5107 in needs-quoting? in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5109,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li98),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5114(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5107 in needs-quoting? in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5114(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5114,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1821 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k5136 in loop in k5107 in needs-quoting? in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1821 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5125 in loop in k5107 in needs-quoting? in $quote-args-list in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1822 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5114(t3,((C_word*)t0)[4],t2);}}

/* glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4985r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4985r(t0,t1,t2);}}

static void C_ccall f_4985r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li96),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_4991(t6,t1,t2);}

/* conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4991,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5006,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li95),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5012,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5089,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[278]);
/* posixwin.scm: 1778 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5087 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1778 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1779 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1780 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5020 in k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[277]);
/* posixwin.scm: 1781 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5027 in k5020 in k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li94),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5031(t5,((C_word*)t0)[2],t1);}

/* loop in k5027 in k5020 in k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_5031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5031,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1782 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4991(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1783 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5046 in loop in k5027 in k5020 in k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1784 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1785 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5031(t3,((C_word*)t0)[6],t2);}}

/* k5056 in k5046 in loop in k5027 in k5020 in k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1784 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5031(t4,t2,t3);}

/* k5060 in k5056 in k5046 in loop in k5027 in k5020 in k5017 in k5014 in a5011 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a5005 in conc-loop in glob in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
/* posixwin.scm: 1777 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4926r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4926r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4926r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4930,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1748 ##sys#check-port */
t6=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[264]);}

/* k4928 in set-buffering-mode! in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[266]);
if(C_truep(t6)){
t7=t5;
f_4936(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[267]);
if(C_truep(t7)){
t8=t5;
f_4936(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[268]);
if(C_truep(t8)){
t9=t5;
f_4936(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1754 ##sys#error */
t9=*((C_word*)lf[60]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[264],lf[269],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k4934 in k4928 in set-buffering-mode! in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[264]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[79],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1760 ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[264],lf[265],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* terminal-port? in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4920,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4924,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1738 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[263]);}

/* k4922 in terminal-port? in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4904r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4904r(t0,t1,t2);}}

static void C_ccall f_4904r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1142(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1134(t2),C_fix(0));}

/* local-time->seconds in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4864,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[257]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4871,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1720 ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[257],lf[260],t2);}
else{
t6=t4;
f_4871(2,t6,C_SCHEME_UNDEFINED);}}

/* k4869 in local-time->seconds in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1722 ##sys#cons-flonum */
t2=*((C_word*)lf[258]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1723 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[257],lf[259],((C_word*)t0)[3]);}}

/* time->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4784r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4784r(t0,t1,t2,t3);}}

static void C_ccall f_4784r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4788,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4788(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4788(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4786 in time->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4788,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[253]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixwin.scm: 1707 ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[253],lf[256],((C_word*)t0)[3]);}
else{
t5=t3;
f_4794(2,t5,C_SCHEME_UNDEFINED);}}

/* k4792 in k4786 in time->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4794,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[253]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1711 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1077(t4,t3),C_fix(0));}}

/* k4814 in k4792 in k4786 in time->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1715 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1716 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[253],lf[255],((C_word*)t0)[2]);}}

/* k4811 in k4792 in k4786 in time->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1085(t3,t2,t1),C_fix(0));}

/* k4801 in k4792 in k4786 in time->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1712 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[253],lf[254],((C_word*)t0)[2]);}}

/* seconds->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4751,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub1062(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4753 in seconds->string in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1699 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1700 ##sys#error */
t2=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[251],lf[252],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4732,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[250]);
/* posixwin.scm: 1692 ##sys#decode-seconds */
t4=*((C_word*)lf[249]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4723,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[248]);
/* posixwin.scm: 1688 ##sys#decode-seconds */
t4=*((C_word*)lf[249]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4663(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4663,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4667,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1026(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4665 in loop in get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4675,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li81),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4675(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4665 in loop in get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4675(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4675,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1678 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1679 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4699 in scan in k4665 in loop in get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1678 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k4703 in k4699 in scan in k4665 in loop in get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4693,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1678 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4663(t5,t3,t4);}

/* k4691 in k4703 in k4699 in scan in k4665 in loop in get-environment-variables in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4637,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[244]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4645,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1666 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4643 in unsetenv in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4620,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[243]);
t5=(C_word)C_i_check_string_2(t3,lf[243]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1661 ##sys#make-c-string */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4629 in setenv in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1661 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4633 in k4629 in setenv in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4590r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4590r(t0,t1,t2,t3);}}

static void C_ccall f_4590r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[241]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4597,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4597(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[241]);
t8=t5;
f_4597(t8,(C_word)C_dup2(t2,t6));}}

/* k4595 in duplicate-fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4597,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4600,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1650 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4600(2,t3,C_SCHEME_UNDEFINED);}}

/* k4604 in k4595 in duplicate-fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1651 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[241],lf[242],((C_word*)t0)[2]);}

/* k4598 in k4595 in duplicate-fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4555,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1632 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[237]);}

/* k4557 in port->fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1633 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[240]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4586 in k4557 in port->fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4588,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1639 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[44],lf[237],lf[238],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1636 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4568(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4572 in k4586 in k4557 in port->fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1637 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[237],lf[239],((C_word*)t0)[2]);}

/* k4566 in k4586 in k4557 in port->fileno in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4541r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4541r(t0,t1,t2,t3);}}

static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4553,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1628 mode */
f_4472(t5,C_SCHEME_FALSE,t3);}

/* k4551 in open-output-file* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1628 check */
f_4509(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4527r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4527r(t0,t1,t2,t3);}}

static void C_ccall f_4527r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[235]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4539,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1624 mode */
f_4472(t5,C_SCHEME_TRUE,t3);}

/* k4537 in open-input-file* in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1624 check */
f_4509(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4509(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4509,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4513,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1615 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4511 in check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1617 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[233],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1618 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[234],lf[79]);}}

/* k4523 in k4511 in check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4472(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4472,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4480,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[227]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1610 ##sys#error */
t8=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[228],t5);}
else{
t8=t4;
f_4480(2,t8,lf[229]);}}
else{
/* posixwin.scm: 1611 ##sys#error */
t7=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[230],t5);}}
else{
t5=t4;
f_4480(2,t5,(C_truep(t2)?lf[231]:lf[232]));}}

/* k4478 in mode in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1606 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4463,3,t0,t1,t2);}
/* posixwin.scm: 1590 check */
f_4427(t1,t2,C_fix((C_word)2),lf[223]);}

/* file-write-access? in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4457,3,t0,t1,t2);}
/* posixwin.scm: 1589 check */
f_4427(t1,t2,C_fix((C_word)4),lf[222]);}

/* file-read-access? in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4451,3,t0,t1,t2);}
/* posixwin.scm: 1588 check */
f_4427(t1,t2,C_fix((C_word)2),lf[221]);}

/* check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4427(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4427,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4445,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4449,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1585 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k4447 in check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1585 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4443 in check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4437(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1586 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4435 in k4443 in check in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4397,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[219]);
t5=(C_word)C_i_check_exact_2(t3,lf[219]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4421,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4425,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1574 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k4423 in change-file-mode in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1574 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4419 in change-file-mode in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1575 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4411 in k4419 in change-file-mode in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1576 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[219],lf[220],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4341,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4351,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1482 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1484 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4349 in ##sys#interrupt-hook in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1483 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4328,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[180]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k4315 in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4319,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[179]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4243r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4243r(t0,t1,t2);}}

static void C_ccall f_4243r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4247(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[19]+1),*((C_word*)lf[21]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4247(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4245 in create-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4259,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1419 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4250(2,t3,C_SCHEME_UNDEFINED);}}

/* k4257 in k4245 in create-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1420 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[35],lf[149],lf[150]);}

/* k4248 in k4245 in create-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1421 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4223r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4223r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[148]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4227,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4225 in with-output-to-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4227,2,t0,t1);}
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4233,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1404 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4232 in k4225 in with-output-to-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4233r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4233r(t0,t1,t2);}}

static void C_ccall f_4233r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1406 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4235 in a4232 in k4225 in with-output-to-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[148]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4203r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4203r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[146]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4207,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4205 in with-input-from-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4213,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1394 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4212 in k4205 in with-input-from-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4213r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4213r(t0,t1,t2);}}

static void C_ccall f_4213r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4217,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1396 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4215 in a4212 in k4205 in with-input-from-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[146]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4179r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4179r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4179r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4183,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4181 in call-with-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1384 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4193 in k4181 in call-with-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4194r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4194r(t0,t1,t2);}}

static void C_ccall f_4194r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1387 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4196 in a4193 in k4181 in call-with-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4187 in k4181 in call-with-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
/* posixwin.scm: 1385 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4155r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4155r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4155r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4159,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4157 in call-with-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4170,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1376 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4169 in k4157 in call-with-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4170r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4170r(t0,t1,t2);}}

static void C_ccall f_4170r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4174,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1379 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4172 in a4169 in k4157 in call-with-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4163 in k4157 in call-with-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
/* posixwin.scm: 1377 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4136,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4140,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1363 ##sys#check-port */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[139]);}

/* k4138 in close-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1365 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4141 in k4138 in close-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1366 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[35],lf[139],lf[140],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4100r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4100r(t0,t1,t2,t3);}}

static void C_ccall f_4100r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[138]);
t5=f_4028(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4114,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[130]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1358 ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4131,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1359 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1360 badmode */
f_4040(t6,t5);}}}

/* k4129 in open-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4114(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4119 in open-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4121,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4114(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4112 in open-output-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1355 check */
f_4046(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4064r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4064r(t0,t1,t2,t3);}}

static void C_ccall f_4064r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[136]);
t5=f_4028(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4078,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[130]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4085,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1348 ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1349 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1350 badmode */
f_4040(t6,t5);}}}

/* k4093 in open-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4078(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4083 in open-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4078(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4076 in open-input-pipe in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1345 check */
f_4046(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4046(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4046,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4050,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1335 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4048 in check in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1337 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[132],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1338 ##sys#make-port */
t3=*((C_word*)lf[133]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[134]+1),lf[135],lf[79]);}}

/* k4060 in k4048 in check in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_4040(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4040,NULL,2,t1,t2);}
/* posixwin.scm: 1333 ##sys#error */
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[131],t2);}

/* mode in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static C_word C_fcall f_4028(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[130]));}

/* canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3671,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3678,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1272 cwd */
t8=((C_word*)t0)[5];
f_3615(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1274 sref */
t10=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3817(t9,C_SCHEME_FALSE);}}}

/* k4016 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1274 sep? */
t2=((C_word*)t0)[3];
f_3817(t2,f_3604(t1));}

/* k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3828,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1276 cwd */
t4=((C_word*)t0)[7];
f_3615(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1279 cwd */
t5=((C_word*)t0)[7];
f_3615(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4004,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1280 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k4002 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1280 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3991 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1281 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3847(t2,C_SCHEME_FALSE);}}

/* k3998 in k3991 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1281 sep? */
t2=((C_word*)t0)[3];
f_3847(t2,f_3604(t1));}

/* k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3847,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1283 cwd */
t4=((C_word*)t0)[6];
f_3615(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1289 cwd */
t5=((C_word*)t0)[6];
f_3615(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1290 sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3984 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3963 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3982,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1291 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_3889(t2,C_SCHEME_FALSE);}}

/* k3980 in k3963 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1291 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3969 in k3963 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1292 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_3889(t2,C_SCHEME_FALSE);}}

/* k3976 in k3969 in k3963 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1292 sep? */
t2=((C_word*)t0)[3];
f_3889(t2,f_3604(t1));}

/* k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_3678(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3962,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1294 sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3960 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1294 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3939 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3958,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1295 sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3895(2,t2,C_SCHEME_FALSE);}}

/* k3956 in k3939 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1295 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3945 in k3939 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1296 sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3895(2,t2,C_SCHEME_FALSE);}}

/* k3952 in k3945 in k3939 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1296 char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1298 ##sys#substring */
t3=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1302 sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k3936 in k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=f_3604(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3927,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1304 cwd */
t5=((C_word*)t0)[2];
f_3615(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1307 cwd */
t4=((C_word*)t0)[2];
f_3615(t4,t3);}}

/* k3932 in k3936 in k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1307 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[129],((C_word*)t0)[2]);}

/* k3925 in k3936 in k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3921 in k3936 in k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3900 in k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3906,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1300 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3904 in k3900 in k3893 in k3887 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k3881 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1289 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[127],((C_word*)t0)[2]);}

/* k3868 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1283 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3852 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1285 user */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3856 in k3852 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3862,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1286 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3860 in k3856 in k3852 in k3845 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1282 sappend */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[126],((C_word*)t0)[2],t1);}

/* k3839 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1279 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[125],((C_word*)t0)[2]);}

/* k3826 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1276 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3822 in k3815 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3809 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1272 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[124]);}

/* k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3797,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1308 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t1,C_fix(3),t4);}

/* k3795 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
t2=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[123]);}

/* k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3687,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3687(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3687(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3687,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1310 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1311 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3766,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1322 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[122],t5);}}

/* k3767 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3766(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1324 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[121],t3);}}

/* k3776 in k3767 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3778,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3766(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_3766(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k3764 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1320 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3687(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1312 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1313 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=f_3604(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1315 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1318 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k3733 in k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3743,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1319 reverse */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3741 in k3733 in k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1319 isperse */
f_3599(((C_word*)t0)[2],t1);}

/* k3737 in k3733 in k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1317 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3714 in k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3720,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3724,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[119],((C_word*)t0)[2]);
/* posixwin.scm: 1316 reverse */
t5=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3722 in k3714 in k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1316 isperse */
f_3599(((C_word*)t0)[2],t1);}

/* k3718 in k3714 in k3745 in k3698 in k3692 in loop in k3683 in k3676 in canonical-path in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1314 sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3615,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3630,a[2]=t2,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3648,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[117]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3647 in a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3654,a[2]=((C_word*)t0)[3],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3659 in a3647 in a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3660r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3660r(t0,t1,t2);}}

static void C_ccall f_3660r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3666,a[2]=t2,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* k572578 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3665 in a3659 in a3647 in a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3653 in a3647 in a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
/* posixwin.scm: 1267 cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3629 in a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3630,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3636,a[2]=t2,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* k572578 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3635 in a3629 in a3623 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3636,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[115]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[116]);}

/* k3620 in cwd in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static C_word C_fcall f_3604(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3599(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3599,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[112]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[113]);}

/* current-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3548r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3548r(t0,t1,t2);}}

static void C_ccall f_3548r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3552(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3552(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3550 in current-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1245 change-directory */
t2=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1246 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3559 in k3550 in current-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3564,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1248 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3562 in k3559 in k3550 in current-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1250 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1251 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[103],lf[106]);}}

/* directory? in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3521,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3542,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1238 ##sys#expand-home-path */
t7=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k3544 in directory? in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1238 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[105]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3540 in directory? in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1237 ##sys#file-info */
t2=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3526 in directory? in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_3361r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3361r(t0,t1,t2);}}

static void C_ccall f_3361r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=t3,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=t4,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec419477 */
t6=t5;
f_3469(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?420473 */
t8=t4;
f_3464(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body417426 */
t10=t3;
f_3363(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec419 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3469,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1208 current-directory */
t3=*((C_word*)lf[103]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3475 in def-spec419 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?420473 */
t2=((C_word*)t0)[3];
f_3464(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?420 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3464,NULL,3,t0,t1,t2);}
/* body417426 */
t3=((C_word*)t0)[2];
f_3363(t3,t1,t2,C_SCHEME_FALSE);}

/* body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3363(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3363,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[100]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3370,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1210 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1211 ##sys#make-pointer */
t3=*((C_word*)lf[102]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1212 ##sys#make-pointer */
t3=*((C_word*)lf[102]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3463,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1213 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3461 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1213 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3378 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1216 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li29),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3397(t6,((C_word*)t0)[6]);}}

/* loop in k3378 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3397,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1225 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k3405 in loop in k3378 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3419,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_3419(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_3419(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_3419(t7,C_SCHEME_FALSE);}}

/* k3417 in k3405 in loop in k3378 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3419,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1232 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3397(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1233 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3397(t3,t2);}}

/* k3427 in k3417 in k3405 in loop in k3378 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3387 in k3378 in k3374 in k3371 in k3368 in body417 in directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1217 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[100],lf[101],((C_word*)t0)[2]);}

/* delete-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3334,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3355,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1200 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3357 in delete-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1200 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3353 in delete-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1201 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3345 in k3353 in delete-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1202 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[97],lf[98],((C_word*)t0)[2]);}

/* change-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3307,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[95]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3332,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1193 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3330 in change-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1193 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3326 in change-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3328,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1194 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3318 in k3326 in change-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1195 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[95],lf[96],((C_word*)t0)[2]);}

/* create-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3167r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3167r(t0,t1,t2,t3);}}

static void C_ccall f_3167r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3171,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3171(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3171(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3169 in create-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[87]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1181 canonical-path */
t4=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1182 canonical-path */
t4=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}

/* k3265 in k3169 in create-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3268 in k3265 in k3169 in create-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3268,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3286,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1152 ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3284 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3286,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3276 in k3284 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1154 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[87],lf[88],((C_word*)t0)[2]);}

/* k3182 in k3169 in create-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3185,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3185 in k3182 in k3169 in create-directory in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3185,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3189,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1169 string-split */
t4=*((C_word*)lf[92]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[93]);}

/* k3187 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=t4,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t1);
/* for-each */
t7=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a3196 in k3187 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3197,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3202,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1173 string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[90],t2);}

/* k3200 in a3196 in k3187 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3206,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_3206 in k3200 in a3196 in k3187 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3206,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3213,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3236 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3243,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1158 file-exists? */
t4=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3241 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1159 ##sys#file-info */
t3=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3244 in k3241 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3211 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3213,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_3217 in k3211 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1152 ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3233 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1153 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3225 in k3233 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1154 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[87],lf[88],((C_word*)t0)[2]);}

/* set-file-position! in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3106r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3106r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3106r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[82]);
t8=(C_word)C_i_check_exact_2(t6,lf[82]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3119,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1139 ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[85],lf[82],lf[86],t3,t2);}
else{
t10=t9;
f_3119(2,t10,C_SCHEME_UNDEFINED);}}

/* k3117 in set-file-position! in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1140 port? */
t4=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k3132 in k3117 in set-file-position! in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[79]);
t4=((C_word*)t0)[4];
f_3125(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_3125(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1144 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[44],lf[82],lf[84],((C_word*)t0)[5]);}}}

/* k3123 in k3117 in set-file-position! in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1145 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3126 in k3123 in k3117 in set-file-position! in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1146 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[82],lf[83],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3066,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3085,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1123 port? */
t5=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3083 in file-position in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[79]);
t4=((C_word*)t0)[2];
f_3070(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_3070(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1128 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[44],lf[77],lf[80],((C_word*)t0)[3]);}}}

/* k3068 in file-position in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1130 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3073(2,t3,C_SCHEME_UNDEFINED);}}

/* k3077 in k3068 in file-position in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1131 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[77],lf[78],((C_word*)t0)[2]);}

/* k3071 in k3068 in file-position in k3062 in k3058 in k3054 in k3050 in k3046 in k3042 in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_3033(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3033,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));}

/* f_3035 in stat-type in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3035,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3028,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3005,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[67]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3026,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1101 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3024 in regular-file? in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1101 ##sys#file-info */
t2=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3010 in regular-file? in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2999,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3003,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_2900(t3,t2);}

/* k3001 in file-permissions in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2993,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2900(t3,t2);}

/* k2995 in file-owner in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2987,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_2900(t3,t2);}

/* k2989 in file-change-time in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2981,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_2900(t3,t2);}

/* k2983 in file-access-time in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1093 ##sys#stat */
f_2900(t3,t2);}

/* k2977 in file-modification-time in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2969,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2973,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1092 ##sys#stat */
f_2900(t3,t2);}

/* k2971 in file-size in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2938r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2938r(t0,t1,t2,t3);}}

static void C_ccall f_2938r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2942(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2942(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2940 in file-stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1086 ##sys#stat */
f_2900(t2,((C_word*)t0)[2]);}

/* k2943 in k2940 in file-stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_fcall f_2900(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2900,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2904,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2904(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2929,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1079 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1080 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[44],lf[58],t2);}}}

/* k2931 in ##sys#stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1079 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2927 in ##sys#stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2904(2,t2,(C_word)C_stat(t1));}

/* k2902 in ##sys#stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1082 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2911 in k2902 in ##sys#stat in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1083 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[57],((C_word*)t0)[2]);}

/* file-mkstemp in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2862,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[50]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1048 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2867 in file-mkstemp in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1050 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k2870 in k2867 in file-mkstemp in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1052 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2875(2,t4,C_SCHEME_UNDEFINED);}}

/* k2890 in k2870 in k2867 in file-mkstemp in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1053 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[50],lf[52],((C_word*)t0)[2]);}

/* k2873 in k2870 in k2867 in file-mkstemp in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1054 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2880 in k2873 in k2870 in k2867 in file-mkstemp in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1054 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2820r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2820r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2820r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[46]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_2827(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1035 ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[44],lf[46],lf[48],t3);}}

/* k2825 in file-write in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[46]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1040 ##sys#update-errno */
t9=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2836(2,t8,C_SCHEME_UNDEFINED);}}

/* k2840 in k2825 in file-write in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1041 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[46],lf[47],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2834 in k2825 in file-write in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2775r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2775r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2775r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[42]);
t6=(C_word)C_i_check_exact_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2785,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2785(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1022 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2783 in file-read in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2788(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1024 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[44],lf[42],lf[45],t1);}}

/* k2786 in k2783 in file-read in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1027 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2791(2,t5,C_SCHEME_UNDEFINED);}}

/* k2798 in k2786 in k2783 in file-read in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1028 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[42],lf[43],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2789 in k2786 in k2783 in file-read in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2757,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[39]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1014 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2768 in file-close in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1015 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[39],lf[40],((C_word*)t0)[2]);}

/* file-open in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2716r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2716r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2716r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[34]);
t8=(C_word)C_i_check_exact_2(t3,lf[34]);
t9=(C_word)C_i_check_exact_2(t6,lf[34]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1004 ##sys#expand-home-path */
t12=*((C_word*)lf[38]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k2747 in file-open in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1004 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2731 in file-open in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2736,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1006 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_2736(2,t5,C_SCHEME_UNDEFINED);}}

/* k2740 in k2731 in file-open in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1007 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[35],lf[34],lf[36],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2734 in k2731 in file-open in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2670r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2670r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2670r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2674,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 935  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2672 in posix-error in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2683 in k2672 in posix-error in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 936  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k2679 in k2672 in posix-error in k2656 in k2653 in k2650 in k2647 in k2644 in k2641 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[507] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_2643posixwin.scm",(void*)f_2643},
{"f_2646posixwin.scm",(void*)f_2646},
{"f_2649posixwin.scm",(void*)f_2649},
{"f_2652posixwin.scm",(void*)f_2652},
{"f_2655posixwin.scm",(void*)f_2655},
{"f_2658posixwin.scm",(void*)f_2658},
{"f_3044posixwin.scm",(void*)f_3044},
{"f_3048posixwin.scm",(void*)f_3048},
{"f_3052posixwin.scm",(void*)f_3052},
{"f_3056posixwin.scm",(void*)f_3056},
{"f_3060posixwin.scm",(void*)f_3060},
{"f_3064posixwin.scm",(void*)f_3064},
{"f_4317posixwin.scm",(void*)f_4317},
{"f_6875posixwin.scm",(void*)f_6875},
{"f_6305posixwin.scm",(void*)f_6305},
{"f_6865posixwin.scm",(void*)f_6865},
{"f_6308posixwin.scm",(void*)f_6308},
{"f_6855posixwin.scm",(void*)f_6855},
{"f_6311posixwin.scm",(void*)f_6311},
{"f_6845posixwin.scm",(void*)f_6845},
{"f_6314posixwin.scm",(void*)f_6314},
{"f_6835posixwin.scm",(void*)f_6835},
{"f_6317posixwin.scm",(void*)f_6317},
{"f_6825posixwin.scm",(void*)f_6825},
{"f_6320posixwin.scm",(void*)f_6320},
{"f_6815posixwin.scm",(void*)f_6815},
{"f_6323posixwin.scm",(void*)f_6323},
{"f_6805posixwin.scm",(void*)f_6805},
{"f_6326posixwin.scm",(void*)f_6326},
{"f_6795posixwin.scm",(void*)f_6795},
{"f_6329posixwin.scm",(void*)f_6329},
{"f_6785posixwin.scm",(void*)f_6785},
{"f_6332posixwin.scm",(void*)f_6332},
{"f_6775posixwin.scm",(void*)f_6775},
{"f_6335posixwin.scm",(void*)f_6335},
{"f_6765posixwin.scm",(void*)f_6765},
{"f_6338posixwin.scm",(void*)f_6338},
{"f_6755posixwin.scm",(void*)f_6755},
{"f_6341posixwin.scm",(void*)f_6341},
{"f_6745posixwin.scm",(void*)f_6745},
{"f_6344posixwin.scm",(void*)f_6344},
{"f_6735posixwin.scm",(void*)f_6735},
{"f_6347posixwin.scm",(void*)f_6347},
{"f_6725posixwin.scm",(void*)f_6725},
{"f_6350posixwin.scm",(void*)f_6350},
{"f_6715posixwin.scm",(void*)f_6715},
{"f_6353posixwin.scm",(void*)f_6353},
{"f_6705posixwin.scm",(void*)f_6705},
{"f_6356posixwin.scm",(void*)f_6356},
{"f_6695posixwin.scm",(void*)f_6695},
{"f_6359posixwin.scm",(void*)f_6359},
{"f_6685posixwin.scm",(void*)f_6685},
{"f_6362posixwin.scm",(void*)f_6362},
{"f_6675posixwin.scm",(void*)f_6675},
{"f_6365posixwin.scm",(void*)f_6365},
{"f_6665posixwin.scm",(void*)f_6665},
{"f_6368posixwin.scm",(void*)f_6368},
{"f_6655posixwin.scm",(void*)f_6655},
{"f_6371posixwin.scm",(void*)f_6371},
{"f_6645posixwin.scm",(void*)f_6645},
{"f_6374posixwin.scm",(void*)f_6374},
{"f_6635posixwin.scm",(void*)f_6635},
{"f_6377posixwin.scm",(void*)f_6377},
{"f_6625posixwin.scm",(void*)f_6625},
{"f_6380posixwin.scm",(void*)f_6380},
{"f_6615posixwin.scm",(void*)f_6615},
{"f_6383posixwin.scm",(void*)f_6383},
{"f_6605posixwin.scm",(void*)f_6605},
{"f_6386posixwin.scm",(void*)f_6386},
{"f_6595posixwin.scm",(void*)f_6595},
{"f_6389posixwin.scm",(void*)f_6389},
{"f_6585posixwin.scm",(void*)f_6585},
{"f_6392posixwin.scm",(void*)f_6392},
{"f_6575posixwin.scm",(void*)f_6575},
{"f_6395posixwin.scm",(void*)f_6395},
{"f_6565posixwin.scm",(void*)f_6565},
{"f_6398posixwin.scm",(void*)f_6398},
{"f_6555posixwin.scm",(void*)f_6555},
{"f_6401posixwin.scm",(void*)f_6401},
{"f_6545posixwin.scm",(void*)f_6545},
{"f_6404posixwin.scm",(void*)f_6404},
{"f_6535posixwin.scm",(void*)f_6535},
{"f_6407posixwin.scm",(void*)f_6407},
{"f_6525posixwin.scm",(void*)f_6525},
{"f_6410posixwin.scm",(void*)f_6410},
{"f_6515posixwin.scm",(void*)f_6515},
{"f_6413posixwin.scm",(void*)f_6413},
{"f_6505posixwin.scm",(void*)f_6505},
{"f_6416posixwin.scm",(void*)f_6416},
{"f_6495posixwin.scm",(void*)f_6495},
{"f_6419posixwin.scm",(void*)f_6419},
{"f_6485posixwin.scm",(void*)f_6485},
{"f_6422posixwin.scm",(void*)f_6422},
{"f_6475posixwin.scm",(void*)f_6475},
{"f_6425posixwin.scm",(void*)f_6425},
{"f_6465posixwin.scm",(void*)f_6465},
{"f_6428posixwin.scm",(void*)f_6428},
{"f_6455posixwin.scm",(void*)f_6455},
{"f_6431posixwin.scm",(void*)f_6431},
{"f_6437posixwin.scm",(void*)f_6437},
{"f_6434posixwin.scm",(void*)f_6434},
{"f_6084posixwin.scm",(void*)f_6084},
{"f_6235posixwin.scm",(void*)f_6235},
{"f_6241posixwin.scm",(void*)f_6241},
{"f_6230posixwin.scm",(void*)f_6230},
{"f_6225posixwin.scm",(void*)f_6225},
{"f_6086posixwin.scm",(void*)f_6086},
{"f_6212posixwin.scm",(void*)f_6212},
{"f_6220posixwin.scm",(void*)f_6220},
{"f_6093posixwin.scm",(void*)f_6093},
{"f_6200posixwin.scm",(void*)f_6200},
{"f_6103posixwin.scm",(void*)f_6103},
{"f_6105posixwin.scm",(void*)f_6105},
{"f_6124posixwin.scm",(void*)f_6124},
{"f_6186posixwin.scm",(void*)f_6186},
{"f_6193posixwin.scm",(void*)f_6193},
{"f_6180posixwin.scm",(void*)f_6180},
{"f_6139posixwin.scm",(void*)f_6139},
{"f_6170posixwin.scm",(void*)f_6170},
{"f_6156posixwin.scm",(void*)f_6156},
{"f_6168posixwin.scm",(void*)f_6168},
{"f_6164posixwin.scm",(void*)f_6164},
{"f_6151posixwin.scm",(void*)f_6151},
{"f_6149posixwin.scm",(void*)f_6149},
{"f_6204posixwin.scm",(void*)f_6204},
{"f_6069posixwin.scm",(void*)f_6069},
{"f_6079posixwin.scm",(void*)f_6079},
{"f_6038posixwin.scm",(void*)f_6038},
{"f_6064posixwin.scm",(void*)f_6064},
{"f_6049posixwin.scm",(void*)f_6049},
{"f_6053posixwin.scm",(void*)f_6053},
{"f_6057posixwin.scm",(void*)f_6057},
{"f_6061posixwin.scm",(void*)f_6061},
{"f_6026posixwin.scm",(void*)f_6026},
{"f_6023posixwin.scm",(void*)f_6023},
{"f_5963posixwin.scm",(void*)f_5963},
{"f_5990posixwin.scm",(void*)f_5990},
{"f_6000posixwin.scm",(void*)f_6000},
{"f_5984posixwin.scm",(void*)f_5984},
{"f_5951posixwin.scm",(void*)f_5951},
{"f_5871posixwin.scm",(void*)f_5871},
{"f_5888posixwin.scm",(void*)f_5888},
{"f_5883posixwin.scm",(void*)f_5883},
{"f_5878posixwin.scm",(void*)f_5878},
{"f_5873posixwin.scm",(void*)f_5873},
{"f_5791posixwin.scm",(void*)f_5791},
{"f_5808posixwin.scm",(void*)f_5808},
{"f_5803posixwin.scm",(void*)f_5803},
{"f_5798posixwin.scm",(void*)f_5798},
{"f_5793posixwin.scm",(void*)f_5793},
{"f_5729posixwin.scm",(void*)f_5729},
{"f_5785posixwin.scm",(void*)f_5785},
{"f_5789posixwin.scm",(void*)f_5789},
{"f_5750posixwin.scm",(void*)f_5750},
{"f_5753posixwin.scm",(void*)f_5753},
{"f_5764posixwin.scm",(void*)f_5764},
{"f_5758posixwin.scm",(void*)f_5758},
{"f_5731posixwin.scm",(void*)f_5731},
{"f_5740posixwin.scm",(void*)f_5740},
{"f_5610posixwin.scm",(void*)f_5610},
{"f_5614posixwin.scm",(void*)f_5614},
{"f_5705posixwin.scm",(void*)f_5705},
{"f_5617posixwin.scm",(void*)f_5617},
{"f_5673posixwin.scm",(void*)f_5673},
{"f_5677posixwin.scm",(void*)f_5677},
{"f_5681posixwin.scm",(void*)f_5681},
{"f_5685posixwin.scm",(void*)f_5685},
{"f_5689posixwin.scm",(void*)f_5689},
{"f_5552posixwin.scm",(void*)f_5552},
{"f_5556posixwin.scm",(void*)f_5556},
{"f_5666posixwin.scm",(void*)f_5666},
{"f_5646posixwin.scm",(void*)f_5646},
{"f_5650posixwin.scm",(void*)f_5650},
{"f_5654posixwin.scm",(void*)f_5654},
{"f_5515posixwin.scm",(void*)f_5515},
{"f_5532posixwin.scm",(void*)f_5532},
{"f_5536posixwin.scm",(void*)f_5536},
{"f_5509posixwin.scm",(void*)f_5509},
{"f_5488posixwin.scm",(void*)f_5488},
{"f_5492posixwin.scm",(void*)f_5492},
{"f_5504posixwin.scm",(void*)f_5504},
{"f_5485posixwin.scm",(void*)f_5485},
{"f_5398posixwin.scm",(void*)f_5398},
{"f_5422posixwin.scm",(void*)f_5422},
{"f_5417posixwin.scm",(void*)f_5417},
{"f_5412posixwin.scm",(void*)f_5412},
{"f_5400posixwin.scm",(void*)f_5400},
{"f_5404posixwin.scm",(void*)f_5404},
{"f_5311posixwin.scm",(void*)f_5311},
{"f_5335posixwin.scm",(void*)f_5335},
{"f_5330posixwin.scm",(void*)f_5330},
{"f_5325posixwin.scm",(void*)f_5325},
{"f_5313posixwin.scm",(void*)f_5313},
{"f_5317posixwin.scm",(void*)f_5317},
{"f_5296posixwin.scm",(void*)f_5296},
{"f_5300posixwin.scm",(void*)f_5300},
{"f_5263posixwin.scm",(void*)f_5263},
{"f_5270posixwin.scm",(void*)f_5270},
{"f_5273posixwin.scm",(void*)f_5273},
{"f_5290posixwin.scm",(void*)f_5290},
{"f_5276posixwin.scm",(void*)f_5276},
{"f_5279posixwin.scm",(void*)f_5279},
{"f_5286posixwin.scm",(void*)f_5286},
{"f_5213posixwin.scm",(void*)f_5213},
{"f_5225posixwin.scm",(void*)f_5225},
{"f_5244posixwin.scm",(void*)f_5244},
{"f_5196posixwin.scm",(void*)f_5196},
{"f_5179posixwin.scm",(void*)f_5179},
{"f_5100posixwin.scm",(void*)f_5100},
{"f_5143posixwin.scm",(void*)f_5143},
{"f_5174posixwin.scm",(void*)f_5174},
{"f_5171posixwin.scm",(void*)f_5171},
{"f_5105posixwin.scm",(void*)f_5105},
{"f_5109posixwin.scm",(void*)f_5109},
{"f_5114posixwin.scm",(void*)f_5114},
{"f_5138posixwin.scm",(void*)f_5138},
{"f_5127posixwin.scm",(void*)f_5127},
{"f_4985posixwin.scm",(void*)f_4985},
{"f_4991posixwin.scm",(void*)f_4991},
{"f_5012posixwin.scm",(void*)f_5012},
{"f_5089posixwin.scm",(void*)f_5089},
{"f_5016posixwin.scm",(void*)f_5016},
{"f_5019posixwin.scm",(void*)f_5019},
{"f_5022posixwin.scm",(void*)f_5022},
{"f_5029posixwin.scm",(void*)f_5029},
{"f_5031posixwin.scm",(void*)f_5031},
{"f_5048posixwin.scm",(void*)f_5048},
{"f_5058posixwin.scm",(void*)f_5058},
{"f_5062posixwin.scm",(void*)f_5062},
{"f_5006posixwin.scm",(void*)f_5006},
{"f_4926posixwin.scm",(void*)f_4926},
{"f_4930posixwin.scm",(void*)f_4930},
{"f_4936posixwin.scm",(void*)f_4936},
{"f_4920posixwin.scm",(void*)f_4920},
{"f_4924posixwin.scm",(void*)f_4924},
{"f_4904posixwin.scm",(void*)f_4904},
{"f_4892posixwin.scm",(void*)f_4892},
{"f_4864posixwin.scm",(void*)f_4864},
{"f_4871posixwin.scm",(void*)f_4871},
{"f_4784posixwin.scm",(void*)f_4784},
{"f_4788posixwin.scm",(void*)f_4788},
{"f_4794posixwin.scm",(void*)f_4794},
{"f_4816posixwin.scm",(void*)f_4816},
{"f_4813posixwin.scm",(void*)f_4813},
{"f_4803posixwin.scm",(void*)f_4803},
{"f_4751posixwin.scm",(void*)f_4751},
{"f_4755posixwin.scm",(void*)f_4755},
{"f_4732posixwin.scm",(void*)f_4732},
{"f_4723posixwin.scm",(void*)f_4723},
{"f_4657posixwin.scm",(void*)f_4657},
{"f_4663posixwin.scm",(void*)f_4663},
{"f_4667posixwin.scm",(void*)f_4667},
{"f_4675posixwin.scm",(void*)f_4675},
{"f_4701posixwin.scm",(void*)f_4701},
{"f_4705posixwin.scm",(void*)f_4705},
{"f_4693posixwin.scm",(void*)f_4693},
{"f_4637posixwin.scm",(void*)f_4637},
{"f_4645posixwin.scm",(void*)f_4645},
{"f_4620posixwin.scm",(void*)f_4620},
{"f_4631posixwin.scm",(void*)f_4631},
{"f_4635posixwin.scm",(void*)f_4635},
{"f_4590posixwin.scm",(void*)f_4590},
{"f_4597posixwin.scm",(void*)f_4597},
{"f_4606posixwin.scm",(void*)f_4606},
{"f_4600posixwin.scm",(void*)f_4600},
{"f_4555posixwin.scm",(void*)f_4555},
{"f_4559posixwin.scm",(void*)f_4559},
{"f_4588posixwin.scm",(void*)f_4588},
{"f_4574posixwin.scm",(void*)f_4574},
{"f_4568posixwin.scm",(void*)f_4568},
{"f_4541posixwin.scm",(void*)f_4541},
{"f_4553posixwin.scm",(void*)f_4553},
{"f_4527posixwin.scm",(void*)f_4527},
{"f_4539posixwin.scm",(void*)f_4539},
{"f_4509posixwin.scm",(void*)f_4509},
{"f_4513posixwin.scm",(void*)f_4513},
{"f_4525posixwin.scm",(void*)f_4525},
{"f_4472posixwin.scm",(void*)f_4472},
{"f_4480posixwin.scm",(void*)f_4480},
{"f_4463posixwin.scm",(void*)f_4463},
{"f_4457posixwin.scm",(void*)f_4457},
{"f_4451posixwin.scm",(void*)f_4451},
{"f_4427posixwin.scm",(void*)f_4427},
{"f_4449posixwin.scm",(void*)f_4449},
{"f_4445posixwin.scm",(void*)f_4445},
{"f_4437posixwin.scm",(void*)f_4437},
{"f_4397posixwin.scm",(void*)f_4397},
{"f_4425posixwin.scm",(void*)f_4425},
{"f_4421posixwin.scm",(void*)f_4421},
{"f_4413posixwin.scm",(void*)f_4413},
{"f_4341posixwin.scm",(void*)f_4341},
{"f_4351posixwin.scm",(void*)f_4351},
{"f_4328posixwin.scm",(void*)f_4328},
{"f_4319posixwin.scm",(void*)f_4319},
{"f_4243posixwin.scm",(void*)f_4243},
{"f_4247posixwin.scm",(void*)f_4247},
{"f_4259posixwin.scm",(void*)f_4259},
{"f_4250posixwin.scm",(void*)f_4250},
{"f_4223posixwin.scm",(void*)f_4223},
{"f_4227posixwin.scm",(void*)f_4227},
{"f_4233posixwin.scm",(void*)f_4233},
{"f_4237posixwin.scm",(void*)f_4237},
{"f_4203posixwin.scm",(void*)f_4203},
{"f_4207posixwin.scm",(void*)f_4207},
{"f_4213posixwin.scm",(void*)f_4213},
{"f_4217posixwin.scm",(void*)f_4217},
{"f_4179posixwin.scm",(void*)f_4179},
{"f_4183posixwin.scm",(void*)f_4183},
{"f_4194posixwin.scm",(void*)f_4194},
{"f_4198posixwin.scm",(void*)f_4198},
{"f_4188posixwin.scm",(void*)f_4188},
{"f_4155posixwin.scm",(void*)f_4155},
{"f_4159posixwin.scm",(void*)f_4159},
{"f_4170posixwin.scm",(void*)f_4170},
{"f_4174posixwin.scm",(void*)f_4174},
{"f_4164posixwin.scm",(void*)f_4164},
{"f_4136posixwin.scm",(void*)f_4136},
{"f_4140posixwin.scm",(void*)f_4140},
{"f_4143posixwin.scm",(void*)f_4143},
{"f_4100posixwin.scm",(void*)f_4100},
{"f_4131posixwin.scm",(void*)f_4131},
{"f_4121posixwin.scm",(void*)f_4121},
{"f_4114posixwin.scm",(void*)f_4114},
{"f_4064posixwin.scm",(void*)f_4064},
{"f_4095posixwin.scm",(void*)f_4095},
{"f_4085posixwin.scm",(void*)f_4085},
{"f_4078posixwin.scm",(void*)f_4078},
{"f_4046posixwin.scm",(void*)f_4046},
{"f_4050posixwin.scm",(void*)f_4050},
{"f_4062posixwin.scm",(void*)f_4062},
{"f_4040posixwin.scm",(void*)f_4040},
{"f_4028posixwin.scm",(void*)f_4028},
{"f_3671posixwin.scm",(void*)f_3671},
{"f_4018posixwin.scm",(void*)f_4018},
{"f_3817posixwin.scm",(void*)f_3817},
{"f_4004posixwin.scm",(void*)f_4004},
{"f_3993posixwin.scm",(void*)f_3993},
{"f_4000posixwin.scm",(void*)f_4000},
{"f_3847posixwin.scm",(void*)f_3847},
{"f_3986posixwin.scm",(void*)f_3986},
{"f_3965posixwin.scm",(void*)f_3965},
{"f_3982posixwin.scm",(void*)f_3982},
{"f_3971posixwin.scm",(void*)f_3971},
{"f_3978posixwin.scm",(void*)f_3978},
{"f_3889posixwin.scm",(void*)f_3889},
{"f_3962posixwin.scm",(void*)f_3962},
{"f_3941posixwin.scm",(void*)f_3941},
{"f_3958posixwin.scm",(void*)f_3958},
{"f_3947posixwin.scm",(void*)f_3947},
{"f_3954posixwin.scm",(void*)f_3954},
{"f_3895posixwin.scm",(void*)f_3895},
{"f_3938posixwin.scm",(void*)f_3938},
{"f_3934posixwin.scm",(void*)f_3934},
{"f_3927posixwin.scm",(void*)f_3927},
{"f_3923posixwin.scm",(void*)f_3923},
{"f_3902posixwin.scm",(void*)f_3902},
{"f_3906posixwin.scm",(void*)f_3906},
{"f_3883posixwin.scm",(void*)f_3883},
{"f_3870posixwin.scm",(void*)f_3870},
{"f_3854posixwin.scm",(void*)f_3854},
{"f_3858posixwin.scm",(void*)f_3858},
{"f_3862posixwin.scm",(void*)f_3862},
{"f_3841posixwin.scm",(void*)f_3841},
{"f_3828posixwin.scm",(void*)f_3828},
{"f_3824posixwin.scm",(void*)f_3824},
{"f_3811posixwin.scm",(void*)f_3811},
{"f_3678posixwin.scm",(void*)f_3678},
{"f_3797posixwin.scm",(void*)f_3797},
{"f_3685posixwin.scm",(void*)f_3685},
{"f_3687posixwin.scm",(void*)f_3687},
{"f_3694posixwin.scm",(void*)f_3694},
{"f_3769posixwin.scm",(void*)f_3769},
{"f_3778posixwin.scm",(void*)f_3778},
{"f_3766posixwin.scm",(void*)f_3766},
{"f_3700posixwin.scm",(void*)f_3700},
{"f_3747posixwin.scm",(void*)f_3747},
{"f_3735posixwin.scm",(void*)f_3735},
{"f_3743posixwin.scm",(void*)f_3743},
{"f_3739posixwin.scm",(void*)f_3739},
{"f_3716posixwin.scm",(void*)f_3716},
{"f_3724posixwin.scm",(void*)f_3724},
{"f_3720posixwin.scm",(void*)f_3720},
{"f_3615posixwin.scm",(void*)f_3615},
{"f_3624posixwin.scm",(void*)f_3624},
{"f_3648posixwin.scm",(void*)f_3648},
{"f_3660posixwin.scm",(void*)f_3660},
{"f_3666posixwin.scm",(void*)f_3666},
{"f_3654posixwin.scm",(void*)f_3654},
{"f_3630posixwin.scm",(void*)f_3630},
{"f_3636posixwin.scm",(void*)f_3636},
{"f_3622posixwin.scm",(void*)f_3622},
{"f_3604posixwin.scm",(void*)f_3604},
{"f_3599posixwin.scm",(void*)f_3599},
{"f_3548posixwin.scm",(void*)f_3548},
{"f_3552posixwin.scm",(void*)f_3552},
{"f_3561posixwin.scm",(void*)f_3561},
{"f_3564posixwin.scm",(void*)f_3564},
{"f_3521posixwin.scm",(void*)f_3521},
{"f_3546posixwin.scm",(void*)f_3546},
{"f_3542posixwin.scm",(void*)f_3542},
{"f_3528posixwin.scm",(void*)f_3528},
{"f_3361posixwin.scm",(void*)f_3361},
{"f_3469posixwin.scm",(void*)f_3469},
{"f_3477posixwin.scm",(void*)f_3477},
{"f_3464posixwin.scm",(void*)f_3464},
{"f_3363posixwin.scm",(void*)f_3363},
{"f_3370posixwin.scm",(void*)f_3370},
{"f_3373posixwin.scm",(void*)f_3373},
{"f_3376posixwin.scm",(void*)f_3376},
{"f_3463posixwin.scm",(void*)f_3463},
{"f_3380posixwin.scm",(void*)f_3380},
{"f_3397posixwin.scm",(void*)f_3397},
{"f_3407posixwin.scm",(void*)f_3407},
{"f_3419posixwin.scm",(void*)f_3419},
{"f_3429posixwin.scm",(void*)f_3429},
{"f_3389posixwin.scm",(void*)f_3389},
{"f_3334posixwin.scm",(void*)f_3334},
{"f_3359posixwin.scm",(void*)f_3359},
{"f_3355posixwin.scm",(void*)f_3355},
{"f_3347posixwin.scm",(void*)f_3347},
{"f_3307posixwin.scm",(void*)f_3307},
{"f_3332posixwin.scm",(void*)f_3332},
{"f_3328posixwin.scm",(void*)f_3328},
{"f_3320posixwin.scm",(void*)f_3320},
{"f_3167posixwin.scm",(void*)f_3167},
{"f_3171posixwin.scm",(void*)f_3171},
{"f_3267posixwin.scm",(void*)f_3267},
{"f_3268posixwin.scm",(void*)f_3268},
{"f_3286posixwin.scm",(void*)f_3286},
{"f_3278posixwin.scm",(void*)f_3278},
{"f_3184posixwin.scm",(void*)f_3184},
{"f_3185posixwin.scm",(void*)f_3185},
{"f_3189posixwin.scm",(void*)f_3189},
{"f_3197posixwin.scm",(void*)f_3197},
{"f_3202posixwin.scm",(void*)f_3202},
{"f_3206posixwin.scm",(void*)f_3206},
{"f_3236posixwin.scm",(void*)f_3236},
{"f_3243posixwin.scm",(void*)f_3243},
{"f_3246posixwin.scm",(void*)f_3246},
{"f_3213posixwin.scm",(void*)f_3213},
{"f_3217posixwin.scm",(void*)f_3217},
{"f_3235posixwin.scm",(void*)f_3235},
{"f_3227posixwin.scm",(void*)f_3227},
{"f_3106posixwin.scm",(void*)f_3106},
{"f_3119posixwin.scm",(void*)f_3119},
{"f_3134posixwin.scm",(void*)f_3134},
{"f_3125posixwin.scm",(void*)f_3125},
{"f_3128posixwin.scm",(void*)f_3128},
{"f_3066posixwin.scm",(void*)f_3066},
{"f_3085posixwin.scm",(void*)f_3085},
{"f_3070posixwin.scm",(void*)f_3070},
{"f_3079posixwin.scm",(void*)f_3079},
{"f_3073posixwin.scm",(void*)f_3073},
{"f_3033posixwin.scm",(void*)f_3033},
{"f_3035posixwin.scm",(void*)f_3035},
{"f_3028posixwin.scm",(void*)f_3028},
{"f_3005posixwin.scm",(void*)f_3005},
{"f_3026posixwin.scm",(void*)f_3026},
{"f_3012posixwin.scm",(void*)f_3012},
{"f_2999posixwin.scm",(void*)f_2999},
{"f_3003posixwin.scm",(void*)f_3003},
{"f_2993posixwin.scm",(void*)f_2993},
{"f_2997posixwin.scm",(void*)f_2997},
{"f_2987posixwin.scm",(void*)f_2987},
{"f_2991posixwin.scm",(void*)f_2991},
{"f_2981posixwin.scm",(void*)f_2981},
{"f_2985posixwin.scm",(void*)f_2985},
{"f_2975posixwin.scm",(void*)f_2975},
{"f_2979posixwin.scm",(void*)f_2979},
{"f_2969posixwin.scm",(void*)f_2969},
{"f_2973posixwin.scm",(void*)f_2973},
{"f_2938posixwin.scm",(void*)f_2938},
{"f_2942posixwin.scm",(void*)f_2942},
{"f_2945posixwin.scm",(void*)f_2945},
{"f_2900posixwin.scm",(void*)f_2900},
{"f_2933posixwin.scm",(void*)f_2933},
{"f_2929posixwin.scm",(void*)f_2929},
{"f_2904posixwin.scm",(void*)f_2904},
{"f_2913posixwin.scm",(void*)f_2913},
{"f_2862posixwin.scm",(void*)f_2862},
{"f_2869posixwin.scm",(void*)f_2869},
{"f_2872posixwin.scm",(void*)f_2872},
{"f_2892posixwin.scm",(void*)f_2892},
{"f_2875posixwin.scm",(void*)f_2875},
{"f_2882posixwin.scm",(void*)f_2882},
{"f_2820posixwin.scm",(void*)f_2820},
{"f_2827posixwin.scm",(void*)f_2827},
{"f_2842posixwin.scm",(void*)f_2842},
{"f_2836posixwin.scm",(void*)f_2836},
{"f_2775posixwin.scm",(void*)f_2775},
{"f_2785posixwin.scm",(void*)f_2785},
{"f_2788posixwin.scm",(void*)f_2788},
{"f_2800posixwin.scm",(void*)f_2800},
{"f_2791posixwin.scm",(void*)f_2791},
{"f_2757posixwin.scm",(void*)f_2757},
{"f_2770posixwin.scm",(void*)f_2770},
{"f_2716posixwin.scm",(void*)f_2716},
{"f_2749posixwin.scm",(void*)f_2749},
{"f_2733posixwin.scm",(void*)f_2733},
{"f_2742posixwin.scm",(void*)f_2742},
{"f_2736posixwin.scm",(void*)f_2736},
{"f_2670posixwin.scm",(void*)f_2670},
{"f_2674posixwin.scm",(void*)f_2674},
{"f_2685posixwin.scm",(void*)f_2685},
{"f_2681posixwin.scm",(void*)f_2681},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
