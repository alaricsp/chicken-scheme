/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-08 08:52
   Version 4.0.0x3 - SVN rev. 12690
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-12-01 on dill (Linux)
   command line: batch-driver.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[364];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_fcall f_3251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_fcall f_1118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_fcall f_1512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_fcall f_1530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_fcall f_1536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_fcall f_1542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_fcall f_1545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_fcall f_1548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_fcall f_1558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_fcall f_1564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_fcall f_1567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_fcall f_1570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_fcall f_1576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_fcall f_1579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_fcall f_1582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_fcall f_1588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_fcall f_1594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_fcall f_1619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_fcall f_1657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_fcall f_1688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_fcall f_1722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_fcall f_1755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_fcall f_2567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_fcall f_2622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_fcall f_1831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_fcall f_1840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_fcall f_2371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_fcall f_1902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_fcall f_1905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_fcall f_1928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_fcall f_2134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_fcall f_1430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1460)
static void C_fcall f_1460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_fcall f_1455(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1432)
static void C_fcall f_1432(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1407)
static void C_fcall f_1407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1397)
static C_word C_fcall f_1397(C_word t0);
C_noret_decl(f_1367)
static void C_fcall f_1367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1373)
static void C_fcall f_1373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_fcall f_1248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_fcall f_1211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_fcall f_1174(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_fcall f_1165(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1060)
static void C_fcall f_1060(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3251)
static void C_fcall trf_3251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3251(t0,t1);}

C_noret_decl(trf_1118)
static void C_fcall trf_1118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1118(t0,t1);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1509(t0,t1);}

C_noret_decl(trf_1512)
static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1512(t0,t1);}

C_noret_decl(trf_1530)
static void C_fcall trf_1530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1530(t0,t1);}

C_noret_decl(trf_1536)
static void C_fcall trf_1536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1536(t0,t1);}

C_noret_decl(trf_1542)
static void C_fcall trf_1542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1542(t0,t1);}

C_noret_decl(trf_1545)
static void C_fcall trf_1545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1545(t0,t1);}

C_noret_decl(trf_1548)
static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1548(t0,t1);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1551(t0,t1);}

C_noret_decl(trf_1558)
static void C_fcall trf_1558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1558(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1564)
static void C_fcall trf_1564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1564(t0,t1);}

C_noret_decl(trf_1567)
static void C_fcall trf_1567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1567(t0,t1);}

C_noret_decl(trf_1570)
static void C_fcall trf_1570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1570(t0,t1);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1573(t0,t1);}

C_noret_decl(trf_1576)
static void C_fcall trf_1576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1576(t0,t1);}

C_noret_decl(trf_1579)
static void C_fcall trf_1579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1579(t0,t1);}

C_noret_decl(trf_1582)
static void C_fcall trf_1582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1582(t0,t1);}

C_noret_decl(trf_1588)
static void C_fcall trf_1588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1588(t0,t1);}

C_noret_decl(trf_1594)
static void C_fcall trf_1594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1594(t0,t1);}

C_noret_decl(trf_1619)
static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1619(t0,t1);}

C_noret_decl(trf_1657)
static void C_fcall trf_1657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1657(t0,t1);}

C_noret_decl(trf_1688)
static void C_fcall trf_1688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1688(t0,t1);}

C_noret_decl(trf_1722)
static void C_fcall trf_1722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1722(t0,t1);}

C_noret_decl(trf_1755)
static void C_fcall trf_1755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1755(t0,t1);}

C_noret_decl(trf_2567)
static void C_fcall trf_2567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2567(t0,t1,t2);}

C_noret_decl(trf_2622)
static void C_fcall trf_2622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2622(t0,t1,t2);}

C_noret_decl(trf_1831)
static void C_fcall trf_1831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1831(t0,t1);}

C_noret_decl(trf_1840)
static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1840(t0,t1);}

C_noret_decl(trf_2371)
static void C_fcall trf_2371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2371(t0,t1);}

C_noret_decl(trf_1902)
static void C_fcall trf_1902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1902(t0,t1);}

C_noret_decl(trf_1905)
static void C_fcall trf_1905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1905(t0,t1);}

C_noret_decl(trf_1928)
static void C_fcall trf_1928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1928(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1928(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2134)
static void C_fcall trf_2134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2134(t0,t1);}

C_noret_decl(trf_1659)
static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1659(t0,t1,t2);}

C_noret_decl(trf_1430)
static void C_fcall trf_1430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1430(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1430(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1460)
static void C_fcall trf_1460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1460(t0,t1);}

C_noret_decl(trf_1455)
static void C_fcall trf_1455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1455(t0,t1,t2);}

C_noret_decl(trf_1432)
static void C_fcall trf_1432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1432(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1432(t0,t1,t2,t3);}

C_noret_decl(trf_1424)
static void C_fcall trf_1424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1424(t0,t1,t2);}

C_noret_decl(trf_1407)
static void C_fcall trf_1407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1407(t0,t1,t2);}

C_noret_decl(trf_1367)
static void C_fcall trf_1367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1367(t0,t1,t2);}

C_noret_decl(trf_1373)
static void C_fcall trf_1373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1373(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1373(t0,t1,t2);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1287(t0,t1);}

C_noret_decl(trf_1248)
static void C_fcall trf_1248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1248(t0,t1);}

C_noret_decl(trf_1226)
static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1226(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1211)
static void C_fcall trf_1211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1211(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1211(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1189)
static void C_fcall trf_1189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1189(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1189(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1174)
static void C_fcall trf_1174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1174(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1174(t0,t1,t2,t3);}

C_noret_decl(trf_1165)
static void C_fcall trf_1165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1165(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1165(t0,t1,t2,t3);}

C_noret_decl(trf_1060)
static void C_fcall trf_1060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1060(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2780)){
C_save(t1);
C_rereclaim2(2780*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,364);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],11,"user-pass-2");
lf[5]=C_h_intern(&lf[5],23,"user-post-analysis-pass");
lf[6]=C_h_intern(&lf[6],19,"compile-source-file");
lf[7]=C_h_intern(&lf[7],4,"quit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],26,"\010compilerexplicit-use-flag");
lf[12]=C_h_intern(&lf[12],12,"\004coredeclare");
lf[13]=C_h_intern(&lf[13],7,"verbose");
lf[14]=C_h_intern(&lf[14],11,"output-file");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[20]=C_h_intern(&lf[20],9,"heap-size");
lf[21]=C_h_intern(&lf[21],17,"heap-initial-size");
lf[22]=C_h_intern(&lf[22],11,"heap-growth");
lf[23]=C_h_intern(&lf[23],14,"heap-shrinkage");
lf[24]=C_h_intern(&lf[24],13,"keyword-style");
lf[25]=C_h_intern(&lf[25],4,"unit");
lf[26]=C_h_intern(&lf[26],12,"analyze-only");
lf[27]=C_h_intern(&lf[27],7,"dynamic");
lf[28]=C_h_intern(&lf[28],7,"nursery");
lf[29]=C_h_intern(&lf[29],10,"stack-size");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006~\077~%~!");
lf[32]=C_h_intern(&lf[32],26,"\010compilerdebugging-chicken");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[35]=C_h_intern(&lf[35],19,"\010compilerdump-nodes");
lf[36]=C_h_intern(&lf[36],12,"pretty-print");
lf[37]=C_h_intern(&lf[37],30,"\010compilerbuild-expression-tree");
lf[38]=C_h_intern(&lf[38],34,"\010compilerdisplay-analysis-database");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[40]=C_h_intern(&lf[40],12,"\003sysfor-each");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_h_intern(&lf[42],24,"\003sysline-number-database");
lf[43]=C_h_intern(&lf[43],10,"alist-cons");
lf[44]=C_h_intern(&lf[44],18,"\003syshash-table-ref");
lf[45]=C_h_intern(&lf[45],9,"list-info");
lf[46]=C_h_intern(&lf[46],26,"\003sysdefault-read-info-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[50]=C_h_intern(&lf[50],8,"\003sysread");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],15,"lset-difference");
lf[68]=C_h_intern(&lf[68],3,"eq\077");
lf[69]=C_h_intern(&lf[69],7,"\003sysmap");
lf[70]=C_h_intern(&lf[70],14,"string->symbol");
lf[71]=C_h_intern(&lf[71],12,"string-split");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[73]=C_h_intern(&lf[73],10,"append-map");
lf[74]=C_h_intern(&lf[74],25,"\010compilertarget-heap-size");
lf[75]=C_h_intern(&lf[75],33,"\010compilertarget-initial-heap-size");
lf[76]=C_h_intern(&lf[76],27,"\010compilertarget-heap-growth");
lf[77]=C_h_intern(&lf[77],30,"\010compilertarget-heap-shrinkage");
lf[78]=C_h_intern(&lf[78],26,"\010compilertarget-stack-size");
lf[79]=C_h_intern(&lf[79],8,"no-trace");
lf[80]=C_h_intern(&lf[80],24,"\010compileremit-trace-info");
lf[81]=C_h_intern(&lf[81],29,"disable-stack-overflow-checks");
lf[82]=C_h_intern(&lf[82],40,"\010compilerdisable-stack-overflow-checking");
lf[83]=C_h_intern(&lf[83],7,"version");
lf[84]=C_h_intern(&lf[84],7,"newline");
lf[85]=C_h_intern(&lf[85],22,"\010compilerprint-version");
lf[86]=C_h_intern(&lf[86],4,"help");
lf[87]=C_h_intern(&lf[87],20,"\010compilerprint-usage");
lf[88]=C_h_intern(&lf[88],7,"release");
lf[89]=C_h_intern(&lf[89],7,"display");
lf[90]=C_h_intern(&lf[90],15,"chicken-version");
lf[91]=C_h_intern(&lf[91],24,"\010compilersource-filename");
lf[92]=C_h_intern(&lf[92],28,"\010compilerprofile-lambda-list");
lf[93]=C_h_intern(&lf[93],31,"\010compilerline-number-database-2");
lf[94]=C_h_intern(&lf[94],23,"\010compilerconstant-table");
lf[95]=C_h_intern(&lf[95],21,"\010compilerinline-table");
lf[96]=C_h_intern(&lf[96],23,"\010compilerfirst-analysis");
lf[97]=C_h_intern(&lf[97],41,"\010compilerperform-high-level-optimizations");
lf[98]=C_h_intern(&lf[98],37,"\010compilerinline-substitutions-enabled");
lf[99]=C_h_intern(&lf[99],22,"optimize-leaf-routines");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[101]=C_h_intern(&lf[101],34,"\010compilertransform-direct-lambdas!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[103]=C_h_intern(&lf[103],4,"leaf");
lf[104]=C_h_intern(&lf[104],18,"\010compilerdebugging");
lf[105]=C_h_intern(&lf[105],1,"p");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[108]=C_h_intern(&lf[108],1,"5");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[111]=C_h_intern(&lf[111],36,"\010compilerprepare-for-code-generation");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[113]=C_h_intern(&lf[113],30,"\010compilercompiler-cleanup-hook");
lf[114]=C_h_intern(&lf[114],1,"t");
lf[115]=C_h_intern(&lf[115],17,"\003sysdisplay-times");
lf[116]=C_h_intern(&lf[116],14,"\003sysstop-timer");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[118]=C_h_intern(&lf[118],17,"close-output-port");
lf[119]=C_h_intern(&lf[119],22,"\010compilergenerate-code");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[121]=C_h_intern(&lf[121],16,"open-output-file");
lf[122]=C_h_intern(&lf[122],19,"current-output-port");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[125]=C_h_intern(&lf[125],1,"9");
lf[126]=C_h_intern(&lf[126],4,"exit");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[128]=C_h_intern(&lf[128],20,"\003syswarnings-enabled");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[130]=C_h_intern(&lf[130],1,"8");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[132]=C_h_intern(&lf[132],35,"\010compilerperform-closure-conversion");
lf[133]=C_h_intern(&lf[133],27,"\010compilerinline-output-file");
lf[134]=C_h_intern(&lf[134],32,"\010compileremit-global-inline-file");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[137]=C_h_intern(&lf[137],1,"7");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],33,"\010compilerprint-program-statistics");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[141]=C_h_intern(&lf[141],1,"4");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[143]=C_h_intern(&lf[143],1,"u");
lf[144]=C_h_intern(&lf[144],31,"\010compilerdump-undefined-globals");
lf[145]=C_h_intern(&lf[145],3,"opt");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[147]=C_h_intern(&lf[147],1,"3");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[149]=C_h_intern(&lf[149],31,"\010compilerperform-cps-conversion");
lf[150]=C_h_intern(&lf[150],6,"unsafe");
lf[151]=C_h_intern(&lf[151],34,"\010compilerscan-toplevel-assignments");
lf[152]=C_h_intern(&lf[152],26,"\010compilerdo-lambda-lifting");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[154]=C_h_intern(&lf[154],1,"L");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[156]=C_h_intern(&lf[156],32,"\010compilerperform-lambda-lifting!");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[159]=C_h_intern(&lf[159],1,"0");
lf[160]=C_h_intern(&lf[160],4,"lift");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[162]=C_h_intern(&lf[162],1,"U");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[166]=C_h_intern(&lf[166],4,"user");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\026Secondary user pass...");
lf[168]=C_h_intern(&lf[168],4,"node");
lf[169]=C_h_intern(&lf[169],6,"lambda");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[171]=C_h_intern(&lf[171],25,"\010compilerbuild-node-graph");
lf[172]=C_h_intern(&lf[172],32,"\010compilercanonicalize-begin-body");
lf[173]=C_h_intern(&lf[173],24,"\010compilerinline-globally");
lf[174]=C_h_intern(&lf[174],25,"\010compilerload-inline-file");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[176]=C_h_intern(&lf[176],12,"file-exists\077");
lf[177]=C_h_intern(&lf[177],28,"\003sysresolve-include-filename");
lf[178]=C_h_intern(&lf[178],13,"make-pathname");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[180]=C_h_intern(&lf[180],14,"symbol->string");
lf[181]=C_h_intern(&lf[181],11,"concatenate");
lf[182]=C_h_intern(&lf[182],3,"cdr");
lf[183]=C_h_intern(&lf[183],2,"pp");
lf[184]=C_h_intern(&lf[184],1,"M");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[186]=C_h_intern(&lf[186],12,"vector->list");
lf[187]=C_h_intern(&lf[187],26,"\010compilerfile-requirements");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[190]=C_h_intern(&lf[190],12,"check-syntax");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[192]=C_h_intern(&lf[192],1,"2");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[194]=C_h_intern(&lf[194],25,"\010compilercompiler-warning");
lf[195]=C_h_intern(&lf[195],5,"style");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[197]=C_h_intern(&lf[197],8,"feature\077");
lf[198]=C_h_intern(&lf[198],19,"compiling-extension");
lf[199]=C_h_intern(&lf[199],18,"\010compilerunit-name");
lf[200]=C_h_intern(&lf[200],5,"usage");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[202]=C_h_intern(&lf[202],26,"\010compilerblock-compilation");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[204]=C_h_intern(&lf[204],37,"\010compilerdisplay-line-number-database");
lf[205]=C_h_intern(&lf[205],1,"n");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[207]=C_h_intern(&lf[207],32,"\010compilerdisplay-real-name-table");
lf[208]=C_h_intern(&lf[208],1,"N");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[210]=C_h_intern(&lf[210],6,"append");
lf[211]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[212]=C_h_intern(&lf[212],5,"quote");
lf[213]=C_h_intern(&lf[213],33,"\010compilerprofile-info-vector-name");
lf[214]=C_h_intern(&lf[214],28,"\003sysset-profile-info-vector!");
lf[215]=C_h_intern(&lf[215],21,"\010compileremit-profile");
lf[216]=C_h_intern(&lf[216],25,"\003sysregister-profile-info");
lf[217]=C_h_intern(&lf[217],4,"set!");
lf[218]=C_h_intern(&lf[218],13,"\004corecallunit");
lf[219]=C_h_intern(&lf[219],19,"\010compilerused-units");
lf[220]=C_h_intern(&lf[220],28,"\010compilerimmutable-constants");
lf[221]=C_h_intern(&lf[221],6,"gensym");
lf[222]=C_h_intern(&lf[222],32,"\010compilercanonicalize-expression");
lf[223]=C_h_intern(&lf[223],28,"\003sysexplicit-library-modules");
lf[224]=C_h_intern(&lf[224],4,"uses");
lf[225]=C_h_intern(&lf[225],7,"declare");
lf[226]=C_h_intern(&lf[226],10,"\003sysappend");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[228]=C_h_intern(&lf[228],1,"1");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[231]=C_h_intern(&lf[231],21,"\010compilerstring->expr");
lf[232]=C_h_intern(&lf[232],7,"reverse");
lf[233]=C_h_intern(&lf[233],27,"\003syscurrent-source-filename");
lf[234]=C_h_intern(&lf[234],33,"\010compilerclose-checked-input-file");
lf[235]=C_h_intern(&lf[235],16,"\003sysdynamic-wind");
lf[236]=C_h_intern(&lf[236],34,"\010compilercheck-and-open-input-file");
lf[237]=C_h_intern(&lf[237],8,"epilogue");
lf[238]=C_h_intern(&lf[238],8,"prologue");
lf[239]=C_h_intern(&lf[239],8,"postlude");
lf[240]=C_h_intern(&lf[240],7,"prelude");
lf[241]=C_h_intern(&lf[241],11,"make-vector");
lf[242]=C_h_intern(&lf[242],34,"\010compilerline-number-database-size");
lf[243]=C_h_intern(&lf[243],1,"r");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[250]=C_h_intern(&lf[250],5,"-help");
lf[251]=C_h_intern(&lf[251],1,"h");
lf[252]=C_h_intern(&lf[252],2,"-h");
lf[253]=C_h_intern(&lf[253],8,"\003sysput!");
lf[254]=C_h_intern(&lf[254],7,"\004coredb");
lf[255]=C_h_intern(&lf[255],7,"\003sysget");
lf[256]=C_h_intern(&lf[256],9,"read-file");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\027loading database ~a ...");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[259]=C_h_intern(&lf[259],15,"repository-path");
lf[260]=C_h_intern(&lf[260],18,"accumulate-profile");
lf[261]=C_h_intern(&lf[261],28,"\010compilerprofiled-procedures");
lf[262]=C_h_intern(&lf[262],3,"all");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[266]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[267]=C_h_intern(&lf[267],39,"\010compilerdefault-profiling-declarations");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[271]=C_h_intern(&lf[271],21,"no-usual-integrations");
lf[272]=C_h_intern(&lf[272],17,"standard-bindings");
lf[273]=C_h_intern(&lf[273],34,"\010compilerdefault-standard-bindings");
lf[274]=C_h_intern(&lf[274],17,"extended-bindings");
lf[275]=C_h_intern(&lf[275],34,"\010compilerdefault-extended-bindings");
lf[276]=C_h_intern(&lf[276],1,"m");
lf[277]=C_h_intern(&lf[277],14,"set-gc-report!");
lf[278]=C_h_intern(&lf[278],42,"\010compilerdefault-default-target-stack-size");
lf[279]=C_h_intern(&lf[279],41,"\010compilerdefault-default-target-heap-size");
lf[280]=C_h_intern(&lf[280],14,"compile-syntax");
lf[281]=C_h_intern(&lf[281],25,"\003sysenable-runtime-macros");
lf[282]=C_h_intern(&lf[282],22,"\004corerequire-extension");
lf[283]=C_h_intern(&lf[283],17,"require-extension");
lf[284]=C_h_intern(&lf[284],9,"extension");
lf[285]=C_h_intern(&lf[285],16,"define-extension");
lf[286]=C_h_intern(&lf[286],13,"pathname-file");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[288]=C_h_intern(&lf[288],28,"\010compilerpostponed-initforms");
lf[289]=C_h_intern(&lf[289],6,"delete");
lf[290]=C_h_intern(&lf[290],4,"load");
lf[291]=C_h_intern(&lf[291],12,"load-verbose");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[293]=C_h_intern(&lf[293],6,"extend");
lf[294]=C_h_intern(&lf[294],17,"register-feature!");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[296]=C_h_intern(&lf[296],7,"feature");
lf[297]=C_h_intern(&lf[297],20,"keep-shadowed-macros");
lf[298]=C_h_intern(&lf[298],33,"\010compilerundefine-shadowed-macros");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[301]=C_h_intern(&lf[301],23,"\010compilerchop-separator");
lf[302]=C_h_intern(&lf[302],12,"include-path");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[304]=C_h_intern(&lf[304],7,"\000prefix");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[306]=C_h_intern(&lf[306],5,"\000none");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[308]=C_h_intern(&lf[308],7,"\000suffix");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[310]=C_h_intern(&lf[310],17,"compress-literals");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[312]=C_h_intern(&lf[312],16,"case-insensitive");
lf[313]=C_h_intern(&lf[313],14,"case-sensitive");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[315]=C_h_intern(&lf[315],24,"\010compilerinline-max-size");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[317]=C_h_intern(&lf[317],23,"\010compilerinline-locally");
lf[318]=C_h_intern(&lf[318],26,"\010compilerlocal-definitions");
lf[319]=C_h_intern(&lf[319],6,"inline");
lf[320]=C_h_intern(&lf[320],30,"emit-external-prototypes-first");
lf[321]=C_h_intern(&lf[321],30,"\010compilerexternal-protos-first");
lf[322]=C_h_intern(&lf[322],5,"block");
lf[323]=C_h_intern(&lf[323],17,"fixnum-arithmetic");
lf[324]=C_h_intern(&lf[324],11,"number-type");
lf[325]=C_h_intern(&lf[325],6,"fixnum");
lf[326]=C_h_intern(&lf[326],18,"disable-interrupts");
lf[327]=C_h_intern(&lf[327],28,"\010compilerinsert-timer-checks");
lf[328]=C_h_intern(&lf[328],16,"unsafe-libraries");
lf[329]=C_h_intern(&lf[329],27,"\010compileremit-unsafe-marker");
lf[330]=C_h_intern(&lf[330],11,"no-warnings");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[332]=C_h_intern(&lf[332],15,"disable-warning");
lf[333]=C_h_intern(&lf[333],13,"inline-global");
lf[334]=C_h_intern(&lf[334],5,"local");
lf[335]=C_h_intern(&lf[335],14,"no-lambda-info");
lf[336]=C_h_intern(&lf[336],26,"\010compileremit-closure-info");
lf[337]=C_h_intern(&lf[337],3,"raw");
lf[338]=C_h_intern(&lf[338],12,"emit-exports");
lf[339]=C_h_intern(&lf[339],7,"warning");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[341]=C_h_intern(&lf[341],1,"b");
lf[342]=C_h_intern(&lf[342],15,"\003sysstart-timer");
lf[343]=C_h_intern(&lf[343],11,"lambda-lift");
lf[344]=C_h_intern(&lf[344],13,"string-append");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[346]=C_h_intern(&lf[346],19,"emit-import-library");
lf[347]=C_h_intern(&lf[347],16,"\003sysstring->list");
lf[348]=C_h_intern(&lf[348],5,"debug");
lf[349]=C_h_intern(&lf[349],17,"ignore-repository");
lf[350]=C_h_intern(&lf[350],30,"\010compilerstandalone-executable");
lf[351]=C_h_intern(&lf[351],29,"\010compilerstring->c-identifier");
lf[352]=C_h_intern(&lf[352],18,"\010compilerstringify");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[355]=C_h_intern(&lf[355],6,"getenv");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[357]=C_h_intern(&lf[357],9,"to-stdout");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[360]=C_h_intern(&lf[360],29,"\010compilerdefault-declarations");
lf[361]=C_h_intern(&lf[361],30,"\010compilerunits-used-by-default");
lf[362]=C_h_intern(&lf[362],28,"\010compilerinitialize-compiler");
lf[363]=C_h_intern(&lf[363],14,"make-parameter");
C_register_lf2(lf,364,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1013 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1016 in k1013 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1019 in k1016 in k1013 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 81   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t2,C_SCHEME_FALSE);}

/* k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t3,C_SCHEME_FALSE);}

/* k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t3,C_SCHEME_FALSE);}

/* k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t3,C_SCHEME_FALSE);}

/* k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t3,C_SCHEME_FALSE);}

/* k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 86   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t3,C_SCHEME_FALSE);}

/* k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1057,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1057r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1057r(t0,t1,t2,t3);}}

static void C_ccall f_1057r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1060,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1093,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 99   initialize-compiler */
((C_proc2)C_retrieve_symbol_proc(lf[362]))(2,*((C_word*)lf[362]+1),t5);}

/* k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
t2=(C_word)C_i_memq(lf[10],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[11]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[11]))){
t7=t6;
f_3251(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[361]),C_SCHEME_END_OF_LIST);}}

/* k3260 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[224],t1);
t3=((C_word*)t0)[2];
f_3251(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3249 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_3251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 102  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),((C_word*)t0)[2],C_retrieve(lf[360]),t1);}

/* k3245 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 110  option-arg */
f_1060(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[357],((C_word*)t0)[5]))){
t9=t8;
f_1109(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 115  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3232(2,t10,lf[359]);}}}}

/* k3230 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 115  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[178]))(5,*((C_word*)lf[178]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[358]);}

/* k3208 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 112  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[180]+1)))(3,*((C_word*)lf[180]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1109(2,t2,t1);}}

/* k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1112,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 116  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),t4,lf[356]);}

/* k3202 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[353]);
/* batch-driver.scm: 116  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),((C_word*)t0)[2],t2,lf[354]);}

/* k3198 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[301]),t1);}

/* k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=C_retrieve(lf[15]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[16];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[17],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1118,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1118(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[260],((C_word*)t0)[8]);
t14=t12;
f_1118(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[18],((C_word*)t0)[8])));}}

/* k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1118,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[19]);
t5=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t22=(C_truep(t21)?t21:(C_word)C_i_memq(lf[29],((C_word*)t0)[13]));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1189,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1211,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1226,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1238,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1287,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1430,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t22,a[12]=t1,a[13]=t33,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t27,a[18]=t26,a[19]=t13,a[20]=t14,a[21]=((C_word*)t0)[5],a[22]=t23,a[23]=t25,a[24]=t34,a[25]=t32,a[26]=t31,a[27]=t18,a[28]=((C_word*)t0)[6],a[29]=((C_word*)t0)[7],a[30]=t30,a[31]=((C_word*)t0)[8],a[32]=t20,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3173,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 213  option-arg */
f_1060(t38,t12);}
else{
t36=t35;
f_1509(t36,C_SCHEME_UNDEFINED);}}

/* k3179 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 213  stringify */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),((C_word*)t0)[2],t1);}

/* k3175 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 213  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),((C_word*)t0)[2],t1);}

/* k3171 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[199]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1509(t3,t2);}

/* k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[199]);
t4=(C_truep(t3)?t3:((C_word*)t0)[20]);
if(C_truep(t4)){
t5=C_set_block_item(lf[350] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1512(t6,t5);}
else{
t5=t2;
f_1512(t5,C_SCHEME_UNDEFINED);}}

/* k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[35]))){
/* batch-driver.scm: 217  repository-path */
((C_proc3)C_retrieve_symbol_proc(lf[259]))(3,*((C_word*)lf[259]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1515(2,t3,C_SCHEME_UNDEFINED);}}

/* k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3137,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 223  collect-options */
t5=((C_word*)t0)[30];
f_1367(t5,t4,lf[348]);}

/* k3157 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 219  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3136 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3137,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3143,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[347]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3153 in a3136 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3142 in a3136 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3143,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 221  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[70]+1)))(3,*((C_word*)lf[70]+1),t1,t3);}

/* k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[32]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 229  collect-options */
t8=((C_word*)t0)[30];
f_1367(t8,t7,lf[346]);}

/* k3133 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3118 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 227  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[70]+1)))(3,*((C_word*)lf[70]+1),t3,t2);}

/* k3125 in a3118 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3131,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 228  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[344]+1)))(4,*((C_word*)lf[344]+1),t2,((C_word*)t0)[2],lf[345]);}

/* k3129 in k3125 in a3118 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1527,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[343],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[152] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1530(t5,t4);}
else{
t4=t3;
f_1530(t4,C_SCHEME_UNDEFINED);}}

/* k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1530,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[114],C_retrieve(lf[32])))){
/* batch-driver.scm: 231  ##sys#start-timer */
t3=*((C_word*)lf[342]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1533(2,t3,C_SCHEME_UNDEFINED);}}

/* k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[341],C_retrieve(lf[32])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1536(t4,t3);}
else{
t3=t2;
f_1536(t3,C_SCHEME_UNDEFINED);}}

/* k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1536,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[338],((C_word*)t0)[34]))){
/* batch-driver.scm: 234  warning */
((C_proc3)C_retrieve_symbol_proc(lf[339]))(3,*((C_word*)lf[339]+1),t2,lf[340]);}
else{
t3=t2;
f_1539(2,t3,C_SCHEME_UNDEFINED);}}

/* k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[337],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[11] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1542(t6,t5);}
else{
t3=t2;
f_1542(t3,C_SCHEME_UNDEFINED);}}

/* k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1542,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[335],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[336] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1545(t4,t3);}
else{
t3=t2;
f_1545(t3,C_SCHEME_UNDEFINED);}}

/* k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1545,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[334],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[318] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1548(t4,t3);}
else{
t3=t2;
f_1548(t3,C_SCHEME_UNDEFINED);}}

/* k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[333],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[317] /* inline-locally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[173] /* inline-globally */,0,C_SCHEME_TRUE);
t5=t2;
f_1551(t5,t4);}
else{
t3=t2;
f_1551(t3,C_SCHEME_UNDEFINED);}}

/* k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1551,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 246  collect-options */
t4=((C_word*)t0)[29];
f_1367(t4,t3,lf[332]);}

/* k3076 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 248  dribble */
t5=((C_word*)t0)[21];
f_1165(t5,t4,lf[331],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1558(t4,C_SCHEME_UNDEFINED);}}

/* k3071 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[128] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1558(t3,t2);}

/* k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[99],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[99] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1561(t4,t3);}
else{
t3=t2;
f_1561(t3,C_SCHEME_UNDEFINED);}}

/* k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[150],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[150] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1564(t4,t3);}
else{
t3=t2;
f_1564(t3,C_SCHEME_UNDEFINED);}}

/* k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1564,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[19])?(C_word)C_i_memq(lf[328],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[329] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1567(t5,t4);}
else{
t4=t2;
f_1567(t4,C_SCHEME_UNDEFINED);}}

/* k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1567,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[326],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[327] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1570(t4,t3);}
else{
t3=t2;
f_1570(t3,C_SCHEME_UNDEFINED);}}

/* k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1570,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[323],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[324]+1 /* (set! number-type ...) */,lf[325]);
t4=t2;
f_1573(t4,t3);}
else{
t3=t2;
f_1573(t3,C_SCHEME_UNDEFINED);}}

/* k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[202] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1576(t4,t3);}
else{
t3=t2;
f_1576(t3,C_SCHEME_UNDEFINED);}}

/* k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1576,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[320],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[321] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1579(t4,t3);}
else{
t3=t2;
f_1579(t3,C_SCHEME_UNDEFINED);}}

/* k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1579,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[319],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[317] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1582(t4,t3);}
else{
t3=t2;
f_1582(t3,C_SCHEME_UNDEFINED);}}

/* k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1582,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[317] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[318] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 264  option-arg */
f_1060(t6,t2);}
else{
t4=t3;
f_1588(t4,C_SCHEME_FALSE);}}

/* k3030 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[133]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1588(t3,t2);}

/* k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1588,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[34],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 267  option-arg */
f_1060(t4,t2);}
else{
t4=t3;
f_1594(t4,C_SCHEME_FALSE);}}

/* k3015 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 268  string->number */
C_string_to_number(3,0,t2,t1);}

/* k3018 in k3015 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3023(2,t3,t1);}
else{
/* batch-driver.scm: 269  quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[316],((C_word*)t0)[2]);}}

/* k3021 in k3018 in k3015 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[315]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1594(t3,t2);}

/* k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1594,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 271  dribble */
t4=((C_word*)t0)[21];
f_1165(t4,t3,lf[314],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1597(2,t3,C_SCHEME_UNDEFINED);}}

/* k3005 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 272  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t2,lf[312]);}

/* k3008 in k3005 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 273  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[310],((C_word*)t0)[29]))){
/* batch-driver.scm: 275  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[194]))(4,*((C_word*)lf[194]+1),t2,lf[200],lf[311]);}
else{
t3=t2;
f_1600(2,t3,C_SCHEME_UNDEFINED);}}

/* k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 277  option-arg */
f_1060(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1603(2,t3,C_SCHEME_UNDEFINED);}}

/* k2963 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[303],t1))){
/* batch-driver.scm: 278  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[304]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[305],t1))){
/* batch-driver.scm: 279  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[306]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[307],t1))){
/* batch-driver.scm: 280  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[308]);}
else{
/* batch-driver.scm: 281  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[309]);}}}}

/* k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2962,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 285  collect-options */
t7=((C_word*)t0)[29];
f_1367(t7,t6,lf[302]);}

/* k2960 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[301]),t1);}

/* k2956 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 285  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[210]+1)))(5,*((C_word*)lf[210]+1),((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[19])?(C_truep(((C_word*)t0)[26])?(C_word)C_i_string_equal_p(((C_word*)t0)[19],((C_word*)t0)[26]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 289  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t3,lf[300]);}
else{
t5=t3;
f_1612(2,t5,C_SCHEME_UNDEFINED);}}

/* k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2934,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2942,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 294  collect-options */
t6=((C_word*)t0)[29];
f_1367(t6,t5,lf[224]);}

/* k2940 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 292  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2933 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2934,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),t1,t2,lf[299]);}

/* k2930 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[297],((C_word*)t0)[28]))){
t4=C_set_block_item(lf[298] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1619(t5,t4);}
else{
t4=t3;
f_1619(t4,C_SCHEME_UNDEFINED);}}

/* k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2914,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2916,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 301  collect-options */
t6=((C_word*)t0)[29];
f_1367(t6,t5,lf[296]);}

/* k2922 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 301  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2915 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2916,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),t1,t2,lf[295]);}

/* k2912 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[294]),t1);}

/* k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 305  collect-options */
t5=((C_word*)t0)[29];
f_1367(t5,t4,lf[293]);}

/* k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 306  dribble */
t3=((C_word*)t0)[20];
f_1165(t3,t2,lf[292],C_SCHEME_END_OF_LIST);}

/* k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 307  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1635(2,t3,C_SCHEME_UNDEFINED);}}

/* k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2899,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2898 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2899,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2907,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 309  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[177]))(5,*((C_word*)lf[177]+1),t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2905 in a2898 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 309  load */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),((C_word*)t0)[2],t1);}

/* k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 311  delete */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[68]+1));}

/* k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 314  user-post-analysis-pass */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t5);}

/* k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 317  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[288]));}

/* k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[284],((C_word*)t0)[27]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=t3,a[3]=((C_word*)t0)[30],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[30],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2885,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[18])){
/* batch-driver.scm: 326  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t6,((C_word*)t0)[18]);}
else{
if(C_truep(((C_word*)t0)[25])){
/* batch-driver.scm: 327  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t6,((C_word*)t0)[25]);}
else{
/* batch-driver.scm: 328  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t6,lf[287]);}}}
else{
t4=t3;
f_1657(t4,C_SCHEME_UNDEFINED);}}

/* k2883 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 325  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[70]+1)))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t1);}

/* k2879 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[285],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 322  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}

/* k2863 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1657(t3,t2);}

/* k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1657,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[29],a[3]=((C_word*)t0)[30],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[29],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[30],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[28],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2838,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 344  ids */
t7=t2;
f_1659(t7,t6,lf[283]);}

/* k2856 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2837 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2838,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[282],t5));}

/* k2834 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 341  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[30],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[280],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[281] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1688(t5,t4);}
else{
t4=t3;
f_1688(t4,C_SCHEME_UNDEFINED);}}

/* k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1688,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2815,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 350  option-arg */
f_1060(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[279]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1692(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1692(2,t4,C_SCHEME_FALSE);}}}

/* k2813 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 350  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 354  option-arg */
f_1060(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1696(2,t4,C_SCHEME_FALSE);}}

/* k2806 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 354  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2801,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 355  option-arg */
f_1060(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1700(2,t4,C_SCHEME_FALSE);}}

/* k2799 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 355  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 356  option-arg */
f_1060(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1704(2,t4,C_SCHEME_FALSE);}}

/* k2792 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 356  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 359  option-arg */
f_1060(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[278]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1708(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1708(2,t5,C_SCHEME_FALSE);}}}

/* k2772 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 359  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[79],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[80]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[81],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[82]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[276],C_retrieve(lf[32])))){
/* batch-driver.scm: 365  set-gc-report! */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1719(2,t9,C_SCHEME_UNDEFINED);}}

/* k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[271],((C_word*)t0)[23]))){
t3=t2;
f_1722(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[272]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[273]));
t4=C_mutate((C_word*)lf[274]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[275]));
t5=t2;
f_1722(t5,t4);}}

/* k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1722,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(C_truep(C_retrieve(lf[80]))?lf[268]:lf[269]);
/* batch-driver.scm: 369  dribble */
t4=((C_word*)t0)[15];
f_1165(t4,t2,lf[270],(C_word)C_a_i_list(&a,1,t3));}

/* k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[260],t3);
t5=C_set_block_item(lf[215] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[261]+1 /* (set! profiled-procedures ...) */,lf[262]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[266]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 378  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[210]+1)))(5,*((C_word*)lf[210]+1),t7,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[267]),t8);}
else{
t3=t2;
f_1728(2,t3,C_SCHEME_UNDEFINED);}}

/* k2731 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_truep(((C_word*)t0)[4])?lf[263]:lf[264]);
/* batch-driver.scm: 384  dribble */
t4=((C_word*)t0)[3];
f_1165(t4,((C_word*)t0)[2],lf[265],(C_word)C_a_i_list(&a,1,t3));}

/* k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 387  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[259]))(2,*((C_word*)lf[259]+1),t2);}

/* k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 388  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t4,t1,lf[258]);}
else{
t3=t2;
f_1734(2,t3,C_SCHEME_FALSE);}}

/* k2722 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 388  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),((C_word*)t0)[2],t1);}

/* k2676 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 389  dribble */
t3=((C_word*)t0)[2];
f_1165(t3,t2,lf[257],(C_word)C_a_i_list(&a,1,t1));}
else{
t2=((C_word*)t0)[3];
f_1734(2,t2,C_SCHEME_FALSE);}}

/* k2682 in k2676 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2689,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2720,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 395  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[256]))(3,*((C_word*)lf[256]+1),t3,((C_word*)t0)[2]);}

/* k2718 in k2682 in k2676 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2688 in k2682 in k2676 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2689,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2705,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* batch-driver.scm: 394  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[255]))(4,*((C_word*)lf[255]+1),t5,t6,lf[254]);}

/* k2703 in a2688 in k2682 in k2676 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* batch-driver.scm: 394  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),((C_word*)t0)[2],t2,t3);}

/* k2699 in a2688 in k2682 in k2676 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 392  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[253]))(5,*((C_word*)lf[253]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[254],t1);}

/* k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[83],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 398  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[86],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1755(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[250],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1755(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[251],((C_word*)t0)[22]);
t6=t3;
f_1755(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[252],((C_word*)t0)[22])));}}}}

/* k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1755,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 401  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[87]))(2,*((C_word*)lf[87]+1),((C_word*)t0)[22]);}
else{
if(C_truep((C_word)C_i_memq(lf[88],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 403  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[90]))(2,*((C_word*)lf[90]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 411  dribble */
t4=((C_word*)t0)[14];
f_1165(t4,t3,lf[248],(C_word)C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 406  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t3,C_SCHEME_TRUE);}}}}

/* k1781 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 407  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),((C_word*)t0)[2],lf[249]);}

/* k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 413  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[104]))(5,*((C_word*)lf[104]+1),t3,lf[243],lf[247],((C_word*)t0)[10]);}

/* k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 414  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[104]))(5,*((C_word*)lf[104]+1),t2,lf[243],lf[246],C_retrieve(lf[32]));}

/* k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 415  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[104]))(5,*((C_word*)lf[104]+1),t2,lf[243],lf[245],C_retrieve(lf[74]));}

/* k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 416  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[104]))(5,*((C_word*)lf[104]+1),t2,lf[243],lf[244],C_retrieve(lf[78]));}

/* k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[22],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 420  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[241]+1)))(4,*((C_word*)lf[241]+1),t4,C_retrieve(lf[242]),C_SCHEME_END_OF_LIST);}

/* k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 421  collect-options */
t4=((C_word*)t0)[2];
f_1367(t4,t3,lf[240]);}

/* k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 422  collect-options */
t3=((C_word*)t0)[2];
f_1367(t3,t2,lf[239]);}

/* k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 424  collect-options */
t4=((C_word*)t0)[2];
f_1367(t4,t3,lf[238]);}

/* k2650 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2660,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 426  collect-options */
t4=((C_word*)t0)[2];
f_1367(t4,t3,lf[237]);}

/* k2658 in k2650 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 423  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[210]+1)))(5,*((C_word*)lf[210]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 428  user-read-pass */
((C_proc2)C_retrieve_symbol_proc(lf[1]))(2,*((C_word*)lf[1]+1),t2);}

/* k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 430  dribble */
t4=((C_word*)t0)[20];
f_1165(t4,t3,lf[230],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2567(t6,t2,((C_word*)t0)[4]);}}

/* doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_2567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2567,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2578,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[231]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 440  check-and-open-input-file */
((C_proc3)C_retrieve_symbol_proc(lf[236]))(3,*((C_word*)lf[236]+1),t4,t3);}}

/* k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2608,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2645,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2644 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2645,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[233]));
t3=C_mutate((C_word*)lf[233]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2612 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2617,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 442  read-form */
t3=((C_word*)t0)[2];
f_1424(t3,t2,((C_word*)t0)[5]);}

/* k2615 in a2612 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2622(t5,((C_word*)t0)[2],t1);}

/* doloop640 in k2615 in a2612 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_2622(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2622,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 445  close-checked-input-file */
((C_proc4)C_retrieve_symbol_proc(lf[234]))(4,*((C_word*)lf[234]+1),t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2643,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 443  read-form */
t6=((C_word*)t0)[2];
f_1424(t6,t5,((C_word*)t0)[6]);}}

/* k2641 in doloop640 in k2615 in a2612 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2622(t2,((C_word*)t0)[2],t1);}

/* a2607 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[233]));
t3=C_mutate((C_word*)lf[233]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2597 in k2594 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2567(t3,((C_word*)t0)[2],t2);}

/* k2580 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 437  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[232]+1)))(3,*((C_word*)lf[232]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2584 in k2580 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2590,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[231]),((C_word*)t0)[2]);}

/* k2588 in k2584 in k2580 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 436  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[210]+1)))(5,*((C_word*)lf[210]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2576 in doloop611 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2556 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 431  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2560 in k2556 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1825(2,t3,t2);}

/* k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 449  user-preprocessor-pass */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2551,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 451  dribble */
t4=((C_word*)t0)[16];
f_1165(t4,t3,lf[229],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1831(t3,C_SCHEME_UNDEFINED);}}

/* k2549 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2553 in k2549 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1831(t3,t2);}

/* k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1831,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 454  print-expr */
t3=((C_word*)t0)[7];
f_1226(t3,t2,lf[227],lf[228],((C_word*)((C_word*)t0)[3])[1]);}

/* k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=f_1397(((C_word*)t0)[20]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1840(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 457  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),t4,C_retrieve(lf[223]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2526 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=C_mutate((C_word*)lf[223]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[226]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2546 in k2526 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[224],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[225],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1840(t7,t6);}

/* k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 459  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[210]+1)))(4,*((C_word*)lf[210]+1),t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2519 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[222]),t1);}

/* k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 460  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[221]))(2,*((C_word*)lf[221]+1),t2);}

/* k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[92]));
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],tmp=(C_word)a,a+=16,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2489,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[220]));}

/* a2488 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2489,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[212],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[217],t8));}

/* k2361 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2479,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[219]));}

/* a2478 in k2361 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2479,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[218],t3));}

/* k2365 in k2361 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[215]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[212],t3);
t5=(C_truep(C_retrieve(lf[199]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[212],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[216],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[213]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[217],t12);
t14=t2;
f_2371(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2371(t3,C_SCHEME_END_OF_LIST);}}

/* k2369 in k2365 in k2361 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_2371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2371,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2390,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[92]));}

/* a2389 in k2369 in k2365 in k2361 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2390,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[212],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[212],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[213]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[214],t11));}

/* k2373 in k2369 in k2365 in k2361 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[199]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 462  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[210]+1)))(9,*((C_word*)lf[210]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[211]);}

/* k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2356,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 483  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t5,lf[208],lf[209]);}

/* k2354 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 484  display-real-name-table */
((C_proc2)C_retrieve_symbol_proc(lf[207]))(2,*((C_word*)lf[207]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1855(2,t2,C_SCHEME_UNDEFINED);}}

/* k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 485  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t3,lf[205],lf[206]);}

/* k2348 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 486  display-line-number-database */
((C_proc2)C_retrieve_symbol_proc(lf[204]))(2,*((C_word*)lf[204]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1858(2,t2,C_SCHEME_UNDEFINED);}}

/* k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(C_retrieve(lf[202]))?C_retrieve(lf[199]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 489  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[194]))(5,*((C_word*)lf[194]+1),t2,lf[200],lf[203],C_retrieve(lf[199]));}
else{
t4=t2;
f_1861(2,t4,C_SCHEME_UNDEFINED);}}

/* k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(C_retrieve(lf[199]))?((C_word*)t0)[9]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 495  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[194]))(5,*((C_word*)lf[194]+1),t2,lf[200],lf[201],C_retrieve(lf[199]));}
else{
t4=t2;
f_1864(2,t4,C_SCHEME_UNDEFINED);}}

/* k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[150]))){
/* batch-driver.scm: 497  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t3,lf[198]);}
else{
t4=t3;
f_2329(2,t4,C_SCHEME_FALSE);}}

/* k2327 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 498  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[194]))(4,*((C_word*)lf[194]+1),((C_word*)t0)[2],lf[195],lf[196]);}
else{
t2=((C_word*)t0)[2];
f_1867(2,t2,C_SCHEME_UNDEFINED);}}

/* k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,C_retrieve(lf[93]));
t3=C_set_block_item(lf[93] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 505  end-time */
t5=((C_word*)t0)[15];
f_1407(t5,t4,lf[193]);}

/* k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 506  print-expr */
t3=((C_word*)t0)[2];
f_1226(t3,t2,lf[191],lf[192],((C_word*)((C_word*)t0)[4])[1]);}

/* k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_memq(lf[190],((C_word*)t0)[2]))){
/* batch-driver.scm: 508  exit */
((C_proc2)C_retrieve_symbol_proc(lf[126]))(2,*((C_word*)lf[126]+1),t2);}
else{
t3=t2;
f_1878(2,t3,C_SCHEME_UNDEFINED);}}

/* k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 510  user-pass */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2310,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 512  dribble */
t4=((C_word*)t0)[10];
f_1165(t4,t3,lf[189],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1884(2,t3,C_SCHEME_UNDEFINED);}}

/* k2308 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=f_1397(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2315 in k2308 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 515  end-time */
t3=((C_word*)t0)[3];
f_1407(t3,((C_word*)t0)[2],lf[188]);}

/* k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 517  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[186]+1)))(3,*((C_word*)lf[186]+1),t3,C_retrieve(lf[187]));}

/* k2305 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 517  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[181]))(3,*((C_word*)lf[181]+1),((C_word*)t0)[2],t1);}

/* k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1890,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 518  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t3,lf[184],lf[185]);}

/* k2298 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 519  pp */
((C_proc3)C_retrieve_symbol_proc(lf[183]))(3,*((C_word*)lf[183]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1890(2,t2,C_SCHEME_UNDEFINED);}}

/* k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[173]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[182]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1893(2,t3,C_SCHEME_UNDEFINED);}}

/* k2295 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 529  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[181]))(3,*((C_word*)lf[181]+1),((C_word*)t0)[2],t1);}

/* k2291 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2261 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2262,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 524  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[180]+1)))(3,*((C_word*)lf[180]+1),t5,t2);}

/* k2287 in a2261 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 524  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[178]))(5,*((C_word*)lf[178]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[179]);}

/* k2283 in a2261 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 523  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[177]))(5,*((C_word*)lf[177]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2264 in a2261 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 526  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2273 in k2264 in a2261 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 527  dribble */
t3=((C_word*)t0)[2];
f_1165(t3,t2,lf[175],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2276 in k2273 in k2264 in a2261 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 528  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 534  canonicalize-begin-body */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2255 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 533  build-node-graph */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],t1);}

/* k2251 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2245,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[169],lf[170],t2);}

/* f_2245 in k2251 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2245,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[168],t2,t3,t4));}

/* k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1899,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 535  user-pass-2 */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t2);}

/* k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[11],a[8]=t2,a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 537  dribble */
t4=((C_word*)t0)[10];
f_1165(t4,t3,lf[167],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1902(t3,C_SCHEME_UNDEFINED);}}

/* k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=f_1397(((C_word*)t0)[9]);
t3=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 540  analyze */
t5=((C_word*)t0)[2];
f_1430(t5,t4,lf[166],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2219 in k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 541  print-db */
t3=((C_word*)t0)[2];
f_1211(t3,t2,lf[165],lf[159],t1,C_fix(0));}

/* k2222 in k2219 in k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 542  end-time */
t3=((C_word*)t0)[3];
f_1407(t3,t2,lf[164]);}

/* k2225 in k2222 in k2219 in k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=f_1397(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 544  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2231 in k2225 in k2222 in k2219 in k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 545  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[163]);}

/* k2234 in k2231 in k2225 in k2222 in k2219 in k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 546  print-node */
t3=((C_word*)t0)[3];
f_1189(t3,t2,lf[161],lf[162],((C_word*)t0)[2]);}

/* k2237 in k2234 in k2231 in k2225 in k2222 in k2219 in k2212 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1902(t3,t2);}

/* k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1902,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[152]))){
t3=f_1397(((C_word*)t0)[14]);
t4=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 552  analyze */
t6=((C_word*)t0)[12];
f_1430(t6,t5,lf[160],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1905(t3,C_SCHEME_UNDEFINED);}}

/* k2190 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2195,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 553  print-db */
t3=((C_word*)t0)[2];
f_1211(t3,t2,lf[158],lf[159],t1,C_fix(0));}

/* k2193 in k2190 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 554  end-time */
t3=((C_word*)t0)[3];
f_1407(t3,t2,lf[157]);}

/* k2196 in k2193 in k2190 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=f_1397(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 556  perform-lambda-lifting! */
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2202 in k2196 in k2193 in k2190 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 557  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[155]);}

/* k2205 in k2202 in k2196 in k2193 in k2190 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 558  print-node */
t3=((C_word*)t0)[3];
f_1189(t3,t2,lf[153],lf[154],((C_word*)t0)[2]);}

/* k2208 in k2205 in k2202 in k2196 in k2193 in k2190 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1905(t3,t2);}

/* k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1905,NULL,2,t0,t1);}
t2=C_set_block_item(lf[42] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[94] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[95] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[150]))){
t6=t5;
f_1911(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2181,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2181 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2181,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2178 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* batch-driver.scm: 565  scan-toplevel-assignments */
((C_proc3)C_retrieve_symbol_proc(lf[151]))(3,*((C_word*)lf[151]+1),((C_word*)t0)[2],t2);}

/* k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=f_1397(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 568  perform-cps-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[149]))(3,*((C_word*)lf[149]+1),t3,((C_word*)t0)[2]);}

/* k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1920,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 569  end-time */
t3=((C_word*)t0)[12];
f_1407(t3,t2,lf[148]);}

/* k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 570  print-node */
t3=((C_word*)t0)[11];
f_1189(t3,t2,lf[146],lf[147],((C_word*)t0)[2]);}

/* k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t3,a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp));
t5=((C_word*)t3)[1];
f_1928(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1928,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1397(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=t3,a[16]=((C_word*)t0)[13],a[17]=t4,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 576  analyze */
t7=((C_word*)t0)[10];
f_1430(t7,t6,lf[145],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(C_retrieve(lf[96]))){
if(C_truep((C_word)C_i_memq(lf[143],C_retrieve(lf[32])))){
/* batch-driver.scm: 579  dump-undefined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t2,t1);}
else{
t3=t2;
f_1938(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1938(2,t3,C_SCHEME_UNDEFINED);}}

/* k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 581  end-time */
t4=((C_word*)t0)[12];
f_1407(t4,t3,lf[142]);}

/* k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 582  print-db */
t3=((C_word*)t0)[2];
f_1211(t3,t2,lf[140],lf[141],((C_word*)t0)[15],((C_word*)t0)[14]);}

/* k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_memq(lf[138],C_retrieve(lf[32])))){
/* batch-driver.scm: 584  print-program-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,((C_word*)t0)[15]);}
else{
t3=t2;
f_1948(2,t3,C_SCHEME_UNDEFINED);}}

/* k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
if(C_truep(((C_word*)t0)[18])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 587  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[104]))(5,*((C_word*)lf[104]+1),t2,lf[105],lf[110],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 611  print-node */
t3=((C_word*)t0)[10];
f_1189(t3,t2,lf[136],lf[137],((C_word*)t0)[16]);}}

/* k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[133]))){
t3=C_retrieve(lf[133]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 615  dribble */
t5=((C_word*)t0)[13];
f_1165(t5,t4,lf[135],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_2043(2,t3,C_SCHEME_UNDEFINED);}}

/* k2149 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 616  emit-global-inline-file */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=f_1397(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 619  perform-closure-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t3,((C_word*)t0)[2],((C_word*)t0)[14]);}

/* k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 620  end-time */
t3=((C_word*)t0)[11];
f_1407(t3,t2,lf[131]);}

/* k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 621  print-db */
t3=((C_word*)t0)[3];
f_1211(t3,t2,lf[129],lf[130],((C_word*)t0)[13],((C_word*)t0)[2]);}

/* k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[128]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2134(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2134(t4,C_SCHEME_FALSE);}}

/* k2132 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_2134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 623  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),((C_word*)t0)[2],lf[127]);}
else{
t2=((C_word*)t0)[2];
f_2058(2,t2,C_SCHEME_UNDEFINED);}}

/* k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 624  exit */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t2,C_fix(0));}
else{
t3=t2;
f_2061(2,t3,C_SCHEME_UNDEFINED);}}

/* k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 625  print-node */
t3=((C_word*)t0)[2];
f_1189(t3,t2,lf[124],lf[125],((C_word*)t0)[10]);}

/* k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=f_1397(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2078,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 630  end-time */
t7=((C_word*)t0)[6];
f_1407(t7,t6,lf[123]);}

/* k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=f_1397(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm: 633  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[121]+1)))(3,*((C_word*)lf[121]+1),t3,((C_word*)t0)[8]);}
else{
/* batch-driver.scm: 633  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[122]+1)))(2,*((C_word*)lf[122]+1),t3);}}

/* k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 634  dribble */
t3=((C_word*)t0)[11];
f_1165(t3,t2,lf[120],(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 635  generate-code */
((C_proc9)C_retrieve_symbol_proc(lf[119]))(9,*((C_word*)lf[119]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2092 in k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 636  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2097(2,t3,C_SCHEME_UNDEFINED);}}

/* k2095 in k2092 in k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 637  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[117]);}

/* k2098 in k2095 in k2092 in k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[114],C_retrieve(lf[32])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 638  ##sys#stop-timer */
t4=*((C_word*)lf[116]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2103(2,t3,C_SCHEME_UNDEFINED);}}

/* k2117 in k2098 in k2095 in k2092 in k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 638  ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[115]))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* k2101 in k2098 in k2095 in k2092 in k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 639  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[113]))(2,*((C_word*)lf[113]+1),t2);}

/* k2104 in k2101 in k2098 in k2095 in k2092 in k2089 in k2086 in k2080 in a2077 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 640  dribble */
t2=((C_word*)t0)[3];
f_1165(t2,((C_word*)t0)[2],lf[112],C_SCHEME_END_OF_LIST);}

/* a2071 in k2062 in k2059 in k2056 in k2053 in k2050 in k2047 in k2041 in k2038 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
/* batch-driver.scm: 629  prepare-for-code-generation */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=f_1397(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1968,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 592  end-time */
t5=((C_word*)t0)[4];
f_1407(t5,t4,lf[109]);}

/* k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 593  print-node */
t3=((C_word*)t0)[2];
f_1189(t3,t2,lf[107],lf[108],((C_word*)t0)[6]);}

/* k1973 in k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 595  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1928(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[98]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[99]))){
t3=f_1397(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 602  analyze */
t5=((C_word*)t0)[2];
f_1430(t5,t4,lf[103],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 608  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1928(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 597  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t3,lf[105],lf[106]);}}}

/* k1992 in k1973 in k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[98] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 599  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1928(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2009 in k1973 in k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 603  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[102]);}

/* k2012 in k2009 in k1973 in k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=f_1397(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 605  transform-direct-lambdas! */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2018 in k2012 in k2009 in k1973 in k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2023,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 606  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[100]);}

/* k2021 in k2018 in k2012 in k2009 in k1973 in k1970 in a1967 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 607  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1928(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1961 in k1952 in k1946 in k1943 in k1940 in k1936 in k1933 in loop in k1921 in k1918 in k1915 in k1909 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1865 in k1862 in k1859 in k1856 in k1853 in k1850 in k1844 in k1841 in k1838 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1800 in k1797 in k1794 in k1791 in k1787 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
/* batch-driver.scm: 591  perform-high-level-optimizations */
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1772 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 403  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),((C_word*)t0)[2],t1);}

/* k1765 in k1753 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 404  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[84]+1)))(2,*((C_word*)lf[84]+1),((C_word*)t0)[2]);}

/* k1741 in k1732 in k1729 in k1726 in k1723 in k1720 in k1717 in k1706 in k1702 in k1698 in k1694 in k1690 in k1686 in k1683 in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 399  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[84]+1)))(2,*((C_word*)lf[84]+1),((C_word*)t0)[2]);}

/* ids in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1673,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1681,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 338  collect-options */
t7=((C_word*)t0)[2];
f_1367(t7,t6,t2);}

/* k1679 in ids in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 336  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1672 in ids in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1673,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),t1,t2,lf[72]);}

/* k1669 in ids in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1665 in ids in k1655 in k1652 in k1648 in k1640 in k1636 in k1633 in k1630 in k1627 in k1620 in k1617 in k1614 in k1610 in k1607 in k1601 in k1598 in k1595 in k1592 in k1586 in k1580 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1549 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1517 in k1513 in k1510 in k1507 in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 333  lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],*((C_word*)lf[68]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1430,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1432,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no305353 */
t8=t7;
f_1460(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf306349 */
t10=t6;
f_1455(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body303312 */
t12=t5;
f_1432(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[55],t11);}}}}

/* def-no305 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1460,NULL,2,t0,t1);}
/* def-contf306349 */
t2=((C_word*)t0)[2];
f_1455(t2,t1,C_fix(0));}

/* def-contf306 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1455,NULL,3,t0,t1,t2);}
/* body303312 */
t3=((C_word*)t0)[2];
f_1432(t3,t1,t2,C_SCHEME_TRUE);}

/* body303 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1432(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1432,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1436,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 204  analyze-expression */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t4,((C_word*)t0)[2]);}

/* k1434 in body303 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1439,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 206  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1439(2,t3,C_SCHEME_UNDEFINED);}}

/* a1449 in k1434 in body303 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1450,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[52]))(6,*((C_word*)lf[52]+1),t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1443 in k1434 in body303 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1444,4,t0,t1,t2,t3);}
/* ##compiler#get */
((C_proc5)C_retrieve_symbol_proc(lf[51]))(5,*((C_word*)lf[51]+1),t1,((C_word*)t0)[2],t2,t3);}

/* k1437 in k1434 in body303 in analyze in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1424,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 200  ##sys#read */
((C_proc4)C_retrieve_symbol_proc(lf[50]))(4,*((C_word*)lf[50]+1),t1,t2,((C_word*)t0)[2]);}

/* end-time in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1407(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1407,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 197  printf */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t1,lf[49],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static C_word C_fcall f_1397(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1367,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1373(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1373,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 189  option-arg */
f_1060(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1385 in loop in collect-options in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1391,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 189  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1373(t4,t2,t3);}

/* k1389 in k1385 in loop in collect-options in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1287(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1287,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 180  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 182  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 183  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 184  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1354 in arg-val in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 183  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1350 in arg-val in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1297(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1334 in arg-val in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1326 in arg-val in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1297(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1295 in arg-val in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 185  quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1238,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1242,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[46]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1284,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1284 in infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1284,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1240 in infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[45],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1248(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1248(t5,C_SCHEME_FALSE);}}

/* k1246 in k1240 in infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1259,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 172  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t4,C_retrieve(lf[42]),t5);}
else{
t2=((C_word*)t0)[3];
f_1245(2,t2,C_SCHEME_UNDEFINED);}}

/* k1261 in k1246 in k1240 in infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 171  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1257 in k1246 in k1240 in infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 168  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[3],C_retrieve(lf[42]),((C_word*)t0)[2],t1);}

/* k1243 in k1240 in infohook in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1226,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 162  print-header */
t6=((C_word*)t0)[2];
f_1174(t6,t5,t2,t3);}

/* k1231 in print-expr in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[36]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1211,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1218,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 157  print-header */
t7=((C_word*)t0)[2];
f_1174(t7,t6,t2,t3);}

/* k1216 in print-db in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 158  printf */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[39],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1219 in k1216 in print-db in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 159  display-analysis-database */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1189,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 151  print-header */
t6=((C_word*)t0)[2];
f_1174(t6,t5,t2,t3);}

/* k1194 in print-node in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 153  dump-nodes */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 154  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1207 in k1194 in print-node in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 154  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* print-header in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1174(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1174,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1178,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 144  dribble */
t5=((C_word*)t0)[2];
f_1165(t5,t4,lf[34],(C_word)C_a_i_list(&a,1,t2));}

/* k1176 in print-header in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[32])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 147  printf */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[33],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1185 in k1176 in print-header in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1116 in k1110 in k1107 in k3241 in k1091 in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1165(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1165,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 141  printf */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t1,lf[31],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* option-arg in compile-source-file in k1053 in k1049 in k1045 in k1041 in k1037 in k1033 in k1028 in k1025 in k1022 in k1019 in k1016 in k1013 */
static void C_fcall f_1060(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1060,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 94   quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t1,lf[8],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 97   quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t1,lf[9],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[319] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_1015:batch_driver_scm",(void*)f_1015},
{"f_1018:batch_driver_scm",(void*)f_1018},
{"f_1021:batch_driver_scm",(void*)f_1021},
{"f_1024:batch_driver_scm",(void*)f_1024},
{"f_1027:batch_driver_scm",(void*)f_1027},
{"f_1030:batch_driver_scm",(void*)f_1030},
{"f_1035:batch_driver_scm",(void*)f_1035},
{"f_1039:batch_driver_scm",(void*)f_1039},
{"f_1043:batch_driver_scm",(void*)f_1043},
{"f_1047:batch_driver_scm",(void*)f_1047},
{"f_1051:batch_driver_scm",(void*)f_1051},
{"f_1055:batch_driver_scm",(void*)f_1055},
{"f_1057:batch_driver_scm",(void*)f_1057},
{"f_1093:batch_driver_scm",(void*)f_1093},
{"f_3262:batch_driver_scm",(void*)f_3262},
{"f_3251:batch_driver_scm",(void*)f_3251},
{"f_3247:batch_driver_scm",(void*)f_3247},
{"f_3243:batch_driver_scm",(void*)f_3243},
{"f_3232:batch_driver_scm",(void*)f_3232},
{"f_3210:batch_driver_scm",(void*)f_3210},
{"f_1109:batch_driver_scm",(void*)f_1109},
{"f_3204:batch_driver_scm",(void*)f_3204},
{"f_3200:batch_driver_scm",(void*)f_3200},
{"f_1112:batch_driver_scm",(void*)f_1112},
{"f_1118:batch_driver_scm",(void*)f_1118},
{"f_3181:batch_driver_scm",(void*)f_3181},
{"f_3177:batch_driver_scm",(void*)f_3177},
{"f_3173:batch_driver_scm",(void*)f_3173},
{"f_1509:batch_driver_scm",(void*)f_1509},
{"f_1512:batch_driver_scm",(void*)f_1512},
{"f_1515:batch_driver_scm",(void*)f_1515},
{"f_3159:batch_driver_scm",(void*)f_3159},
{"f_3137:batch_driver_scm",(void*)f_3137},
{"f_3155:batch_driver_scm",(void*)f_3155},
{"f_3143:batch_driver_scm",(void*)f_3143},
{"f_1519:batch_driver_scm",(void*)f_1519},
{"f_3135:batch_driver_scm",(void*)f_3135},
{"f_3119:batch_driver_scm",(void*)f_3119},
{"f_3127:batch_driver_scm",(void*)f_3127},
{"f_3131:batch_driver_scm",(void*)f_3131},
{"f_1527:batch_driver_scm",(void*)f_1527},
{"f_1530:batch_driver_scm",(void*)f_1530},
{"f_1533:batch_driver_scm",(void*)f_1533},
{"f_1536:batch_driver_scm",(void*)f_1536},
{"f_1539:batch_driver_scm",(void*)f_1539},
{"f_1542:batch_driver_scm",(void*)f_1542},
{"f_1545:batch_driver_scm",(void*)f_1545},
{"f_1548:batch_driver_scm",(void*)f_1548},
{"f_1551:batch_driver_scm",(void*)f_1551},
{"f_3078:batch_driver_scm",(void*)f_3078},
{"f_1555:batch_driver_scm",(void*)f_1555},
{"f_3073:batch_driver_scm",(void*)f_3073},
{"f_1558:batch_driver_scm",(void*)f_1558},
{"f_1561:batch_driver_scm",(void*)f_1561},
{"f_1564:batch_driver_scm",(void*)f_1564},
{"f_1567:batch_driver_scm",(void*)f_1567},
{"f_1570:batch_driver_scm",(void*)f_1570},
{"f_1573:batch_driver_scm",(void*)f_1573},
{"f_1576:batch_driver_scm",(void*)f_1576},
{"f_1579:batch_driver_scm",(void*)f_1579},
{"f_1582:batch_driver_scm",(void*)f_1582},
{"f_3032:batch_driver_scm",(void*)f_3032},
{"f_1588:batch_driver_scm",(void*)f_1588},
{"f_3017:batch_driver_scm",(void*)f_3017},
{"f_3020:batch_driver_scm",(void*)f_3020},
{"f_3023:batch_driver_scm",(void*)f_3023},
{"f_1594:batch_driver_scm",(void*)f_1594},
{"f_3007:batch_driver_scm",(void*)f_3007},
{"f_3010:batch_driver_scm",(void*)f_3010},
{"f_1597:batch_driver_scm",(void*)f_1597},
{"f_1600:batch_driver_scm",(void*)f_1600},
{"f_2965:batch_driver_scm",(void*)f_2965},
{"f_1603:batch_driver_scm",(void*)f_1603},
{"f_2962:batch_driver_scm",(void*)f_2962},
{"f_2958:batch_driver_scm",(void*)f_2958},
{"f_1609:batch_driver_scm",(void*)f_1609},
{"f_1612:batch_driver_scm",(void*)f_1612},
{"f_2942:batch_driver_scm",(void*)f_2942},
{"f_2934:batch_driver_scm",(void*)f_2934},
{"f_2932:batch_driver_scm",(void*)f_2932},
{"f_1616:batch_driver_scm",(void*)f_1616},
{"f_1619:batch_driver_scm",(void*)f_1619},
{"f_2924:batch_driver_scm",(void*)f_2924},
{"f_2916:batch_driver_scm",(void*)f_2916},
{"f_2914:batch_driver_scm",(void*)f_2914},
{"f_1622:batch_driver_scm",(void*)f_1622},
{"f_1629:batch_driver_scm",(void*)f_1629},
{"f_1632:batch_driver_scm",(void*)f_1632},
{"f_1635:batch_driver_scm",(void*)f_1635},
{"f_2899:batch_driver_scm",(void*)f_2899},
{"f_2907:batch_driver_scm",(void*)f_2907},
{"f_1638:batch_driver_scm",(void*)f_1638},
{"f_1642:batch_driver_scm",(void*)f_1642},
{"f_1650:batch_driver_scm",(void*)f_1650},
{"f_1654:batch_driver_scm",(void*)f_1654},
{"f_2885:batch_driver_scm",(void*)f_2885},
{"f_2881:batch_driver_scm",(void*)f_2881},
{"f_2865:batch_driver_scm",(void*)f_2865},
{"f_1657:batch_driver_scm",(void*)f_1657},
{"f_2858:batch_driver_scm",(void*)f_2858},
{"f_2838:batch_driver_scm",(void*)f_2838},
{"f_2836:batch_driver_scm",(void*)f_2836},
{"f_1685:batch_driver_scm",(void*)f_1685},
{"f_1688:batch_driver_scm",(void*)f_1688},
{"f_2815:batch_driver_scm",(void*)f_2815},
{"f_1692:batch_driver_scm",(void*)f_1692},
{"f_2808:batch_driver_scm",(void*)f_2808},
{"f_1696:batch_driver_scm",(void*)f_1696},
{"f_2801:batch_driver_scm",(void*)f_2801},
{"f_1700:batch_driver_scm",(void*)f_1700},
{"f_2794:batch_driver_scm",(void*)f_2794},
{"f_1704:batch_driver_scm",(void*)f_1704},
{"f_2774:batch_driver_scm",(void*)f_2774},
{"f_1708:batch_driver_scm",(void*)f_1708},
{"f_1719:batch_driver_scm",(void*)f_1719},
{"f_1722:batch_driver_scm",(void*)f_1722},
{"f_1725:batch_driver_scm",(void*)f_1725},
{"f_2733:batch_driver_scm",(void*)f_2733},
{"f_1728:batch_driver_scm",(void*)f_1728},
{"f_1731:batch_driver_scm",(void*)f_1731},
{"f_2724:batch_driver_scm",(void*)f_2724},
{"f_2678:batch_driver_scm",(void*)f_2678},
{"f_2684:batch_driver_scm",(void*)f_2684},
{"f_2720:batch_driver_scm",(void*)f_2720},
{"f_2689:batch_driver_scm",(void*)f_2689},
{"f_2705:batch_driver_scm",(void*)f_2705},
{"f_2701:batch_driver_scm",(void*)f_2701},
{"f_1734:batch_driver_scm",(void*)f_1734},
{"f_1755:batch_driver_scm",(void*)f_1755},
{"f_1783:batch_driver_scm",(void*)f_1783},
{"f_1789:batch_driver_scm",(void*)f_1789},
{"f_1793:batch_driver_scm",(void*)f_1793},
{"f_1796:batch_driver_scm",(void*)f_1796},
{"f_1799:batch_driver_scm",(void*)f_1799},
{"f_1802:batch_driver_scm",(void*)f_1802},
{"f_1810:batch_driver_scm",(void*)f_1810},
{"f_1813:batch_driver_scm",(void*)f_1813},
{"f_1816:batch_driver_scm",(void*)f_1816},
{"f_2652:batch_driver_scm",(void*)f_2652},
{"f_2660:batch_driver_scm",(void*)f_2660},
{"f_1819:batch_driver_scm",(void*)f_1819},
{"f_1822:batch_driver_scm",(void*)f_1822},
{"f_2567:batch_driver_scm",(void*)f_2567},
{"f_2596:batch_driver_scm",(void*)f_2596},
{"f_2645:batch_driver_scm",(void*)f_2645},
{"f_2613:batch_driver_scm",(void*)f_2613},
{"f_2617:batch_driver_scm",(void*)f_2617},
{"f_2622:batch_driver_scm",(void*)f_2622},
{"f_2643:batch_driver_scm",(void*)f_2643},
{"f_2608:batch_driver_scm",(void*)f_2608},
{"f_2599:batch_driver_scm",(void*)f_2599},
{"f_2582:batch_driver_scm",(void*)f_2582},
{"f_2586:batch_driver_scm",(void*)f_2586},
{"f_2590:batch_driver_scm",(void*)f_2590},
{"f_2578:batch_driver_scm",(void*)f_2578},
{"f_2558:batch_driver_scm",(void*)f_2558},
{"f_2562:batch_driver_scm",(void*)f_2562},
{"f_1825:batch_driver_scm",(void*)f_1825},
{"f_1828:batch_driver_scm",(void*)f_1828},
{"f_2551:batch_driver_scm",(void*)f_2551},
{"f_2555:batch_driver_scm",(void*)f_2555},
{"f_1831:batch_driver_scm",(void*)f_1831},
{"f_1834:batch_driver_scm",(void*)f_1834},
{"f_2528:batch_driver_scm",(void*)f_2528},
{"f_2548:batch_driver_scm",(void*)f_2548},
{"f_1840:batch_driver_scm",(void*)f_1840},
{"f_2521:batch_driver_scm",(void*)f_2521},
{"f_1843:batch_driver_scm",(void*)f_1843},
{"f_1846:batch_driver_scm",(void*)f_1846},
{"f_2489:batch_driver_scm",(void*)f_2489},
{"f_2363:batch_driver_scm",(void*)f_2363},
{"f_2479:batch_driver_scm",(void*)f_2479},
{"f_2367:batch_driver_scm",(void*)f_2367},
{"f_2371:batch_driver_scm",(void*)f_2371},
{"f_2390:batch_driver_scm",(void*)f_2390},
{"f_2375:batch_driver_scm",(void*)f_2375},
{"f_1852:batch_driver_scm",(void*)f_1852},
{"f_2356:batch_driver_scm",(void*)f_2356},
{"f_1855:batch_driver_scm",(void*)f_1855},
{"f_2350:batch_driver_scm",(void*)f_2350},
{"f_1858:batch_driver_scm",(void*)f_1858},
{"f_1861:batch_driver_scm",(void*)f_1861},
{"f_1864:batch_driver_scm",(void*)f_1864},
{"f_2329:batch_driver_scm",(void*)f_2329},
{"f_1867:batch_driver_scm",(void*)f_1867},
{"f_1872:batch_driver_scm",(void*)f_1872},
{"f_1875:batch_driver_scm",(void*)f_1875},
{"f_1878:batch_driver_scm",(void*)f_1878},
{"f_1881:batch_driver_scm",(void*)f_1881},
{"f_2310:batch_driver_scm",(void*)f_2310},
{"f_2317:batch_driver_scm",(void*)f_2317},
{"f_1884:batch_driver_scm",(void*)f_1884},
{"f_2307:batch_driver_scm",(void*)f_2307},
{"f_1887:batch_driver_scm",(void*)f_1887},
{"f_2300:batch_driver_scm",(void*)f_2300},
{"f_1890:batch_driver_scm",(void*)f_1890},
{"f_2297:batch_driver_scm",(void*)f_2297},
{"f_2293:batch_driver_scm",(void*)f_2293},
{"f_2262:batch_driver_scm",(void*)f_2262},
{"f_2289:batch_driver_scm",(void*)f_2289},
{"f_2285:batch_driver_scm",(void*)f_2285},
{"f_2266:batch_driver_scm",(void*)f_2266},
{"f_2275:batch_driver_scm",(void*)f_2275},
{"f_2278:batch_driver_scm",(void*)f_2278},
{"f_1893:batch_driver_scm",(void*)f_1893},
{"f_2257:batch_driver_scm",(void*)f_2257},
{"f_2253:batch_driver_scm",(void*)f_2253},
{"f_2245:batch_driver_scm",(void*)f_2245},
{"f_1896:batch_driver_scm",(void*)f_1896},
{"f_1899:batch_driver_scm",(void*)f_1899},
{"f_2214:batch_driver_scm",(void*)f_2214},
{"f_2221:batch_driver_scm",(void*)f_2221},
{"f_2224:batch_driver_scm",(void*)f_2224},
{"f_2227:batch_driver_scm",(void*)f_2227},
{"f_2233:batch_driver_scm",(void*)f_2233},
{"f_2236:batch_driver_scm",(void*)f_2236},
{"f_2239:batch_driver_scm",(void*)f_2239},
{"f_1902:batch_driver_scm",(void*)f_1902},
{"f_2192:batch_driver_scm",(void*)f_2192},
{"f_2195:batch_driver_scm",(void*)f_2195},
{"f_2198:batch_driver_scm",(void*)f_2198},
{"f_2204:batch_driver_scm",(void*)f_2204},
{"f_2207:batch_driver_scm",(void*)f_2207},
{"f_2210:batch_driver_scm",(void*)f_2210},
{"f_1905:batch_driver_scm",(void*)f_1905},
{"f_2181:batch_driver_scm",(void*)f_2181},
{"f_2180:batch_driver_scm",(void*)f_2180},
{"f_1911:batch_driver_scm",(void*)f_1911},
{"f_1917:batch_driver_scm",(void*)f_1917},
{"f_1920:batch_driver_scm",(void*)f_1920},
{"f_1923:batch_driver_scm",(void*)f_1923},
{"f_1928:batch_driver_scm",(void*)f_1928},
{"f_1935:batch_driver_scm",(void*)f_1935},
{"f_1938:batch_driver_scm",(void*)f_1938},
{"f_1942:batch_driver_scm",(void*)f_1942},
{"f_1945:batch_driver_scm",(void*)f_1945},
{"f_1948:batch_driver_scm",(void*)f_1948},
{"f_2040:batch_driver_scm",(void*)f_2040},
{"f_2151:batch_driver_scm",(void*)f_2151},
{"f_2043:batch_driver_scm",(void*)f_2043},
{"f_2049:batch_driver_scm",(void*)f_2049},
{"f_2052:batch_driver_scm",(void*)f_2052},
{"f_2055:batch_driver_scm",(void*)f_2055},
{"f_2134:batch_driver_scm",(void*)f_2134},
{"f_2058:batch_driver_scm",(void*)f_2058},
{"f_2061:batch_driver_scm",(void*)f_2061},
{"f_2064:batch_driver_scm",(void*)f_2064},
{"f_2078:batch_driver_scm",(void*)f_2078},
{"f_2082:batch_driver_scm",(void*)f_2082},
{"f_2088:batch_driver_scm",(void*)f_2088},
{"f_2091:batch_driver_scm",(void*)f_2091},
{"f_2094:batch_driver_scm",(void*)f_2094},
{"f_2097:batch_driver_scm",(void*)f_2097},
{"f_2100:batch_driver_scm",(void*)f_2100},
{"f_2119:batch_driver_scm",(void*)f_2119},
{"f_2103:batch_driver_scm",(void*)f_2103},
{"f_2106:batch_driver_scm",(void*)f_2106},
{"f_2072:batch_driver_scm",(void*)f_2072},
{"f_1954:batch_driver_scm",(void*)f_1954},
{"f_1968:batch_driver_scm",(void*)f_1968},
{"f_1972:batch_driver_scm",(void*)f_1972},
{"f_1975:batch_driver_scm",(void*)f_1975},
{"f_1994:batch_driver_scm",(void*)f_1994},
{"f_2011:batch_driver_scm",(void*)f_2011},
{"f_2014:batch_driver_scm",(void*)f_2014},
{"f_2020:batch_driver_scm",(void*)f_2020},
{"f_2023:batch_driver_scm",(void*)f_2023},
{"f_1962:batch_driver_scm",(void*)f_1962},
{"f_1774:batch_driver_scm",(void*)f_1774},
{"f_1767:batch_driver_scm",(void*)f_1767},
{"f_1743:batch_driver_scm",(void*)f_1743},
{"f_1659:batch_driver_scm",(void*)f_1659},
{"f_1681:batch_driver_scm",(void*)f_1681},
{"f_1673:batch_driver_scm",(void*)f_1673},
{"f_1671:batch_driver_scm",(void*)f_1671},
{"f_1667:batch_driver_scm",(void*)f_1667},
{"f_1430:batch_driver_scm",(void*)f_1430},
{"f_1460:batch_driver_scm",(void*)f_1460},
{"f_1455:batch_driver_scm",(void*)f_1455},
{"f_1432:batch_driver_scm",(void*)f_1432},
{"f_1436:batch_driver_scm",(void*)f_1436},
{"f_1450:batch_driver_scm",(void*)f_1450},
{"f_1444:batch_driver_scm",(void*)f_1444},
{"f_1439:batch_driver_scm",(void*)f_1439},
{"f_1424:batch_driver_scm",(void*)f_1424},
{"f_1407:batch_driver_scm",(void*)f_1407},
{"f_1397:batch_driver_scm",(void*)f_1397},
{"f_1367:batch_driver_scm",(void*)f_1367},
{"f_1373:batch_driver_scm",(void*)f_1373},
{"f_1387:batch_driver_scm",(void*)f_1387},
{"f_1391:batch_driver_scm",(void*)f_1391},
{"f_1287:batch_driver_scm",(void*)f_1287},
{"f_1356:batch_driver_scm",(void*)f_1356},
{"f_1352:batch_driver_scm",(void*)f_1352},
{"f_1336:batch_driver_scm",(void*)f_1336},
{"f_1328:batch_driver_scm",(void*)f_1328},
{"f_1297:batch_driver_scm",(void*)f_1297},
{"f_1238:batch_driver_scm",(void*)f_1238},
{"f_1284:batch_driver_scm",(void*)f_1284},
{"f_1242:batch_driver_scm",(void*)f_1242},
{"f_1248:batch_driver_scm",(void*)f_1248},
{"f_1263:batch_driver_scm",(void*)f_1263},
{"f_1259:batch_driver_scm",(void*)f_1259},
{"f_1245:batch_driver_scm",(void*)f_1245},
{"f_1226:batch_driver_scm",(void*)f_1226},
{"f_1233:batch_driver_scm",(void*)f_1233},
{"f_1211:batch_driver_scm",(void*)f_1211},
{"f_1218:batch_driver_scm",(void*)f_1218},
{"f_1221:batch_driver_scm",(void*)f_1221},
{"f_1189:batch_driver_scm",(void*)f_1189},
{"f_1196:batch_driver_scm",(void*)f_1196},
{"f_1209:batch_driver_scm",(void*)f_1209},
{"f_1174:batch_driver_scm",(void*)f_1174},
{"f_1178:batch_driver_scm",(void*)f_1178},
{"f_1187:batch_driver_scm",(void*)f_1187},
{"f_1165:batch_driver_scm",(void*)f_1165},
{"f_1060:batch_driver_scm",(void*)f_1060},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
