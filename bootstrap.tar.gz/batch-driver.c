/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-07 15:24
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[356];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_fcall f_3228(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_fcall f_1121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_fcall f_1512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_fcall f_1527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_fcall f_1533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_fcall f_1539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_fcall f_1542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_fcall f_1545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_fcall f_1548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_fcall f_1558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_fcall f_1564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_fcall f_1567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_fcall f_1570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_fcall f_1576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_fcall f_1579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_fcall f_1585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_fcall f_1591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_fcall f_1616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_fcall f_1651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_fcall f_1682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_fcall f_1743(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_fcall f_2637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_fcall f_1822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_fcall f_1831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_fcall f_2380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_fcall f_1893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_fcall f_1896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_fcall f_1919(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_fcall f_2131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_fcall f_1653(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_fcall f_1430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1460)
static void C_fcall f_1460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_fcall f_1455(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1432)
static void C_fcall f_1432(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1407)
static void C_fcall f_1407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1397)
static C_word C_fcall f_1397(C_word t0);
C_noret_decl(f_1367)
static void C_fcall f_1367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1373)
static void C_fcall f_1373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_fcall f_1248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_fcall f_1211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_fcall f_1171(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_fcall f_1063(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3228)
static void C_fcall trf_3228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3228(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3228(t0,t1);}

C_noret_decl(trf_1121)
static void C_fcall trf_1121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1121(t0,t1);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1509(t0,t1);}

C_noret_decl(trf_1512)
static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1512(t0,t1);}

C_noret_decl(trf_1527)
static void C_fcall trf_1527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1527(t0,t1);}

C_noret_decl(trf_1533)
static void C_fcall trf_1533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1533(t0,t1);}

C_noret_decl(trf_1539)
static void C_fcall trf_1539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1539(t0,t1);}

C_noret_decl(trf_1542)
static void C_fcall trf_1542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1542(t0,t1);}

C_noret_decl(trf_1545)
static void C_fcall trf_1545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1545(t0,t1);}

C_noret_decl(trf_1548)
static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1548(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1555(t0,t1);}

C_noret_decl(trf_1558)
static void C_fcall trf_1558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1558(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1564)
static void C_fcall trf_1564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1564(t0,t1);}

C_noret_decl(trf_1567)
static void C_fcall trf_1567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1567(t0,t1);}

C_noret_decl(trf_1570)
static void C_fcall trf_1570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1570(t0,t1);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1573(t0,t1);}

C_noret_decl(trf_1576)
static void C_fcall trf_1576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1576(t0,t1);}

C_noret_decl(trf_1579)
static void C_fcall trf_1579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1579(t0,t1);}

C_noret_decl(trf_1585)
static void C_fcall trf_1585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1585(t0,t1);}

C_noret_decl(trf_1591)
static void C_fcall trf_1591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1591(t0,t1);}

C_noret_decl(trf_1616)
static void C_fcall trf_1616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1616(t0,t1);}

C_noret_decl(trf_1651)
static void C_fcall trf_1651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1651(t0,t1);}

C_noret_decl(trf_1682)
static void C_fcall trf_1682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1682(t0,t1);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1716(t0,t1);}

C_noret_decl(trf_1743)
static void C_fcall trf_1743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1743(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1743(t0,t1);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2582(t0,t1,t2);}

C_noret_decl(trf_2637)
static void C_fcall trf_2637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2637(t0,t1,t2);}

C_noret_decl(trf_1822)
static void C_fcall trf_1822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1822(t0,t1);}

C_noret_decl(trf_1831)
static void C_fcall trf_1831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1831(t0,t1);}

C_noret_decl(trf_2380)
static void C_fcall trf_2380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2380(t0,t1);}

C_noret_decl(trf_1893)
static void C_fcall trf_1893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1893(t0,t1);}

C_noret_decl(trf_1896)
static void C_fcall trf_1896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1896(t0,t1);}

C_noret_decl(trf_1919)
static void C_fcall trf_1919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1919(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1919(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2131)
static void C_fcall trf_2131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2131(t0,t1);}

C_noret_decl(trf_1653)
static void C_fcall trf_1653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1653(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1653(t0,t1,t2);}

C_noret_decl(trf_1430)
static void C_fcall trf_1430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1430(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1430(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1460)
static void C_fcall trf_1460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1460(t0,t1);}

C_noret_decl(trf_1455)
static void C_fcall trf_1455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1455(t0,t1,t2);}

C_noret_decl(trf_1432)
static void C_fcall trf_1432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1432(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1432(t0,t1,t2,t3);}

C_noret_decl(trf_1424)
static void C_fcall trf_1424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1424(t0,t1,t2);}

C_noret_decl(trf_1407)
static void C_fcall trf_1407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1407(t0,t1,t2);}

C_noret_decl(trf_1367)
static void C_fcall trf_1367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1367(t0,t1,t2);}

C_noret_decl(trf_1373)
static void C_fcall trf_1373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1373(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1373(t0,t1,t2);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1287(t0,t1);}

C_noret_decl(trf_1248)
static void C_fcall trf_1248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1248(t0,t1);}

C_noret_decl(trf_1226)
static void C_fcall trf_1226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1226(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1226(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1211)
static void C_fcall trf_1211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1211(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1211(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1189)
static void C_fcall trf_1189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1189(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1189(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1171)
static void C_fcall trf_1171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1171(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1171(t0,t1,t2,t3);}

C_noret_decl(trf_1063)
static void C_fcall trf_1063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1063(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2720)){
C_save(t1);
C_rereclaim2(2720*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,356);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],11,"user-pass-2");
lf[5]=C_h_intern(&lf[5],23,"user-post-analysis-pass");
lf[6]=C_h_intern(&lf[6],19,"compile-source-file");
lf[7]=C_h_intern(&lf[7],4,"quit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],26,"\010compilerexplicit-use-flag");
lf[12]=C_h_intern(&lf[12],12,"\004coredeclare");
lf[13]=C_h_intern(&lf[13],7,"verbose");
lf[14]=C_h_intern(&lf[14],11,"output-file");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[20]=C_h_intern(&lf[20],9,"heap-size");
lf[21]=C_h_intern(&lf[21],17,"heap-initial-size");
lf[22]=C_h_intern(&lf[22],11,"heap-growth");
lf[23]=C_h_intern(&lf[23],14,"heap-shrinkage");
lf[24]=C_h_intern(&lf[24],13,"keyword-style");
lf[25]=C_h_intern(&lf[25],4,"unit");
lf[26]=C_h_intern(&lf[26],12,"analyze-only");
lf[27]=C_h_intern(&lf[27],7,"dynamic");
lf[28]=C_h_intern(&lf[28],5,"quiet");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],10,"stack-size");
lf[31]=C_h_intern(&lf[31],26,"\010compilerdebugging-chicken");
lf[32]=C_h_intern(&lf[32],6,"printf");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[35]=C_h_intern(&lf[35],19,"\010compilerdump-nodes");
lf[36]=C_h_intern(&lf[36],12,"pretty-print");
lf[37]=C_h_intern(&lf[37],30,"\010compilerbuild-expression-tree");
lf[38]=C_h_intern(&lf[38],34,"\010compilerdisplay-analysis-database");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[40]=C_h_intern(&lf[40],12,"\003sysfor-each");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_h_intern(&lf[42],24,"\003sysline-number-database");
lf[43]=C_h_intern(&lf[43],10,"alist-cons");
lf[44]=C_h_intern(&lf[44],18,"\003syshash-table-ref");
lf[45]=C_h_intern(&lf[45],9,"list-info");
lf[46]=C_h_intern(&lf[46],26,"\003sysdefault-read-info-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[50]=C_h_intern(&lf[50],8,"\003sysread");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],15,"lset-difference");
lf[68]=C_h_intern(&lf[68],3,"eq\077");
lf[69]=C_h_intern(&lf[69],7,"\003sysmap");
lf[70]=C_h_intern(&lf[70],14,"string->symbol");
lf[71]=C_h_intern(&lf[71],12,"string-split");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[73]=C_h_intern(&lf[73],10,"append-map");
lf[74]=C_h_intern(&lf[74],25,"\010compilertarget-heap-size");
lf[75]=C_h_intern(&lf[75],33,"\010compilertarget-initial-heap-size");
lf[76]=C_h_intern(&lf[76],27,"\010compilertarget-heap-growth");
lf[77]=C_h_intern(&lf[77],30,"\010compilertarget-heap-shrinkage");
lf[78]=C_h_intern(&lf[78],26,"\010compilertarget-stack-size");
lf[79]=C_h_intern(&lf[79],8,"no-trace");
lf[80]=C_h_intern(&lf[80],24,"\010compileremit-trace-info");
lf[81]=C_h_intern(&lf[81],29,"disable-stack-overflow-checks");
lf[82]=C_h_intern(&lf[82],40,"\010compilerdisable-stack-overflow-checking");
lf[83]=C_h_intern(&lf[83],7,"version");
lf[84]=C_h_intern(&lf[84],7,"newline");
lf[85]=C_h_intern(&lf[85],22,"\010compilerprint-version");
lf[86]=C_h_intern(&lf[86],4,"help");
lf[87]=C_h_intern(&lf[87],20,"\010compilerprint-usage");
lf[88]=C_h_intern(&lf[88],7,"release");
lf[89]=C_h_intern(&lf[89],7,"display");
lf[90]=C_h_intern(&lf[90],15,"chicken-version");
lf[91]=C_h_intern(&lf[91],24,"\010compilersource-filename");
lf[92]=C_h_intern(&lf[92],28,"\010compilerprofile-lambda-list");
lf[93]=C_h_intern(&lf[93],31,"\010compilerline-number-database-2");
lf[94]=C_h_intern(&lf[94],23,"\010compilerconstant-table");
lf[95]=C_h_intern(&lf[95],21,"\010compilerinline-table");
lf[96]=C_h_intern(&lf[96],23,"\010compilerfirst-analysis");
lf[97]=C_h_intern(&lf[97],41,"\010compilerperform-high-level-optimizations");
lf[98]=C_h_intern(&lf[98],37,"\010compilerinline-substitutions-enabled");
lf[99]=C_h_intern(&lf[99],22,"optimize-leaf-routines");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[101]=C_h_intern(&lf[101],34,"\010compilertransform-direct-lambdas!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[103]=C_h_intern(&lf[103],4,"leaf");
lf[104]=C_h_intern(&lf[104],18,"\010compilerdebugging");
lf[105]=C_h_intern(&lf[105],1,"p");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[108]=C_h_intern(&lf[108],1,"5");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[111]=C_h_intern(&lf[111],36,"\010compilerprepare-for-code-generation");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[113]=C_h_intern(&lf[113],30,"\010compilercompiler-cleanup-hook");
lf[114]=C_h_intern(&lf[114],1,"t");
lf[115]=C_h_intern(&lf[115],17,"\003sysdisplay-times");
lf[116]=C_h_intern(&lf[116],14,"\003sysstop-timer");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[118]=C_h_intern(&lf[118],17,"close-output-port");
lf[119]=C_h_intern(&lf[119],22,"\010compilergenerate-code");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[121]=C_h_intern(&lf[121],16,"open-output-file");
lf[122]=C_h_intern(&lf[122],19,"current-output-port");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[125]=C_h_intern(&lf[125],1,"9");
lf[126]=C_h_intern(&lf[126],4,"exit");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[128]=C_h_intern(&lf[128],20,"\003syswarnings-enabled");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[130]=C_h_intern(&lf[130],1,"8");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[132]=C_h_intern(&lf[132],35,"\010compilerperform-closure-conversion");
lf[133]=C_h_intern(&lf[133],27,"\010compilerinline-output-file");
lf[134]=C_h_intern(&lf[134],32,"\010compileremit-global-inline-file");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000(Generating global inline file `~a\047 ...~%");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[137]=C_h_intern(&lf[137],1,"7");
lf[138]=C_h_intern(&lf[138],1,"s");
lf[139]=C_h_intern(&lf[139],33,"\010compilerprint-program-statistics");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[141]=C_h_intern(&lf[141],1,"4");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[143]=C_h_intern(&lf[143],1,"u");
lf[144]=C_h_intern(&lf[144],31,"\010compilerdump-undefined-globals");
lf[145]=C_h_intern(&lf[145],3,"opt");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[147]=C_h_intern(&lf[147],1,"3");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[149]=C_h_intern(&lf[149],31,"\010compilerperform-cps-conversion");
lf[150]=C_h_intern(&lf[150],6,"unsafe");
lf[151]=C_h_intern(&lf[151],34,"\010compilerscan-toplevel-assignments");
lf[152]=C_h_intern(&lf[152],26,"\010compilerdo-lambda-lifting");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[154]=C_h_intern(&lf[154],1,"L");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[156]=C_h_intern(&lf[156],32,"\010compilerperform-lambda-lifting!");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[159]=C_h_intern(&lf[159],1,"0");
lf[160]=C_h_intern(&lf[160],4,"lift");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[162]=C_h_intern(&lf[162],1,"U");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[166]=C_h_intern(&lf[166],4,"user");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[168]=C_h_intern(&lf[168],4,"node");
lf[169]=C_h_intern(&lf[169],6,"lambda");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[171]=C_h_intern(&lf[171],25,"\010compilerbuild-node-graph");
lf[172]=C_h_intern(&lf[172],32,"\010compilercanonicalize-begin-body");
lf[173]=C_h_intern(&lf[173],24,"\010compilerinline-globally");
lf[174]=C_h_intern(&lf[174],25,"\010compilerload-inline-file");
lf[175]=C_h_intern(&lf[175],5,"print");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\024Loading inline file ");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[178]=C_h_intern(&lf[178],12,"file-exists\077");
lf[179]=C_h_intern(&lf[179],28,"\003sysresolve-include-filename");
lf[180]=C_h_intern(&lf[180],13,"make-pathname");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[182]=C_h_intern(&lf[182],14,"symbol->string");
lf[183]=C_h_intern(&lf[183],11,"concatenate");
lf[184]=C_h_intern(&lf[184],3,"cdr");
lf[185]=C_h_intern(&lf[185],2,"pp");
lf[186]=C_h_intern(&lf[186],1,"M");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[188]=C_h_intern(&lf[188],12,"vector->list");
lf[189]=C_h_intern(&lf[189],26,"\010compilerfile-requirements");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[192]=C_h_intern(&lf[192],12,"check-syntax");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[194]=C_h_intern(&lf[194],1,"2");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[196]=C_h_intern(&lf[196],25,"\010compilercompiler-warning");
lf[197]=C_h_intern(&lf[197],5,"style");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[199]=C_h_intern(&lf[199],8,"feature\077");
lf[200]=C_h_intern(&lf[200],19,"compiling-extension");
lf[201]=C_h_intern(&lf[201],18,"\010compilerunit-name");
lf[202]=C_h_intern(&lf[202],5,"usage");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[204]=C_h_intern(&lf[204],26,"\010compilerblock-compilation");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[206]=C_h_intern(&lf[206],37,"\010compilerdisplay-line-number-database");
lf[207]=C_h_intern(&lf[207],1,"n");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[209]=C_h_intern(&lf[209],32,"\010compilerdisplay-real-name-table");
lf[210]=C_h_intern(&lf[210],1,"N");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[212]=C_h_intern(&lf[212],6,"append");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[214]=C_h_intern(&lf[214],5,"quote");
lf[215]=C_h_intern(&lf[215],33,"\010compilerprofile-info-vector-name");
lf[216]=C_h_intern(&lf[216],28,"\003sysset-profile-info-vector!");
lf[217]=C_h_intern(&lf[217],21,"\010compileremit-profile");
lf[218]=C_h_intern(&lf[218],25,"\003sysregister-profile-info");
lf[219]=C_h_intern(&lf[219],4,"set!");
lf[220]=C_h_intern(&lf[220],13,"\004corecallunit");
lf[221]=C_h_intern(&lf[221],19,"\010compilerused-units");
lf[222]=C_h_intern(&lf[222],28,"\010compilerimmutable-constants");
lf[223]=C_h_intern(&lf[223],6,"gensym");
lf[224]=C_h_intern(&lf[224],32,"\010compilercanonicalize-expression");
lf[225]=C_h_intern(&lf[225],28,"\003sysexplicit-library-modules");
lf[226]=C_h_intern(&lf[226],4,"uses");
lf[227]=C_h_intern(&lf[227],7,"declare");
lf[228]=C_h_intern(&lf[228],10,"\003sysappend");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[230]=C_h_intern(&lf[230],1,"1");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[233]=C_h_intern(&lf[233],21,"\010compilerstring->expr");
lf[234]=C_h_intern(&lf[234],7,"reverse");
lf[235]=C_h_intern(&lf[235],27,"\003syscurrent-source-filename");
lf[236]=C_h_intern(&lf[236],33,"\010compilerclose-checked-input-file");
lf[237]=C_h_intern(&lf[237],16,"\003sysdynamic-wind");
lf[238]=C_h_intern(&lf[238],34,"\010compilercheck-and-open-input-file");
lf[239]=C_h_intern(&lf[239],8,"epilogue");
lf[240]=C_h_intern(&lf[240],8,"prologue");
lf[241]=C_h_intern(&lf[241],8,"postlude");
lf[242]=C_h_intern(&lf[242],7,"prelude");
lf[243]=C_h_intern(&lf[243],11,"make-vector");
lf[244]=C_h_intern(&lf[244],34,"\010compilerline-number-database-size");
lf[245]=C_h_intern(&lf[245],1,"r");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[252]=C_h_intern(&lf[252],5,"-help");
lf[253]=C_h_intern(&lf[253],1,"h");
lf[254]=C_h_intern(&lf[254],2,"-h");
lf[255]=C_h_intern(&lf[255],18,"accumulate-profile");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[259]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[260]=C_h_intern(&lf[260],39,"\010compilerdefault-profiling-declarations");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[264]=C_h_intern(&lf[264],21,"no-usual-integrations");
lf[265]=C_h_intern(&lf[265],17,"standard-bindings");
lf[266]=C_h_intern(&lf[266],34,"\010compilerdefault-standard-bindings");
lf[267]=C_h_intern(&lf[267],17,"extended-bindings");
lf[268]=C_h_intern(&lf[268],34,"\010compilerdefault-extended-bindings");
lf[269]=C_h_intern(&lf[269],1,"m");
lf[270]=C_h_intern(&lf[270],14,"set-gc-report!");
lf[271]=C_h_intern(&lf[271],42,"\010compilerdefault-default-target-stack-size");
lf[272]=C_h_intern(&lf[272],41,"\010compilerdefault-default-target-heap-size");
lf[273]=C_h_intern(&lf[273],14,"compile-syntax");
lf[274]=C_h_intern(&lf[274],25,"\003sysenable-runtime-macros");
lf[275]=C_h_intern(&lf[275],22,"\004corerequire-extension");
lf[276]=C_h_intern(&lf[276],17,"require-extension");
lf[277]=C_h_intern(&lf[277],9,"extension");
lf[278]=C_h_intern(&lf[278],16,"define-extension");
lf[279]=C_h_intern(&lf[279],13,"pathname-file");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[281]=C_h_intern(&lf[281],28,"\010compilerpostponed-initforms");
lf[282]=C_h_intern(&lf[282],6,"delete");
lf[283]=C_h_intern(&lf[283],4,"load");
lf[284]=C_h_intern(&lf[284],12,"load-verbose");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[286]=C_h_intern(&lf[286],6,"extend");
lf[287]=C_h_intern(&lf[287],17,"register-feature!");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[289]=C_h_intern(&lf[289],7,"feature");
lf[290]=C_h_intern(&lf[290],20,"keep-shadowed-macros");
lf[291]=C_h_intern(&lf[291],33,"\010compilerundefine-shadowed-macros");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[294]=C_h_intern(&lf[294],23,"\010compilerchop-separator");
lf[295]=C_h_intern(&lf[295],12,"include-path");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[297]=C_h_intern(&lf[297],7,"\000prefix");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[299]=C_h_intern(&lf[299],5,"\000none");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[301]=C_h_intern(&lf[301],7,"\000suffix");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[303]=C_h_intern(&lf[303],17,"compress-literals");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[305]=C_h_intern(&lf[305],16,"case-insensitive");
lf[306]=C_h_intern(&lf[306],14,"case-sensitive");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[308]=C_h_intern(&lf[308],24,"\010compilerinline-max-size");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[310]=C_h_intern(&lf[310],23,"\010compilerinline-locally");
lf[311]=C_h_intern(&lf[311],26,"\010compilerlocal-definitions");
lf[312]=C_h_intern(&lf[312],6,"inline");
lf[313]=C_h_intern(&lf[313],30,"emit-external-prototypes-first");
lf[314]=C_h_intern(&lf[314],30,"\010compilerexternal-protos-first");
lf[315]=C_h_intern(&lf[315],5,"block");
lf[316]=C_h_intern(&lf[316],17,"fixnum-arithmetic");
lf[317]=C_h_intern(&lf[317],11,"number-type");
lf[318]=C_h_intern(&lf[318],6,"fixnum");
lf[319]=C_h_intern(&lf[319],18,"disable-interrupts");
lf[320]=C_h_intern(&lf[320],28,"\010compilerinsert-timer-checks");
lf[321]=C_h_intern(&lf[321],16,"unsafe-libraries");
lf[322]=C_h_intern(&lf[322],27,"\010compileremit-unsafe-marker");
lf[323]=C_h_intern(&lf[323],11,"no-warnings");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[325]=C_h_intern(&lf[325],15,"disable-warning");
lf[326]=C_h_intern(&lf[326],13,"inline-global");
lf[327]=C_h_intern(&lf[327],5,"local");
lf[328]=C_h_intern(&lf[328],14,"no-lambda-info");
lf[329]=C_h_intern(&lf[329],26,"\010compileremit-closure-info");
lf[330]=C_h_intern(&lf[330],3,"raw");
lf[331]=C_h_intern(&lf[331],12,"emit-exports");
lf[332]=C_h_intern(&lf[332],7,"warning");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[334]=C_h_intern(&lf[334],1,"b");
lf[335]=C_h_intern(&lf[335],15,"\003sysstart-timer");
lf[336]=C_h_intern(&lf[336],11,"lambda-lift");
lf[337]=C_h_intern(&lf[337],13,"string-append");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[339]=C_h_intern(&lf[339],19,"emit-import-library");
lf[340]=C_h_intern(&lf[340],16,"\003sysstring->list");
lf[341]=C_h_intern(&lf[341],5,"debug");
lf[342]=C_h_intern(&lf[342],30,"\010compilerstandalone-executable");
lf[343]=C_h_intern(&lf[343],29,"\010compilerstring->c-identifier");
lf[344]=C_h_intern(&lf[344],18,"\010compilerstringify");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[347]=C_h_intern(&lf[347],6,"getenv");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[349]=C_h_intern(&lf[349],9,"to-stdout");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[352]=C_h_intern(&lf[352],29,"\010compilerdefault-declarations");
lf[353]=C_h_intern(&lf[353],30,"\010compilerunits-used-by-default");
lf[354]=C_h_intern(&lf[354],28,"\010compilerinitialize-compiler");
lf[355]=C_h_intern(&lf[355],14,"make-parameter");
C_register_lf2(lf,356,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1016 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1019 in k1016 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1022 in k1019 in k1016 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 81   make-parameter */
t3=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_FALSE);}

/* k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 86   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1060,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1060r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1060r(t0,t1,t2,t3);}}

static void C_ccall f_1060r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1063,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1096,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 99   initialize-compiler */
t6=C_retrieve(lf[354]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=(C_word)C_i_memq(lf[10],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[11]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[11]))){
t7=t6;
f_3228(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[353]),C_SCHEME_END_OF_LIST);}}

/* k3237 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[226],t1);
t3=((C_word*)t0)[2];
f_3228(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3226 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_3228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 102  append */
t2=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[352]),t1);}

/* k3222 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 110  option-arg */
f_1063(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[5]))){
t9=t8;
f_1112(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 115  pathname-file */
t10=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3209(2,t10,lf[351]);}}}}

/* k3207 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 115  make-pathname */
t2=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[350]);}

/* k3185 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 112  symbol->string */
t2=*((C_word*)lf[182]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1112(2,t2,t1);}}

/* k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1115,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 116  getenv */
t5=C_retrieve(lf[347]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[348]);}

/* k3179 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[345]);
/* batch-driver.scm: 116  string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[346]);}

/* k3175 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[294]),t1);}

/* k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
t2=C_retrieve(lf[15]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[16];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[17],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1121,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1121(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[255],((C_word*)t0)[8]);
t14=t12;
f_1121(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[18],((C_word*)t0)[8])));}}

/* k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[89],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1121,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[19]);
t5=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[30],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1189,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1211,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1226,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1238,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1287,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1430,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t23,a[12]=t1,a[13]=t33,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t27,a[18]=t26,a[19]=t13,a[20]=t17,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t25,a[24]=t34,a[25]=t32,a[26]=t31,a[27]=t19,a[28]=((C_word*)t0)[6],a[29]=((C_word*)t0)[7],a[30]=t30,a[31]=((C_word*)t0)[8],a[32]=t21,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3150,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3158,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 211  option-arg */
f_1063(t38,t12);}
else{
t36=t35;
f_1509(t36,C_SCHEME_UNDEFINED);}}

/* k3156 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 211  stringify */
t2=C_retrieve(lf[344]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3152 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 211  string->c-identifier */
t2=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3148 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[201]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1509(t3,t2);}

/* k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[201]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[342] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1512(t6,t5);}
else{
t5=t2;
f_1512(t5,C_SCHEME_UNDEFINED);}}

/* k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3120,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3142,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 219  collect-options */
t5=((C_word*)t0)[30];
f_1367(t5,t4,lf[341]);}

/* k3140 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 215  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3119 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3120,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3126,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3138,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[340]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3136 in a3119 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3125 in a3119 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3126,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 217  string->symbol */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[31]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3102,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3118,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 225  collect-options */
t8=((C_word*)t0)[30];
f_1367(t8,t7,lf[339]);}

/* k3116 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3101 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3102,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3110,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 223  string->symbol */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3108 in a3101 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3114,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 224  string-append */
t3=*((C_word*)lf[337]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[338]);}

/* k3112 in k3108 in a3101 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3114,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[336],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[152] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1527(t5,t4);}
else{
t4=t3;
f_1527(t4,C_SCHEME_UNDEFINED);}}

/* k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1527,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[114],C_retrieve(lf[31])))){
/* batch-driver.scm: 227  ##sys#start-timer */
t3=*((C_word*)lf[335]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1530(2,t3,C_SCHEME_UNDEFINED);}}

/* k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[334],C_retrieve(lf[31])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1533(t4,t3);}
else{
t3=t2;
f_1533(t3,C_SCHEME_UNDEFINED);}}

/* k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1533,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[331],((C_word*)t0)[34]))){
/* batch-driver.scm: 230  warning */
t3=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[333]);}
else{
t3=t2;
f_1536(2,t3,C_SCHEME_UNDEFINED);}}

/* k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[11] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1539(t6,t5);}
else{
t3=t2;
f_1539(t3,C_SCHEME_UNDEFINED);}}

/* k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1539,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[329] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1542(t4,t3);}
else{
t3=t2;
f_1542(t3,C_SCHEME_UNDEFINED);}}

/* k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1542,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[327],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[311] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1545(t4,t3);}
else{
t3=t2;
f_1545(t3,C_SCHEME_UNDEFINED);}}

/* k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1545,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[326],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[310] /* inline-locally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[173] /* inline-globally */,0,C_SCHEME_TRUE);
t5=t2;
f_1548(t5,t4);}
else{
t3=t2;
f_1548(t3,C_SCHEME_UNDEFINED);}}

/* k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 242  collect-options */
t4=((C_word*)t0)[29];
f_1367(t4,t3,lf[325]);}

/* k3059 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[323],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[33])){
/* batch-driver.scm: 244  printf */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[324]);}
else{
t5=t4;
f_3053(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1555(t4,C_SCHEME_UNDEFINED);}}

/* k3051 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[128] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1555(t3,t2);}

/* k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[99],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[99] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1558(t4,t3);}
else{
t3=t2;
f_1558(t3,C_SCHEME_UNDEFINED);}}

/* k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[150],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[150] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1561(t4,t3);}
else{
t3=t2;
f_1561(t3,C_SCHEME_UNDEFINED);}}

/* k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[321],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[322] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1564(t5,t4);}
else{
t4=t2;
f_1564(t4,C_SCHEME_UNDEFINED);}}

/* k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1564,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[319],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[320] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1567(t4,t3);}
else{
t3=t2;
f_1567(t3,C_SCHEME_UNDEFINED);}}

/* k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1567,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[316],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[317]+1 /* (set! number-type ...) */,lf[318]);
t4=t2;
f_1570(t4,t3);}
else{
t3=t2;
f_1570(t3,C_SCHEME_UNDEFINED);}}

/* k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1570,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[315],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[204] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1573(t4,t3);}
else{
t3=t2;
f_1573(t3,C_SCHEME_UNDEFINED);}}

/* k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[313],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[314] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1576(t4,t3);}
else{
t3=t2;
f_1576(t3,C_SCHEME_UNDEFINED);}}

/* k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1576,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[310] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1579(t4,t3);}
else{
t3=t2;
f_1579(t3,C_SCHEME_UNDEFINED);}}

/* k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1579,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[310] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[311] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 260  option-arg */
f_1063(t6,t2);}
else{
t4=t3;
f_1585(t4,C_SCHEME_FALSE);}}

/* k3010 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[133]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1585(t3,t2);}

/* k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1585,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[34],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 263  option-arg */
f_1063(t4,t2);}
else{
t4=t3;
f_1591(t4,C_SCHEME_FALSE);}}

/* k2995 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3000,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 264  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2998 in k2995 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3003(2,t3,t1);}
else{
/* batch-driver.scm: 265  quit */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[309],((C_word*)t0)[2]);}}

/* k3001 in k2998 in k2995 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[308]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1591(t3,t2);}

/* k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1591,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[305],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 267  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[307]);}
else{
t4=t3;
f_2984(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1594(2,t3,C_SCHEME_UNDEFINED);}}

/* k2982 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 268  register-feature! */
t3=C_retrieve(lf[287]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[305]);}

/* k2985 in k2982 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 269  case-sensitive */
t2=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[303],((C_word*)t0)[29]))){
/* batch-driver.scm: 271  compiler-warning */
t3=C_retrieve(lf[196]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[202],lf[304]);}
else{
t3=t2;
f_1597(2,t3,C_SCHEME_UNDEFINED);}}

/* k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 273  option-arg */
f_1063(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1600(2,t3,C_SCHEME_UNDEFINED);}}

/* k2940 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[296],t1))){
/* batch-driver.scm: 274  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[297]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[298],t1))){
/* batch-driver.scm: 275  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[299]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[300],t1))){
/* batch-driver.scm: 276  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}
else{
/* batch-driver.scm: 277  quit */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[302]);}}}}

/* k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[33],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 281  collect-options */
t7=((C_word*)t0)[29];
f_1367(t7,t6,lf[295]);}

/* k2937 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[294]),t1);}

/* k2933 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 281  append */
t2=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1606,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[19])?(C_truep(((C_word*)t0)[26])?(C_word)C_i_string_equal_p(((C_word*)t0)[19],((C_word*)t0)[26]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 285  quit */
t5=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[293]);}
else{
t5=t3;
f_1609(2,t5,C_SCHEME_UNDEFINED);}}

/* k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2911,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 290  collect-options */
t6=((C_word*)t0)[29];
f_1367(t6,t5,lf[226]);}

/* k2917 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 288  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2910 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2911,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[292]);}

/* k2907 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[290],((C_word*)t0)[28]))){
t4=C_set_block_item(lf[291] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1616(t5,t4);}
else{
t4=t3;
f_1616(t4,C_SCHEME_UNDEFINED);}}

/* k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1616,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2891,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2893,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 297  collect-options */
t6=((C_word*)t0)[29];
f_1367(t6,t5,lf[289]);}

/* k2899 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 297  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2892 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2893,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[288]);}

/* k2889 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[287]),t1);}

/* k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 301  collect-options */
t5=((C_word*)t0)[29];
f_1367(t5,t4,lf[286]);}

/* k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1629,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[20])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 303  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[285]);}
else{
t3=t2;
f_1629(2,t3,C_SCHEME_UNDEFINED);}}

/* k2882 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 304  load-verbose */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2873,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2872 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2873,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 306  ##sys#resolve-include-filename */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2879 in a2872 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 306  load */
t2=C_retrieve(lf[283]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 308  delete */
t3=C_retrieve(lf[282]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[68]+1));}

/* k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1636,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 311  user-post-analysis-pass */
t6=C_retrieve(lf[5]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 314  append */
t4=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[31])[1],C_retrieve(lf[281]));}

/* k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
if(C_truep((C_word)C_i_memq(lf[277],((C_word*)t0)[28]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2839,a[2]=t3,a[3]=((C_word*)t0)[31],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[31],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2859,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[19])){
/* batch-driver.scm: 323  pathname-file */
t7=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[19]);}
else{
if(C_truep(((C_word*)t0)[26])){
/* batch-driver.scm: 324  pathname-file */
t7=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[26]);}
else{
/* batch-driver.scm: 325  quit */
t7=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[280]);}}}
else{
t4=t3;
f_1651(t4,C_SCHEME_UNDEFINED);}}

/* k2857 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 322  string->symbol */
t2=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2853 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[278],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 319  append */
t5=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}

/* k2837 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1651(t3,t2);}

/* k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1651,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[30],a[3]=((C_word*)t0)[31],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[30],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[31],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],tmp=(C_word)a,a+=32,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[29],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2812,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2832,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 341  ids */
t7=t2;
f_1653(t7,t6,lf[276]);}

/* k2830 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2811 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2812,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[275],t5));}

/* k2808 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 338  append */
t2=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[31],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
if(C_truep((C_word)C_i_memq(lf[273],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[274] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1682(t5,t4);}
else{
t4=t3;
f_1682(t4,C_SCHEME_UNDEFINED);}}

/* k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1682,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2789,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 347  option-arg */
f_1063(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[272]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1686(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1686(2,t4,C_SCHEME_FALSE);}}}

/* k2787 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 347  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 351  option-arg */
f_1063(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1690(2,t4,C_SCHEME_FALSE);}}

/* k2780 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 351  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 352  option-arg */
f_1063(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1694(2,t4,C_SCHEME_FALSE);}}

/* k2773 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 352  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 353  option-arg */
f_1063(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1698(2,t4,C_SCHEME_FALSE);}}

/* k2766 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 353  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2748,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 356  option-arg */
f_1063(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[271]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1702(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1702(2,t5,C_SCHEME_FALSE);}}}

/* k2746 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 356  arg-val */
f_1287(((C_word*)t0)[2],t1);}

/* k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[79],((C_word*)t0)[24]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[80]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[81],((C_word*)t0)[24]);
t7=C_mutate((C_word*)lf[82]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep((C_word)C_i_memq(lf[269],C_retrieve(lf[31])))){
/* batch-driver.scm: 362  set-gc-report! */
t9=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1713(2,t9,C_SCHEME_UNDEFINED);}}

/* k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep((C_word)C_i_memq(lf[264],((C_word*)t0)[24]))){
t3=t2;
f_1716(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[265]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[266]));
t4=C_mutate((C_word*)lf[267]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[268]));
t5=t2;
f_1716(t5,t4);}}

/* k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[80]))?lf[261]:lf[262]);
/* batch-driver.scm: 367  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[263],t3);}
else{
t3=t2;
f_1719(2,t3,C_SCHEME_UNDEFINED);}}

/* k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[255],t3);
t5=C_set_block_item(lf[217] /* emit-profile */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2701,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(t4)?lf[259]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 375  append */
t8=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[260]),t7);}
else{
t3=t2;
f_1722(2,t3,C_SCHEME_UNDEFINED);}}

/* k2699 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[256]:lf[257]);
/* batch-driver.scm: 382  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[258],t3);}
else{
t3=((C_word*)t0)[2];
f_1722(2,t3,C_SCHEME_UNDEFINED);}}

/* k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[83],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 385  print-version */
t3=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[86],((C_word*)t0)[23]);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(t2)){
t4=t3;
f_1743(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[252],((C_word*)t0)[23]);
if(C_truep(t4)){
t5=t3;
f_1743(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[253],((C_word*)t0)[23]);
t6=t3;
f_1743(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[254],((C_word*)t0)[23])));}}}}

/* k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1743(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1743,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 388  print-usage */
t2=C_retrieve(lf[87]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[23]);}
else{
if(C_truep((C_word)C_i_memq(lf[88],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 390  chicken-version */
t4=C_retrieve(lf[90]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[21];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[22],a[11]=((C_word*)t0)[23],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1780(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 400  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[250],((C_word*)t0)[21]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[23];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 394  print-version */
t4=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1772 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 395  display */
t2=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[251]);}

/* k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! source-filename ...) */,((C_word*)t0)[23]);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[23],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 402  debugging */
t4=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[245],lf[249],((C_word*)t0)[10]);}

/* k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 403  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[245],lf[248],C_retrieve(lf[31]));}

/* k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 404  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[245],lf[247],C_retrieve(lf[74]));}

/* k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 405  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[245],lf[246],C_retrieve(lf[78]));}

/* k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 409  make-vector */
t5=*((C_word*)lf[243]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[244]),C_SCHEME_END_OF_LIST);}

/* k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 410  collect-options */
t4=((C_word*)t0)[2];
f_1367(t4,t3,lf[242]);}

/* k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 411  collect-options */
t3=((C_word*)t0)[2];
f_1367(t3,t2,lf[241]);}

/* k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[18],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 413  collect-options */
t4=((C_word*)t0)[2];
f_1367(t4,t3,lf[240]);}

/* k2665 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2675,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 415  collect-options */
t4=((C_word*)t0)[2];
f_1367(t4,t3,lf[239]);}

/* k2673 in k2665 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 412  append */
t2=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 417  user-read-pass */
t3=C_retrieve(lf[1]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[21])){
/* batch-driver.scm: 419  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[232]);}
else{
t4=t3;
f_2570(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2582(t6,t2,((C_word*)t0)[4]);}}

/* doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2593,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[233]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 429  check-and-open-input-file */
t5=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[237]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2659 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[235]));
t3=C_mutate((C_word*)lf[235]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2627 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2632,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 431  read-form */
t3=((C_word*)t0)[2];
f_1424(t3,t2,((C_word*)t0)[5]);}

/* k2630 in a2627 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2637(t5,((C_word*)t0)[2],t1);}

/* doloop632 in k2630 in a2627 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_2637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2637,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 434  close-checked-input-file */
t3=C_retrieve(lf[236]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 432  read-form */
t6=((C_word*)t0)[2];
f_1424(t6,t5,((C_word*)t0)[6]);}}

/* k2656 in doloop632 in k2630 in a2627 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2637(t2,((C_word*)t0)[2],t1);}

/* a2622 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[235]));
t3=C_mutate((C_word*)lf[235]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2612 in k2609 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2582(t3,((C_word*)t0)[2],t2);}

/* k2595 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 426  reverse */
t3=*((C_word*)lf[234]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2599 in k2595 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2605,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[233]),((C_word*)t0)[2]);}

/* k2603 in k2599 in k2595 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 425  append */
t2=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2591 in doloop603 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2568 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 420  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2572 in k2568 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1816(2,t3,t2);}

/* k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 438  user-preprocessor-pass */
t3=C_retrieve(lf[2]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2560,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[17])){
/* batch-driver.scm: 440  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[231]);}
else{
t4=t3;
f_2560(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1822(t3,C_SCHEME_UNDEFINED);}}

/* k2558 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2562 in k2558 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1822(t3,t2);}

/* k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1822,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 443  print-expr */
t3=((C_word*)t0)[7];
f_1226(t3,t2,lf[229],lf[230],((C_word*)((C_word*)t0)[3])[1]);}

/* k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=f_1397(((C_word*)t0)[21]);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1831(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 446  append */
t5=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[225]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2535 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=C_mutate((C_word*)lf[225]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2555 in k2535 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[226],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[227],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1831(t7,t6);}

/* k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1831,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 448  append */
t4=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2528 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[224]),t1);}

/* k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 449  gensym */
t3=C_retrieve(lf[223]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[92]));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2498,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[222]));}

/* a2497 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2498,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[214],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[219],t8));}

/* k2370 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2488,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[221]));}

/* a2487 in k2370 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2488,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[220],t3));}

/* k2374 in k2370 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[217]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[214],t3);
t5=(C_truep(C_retrieve(lf[201]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[214],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[218],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[215]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[219],t12);
t14=t2;
f_2380(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2380(t3,C_SCHEME_END_OF_LIST);}}

/* k2378 in k2374 in k2370 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_2380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2380,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2399,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[92]));}

/* a2398 in k2378 in k2374 in k2370 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2399,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[214],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[214],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[215]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[216],t11));}

/* k2382 in k2378 in k2374 in k2370 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[201]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 451  append */
t5=*((C_word*)lf[212]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[213]);}

/* k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2365,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 472  debugging */
t6=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[210],lf[211]);}

/* k2363 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 473  display-real-name-table */
t2=C_retrieve(lf[209]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1846(2,t2,C_SCHEME_UNDEFINED);}}

/* k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 474  debugging */
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[207],lf[208]);}

/* k2357 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 475  display-line-number-database */
t2=C_retrieve(lf[206]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1849(2,t2,C_SCHEME_UNDEFINED);}}

/* k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[204]))?C_retrieve(lf[201]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 478  compiler-warning */
t4=C_retrieve(lf[196]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[202],lf[205],C_retrieve(lf[201]));}
else{
t4=t2;
f_1852(2,t4,C_SCHEME_UNDEFINED);}}

/* k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[201]))?((C_word*)t0)[10]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 484  compiler-warning */
t4=C_retrieve(lf[196]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[202],lf[203],C_retrieve(lf[201]));}
else{
t4=t2;
f_1855(2,t4,C_SCHEME_UNDEFINED);}}

/* k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2338,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[150]))){
/* batch-driver.scm: 486  feature? */
t4=C_retrieve(lf[199]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[200]);}
else{
t4=t3;
f_2338(2,t4,C_SCHEME_FALSE);}}

/* k2336 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 487  compiler-warning */
t2=C_retrieve(lf[196]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[197],lf[198]);}
else{
t2=((C_word*)t0)[2];
f_1858(2,t2,C_SCHEME_UNDEFINED);}}

/* k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,C_retrieve(lf[93]));
t3=C_set_block_item(lf[93] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 494  end-time */
t5=((C_word*)t0)[16];
f_1407(t5,t4,lf[195]);}

/* k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 495  print-expr */
t3=((C_word*)t0)[2];
f_1226(t3,t2,lf[193],lf[194],((C_word*)((C_word*)t0)[4])[1]);}

/* k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_memq(lf[192],((C_word*)t0)[2]))){
/* batch-driver.scm: 497  exit */
t3=C_retrieve(lf[126]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1869(2,t3,C_SCHEME_UNDEFINED);}}

/* k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 499  user-pass */
t3=C_retrieve(lf[3]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2316,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[11])){
/* batch-driver.scm: 501  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[191]);}
else{
t4=t3;
f_2316(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1875(2,t3,C_SCHEME_UNDEFINED);}}

/* k2314 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=f_1397(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2321 in k2314 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 504  end-time */
t3=((C_word*)t0)[3];
f_1407(t3,((C_word*)t0)[2],lf[190]);}

/* k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 506  vector->list */
t4=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[189]));}

/* k2311 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 506  concatenate */
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1881,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2306,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 507  debugging */
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[186],lf[187]);}

/* k2304 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 508  pp */
t2=C_retrieve(lf[185]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1881(2,t2,C_SCHEME_UNDEFINED);}}

/* k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[173]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2299,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2303,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[184]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1884(2,t3,C_SCHEME_UNDEFINED);}}

/* k2301 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 519  concatenate */
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2297 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2264 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2265,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 513  symbol->string */
t6=*((C_word*)lf[182]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2293 in a2264 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 513  make-pathname */
t2=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[181]);}

/* k2289 in a2264 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 512  ##sys#resolve-include-filename */
t2=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2267 in a2264 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 515  file-exists? */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2276 in k2267 in a2264 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2278,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 517  print */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[176],((C_word*)t0)[3],lf[177]);}
else{
t3=t2;
f_2281(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2279 in k2276 in k2267 in a2264 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 518  load-inline-file */
t2=C_retrieve(lf[174]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 524  canonicalize-begin-body */
t5=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2258 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 523  build-node-graph */
t2=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2254 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2248,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[169],lf[170],t2);}

/* f_2248 in k2254 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2248,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[168],t2,t3,t4));}

/* k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1890,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 525  user-pass-2 */
t3=C_retrieve(lf[4]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[12],a[8]=t2,a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* batch-driver.scm: 527  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[167]);}
else{
t4=t3;
f_2214(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1893(t3,C_SCHEME_UNDEFINED);}}

/* k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=f_1397(((C_word*)t0)[9]);
t3=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 530  analyze */
t5=((C_word*)t0)[2];
f_1430(t5,t4,lf[166],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2219 in k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 531  print-db */
t3=((C_word*)t0)[2];
f_1211(t3,t2,lf[165],lf[159],t1,C_fix(0));}

/* k2222 in k2219 in k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 532  end-time */
t3=((C_word*)t0)[3];
f_1407(t3,t2,lf[164]);}

/* k2225 in k2222 in k2219 in k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=f_1397(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 534  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2231 in k2225 in k2222 in k2219 in k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 535  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[163]);}

/* k2234 in k2231 in k2225 in k2222 in k2219 in k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 536  print-node */
t3=((C_word*)t0)[3];
f_1189(t3,t2,lf[161],lf[162],((C_word*)t0)[2]);}

/* k2237 in k2234 in k2231 in k2225 in k2222 in k2219 in k2212 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1893(t3,t2);}

/* k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1893,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[152]))){
t3=f_1397(((C_word*)t0)[15]);
t4=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],a[6]=t2,a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 542  analyze */
t6=((C_word*)t0)[13];
f_1430(t6,t5,lf[160],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1896(t3,C_SCHEME_UNDEFINED);}}

/* k2190 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2195,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 543  print-db */
t3=((C_word*)t0)[2];
f_1211(t3,t2,lf[158],lf[159],t1,C_fix(0));}

/* k2193 in k2190 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 544  end-time */
t3=((C_word*)t0)[3];
f_1407(t3,t2,lf[157]);}

/* k2196 in k2193 in k2190 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=f_1397(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 546  perform-lambda-lifting! */
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2202 in k2196 in k2193 in k2190 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 547  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[155]);}

/* k2205 in k2202 in k2196 in k2193 in k2190 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 548  print-node */
t3=((C_word*)t0)[3];
f_1189(t3,t2,lf[153],lf[154],((C_word*)t0)[2]);}

/* k2208 in k2205 in k2202 in k2196 in k2193 in k2190 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1896(t3,t2);}

/* k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1896,NULL,2,t0,t1);}
t2=C_set_block_item(lf[42] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[94] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[95] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[150]))){
t6=t5;
f_1902(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2181,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2181 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2181,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2178 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* batch-driver.scm: 555  scan-toplevel-assignments */
t3=C_retrieve(lf[151]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=f_1397(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 558  perform-cps-conversion */
t4=C_retrieve(lf[149]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 559  end-time */
t3=((C_word*)t0)[13];
f_1407(t3,t2,lf[148]);}

/* k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 560  print-node */
t3=((C_word*)t0)[12];
f_1189(t3,t2,lf[146],lf[147],((C_word*)t0)[2]);}

/* k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=t3,a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_1919(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1919(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1919,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1397(((C_word*)t0)[14]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=t2,a[16]=t3,a[17]=((C_word*)t0)[14],a[18]=t4,tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 566  analyze */
t7=((C_word*)t0)[11];
f_1430(t7,t6,lf[145],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(C_retrieve(lf[96]))){
if(C_truep((C_word)C_i_memq(lf[143],C_retrieve(lf[31])))){
/* batch-driver.scm: 569  dump-undefined-globals */
t3=C_retrieve(lf[144]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t3=t2;
f_1929(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1929(2,t3,C_SCHEME_UNDEFINED);}}

/* k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 571  end-time */
t4=((C_word*)t0)[13];
f_1407(t4,t3,lf[142]);}

/* k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 572  print-db */
t3=((C_word*)t0)[2];
f_1211(t3,t2,lf[140],lf[141],((C_word*)t0)[16],((C_word*)t0)[15]);}

/* k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_memq(lf[138],C_retrieve(lf[31])))){
/* batch-driver.scm: 574  print-program-statistics */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}
else{
t3=t2;
f_1939(2,t3,C_SCHEME_UNDEFINED);}}

/* k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
if(C_truep(((C_word*)t0)[19])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 577  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[105],lf[110],((C_word*)t0)[15]);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[17],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[18],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 601  print-node */
t3=((C_word*)t0)[11];
f_1189(t3,t2,lf[136],lf[137],((C_word*)t0)[17]);}}

/* k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[133]))){
t3=C_retrieve(lf[133]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[15],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[14])){
/* batch-driver.scm: 606  printf */
t5=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[135],t3);}
else{
t5=t4;
f_2148(2,t5,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2034(2,t3,C_SCHEME_UNDEFINED);}}

/* k2146 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 607  emit-global-inline-file */
t2=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=f_1397(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 610  perform-closure-conversion */
t4=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[15]);}

/* k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 611  end-time */
t3=((C_word*)t0)[12];
f_1407(t3,t2,lf[131]);}

/* k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 612  print-db */
t3=((C_word*)t0)[3];
f_1211(t3,t2,lf[129],lf[130],((C_word*)t0)[14],((C_word*)t0)[2]);}

/* k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[128]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2131(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2131(t4,C_SCHEME_FALSE);}}

/* k2129 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_2131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 614  display */
t2=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[127]);}
else{
t2=((C_word*)t0)[2];
f_2049(2,t2,C_SCHEME_UNDEFINED);}}

/* k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 615  exit */
t3=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_2052(2,t3,C_SCHEME_UNDEFINED);}}

/* k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 616  print-node */
t3=((C_word*)t0)[2];
f_1189(t3,t2,lf[124],lf[125],((C_word*)t0)[11]);}

/* k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=f_1397(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2069,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 621  end-time */
t7=((C_word*)t0)[7];
f_1407(t7,t6,lf[123]);}

/* k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=f_1397(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 624  open-output-file */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 624  current-output-port */
t4=*((C_word*)lf[122]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2082(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 626  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[120],((C_word*)t0)[9]);}}

/* k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 627  generate-code */
t3=C_retrieve(lf[119]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2083 in k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 628  close-output-port */
t3=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2088(2,t3,C_SCHEME_UNDEFINED);}}

/* k2086 in k2083 in k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 629  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[117]);}

/* k2089 in k2086 in k2083 in k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[114],C_retrieve(lf[31])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 630  ##sys#stop-timer */
t4=*((C_word*)lf[116]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2094(2,t3,C_SCHEME_UNDEFINED);}}

/* k2111 in k2089 in k2086 in k2083 in k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 630  ##sys#display-times */
t2=C_retrieve(lf[115]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2092 in k2089 in k2086 in k2083 in k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 631  compiler-cleanup-hook */
t3=C_retrieve(lf[113]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2095 in k2092 in k2089 in k2086 in k2083 in k2080 in k2077 in k2071 in a2068 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 633  printf */
t2=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[112]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2062 in k2053 in k2050 in k2047 in k2044 in k2041 in k2038 in k2032 in k2029 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
/* batch-driver.scm: 620  prepare-for-code-generation */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=f_1397(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1959,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 582  end-time */
t5=((C_word*)t0)[4];
f_1407(t5,t4,lf[109]);}

/* k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 583  print-node */
t3=((C_word*)t0)[2];
f_1189(t3,t2,lf[107],lf[108],((C_word*)t0)[6]);}

/* k1964 in k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 585  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1919(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[98]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[99]))){
t3=f_1397(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 592  analyze */
t5=((C_word*)t0)[2];
f_1430(t5,t4,lf[103],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 598  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1919(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 587  debugging */
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[105],lf[106]);}}}

/* k1983 in k1964 in k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[98] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 589  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1919(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2000 in k1964 in k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2005,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 593  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[102]);}

/* k2003 in k2000 in k1964 in k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=f_1397(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 595  transform-direct-lambdas! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2009 in k2003 in k2000 in k1964 in k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2014,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 596  end-time */
t3=((C_word*)t0)[2];
f_1407(t3,t2,lf[100]);}

/* k2012 in k2009 in k2003 in k2000 in k1964 in k1961 in a1958 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 597  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1919(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1952 in k1943 in k1937 in k1934 in k1931 in k1927 in k1924 in loop in k1912 in k1909 in k1906 in k1900 in k1894 in k1891 in k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1870 in k1867 in k1864 in k1861 in k1856 in k1853 in k1850 in k1847 in k1844 in k1841 in k1835 in k1832 in k1829 in k1823 in k1820 in k1817 in k1814 in k1811 in k1808 in k1805 in k1802 in k1799 in k1791 in k1788 in k1785 in k1782 in k1778 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1953,2,t0,t1);}
/* batch-driver.scm: 581  perform-high-level-optimizations */
t2=C_retrieve(lf[97]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1760 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 390  display */
t2=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1753 in k1741 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 391  newline */
t2=*((C_word*)lf[84]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1729 in k1720 in k1717 in k1714 in k1711 in k1700 in k1696 in k1692 in k1688 in k1684 in k1680 in k1677 in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 386  newline */
t2=*((C_word*)lf[84]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ids in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1653(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1653,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1665,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1667,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 335  collect-options */
t7=((C_word*)t0)[2];
f_1367(t7,t6,t2);}

/* k1673 in ids in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 333  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1666 in ids in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1667,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[72]);}

/* k1663 in ids in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1659 in ids in k1649 in k1646 in k1642 in k1634 in k1630 in k1627 in k1624 in k1617 in k1614 in k1611 in k1607 in k1604 in k1598 in k1595 in k1592 in k1589 in k1583 in k1577 in k1574 in k1571 in k1568 in k1565 in k1562 in k1559 in k1556 in k1553 in k1550 in k1546 in k1543 in k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1514 in k1510 in k1507 in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 330  lset-difference */
t2=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[68]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1430,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1432,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no302350 */
t8=t7;
f_1460(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf303346 */
t10=t6;
f_1455(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body300309 */
t12=t5;
f_1432(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[55],t11);}}}}

/* def-no302 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1460,NULL,2,t0,t1);}
/* def-contf303346 */
t2=((C_word*)t0)[2];
f_1455(t2,t1,C_fix(0));}

/* def-contf303 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1455,NULL,3,t0,t1,t2);}
/* body300309 */
t3=((C_word*)t0)[2];
f_1432(t3,t1,t2,C_SCHEME_TRUE);}

/* body300 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1432(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1432,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1436,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 202  analyze-expression */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1434 in body300 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1439,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 204  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1439(2,t3,C_SCHEME_UNDEFINED);}}

/* a1449 in k1434 in body300 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1450,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[52]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1443 in k1434 in body300 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1444,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k1437 in k1434 in body300 in analyze in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1424,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 198  ##sys#read */
t3=C_retrieve(lf[50]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1407(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1407,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 195  printf */
t5=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[49],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static C_word C_fcall f_1397(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1367,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1373(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1373,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 187  option-arg */
f_1063(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1385 in loop in collect-options in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1391,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1373(t4,t2,t3);}

/* k1389 in k1385 in loop in collect-options in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1287(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1287,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 178  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 180  substring */
t11=*((C_word*)lf[48]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 181  substring */
t13=*((C_word*)lf[48]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1354 in arg-val in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 181  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1350 in arg-val in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1297(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1334 in arg-val in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 180  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1326 in arg-val in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1297(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1295 in arg-val in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 183  quit */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1238,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1242,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[46]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1284,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1284 in infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1284,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1240 in infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[45],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1248(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1248(t5,C_SCHEME_FALSE);}}

/* k1246 in k1240 in infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1259,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 170  ##sys#hash-table-ref */
t6=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[42]),t5);}
else{
t2=((C_word*)t0)[3];
f_1245(2,t2,C_SCHEME_UNDEFINED);}}

/* k1261 in k1246 in k1240 in infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 169  alist-cons */
t3=C_retrieve(lf[43]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1257 in k1246 in k1240 in infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 166  ##sys#hash-table-set! */
t2=C_retrieve(lf[41]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[42]),((C_word*)t0)[2],t1);}

/* k1243 in k1240 in infohook in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1226,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 160  print-header */
t6=((C_word*)t0)[2];
f_1171(t6,t5,t2,t3);}

/* k1231 in print-expr in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[36]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1211,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1218,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 155  print-header */
t7=((C_word*)t0)[2];
f_1171(t7,t6,t2,t3);}

/* k1216 in print-db in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 156  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[39],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1219 in k1216 in print-db in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 157  display-analysis-database */
t2=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1189,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 149  print-header */
t6=((C_word*)t0)[2];
f_1171(t6,t5,t2,t3);}

/* k1194 in print-node in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 151  dump-nodes */
t2=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 152  build-expression-tree */
t3=C_retrieve(lf[37]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1207 in k1194 in print-node in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 152  pretty-print */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1171(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1171,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1175,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 142  printf */
t5=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[34],t2);}
else{
t5=t4;
f_1175(2,t5,C_SCHEME_UNDEFINED);}}

/* k1173 in print-header in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[31])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 145  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[33],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1182 in k1173 in print-header in k1119 in k1113 in k1110 in k3218 in k1094 in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* option-arg in compile-source-file in k1056 in k1052 in k1048 in k1044 in k1040 in k1036 in k1031 in k1028 in k1025 in k1022 in k1019 in k1016 */
static void C_fcall f_1063(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1063,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 94   quit */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[8],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 97   quit */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[9],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[308] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_1018batch-driver.scm",(void*)f_1018},
{"f_1021batch-driver.scm",(void*)f_1021},
{"f_1024batch-driver.scm",(void*)f_1024},
{"f_1027batch-driver.scm",(void*)f_1027},
{"f_1030batch-driver.scm",(void*)f_1030},
{"f_1033batch-driver.scm",(void*)f_1033},
{"f_1038batch-driver.scm",(void*)f_1038},
{"f_1042batch-driver.scm",(void*)f_1042},
{"f_1046batch-driver.scm",(void*)f_1046},
{"f_1050batch-driver.scm",(void*)f_1050},
{"f_1054batch-driver.scm",(void*)f_1054},
{"f_1058batch-driver.scm",(void*)f_1058},
{"f_1060batch-driver.scm",(void*)f_1060},
{"f_1096batch-driver.scm",(void*)f_1096},
{"f_3239batch-driver.scm",(void*)f_3239},
{"f_3228batch-driver.scm",(void*)f_3228},
{"f_3224batch-driver.scm",(void*)f_3224},
{"f_3220batch-driver.scm",(void*)f_3220},
{"f_3209batch-driver.scm",(void*)f_3209},
{"f_3187batch-driver.scm",(void*)f_3187},
{"f_1112batch-driver.scm",(void*)f_1112},
{"f_3181batch-driver.scm",(void*)f_3181},
{"f_3177batch-driver.scm",(void*)f_3177},
{"f_1115batch-driver.scm",(void*)f_1115},
{"f_1121batch-driver.scm",(void*)f_1121},
{"f_3158batch-driver.scm",(void*)f_3158},
{"f_3154batch-driver.scm",(void*)f_3154},
{"f_3150batch-driver.scm",(void*)f_3150},
{"f_1509batch-driver.scm",(void*)f_1509},
{"f_1512batch-driver.scm",(void*)f_1512},
{"f_3142batch-driver.scm",(void*)f_3142},
{"f_3120batch-driver.scm",(void*)f_3120},
{"f_3138batch-driver.scm",(void*)f_3138},
{"f_3126batch-driver.scm",(void*)f_3126},
{"f_1516batch-driver.scm",(void*)f_1516},
{"f_3118batch-driver.scm",(void*)f_3118},
{"f_3102batch-driver.scm",(void*)f_3102},
{"f_3110batch-driver.scm",(void*)f_3110},
{"f_3114batch-driver.scm",(void*)f_3114},
{"f_1524batch-driver.scm",(void*)f_1524},
{"f_1527batch-driver.scm",(void*)f_1527},
{"f_1530batch-driver.scm",(void*)f_1530},
{"f_1533batch-driver.scm",(void*)f_1533},
{"f_1536batch-driver.scm",(void*)f_1536},
{"f_1539batch-driver.scm",(void*)f_1539},
{"f_1542batch-driver.scm",(void*)f_1542},
{"f_1545batch-driver.scm",(void*)f_1545},
{"f_1548batch-driver.scm",(void*)f_1548},
{"f_3061batch-driver.scm",(void*)f_3061},
{"f_1552batch-driver.scm",(void*)f_1552},
{"f_3053batch-driver.scm",(void*)f_3053},
{"f_1555batch-driver.scm",(void*)f_1555},
{"f_1558batch-driver.scm",(void*)f_1558},
{"f_1561batch-driver.scm",(void*)f_1561},
{"f_1564batch-driver.scm",(void*)f_1564},
{"f_1567batch-driver.scm",(void*)f_1567},
{"f_1570batch-driver.scm",(void*)f_1570},
{"f_1573batch-driver.scm",(void*)f_1573},
{"f_1576batch-driver.scm",(void*)f_1576},
{"f_1579batch-driver.scm",(void*)f_1579},
{"f_3012batch-driver.scm",(void*)f_3012},
{"f_1585batch-driver.scm",(void*)f_1585},
{"f_2997batch-driver.scm",(void*)f_2997},
{"f_3000batch-driver.scm",(void*)f_3000},
{"f_3003batch-driver.scm",(void*)f_3003},
{"f_1591batch-driver.scm",(void*)f_1591},
{"f_2984batch-driver.scm",(void*)f_2984},
{"f_2987batch-driver.scm",(void*)f_2987},
{"f_1594batch-driver.scm",(void*)f_1594},
{"f_1597batch-driver.scm",(void*)f_1597},
{"f_2942batch-driver.scm",(void*)f_2942},
{"f_1600batch-driver.scm",(void*)f_1600},
{"f_2939batch-driver.scm",(void*)f_2939},
{"f_2935batch-driver.scm",(void*)f_2935},
{"f_1606batch-driver.scm",(void*)f_1606},
{"f_1609batch-driver.scm",(void*)f_1609},
{"f_2919batch-driver.scm",(void*)f_2919},
{"f_2911batch-driver.scm",(void*)f_2911},
{"f_2909batch-driver.scm",(void*)f_2909},
{"f_1613batch-driver.scm",(void*)f_1613},
{"f_1616batch-driver.scm",(void*)f_1616},
{"f_2901batch-driver.scm",(void*)f_2901},
{"f_2893batch-driver.scm",(void*)f_2893},
{"f_2891batch-driver.scm",(void*)f_2891},
{"f_1619batch-driver.scm",(void*)f_1619},
{"f_1626batch-driver.scm",(void*)f_1626},
{"f_2884batch-driver.scm",(void*)f_2884},
{"f_1629batch-driver.scm",(void*)f_1629},
{"f_2873batch-driver.scm",(void*)f_2873},
{"f_2881batch-driver.scm",(void*)f_2881},
{"f_1632batch-driver.scm",(void*)f_1632},
{"f_1636batch-driver.scm",(void*)f_1636},
{"f_1644batch-driver.scm",(void*)f_1644},
{"f_1648batch-driver.scm",(void*)f_1648},
{"f_2859batch-driver.scm",(void*)f_2859},
{"f_2855batch-driver.scm",(void*)f_2855},
{"f_2839batch-driver.scm",(void*)f_2839},
{"f_1651batch-driver.scm",(void*)f_1651},
{"f_2832batch-driver.scm",(void*)f_2832},
{"f_2812batch-driver.scm",(void*)f_2812},
{"f_2810batch-driver.scm",(void*)f_2810},
{"f_1679batch-driver.scm",(void*)f_1679},
{"f_1682batch-driver.scm",(void*)f_1682},
{"f_2789batch-driver.scm",(void*)f_2789},
{"f_1686batch-driver.scm",(void*)f_1686},
{"f_2782batch-driver.scm",(void*)f_2782},
{"f_1690batch-driver.scm",(void*)f_1690},
{"f_2775batch-driver.scm",(void*)f_2775},
{"f_1694batch-driver.scm",(void*)f_1694},
{"f_2768batch-driver.scm",(void*)f_2768},
{"f_1698batch-driver.scm",(void*)f_1698},
{"f_2748batch-driver.scm",(void*)f_2748},
{"f_1702batch-driver.scm",(void*)f_1702},
{"f_1713batch-driver.scm",(void*)f_1713},
{"f_1716batch-driver.scm",(void*)f_1716},
{"f_1719batch-driver.scm",(void*)f_1719},
{"f_2701batch-driver.scm",(void*)f_2701},
{"f_1722batch-driver.scm",(void*)f_1722},
{"f_1743batch-driver.scm",(void*)f_1743},
{"f_1774batch-driver.scm",(void*)f_1774},
{"f_1780batch-driver.scm",(void*)f_1780},
{"f_1784batch-driver.scm",(void*)f_1784},
{"f_1787batch-driver.scm",(void*)f_1787},
{"f_1790batch-driver.scm",(void*)f_1790},
{"f_1793batch-driver.scm",(void*)f_1793},
{"f_1801batch-driver.scm",(void*)f_1801},
{"f_1804batch-driver.scm",(void*)f_1804},
{"f_1807batch-driver.scm",(void*)f_1807},
{"f_2667batch-driver.scm",(void*)f_2667},
{"f_2675batch-driver.scm",(void*)f_2675},
{"f_1810batch-driver.scm",(void*)f_1810},
{"f_1813batch-driver.scm",(void*)f_1813},
{"f_2582batch-driver.scm",(void*)f_2582},
{"f_2611batch-driver.scm",(void*)f_2611},
{"f_2660batch-driver.scm",(void*)f_2660},
{"f_2628batch-driver.scm",(void*)f_2628},
{"f_2632batch-driver.scm",(void*)f_2632},
{"f_2637batch-driver.scm",(void*)f_2637},
{"f_2658batch-driver.scm",(void*)f_2658},
{"f_2623batch-driver.scm",(void*)f_2623},
{"f_2614batch-driver.scm",(void*)f_2614},
{"f_2597batch-driver.scm",(void*)f_2597},
{"f_2601batch-driver.scm",(void*)f_2601},
{"f_2605batch-driver.scm",(void*)f_2605},
{"f_2593batch-driver.scm",(void*)f_2593},
{"f_2570batch-driver.scm",(void*)f_2570},
{"f_2574batch-driver.scm",(void*)f_2574},
{"f_1816batch-driver.scm",(void*)f_1816},
{"f_1819batch-driver.scm",(void*)f_1819},
{"f_2560batch-driver.scm",(void*)f_2560},
{"f_2564batch-driver.scm",(void*)f_2564},
{"f_1822batch-driver.scm",(void*)f_1822},
{"f_1825batch-driver.scm",(void*)f_1825},
{"f_2537batch-driver.scm",(void*)f_2537},
{"f_2557batch-driver.scm",(void*)f_2557},
{"f_1831batch-driver.scm",(void*)f_1831},
{"f_2530batch-driver.scm",(void*)f_2530},
{"f_1834batch-driver.scm",(void*)f_1834},
{"f_1837batch-driver.scm",(void*)f_1837},
{"f_2498batch-driver.scm",(void*)f_2498},
{"f_2372batch-driver.scm",(void*)f_2372},
{"f_2488batch-driver.scm",(void*)f_2488},
{"f_2376batch-driver.scm",(void*)f_2376},
{"f_2380batch-driver.scm",(void*)f_2380},
{"f_2399batch-driver.scm",(void*)f_2399},
{"f_2384batch-driver.scm",(void*)f_2384},
{"f_1843batch-driver.scm",(void*)f_1843},
{"f_2365batch-driver.scm",(void*)f_2365},
{"f_1846batch-driver.scm",(void*)f_1846},
{"f_2359batch-driver.scm",(void*)f_2359},
{"f_1849batch-driver.scm",(void*)f_1849},
{"f_1852batch-driver.scm",(void*)f_1852},
{"f_1855batch-driver.scm",(void*)f_1855},
{"f_2338batch-driver.scm",(void*)f_2338},
{"f_1858batch-driver.scm",(void*)f_1858},
{"f_1863batch-driver.scm",(void*)f_1863},
{"f_1866batch-driver.scm",(void*)f_1866},
{"f_1869batch-driver.scm",(void*)f_1869},
{"f_1872batch-driver.scm",(void*)f_1872},
{"f_2316batch-driver.scm",(void*)f_2316},
{"f_2323batch-driver.scm",(void*)f_2323},
{"f_1875batch-driver.scm",(void*)f_1875},
{"f_2313batch-driver.scm",(void*)f_2313},
{"f_1878batch-driver.scm",(void*)f_1878},
{"f_2306batch-driver.scm",(void*)f_2306},
{"f_1881batch-driver.scm",(void*)f_1881},
{"f_2303batch-driver.scm",(void*)f_2303},
{"f_2299batch-driver.scm",(void*)f_2299},
{"f_2265batch-driver.scm",(void*)f_2265},
{"f_2295batch-driver.scm",(void*)f_2295},
{"f_2291batch-driver.scm",(void*)f_2291},
{"f_2269batch-driver.scm",(void*)f_2269},
{"f_2278batch-driver.scm",(void*)f_2278},
{"f_2281batch-driver.scm",(void*)f_2281},
{"f_1884batch-driver.scm",(void*)f_1884},
{"f_2260batch-driver.scm",(void*)f_2260},
{"f_2256batch-driver.scm",(void*)f_2256},
{"f_2248batch-driver.scm",(void*)f_2248},
{"f_1887batch-driver.scm",(void*)f_1887},
{"f_1890batch-driver.scm",(void*)f_1890},
{"f_2214batch-driver.scm",(void*)f_2214},
{"f_2221batch-driver.scm",(void*)f_2221},
{"f_2224batch-driver.scm",(void*)f_2224},
{"f_2227batch-driver.scm",(void*)f_2227},
{"f_2233batch-driver.scm",(void*)f_2233},
{"f_2236batch-driver.scm",(void*)f_2236},
{"f_2239batch-driver.scm",(void*)f_2239},
{"f_1893batch-driver.scm",(void*)f_1893},
{"f_2192batch-driver.scm",(void*)f_2192},
{"f_2195batch-driver.scm",(void*)f_2195},
{"f_2198batch-driver.scm",(void*)f_2198},
{"f_2204batch-driver.scm",(void*)f_2204},
{"f_2207batch-driver.scm",(void*)f_2207},
{"f_2210batch-driver.scm",(void*)f_2210},
{"f_1896batch-driver.scm",(void*)f_1896},
{"f_2181batch-driver.scm",(void*)f_2181},
{"f_2180batch-driver.scm",(void*)f_2180},
{"f_1902batch-driver.scm",(void*)f_1902},
{"f_1908batch-driver.scm",(void*)f_1908},
{"f_1911batch-driver.scm",(void*)f_1911},
{"f_1914batch-driver.scm",(void*)f_1914},
{"f_1919batch-driver.scm",(void*)f_1919},
{"f_1926batch-driver.scm",(void*)f_1926},
{"f_1929batch-driver.scm",(void*)f_1929},
{"f_1933batch-driver.scm",(void*)f_1933},
{"f_1936batch-driver.scm",(void*)f_1936},
{"f_1939batch-driver.scm",(void*)f_1939},
{"f_2031batch-driver.scm",(void*)f_2031},
{"f_2148batch-driver.scm",(void*)f_2148},
{"f_2034batch-driver.scm",(void*)f_2034},
{"f_2040batch-driver.scm",(void*)f_2040},
{"f_2043batch-driver.scm",(void*)f_2043},
{"f_2046batch-driver.scm",(void*)f_2046},
{"f_2131batch-driver.scm",(void*)f_2131},
{"f_2049batch-driver.scm",(void*)f_2049},
{"f_2052batch-driver.scm",(void*)f_2052},
{"f_2055batch-driver.scm",(void*)f_2055},
{"f_2069batch-driver.scm",(void*)f_2069},
{"f_2073batch-driver.scm",(void*)f_2073},
{"f_2079batch-driver.scm",(void*)f_2079},
{"f_2082batch-driver.scm",(void*)f_2082},
{"f_2085batch-driver.scm",(void*)f_2085},
{"f_2088batch-driver.scm",(void*)f_2088},
{"f_2091batch-driver.scm",(void*)f_2091},
{"f_2113batch-driver.scm",(void*)f_2113},
{"f_2094batch-driver.scm",(void*)f_2094},
{"f_2097batch-driver.scm",(void*)f_2097},
{"f_2063batch-driver.scm",(void*)f_2063},
{"f_1945batch-driver.scm",(void*)f_1945},
{"f_1959batch-driver.scm",(void*)f_1959},
{"f_1963batch-driver.scm",(void*)f_1963},
{"f_1966batch-driver.scm",(void*)f_1966},
{"f_1985batch-driver.scm",(void*)f_1985},
{"f_2002batch-driver.scm",(void*)f_2002},
{"f_2005batch-driver.scm",(void*)f_2005},
{"f_2011batch-driver.scm",(void*)f_2011},
{"f_2014batch-driver.scm",(void*)f_2014},
{"f_1953batch-driver.scm",(void*)f_1953},
{"f_1762batch-driver.scm",(void*)f_1762},
{"f_1755batch-driver.scm",(void*)f_1755},
{"f_1731batch-driver.scm",(void*)f_1731},
{"f_1653batch-driver.scm",(void*)f_1653},
{"f_1675batch-driver.scm",(void*)f_1675},
{"f_1667batch-driver.scm",(void*)f_1667},
{"f_1665batch-driver.scm",(void*)f_1665},
{"f_1661batch-driver.scm",(void*)f_1661},
{"f_1430batch-driver.scm",(void*)f_1430},
{"f_1460batch-driver.scm",(void*)f_1460},
{"f_1455batch-driver.scm",(void*)f_1455},
{"f_1432batch-driver.scm",(void*)f_1432},
{"f_1436batch-driver.scm",(void*)f_1436},
{"f_1450batch-driver.scm",(void*)f_1450},
{"f_1444batch-driver.scm",(void*)f_1444},
{"f_1439batch-driver.scm",(void*)f_1439},
{"f_1424batch-driver.scm",(void*)f_1424},
{"f_1407batch-driver.scm",(void*)f_1407},
{"f_1397batch-driver.scm",(void*)f_1397},
{"f_1367batch-driver.scm",(void*)f_1367},
{"f_1373batch-driver.scm",(void*)f_1373},
{"f_1387batch-driver.scm",(void*)f_1387},
{"f_1391batch-driver.scm",(void*)f_1391},
{"f_1287batch-driver.scm",(void*)f_1287},
{"f_1356batch-driver.scm",(void*)f_1356},
{"f_1352batch-driver.scm",(void*)f_1352},
{"f_1336batch-driver.scm",(void*)f_1336},
{"f_1328batch-driver.scm",(void*)f_1328},
{"f_1297batch-driver.scm",(void*)f_1297},
{"f_1238batch-driver.scm",(void*)f_1238},
{"f_1284batch-driver.scm",(void*)f_1284},
{"f_1242batch-driver.scm",(void*)f_1242},
{"f_1248batch-driver.scm",(void*)f_1248},
{"f_1263batch-driver.scm",(void*)f_1263},
{"f_1259batch-driver.scm",(void*)f_1259},
{"f_1245batch-driver.scm",(void*)f_1245},
{"f_1226batch-driver.scm",(void*)f_1226},
{"f_1233batch-driver.scm",(void*)f_1233},
{"f_1211batch-driver.scm",(void*)f_1211},
{"f_1218batch-driver.scm",(void*)f_1218},
{"f_1221batch-driver.scm",(void*)f_1221},
{"f_1189batch-driver.scm",(void*)f_1189},
{"f_1196batch-driver.scm",(void*)f_1196},
{"f_1209batch-driver.scm",(void*)f_1209},
{"f_1171batch-driver.scm",(void*)f_1171},
{"f_1175batch-driver.scm",(void*)f_1175},
{"f_1184batch-driver.scm",(void*)f_1184},
{"f_1063batch-driver.scm",(void*)f_1063},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
