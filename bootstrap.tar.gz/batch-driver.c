/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-07 10:49
   Version 3.3.4 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   compiled 2008-07-29 on pequod (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[347];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_436)
static void C_ccall f_436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_442)
static void C_ccall f_442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_fcall f_2464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_ccall f_500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_509)
static void C_fcall f_509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_fcall f_897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_fcall f_908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_fcall f_911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_fcall f_917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_fcall f_923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_fcall f_926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_929)
static void C_fcall f_929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_fcall f_946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_949)
static void C_fcall f_949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_fcall f_955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_fcall f_958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_961)
static void C_fcall f_961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_fcall f_964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_fcall f_967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_fcall f_970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_fcall f_976(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_fcall f_1001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_fcall f_1043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1053)
static void C_fcall f_1053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_fcall f_1087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_fcall f_1114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_fcall f_1886(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_fcall f_1193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_fcall f_1202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_fcall f_1694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_fcall f_1261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_fcall f_1264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_fcall f_1502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_fcall f_818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_848)
static void C_fcall f_848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_fcall f_843(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_820)
static void C_fcall f_820(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_812)
static void C_fcall f_812(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_795)
static void C_fcall f_795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_785)
static C_word C_fcall f_785(C_word t0);
C_noret_decl(f_755)
static void C_fcall f_755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_761)
static void C_fcall f_761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_fcall f_675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_685)
static void C_ccall f_685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_626)
static void C_ccall f_626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_fcall f_636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_614)
static void C_fcall f_614(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_621)
static void C_ccall f_621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_fcall f_599(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_606)
static void C_ccall f_606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_609)
static void C_ccall f_609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_fcall f_577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_fcall f_559(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_ccall f_572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_553)
static C_word C_fcall f_553();
C_noret_decl(f_451)
static void C_fcall f_451(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2464)
static void C_fcall trf_2464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2464(t0,t1);}

C_noret_decl(trf_509)
static void C_fcall trf_509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_509(t0,t1);}

C_noret_decl(trf_897)
static void C_fcall trf_897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_897(t0,t1);}

C_noret_decl(trf_908)
static void C_fcall trf_908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_908(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_908(t0,t1);}

C_noret_decl(trf_911)
static void C_fcall trf_911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_911(t0,t1);}

C_noret_decl(trf_917)
static void C_fcall trf_917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_917(t0,t1);}

C_noret_decl(trf_923)
static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_923(t0,t1);}

C_noret_decl(trf_926)
static void C_fcall trf_926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_926(t0,t1);}

C_noret_decl(trf_929)
static void C_fcall trf_929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_929(t0,t1);}

C_noret_decl(trf_946)
static void C_fcall trf_946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_946(t0,t1);}

C_noret_decl(trf_949)
static void C_fcall trf_949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_949(t0,t1);}

C_noret_decl(trf_955)
static void C_fcall trf_955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_955(t0,t1);}

C_noret_decl(trf_958)
static void C_fcall trf_958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_958(t0,t1);}

C_noret_decl(trf_961)
static void C_fcall trf_961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_961(t0,t1);}

C_noret_decl(trf_964)
static void C_fcall trf_964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_964(t0,t1);}

C_noret_decl(trf_967)
static void C_fcall trf_967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_967(t0,t1);}

C_noret_decl(trf_970)
static void C_fcall trf_970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_970(t0,t1);}

C_noret_decl(trf_976)
static void C_fcall trf_976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_976(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_976(t0,t1);}

C_noret_decl(trf_1001)
static void C_fcall trf_1001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1001(t0,t1);}

C_noret_decl(trf_1043)
static void C_fcall trf_1043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1043(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1043(t0,t1);}

C_noret_decl(trf_1053)
static void C_fcall trf_1053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1053(t0,t1);}

C_noret_decl(trf_1087)
static void C_fcall trf_1087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1087(t0,t1);}

C_noret_decl(trf_1114)
static void C_fcall trf_1114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1114(t0,t1);}

C_noret_decl(trf_1828)
static void C_fcall trf_1828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1828(t0,t1,t2);}

C_noret_decl(trf_1886)
static void C_fcall trf_1886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1886(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1886(t0,t1,t2);}

C_noret_decl(trf_1193)
static void C_fcall trf_1193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1193(t0,t1);}

C_noret_decl(trf_1202)
static void C_fcall trf_1202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1202(t0,t1);}

C_noret_decl(trf_1694)
static void C_fcall trf_1694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1694(t0,t1);}

C_noret_decl(trf_1261)
static void C_fcall trf_1261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1261(t0,t1);}

C_noret_decl(trf_1264)
static void C_fcall trf_1264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1264(t0,t1);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1287(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1502)
static void C_fcall trf_1502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1502(t0,t1);}

C_noret_decl(trf_818)
static void C_fcall trf_818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_818(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_818(t0,t1,t2,t3,t4);}

C_noret_decl(trf_848)
static void C_fcall trf_848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_848(t0,t1);}

C_noret_decl(trf_843)
static void C_fcall trf_843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_843(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_843(t0,t1,t2);}

C_noret_decl(trf_820)
static void C_fcall trf_820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_820(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_820(t0,t1,t2,t3);}

C_noret_decl(trf_812)
static void C_fcall trf_812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_812(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_812(t0,t1,t2);}

C_noret_decl(trf_795)
static void C_fcall trf_795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_795(t0,t1,t2);}

C_noret_decl(trf_755)
static void C_fcall trf_755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_755(t0,t1,t2);}

C_noret_decl(trf_761)
static void C_fcall trf_761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_761(t0,t1,t2);}

C_noret_decl(trf_675)
static void C_fcall trf_675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_675(t0,t1);}

C_noret_decl(trf_636)
static void C_fcall trf_636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_636(t0,t1);}

C_noret_decl(trf_614)
static void C_fcall trf_614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_614(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_614(t0,t1,t2,t3,t4);}

C_noret_decl(trf_599)
static void C_fcall trf_599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_599(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_599(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_577)
static void C_fcall trf_577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_577(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_577(t0,t1,t2,t3,t4);}

C_noret_decl(trf_559)
static void C_fcall trf_559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_559(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_559(t0,t1,t2,t3);}

C_noret_decl(trf_451)
static void C_fcall trf_451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_451(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2670)){
C_save(t1);
C_rereclaim2(2670*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,347);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[5]=C_h_intern(&lf[5],19,"compile-source-file");
lf[6]=C_h_intern(&lf[6],4,"quit");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[9]=C_h_intern(&lf[9],12,"explicit-use");
lf[10]=C_h_intern(&lf[10],26,"\010compilerexplicit-use-flag");
lf[11]=C_h_intern(&lf[11],12,"\004coredeclare");
lf[12]=C_h_intern(&lf[12],7,"verbose");
lf[13]=C_h_intern(&lf[13],11,"output-file");
lf[14]=C_h_intern(&lf[14],36,"\010compilerdefault-optimization-passes");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[16]=C_h_intern(&lf[16],7,"profile");
lf[17]=C_h_intern(&lf[17],12,"profile-name");
lf[18]=C_h_intern(&lf[18],9,"heap-size");
lf[19]=C_h_intern(&lf[19],17,"heap-initial-size");
lf[20]=C_h_intern(&lf[20],11,"heap-growth");
lf[21]=C_h_intern(&lf[21],14,"heap-shrinkage");
lf[22]=C_h_intern(&lf[22],13,"keyword-style");
lf[23]=C_h_intern(&lf[23],4,"unit");
lf[24]=C_h_intern(&lf[24],12,"analyze-only");
lf[25]=C_h_intern(&lf[25],7,"dynamic");
lf[26]=C_h_intern(&lf[26],5,"quiet");
lf[27]=C_h_intern(&lf[27],7,"nursery");
lf[28]=C_h_intern(&lf[28],10,"stack-size");
lf[29]=C_h_intern(&lf[29],26,"\010compilerdebugging-chicken");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[33]=C_h_intern(&lf[33],19,"\010compilerdump-nodes");
lf[34]=C_h_intern(&lf[34],12,"pretty-print");
lf[35]=C_h_intern(&lf[35],30,"\010compilerbuild-expression-tree");
lf[36]=C_h_intern(&lf[36],34,"\010compilerdisplay-analysis-database");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[38]=C_h_intern(&lf[38],12,"\003sysfor-each");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],24,"\003sysline-number-database");
lf[41]=C_h_intern(&lf[41],10,"alist-cons");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],9,"list-info");
lf[44]=C_h_intern(&lf[44],26,"\003sysdefault-read-info-hook");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[46]=C_h_intern(&lf[46],9,"substring");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[48]=C_h_intern(&lf[48],8,"\003sysread");
lf[49]=C_h_intern(&lf[49],12,"\010compilerget");
lf[50]=C_h_intern(&lf[50],13,"\010compilerput!");
lf[51]=C_h_intern(&lf[51],27,"\010compileranalyze-expression");
lf[52]=C_h_intern(&lf[52],9,"\003syserror");
lf[53]=C_h_intern(&lf[53],1,"D");
lf[54]=C_h_intern(&lf[54],12,"emit-exports");
lf[55]=C_h_intern(&lf[55],13,"check-imports");
lf[56]=C_h_intern(&lf[56],25,"\010compileruse-import-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerdisabled-warnings");
lf[58]=C_h_intern(&lf[58],12,"inline-limit");
lf[59]=C_h_intern(&lf[59],21,"\010compilerverbose-mode");
lf[60]=C_h_intern(&lf[60],31,"\003sysread-error-with-line-number");
lf[61]=C_h_intern(&lf[61],21,"\003sysinclude-pathnames");
lf[62]=C_h_intern(&lf[62],19,"\000compiler-extension");
lf[63]=C_h_intern(&lf[63],12,"\003sysfeatures");
lf[64]=C_h_intern(&lf[64],10,"\000compiling");
lf[65]=C_h_intern(&lf[65],6,"\000match");
lf[66]=C_h_intern(&lf[66],25,"\010compilertarget-heap-size");
lf[67]=C_h_intern(&lf[67],33,"\010compilertarget-initial-heap-size");
lf[68]=C_h_intern(&lf[68],27,"\010compilertarget-heap-growth");
lf[69]=C_h_intern(&lf[69],30,"\010compilertarget-heap-shrinkage");
lf[70]=C_h_intern(&lf[70],26,"\010compilertarget-stack-size");
lf[71]=C_h_intern(&lf[71],8,"no-trace");
lf[72]=C_h_intern(&lf[72],24,"\010compileremit-trace-info");
lf[73]=C_h_intern(&lf[73],29,"disable-stack-overflow-checks");
lf[74]=C_h_intern(&lf[74],40,"\010compilerdisable-stack-overflow-checking");
lf[75]=C_h_intern(&lf[75],7,"version");
lf[76]=C_h_intern(&lf[76],7,"newline");
lf[77]=C_h_intern(&lf[77],22,"\010compilerprint-version");
lf[78]=C_h_intern(&lf[78],4,"help");
lf[79]=C_h_intern(&lf[79],20,"\010compilerprint-usage");
lf[80]=C_h_intern(&lf[80],7,"release");
lf[81]=C_h_intern(&lf[81],7,"display");
lf[82]=C_h_intern(&lf[82],15,"chicken-version");
lf[83]=C_h_intern(&lf[83],24,"\010compilersource-filename");
lf[84]=C_h_intern(&lf[84],28,"\010compilerprofile-lambda-list");
lf[85]=C_h_intern(&lf[85],31,"\010compilerline-number-database-2");
lf[86]=C_h_intern(&lf[86],4,"node");
lf[87]=C_h_intern(&lf[87],6,"lambda");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[89]=C_h_intern(&lf[89],23,"\010compilerconstant-table");
lf[90]=C_h_intern(&lf[90],21,"\010compilerinline-table");
lf[91]=C_h_intern(&lf[91],23,"\010compilerfirst-analysis");
lf[92]=C_h_intern(&lf[92],41,"\010compilerperform-high-level-optimizations");
lf[93]=C_h_intern(&lf[93],37,"\010compilerinline-substitutions-enabled");
lf[94]=C_h_intern(&lf[94],22,"optimize-leaf-routines");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[96]=C_h_intern(&lf[96],34,"\010compilertransform-direct-lambdas!");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[98]=C_h_intern(&lf[98],4,"leaf");
lf[99]=C_h_intern(&lf[99],18,"\010compilerdebugging");
lf[100]=C_h_intern(&lf[100],1,"p");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[103]=C_h_intern(&lf[103],1,"5");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[106]=C_h_intern(&lf[106],36,"\010compilerprepare-for-code-generation");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[108]=C_h_intern(&lf[108],30,"\010compilercompiler-cleanup-hook");
lf[109]=C_h_intern(&lf[109],1,"t");
lf[110]=C_h_intern(&lf[110],17,"\003sysdisplay-times");
lf[111]=C_h_intern(&lf[111],14,"\003sysstop-timer");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[113]=C_h_intern(&lf[113],17,"close-output-port");
lf[114]=C_h_intern(&lf[114],22,"\010compilergenerate-code");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[116]=C_h_intern(&lf[116],16,"open-output-file");
lf[117]=C_h_intern(&lf[117],19,"current-output-port");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[120]=C_h_intern(&lf[120],1,"9");
lf[121]=C_h_intern(&lf[121],4,"exit");
lf[122]=C_h_intern(&lf[122],25,"\010compilerexport-file-name");
lf[123]=C_h_intern(&lf[123],30,"\010compilerdump-exported-globals");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000$(do not worry - still compiling...)\012");
lf[125]=C_h_intern(&lf[125],20,"\003syswarnings-enabled");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[127]=C_h_intern(&lf[127],1,"8");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[129]=C_h_intern(&lf[129],35,"\010compilerperform-closure-conversion");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[131]=C_h_intern(&lf[131],1,"7");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],33,"\010compilerprint-program-statistics");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[135]=C_h_intern(&lf[135],1,"4");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[137]=C_h_intern(&lf[137],1,"u");
lf[138]=C_h_intern(&lf[138],31,"\010compilerdump-undefined-globals");
lf[139]=C_h_intern(&lf[139],29,"\010compilercheck-global-exports");
lf[140]=C_h_intern(&lf[140],29,"\010compilercheck-global-imports");
lf[141]=C_h_intern(&lf[141],3,"opt");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[143]=C_h_intern(&lf[143],1,"3");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[145]=C_h_intern(&lf[145],31,"\010compilerperform-cps-conversion");
lf[146]=C_h_intern(&lf[146],6,"unsafe");
lf[147]=C_h_intern(&lf[147],34,"\010compilerscan-toplevel-assignments");
lf[148]=C_h_intern(&lf[148],26,"\010compilerdo-lambda-lifting");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[150]=C_h_intern(&lf[150],1,"L");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[152]=C_h_intern(&lf[152],32,"\010compilerperform-lambda-lifting!");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[155]=C_h_intern(&lf[155],1,"0");
lf[156]=C_h_intern(&lf[156],4,"lift");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[158]=C_h_intern(&lf[158],1,"U");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[162]=C_h_intern(&lf[162],4,"user");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[164]=C_h_intern(&lf[164],21,"\003syshash-table->alist");
lf[165]=C_h_intern(&lf[165],26,"\010compilerfile-requirements");
lf[166]=C_h_intern(&lf[166],1,"M");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[168]=C_h_intern(&lf[168],11,"user-pass-2");
lf[169]=C_h_intern(&lf[169],25,"\010compilerbuild-node-graph");
lf[170]=C_h_intern(&lf[170],32,"\010compilercanonicalize-begin-body");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[172]=C_h_intern(&lf[172],7,"\003sysmap");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[174]=C_h_intern(&lf[174],9,"user-pass");
lf[175]=C_h_intern(&lf[175],12,"check-syntax");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[177]=C_h_intern(&lf[177],1,"2");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[179]=C_h_intern(&lf[179],25,"\010compilercompiler-warning");
lf[180]=C_h_intern(&lf[180],5,"style");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[182]=C_h_intern(&lf[182],8,"feature\077");
lf[183]=C_h_intern(&lf[183],19,"compiling-extension");
lf[184]=C_h_intern(&lf[184],18,"\010compilerunit-name");
lf[185]=C_h_intern(&lf[185],5,"usage");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[187]=C_h_intern(&lf[187],26,"\010compilerblock-compilation");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[189]=C_h_intern(&lf[189],37,"\010compilerdisplay-line-number-database");
lf[190]=C_h_intern(&lf[190],1,"n");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[192]=C_h_intern(&lf[192],32,"\010compilerdisplay-real-name-table");
lf[193]=C_h_intern(&lf[193],1,"N");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[195]=C_h_intern(&lf[195],6,"append");
lf[196]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[197]=C_h_intern(&lf[197],5,"quote");
lf[198]=C_h_intern(&lf[198],28,"\003sysset-profile-info-vector!");
lf[199]=C_h_intern(&lf[199],33,"\010compilerprofile-info-vector-name");
lf[200]=C_h_intern(&lf[200],21,"\010compileremit-profile");
lf[201]=C_h_intern(&lf[201],25,"\003sysregister-profile-info");
lf[202]=C_h_intern(&lf[202],4,"set!");
lf[203]=C_h_intern(&lf[203],13,"\004corecallunit");
lf[204]=C_h_intern(&lf[204],19,"\010compilerused-units");
lf[205]=C_h_intern(&lf[205],28,"\010compilerimmutable-constants");
lf[206]=C_h_intern(&lf[206],6,"gensym");
lf[207]=C_h_intern(&lf[207],32,"\010compilercanonicalize-expression");
lf[208]=C_h_intern(&lf[208],28,"\003sysexplicit-library-modules");
lf[209]=C_h_intern(&lf[209],4,"uses");
lf[210]=C_h_intern(&lf[210],7,"declare");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[212]=C_h_intern(&lf[212],1,"1");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[214]=C_h_intern(&lf[214],22,"user-preprocessor-pass");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[216]=C_h_intern(&lf[216],21,"\010compilerstring->expr");
lf[217]=C_h_intern(&lf[217],7,"reverse");
lf[218]=C_h_intern(&lf[218],27,"\003syscurrent-source-filename");
lf[219]=C_h_intern(&lf[219],33,"\010compilerclose-checked-input-file");
lf[220]=C_h_intern(&lf[220],16,"\003sysdynamic-wind");
lf[221]=C_h_intern(&lf[221],34,"\010compilercheck-and-open-input-file");
lf[222]=C_h_intern(&lf[222],14,"user-read-pass");
lf[223]=C_h_intern(&lf[223],8,"epilogue");
lf[224]=C_h_intern(&lf[224],8,"prologue");
lf[225]=C_h_intern(&lf[225],8,"postlude");
lf[226]=C_h_intern(&lf[226],7,"prelude");
lf[227]=C_h_intern(&lf[227],11,"make-vector");
lf[228]=C_h_intern(&lf[228],34,"\010compilerline-number-database-size");
lf[229]=C_h_intern(&lf[229],1,"r");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[236]=C_h_intern(&lf[236],5,"-help");
lf[237]=C_h_intern(&lf[237],1,"h");
lf[238]=C_h_intern(&lf[238],2,"-h");
lf[239]=C_h_intern(&lf[239],18,"accumulate-profile");
lf[240]=C_h_intern(&lf[240],28,"\010compilerprofiled-procedures");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[244]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[245]=C_h_intern(&lf[245],39,"\010compilerdefault-profiling-declarations");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012stacktrace");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[249]=C_h_intern(&lf[249],21,"no-usual-integrations");
lf[250]=C_h_intern(&lf[250],17,"standard-bindings");
lf[251]=C_h_intern(&lf[251],34,"\010compilerdefault-standard-bindings");
lf[252]=C_h_intern(&lf[252],17,"extended-bindings");
lf[253]=C_h_intern(&lf[253],34,"\010compilerdefault-extended-bindings");
lf[254]=C_h_intern(&lf[254],1,"m");
lf[255]=C_h_intern(&lf[255],14,"set-gc-report!");
lf[256]=C_h_intern(&lf[256],42,"\010compilerdefault-default-target-stack-size");
lf[257]=C_h_intern(&lf[257],41,"\010compilerdefault-default-target-heap-size");
lf[258]=C_h_intern(&lf[258],15,"run-time-macros");
lf[259]=C_h_intern(&lf[259],25,"\003sysenable-runtime-macros");
lf[260]=C_h_intern(&lf[260],22,"\004corerequire-extension");
lf[261]=C_h_intern(&lf[261],15,"lset-difference");
lf[262]=C_h_intern(&lf[262],3,"eq\077");
lf[263]=C_h_intern(&lf[263],14,"string->symbol");
lf[264]=C_h_intern(&lf[264],12,"string-split");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[266]=C_h_intern(&lf[266],10,"append-map");
lf[267]=C_h_intern(&lf[267],17,"require-extension");
lf[268]=C_h_intern(&lf[268],9,"extension");
lf[269]=C_h_intern(&lf[269],16,"define-extension");
lf[270]=C_h_intern(&lf[270],13,"pathname-file");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[272]=C_h_intern(&lf[272],28,"\010compilerpostponed-initforms");
lf[273]=C_h_intern(&lf[273],23,"user-post-analysis-pass");
lf[274]=C_h_intern(&lf[274],11,"\003sysprovide");
lf[275]=C_h_intern(&lf[275],5,"match");
lf[276]=C_h_intern(&lf[276],6,"delete");
lf[277]=C_h_intern(&lf[277],4,"load");
lf[278]=C_h_intern(&lf[278],28,"\003sysresolve-include-filename");
lf[279]=C_h_intern(&lf[279],12,"load-verbose");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[281]=C_h_intern(&lf[281],6,"extend");
lf[282]=C_h_intern(&lf[282],17,"register-feature!");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[284]=C_h_intern(&lf[284],7,"feature");
lf[285]=C_h_intern(&lf[285],20,"keep-shadowed-macros");
lf[286]=C_h_intern(&lf[286],33,"\010compilerundefine-shadowed-macros");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[289]=C_h_intern(&lf[289],23,"\010compilerchop-separator");
lf[290]=C_h_intern(&lf[290],12,"include-path");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[292]=C_h_intern(&lf[292],7,"\000prefix");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[294]=C_h_intern(&lf[294],5,"\000none");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[296]=C_h_intern(&lf[296],7,"\000suffix");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[298]=C_h_intern(&lf[298],17,"compress-literals");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[300]=C_h_intern(&lf[300],16,"case-insensitive");
lf[301]=C_h_intern(&lf[301],14,"case-sensitive");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[303]=C_h_intern(&lf[303],24,"\010compilerinline-max-size");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[305]=C_h_intern(&lf[305],6,"inline");
lf[306]=C_h_intern(&lf[306],30,"emit-external-prototypes-first");
lf[307]=C_h_intern(&lf[307],30,"\010compilerexternal-protos-first");
lf[308]=C_h_intern(&lf[308],5,"block");
lf[309]=C_h_intern(&lf[309],17,"fixnum-arithmetic");
lf[310]=C_h_intern(&lf[310],11,"number-type");
lf[311]=C_h_intern(&lf[311],6,"fixnum");
lf[312]=C_h_intern(&lf[312],18,"disable-interrupts");
lf[313]=C_h_intern(&lf[313],28,"\010compilerinsert-timer-checks");
lf[314]=C_h_intern(&lf[314],16,"unsafe-libraries");
lf[315]=C_h_intern(&lf[315],27,"\010compileremit-unsafe-marker");
lf[316]=C_h_intern(&lf[316],23,"\005matchset-error-control");
lf[317]=C_h_intern(&lf[317],5,"\000fail");
lf[318]=C_h_intern(&lf[318],11,"no-warnings");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[320]=C_h_intern(&lf[320],15,"disable-warning");
lf[321]=C_h_intern(&lf[321],28,"\010compilerlookup-exports-file");
lf[322]=C_h_intern(&lf[322],6,"import");
lf[323]=C_h_intern(&lf[323],14,"no-lambda-info");
lf[324]=C_h_intern(&lf[324],26,"\010compileremit-closure-info");
lf[325]=C_h_intern(&lf[325],3,"raw");
lf[326]=C_h_intern(&lf[326],1,"b");
lf[327]=C_h_intern(&lf[327],15,"\003sysstart-timer");
lf[328]=C_h_intern(&lf[328],23,"disable-compiler-macros");
lf[329]=C_h_intern(&lf[329],32,"\010compilercompiler-macros-enabled");
lf[330]=C_h_intern(&lf[330],11,"lambda-lift");
lf[331]=C_h_intern(&lf[331],16,"\003sysstring->list");
lf[332]=C_h_intern(&lf[332],5,"debug");
lf[333]=C_h_intern(&lf[333],29,"\010compilerstring->c-identifier");
lf[334]=C_h_intern(&lf[334],18,"\010compilerstringify");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[337]=C_h_intern(&lf[337],6,"getenv");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[339]=C_h_intern(&lf[339],14,"symbol->string");
lf[340]=C_h_intern(&lf[340],9,"to-stdout");
lf[341]=C_h_intern(&lf[341],13,"make-pathname");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[344]=C_h_intern(&lf[344],29,"\010compilerdefault-declarations");
lf[345]=C_h_intern(&lf[345],30,"\010compilerunits-used-by-default");
lf[346]=C_h_intern(&lf[346],28,"\010compilerinitialize-compiler");
C_register_lf2(lf,347,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_427,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k425 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k428 in k425 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k431 in k428 in k425 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k434 in k431 in k428 in k425 */
static void C_ccall f_436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_442,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_448,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_448(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_448r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_448r(t0,t1,t2,t3);}}

static void C_ccall f_448r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_451,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_484,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 93   initialize-compiler */
t6=C_retrieve(lf[346]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
t2=(C_word)C_i_memq(lf[9],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2452,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2460,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[10]))){
t8=t7;
f_2464(t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_a_i_cons(&a,2,lf[209],C_retrieve(lf[345]));
t9=t7;
f_2464(t9,(C_word)C_a_i_list(&a,1,t8));}}

/* k2462 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_2464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 97   append */
t2=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[344]),t1);}

/* k2458 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2451 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2452,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[197],t2));}

/* k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[11],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[12],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 105  option-arg */
f_451(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[340],((C_word*)t0)[5]))){
t9=t8;
f_500(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 110  pathname-file */
t10=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_2439(2,t10,lf[343]);}}}}

/* k2437 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 110  make-pathname */
t2=C_retrieve(lf[341]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[342]);}

/* k2415 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 107  symbol->string */
t2=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_500(2,t2,t1);}}

/* k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_503,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2411,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 111  getenv */
t5=C_retrieve(lf[337]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[338]);}

/* k2409 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[335]);
/* batch-driver.scm: 111  string-split */
t3=C_retrieve(lf[264]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[336]);}

/* k2405 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[289]),t1);}

/* k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_503,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[15];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[16],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_509,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_509(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[239],((C_word*)t0)[8]);
t14=t12;
f_509(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[17],((C_word*)t0)[8])));}}

/* k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_509,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[17],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[4]);
t5=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[28],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_553,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_559,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_577,a[2]=t25,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_614,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_626,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_675,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_795,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_812,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t30,a[11]=t23,a[12]=t1,a[13]=t31,a[14]=t34,a[15]=((C_word*)t0)[3],a[16]=t4,a[17]=((C_word*)t0)[4],a[18]=t28,a[19]=t27,a[20]=t13,a[21]=t17,a[22]=t14,a[23]=((C_word*)t0)[5],a[24]=t26,a[25]=t35,a[26]=t33,a[27]=t32,a[28]=t19,a[29]=t24,a[30]=((C_word*)t0)[6],a[31]=((C_word*)t0)[7],a[32]=((C_word*)t0)[8],a[33]=t21,a[34]=t11,a[35]=((C_word*)t0)[12],a[36]=((C_word*)t0)[13],a[37]=t16,tmp=(C_word)a,a+=38,tmp);
if(C_truep(t12)){
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2384,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 206  option-arg */
f_451(t39,t12);}
else{
t37=t36;
f_897(t37,C_SCHEME_UNDEFINED);}}

/* k2386 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 206  stringify */
t2=C_retrieve(lf[334]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2382 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 206  string->c-identifier */
t2=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2378 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[184]+1,t1);
t3=((C_word*)t0)[2];
f_897(t3,t2);}

/* k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_897,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2354,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2376,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 212  collect-options */
t5=((C_word*)t0)[13];
f_755(t5,t4,lf[332]);}

/* k2374 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 208  append-map */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2353 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2360,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[331]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2370 in a2353 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2359 in a2353 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2360,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 210  string->symbol */
t4=*((C_word*)lf[263]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(C_word)C_i_memq(lf[53],C_retrieve(lf[29]));
t4=C_mutate(((C_word *)((C_word*)t0)[37])+1,t3);
t5=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[36]))){
t6=C_set_block_item(lf[148],0,C_SCHEME_TRUE);
t7=t5;
f_908(t7,t6);}
else{
t6=t5;
f_908(t6,C_SCHEME_UNDEFINED);}}

/* k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_908,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[36]))){
t3=C_set_block_item(lf[329],0,C_SCHEME_FALSE);
t4=t2;
f_911(t4,t3);}
else{
t3=t2;
f_911(t3,C_SCHEME_UNDEFINED);}}

/* k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_911,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[29])))){
/* batch-driver.scm: 216  ##sys#start-timer */
t3=*((C_word*)lf[327]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_914(2,t3,C_SCHEME_UNDEFINED);}}

/* k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[326],C_retrieve(lf[29])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_917(t4,t3);}
else{
t3=t2;
f_917(t3,C_SCHEME_UNDEFINED);}}

/* k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_917,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[54],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cadr(t2);
t5=C_mutate((C_word*)lf[122]+1,t4);
t6=t3;
f_923(t6,t5);}
else{
t4=t3;
f_923(t4,C_SCHEME_FALSE);}}

/* k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[325],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[10],0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[16],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[31],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_926(t6,t5);}
else{
t3=t2;
f_926(t3,C_SCHEME_UNDEFINED);}}

/* k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_926,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[323],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[324],0,C_SCHEME_FALSE);
t4=t2;
f_929(t4,t3);}
else{
t3=t2;
f_929(t3,C_SCHEME_UNDEFINED);}}

/* k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_929,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[55],((C_word*)t0)[35]);
t3=C_mutate((C_word*)lf[56]+1,t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
/* batch-driver.scm: 227  collect-options */
t5=((C_word*)t0)[12];
f_755(t5,t4,lf[322]);}

/* k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=C_set_block_item(lf[56],0,C_SCHEME_TRUE);
/* for-each */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve(lf[321]),t1);}
else{
t3=t2;
f_939(2,t3,C_SCHEME_UNDEFINED);}}

/* k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 231  collect-options */
t4=((C_word*)t0)[12];
f_755(t4,t3,lf[320]);}

/* k2311 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[263]+1),t1);}

/* k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[318],((C_word*)t0)[35]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 233  printf */
t5=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[319]);}
else{
t5=t4;
f_2305(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_946(t4,C_SCHEME_UNDEFINED);}}

/* k2303 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_946(t3,t2);}

/* k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_946,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[94],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[94],0,C_SCHEME_TRUE);
t4=t2;
f_949(t4,t3);}
else{
t3=t2;
f_949(t3,C_SCHEME_UNDEFINED);}}

/* k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_949,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[146],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[146],0,C_SCHEME_TRUE);
/* batch-driver.scm: 238  ##match#set-error-control */
t4=C_retrieve(lf[316]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[317]);}
else{
t3=t2;
f_952(2,t3,C_SCHEME_UNDEFINED);}}

/* k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(C_truep(((C_word*)t0)[21])?(C_word)C_i_memq(lf[314],((C_word*)t0)[35]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[315],0,C_SCHEME_TRUE);
t5=t2;
f_955(t5,t4);}
else{
t4=t2;
f_955(t4,C_SCHEME_UNDEFINED);}}

/* k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_955,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[313],0,C_SCHEME_FALSE);
t4=t2;
f_958(t4,t3);}
else{
t3=t2;
f_958(t3,C_SCHEME_UNDEFINED);}}

/* k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_958,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[309],((C_word*)t0)[35]))){
t3=C_mutate((C_word*)lf[310]+1,lf[311]);
t4=t2;
f_961(t4,t3);}
else{
t3=t2;
f_961(t3,C_SCHEME_UNDEFINED);}}

/* k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_961,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[308],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[187],0,C_SCHEME_TRUE);
t4=t2;
f_964(t4,t3);}
else{
t3=t2;
f_964(t3,C_SCHEME_UNDEFINED);}}

/* k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_964,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[306],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[307],0,C_SCHEME_TRUE);
t4=t2;
f_967(t4,t3);}
else{
t3=t2;
f_967(t3,C_SCHEME_UNDEFINED);}}

/* k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_967,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[305],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[303],0,C_fix(10));
t4=t2;
f_970(t4,t3);}
else{
t3=t2;
f_970(t3,C_SCHEME_UNDEFINED);}}

/* k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_970,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[58],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[35],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 248  option-arg */
f_451(t4,t2);}
else{
t4=t3;
f_976(t4,C_SCHEME_FALSE);}}

/* k2250 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 249  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2253 in k2250 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2258(2,t3,t1);}
else{
/* batch-driver.scm: 250  quit */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[304],((C_word*)t0)[2]);}}

/* k2256 in k2253 in k2250 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[303]+1,t1);
t3=((C_word*)t0)[2];
f_976(t3,t2);}

/* k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_976(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_976,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[300],((C_word*)t0)[31]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[35])){
/* batch-driver.scm: 252  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[302]);}
else{
t4=t3;
f_2239(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_979(2,t3,C_SCHEME_UNDEFINED);}}

/* k2237 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 253  register-feature! */
t3=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[300]);}

/* k2240 in k2237 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 254  case-sensitive */
t2=C_retrieve(lf[301]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[298],((C_word*)t0)[31]))){
/* batch-driver.scm: 256  compiler-warning */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[185],lf[299]);}
else{
t3=t2;
f_982(2,t3,C_SCHEME_UNDEFINED);}}

/* k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 258  option-arg */
f_451(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_985(2,t3,C_SCHEME_UNDEFINED);}}

/* k2195 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[291],t1))){
/* batch-driver.scm: 259  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[292]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[293],t1))){
/* batch-driver.scm: 260  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[294]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[295],t1))){
/* batch-driver.scm: 261  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[296]);}
else{
/* batch-driver.scm: 262  quit */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[297]);}}}}

/* k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1,((C_word*)t0)[34]);
t3=C_set_block_item(lf[60],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[34],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 266  collect-options */
t7=((C_word*)t0)[11];
f_755(t7,t6,lf[290]);}

/* k2192 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[289]),t1);}

/* k2188 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 266  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[61]),((C_word*)t0)[2]);}

/* k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[28])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[28]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 270  quit */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[288]);}
else{
t5=t3;
f_994(2,t5,C_SCHEME_UNDEFINED);}}

/* k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2166,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 275  collect-options */
t6=((C_word*)t0)[10];
f_755(t6,t5,lf[209]);}

/* k2172 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 273  append-map */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2165 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2166,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[264]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[287]);}

/* k2162 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[263]+1),t1);}

/* k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[33],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[285],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[286],0,C_SCHEME_FALSE);
t5=t3;
f_1001(t5,t4);}
else{
t4=t3;
f_1001(t4,C_SCHEME_UNDEFINED);}}

/* k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1001,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2146,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2148,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 282  collect-options */
t6=((C_word*)t0)[10];
f_755(t6,t5,lf[284]);}

/* k2154 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 282  append-map */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2147 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2148,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[264]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[283]);}

/* k2144 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[282]),t1);}

/* k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],C_retrieve(lf[63]));
t3=C_mutate((C_word*)lf[63]+1,t2);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 286  collect-options */
t5=((C_word*)t0)[10];
f_755(t5,t4,lf[281]);}

/* k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1014,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[22])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2139,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 288  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[280]);}
else{
t3=t2;
f_1014(2,t3,C_SCHEME_UNDEFINED);}}

/* k2137 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 289  load-verbose */
t2=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2128,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2127 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 290  ##sys#resolve-include-filename */
t4=C_retrieve(lf[278]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2134 in a2127 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 290  load */
t2=C_retrieve(lf[277]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 291  delete */
t3=C_retrieve(lf[276]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[62],C_retrieve(lf[63]),*((C_word*)lf[262]+1));}

/* k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1021,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[63]));
t4=C_mutate((C_word*)lf[63]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[65],C_retrieve(lf[63]));
t6=C_mutate((C_word*)lf[63]+1,t5);
t7=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 295  ##sys#provide */
t8=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[275]);}

/* k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 296  user-post-analysis-pass */
t3=C_retrieve(lf[273]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 299  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[32])[1],C_retrieve(lf[272]));}

/* k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[268],((C_word*)t0)[31]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=t3,a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[32],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2114,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[21])){
/* batch-driver.scm: 308  pathname-file */
t7=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[21]);}
else{
if(C_truep(((C_word*)t0)[29])){
/* batch-driver.scm: 309  pathname-file */
t7=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[29]);}
else{
/* batch-driver.scm: 310  quit */
t7=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[271]);}}}
else{
t4=t3;
f_1043(t4,C_SCHEME_UNDEFINED);}}

/* k2112 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 307  string->symbol */
t2=*((C_word*)lf[263]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2108 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[269],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* batch-driver.scm: 304  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* k2096 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1043(t3,t2);}

/* k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1043,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2083,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 318  collect-options */
t7=((C_word*)t0)[10];
f_755(t7,t6,lf[267]);}

/* k2089 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 316  append-map */
t2=C_retrieve(lf[266]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2082 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2083,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[264]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[265]);}

/* k2079 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[263]+1),t1);}

/* k2075 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 313  lset-difference */
t2=C_retrieve(lf[261]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[262]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[32],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2065,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a2064 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2065,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[197],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[260],t3));}

/* k2061 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 321  append */
t2=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[32],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[258],((C_word*)t0)[31]))){
t4=C_set_block_item(lf[259],0,C_SCHEME_TRUE);
t5=t3;
f_1053(t5,t4);}
else{
t4=t3;
f_1053(t4,C_SCHEME_UNDEFINED);}}

/* k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1053,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 327  option-arg */
f_451(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[257]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1057(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1057(2,t4,C_SCHEME_FALSE);}}}

/* k2040 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 327  arg-val */
f_675(((C_word*)t0)[2],t1);}

/* k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2035,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 331  option-arg */
f_451(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1061(2,t4,C_SCHEME_FALSE);}}

/* k2033 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 331  arg-val */
f_675(((C_word*)t0)[2],t1);}

/* k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2028,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 332  option-arg */
f_451(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1065(2,t4,C_SCHEME_FALSE);}}

/* k2026 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 332  arg-val */
f_675(((C_word*)t0)[2],t1);}

/* k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 333  option-arg */
f_451(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1069(2,t4,C_SCHEME_FALSE);}}

/* k2019 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 333  arg-val */
f_675(((C_word*)t0)[2],t1);}

/* k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1,t1);
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2001,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 336  option-arg */
f_451(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[256]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1073(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1073(2,t5,C_SCHEME_FALSE);}}}

/* k1999 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 336  arg-val */
f_675(((C_word*)t0)[2],t1);}

/* k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1,t1);
t3=(C_word)C_i_memq(lf[71],((C_word*)t0)[25]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[72]+1,t4);
t6=(C_word)C_i_memq(lf[73],((C_word*)t0)[25]);
t7=C_mutate((C_word*)lf[74]+1,t6);
t8=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[254],C_retrieve(lf[29])))){
/* batch-driver.scm: 342  set-gc-report! */
t9=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1084(2,t9,C_SCHEME_UNDEFINED);}}

/* k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[249],((C_word*)t0)[25]))){
t3=t2;
f_1087(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[250]+1,C_retrieve(lf[251]));
t4=C_mutate((C_word*)lf[252]+1,C_retrieve(lf[253]));
t5=t2;
f_1087(t5,t4);}}

/* k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1087,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[72]))?lf[246]:lf[247]);
/* batch-driver.scm: 347  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[248],t3);}
else{
t3=t2;
f_1090(2,t3,C_SCHEME_UNDEFINED);}}

/* k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[239],t3);
t5=C_set_block_item(lf[200],0,C_SCHEME_TRUE);
t6=C_set_block_item(lf[240],0,C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1954,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[244]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 356  append */
t9=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[245]),t8);}
else{
t3=t2;
f_1093(2,t3,C_SCHEME_UNDEFINED);}}

/* k1952 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[241]:lf[242]);
/* batch-driver.scm: 363  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[243],t3);}
else{
t3=((C_word*)t0)[2];
f_1093(2,t3,C_SCHEME_UNDEFINED);}}

/* k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[75],((C_word*)t0)[24]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 366  print-version */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[78],((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(t2)){
t4=t3;
f_1114(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[236],((C_word*)t0)[24]);
if(C_truep(t4)){
t5=t3;
f_1114(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[237],((C_word*)t0)[24]);
t6=t3;
f_1114(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[238],((C_word*)t0)[24])));}}}}

/* k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1114,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 369  print-usage */
t2=C_retrieve(lf[79]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[24]);}
else{
if(C_truep((C_word)C_i_memq(lf[80],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1133,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 371  chicken-version */
t4=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[22];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1151(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 381  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[234],((C_word*)t0)[22]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 375  print-version */
t4=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1143 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 376  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[235]);}

/* k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[24],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 383  debugging */
t4=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[229],lf[233],((C_word*)t0)[10]);}

/* k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 384  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[232],C_retrieve(lf[29]));}

/* k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 385  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[231],C_retrieve(lf[66]));}

/* k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 386  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[230],C_retrieve(lf[70]));}

/* k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1164,2,t0,t1);}
t2=f_553();
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 390  make-vector */
t5=*((C_word*)lf[227]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[228]),C_SCHEME_END_OF_LIST);}

/* k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 391  collect-options */
t4=((C_word*)t0)[2];
f_755(t4,t3,lf[226]);}

/* k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 392  collect-options */
t3=((C_word*)t0)[2];
f_755(t3,t2,lf[225]);}

/* k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 394  collect-options */
t4=((C_word*)t0)[2];
f_755(t4,t3,lf[224]);}

/* k1917 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1927,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 396  collect-options */
t4=((C_word*)t0)[2];
f_755(t4,t3,lf[223]);}

/* k1925 in k1917 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 393  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm: 398  user-read-pass */
t3=C_retrieve(lf[222]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],a[22]=((C_word*)t0)[26],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[22])){
/* batch-driver.scm: 400  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[215]);}
else{
t4=t3;
f_1816(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1828(t6,t2,((C_word*)t0)[4]);}}

/* do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1828,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1839,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[216]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 410  check-and-open-input-file */
t5=C_retrieve(lf[221]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1869,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[220]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a1908 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[218]));
t3=C_mutate((C_word*)lf[218]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* a1876 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1881,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 412  read-form */
t3=((C_word*)t0)[2];
f_812(t3,t2,((C_word*)t0)[5]);}

/* k1879 in a1876 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1886(t5,((C_word*)t0)[2],t1);}

/* do207 in k1879 in a1876 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1886,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 415  close-checked-input-file */
t3=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1907,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 413  read-form */
t6=((C_word*)t0)[2];
f_812(t6,t5,((C_word*)t0)[6]);}}

/* k1905 in do207 in k1879 in a1876 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1886(t2,((C_word*)t0)[2],t1);}

/* a1868 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[218]));
t3=C_mutate((C_word*)lf[218]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* k1858 in k1855 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1828(t3,((C_word*)t0)[2],t2);}

/* k1841 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 407  reverse */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1845 in k1841 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1851,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[216]),((C_word*)t0)[2]);}

/* k1849 in k1845 in k1841 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 406  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1837 in do195 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1814 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 401  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1818 in k1814 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1187(2,t3,t2);}

/* k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 419  user-preprocessor-pass */
t3=C_retrieve(lf[214]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1806,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[18])){
/* batch-driver.scm: 421  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[213]);}
else{
t4=t3;
f_1806(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1193(t3,C_SCHEME_UNDEFINED);}}

/* k1804 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1808 in k1804 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1193(t3,t2);}

/* k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1193,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 424  print-expr */
t3=((C_word*)t0)[7];
f_614(t3,t2,lf[211],lf[212],((C_word*)((C_word*)t0)[3])[1]);}

/* k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=f_785(((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1202(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1791,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 427  append */
t5=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[208]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k1789 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[209],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,2,lf[210],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1202(t7,t6);}

/* k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1202,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 429  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1782 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[207]),t1);}

/* k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 430  gensym */
t3=C_retrieve(lf[206]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[84]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1764,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[205]));}

/* a1763 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1764,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,2,lf[197],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[202],t3,t5));}

/* k1684 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1758,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[204]));}

/* a1757 in k1684 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1758,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[203],t2));}

/* k1688 in k1684 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[200]))){
t3=(C_word)C_a_i_list(&a,2,lf[197],((C_word*)t0)[3]);
t4=(C_truep(C_retrieve(lf[184]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[197],t4);
t6=(C_word)C_a_i_list(&a,3,lf[201],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[202],C_retrieve(lf[199]),t6);
t8=t2;
f_1694(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t3=t2;
f_1694(t3,C_SCHEME_END_OF_LIST);}}

/* k1692 in k1688 in k1684 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1694,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1713,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[84]));}

/* a1712 in k1692 in k1688 in k1684 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1713,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,2,lf[197],t3);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_list(&a,2,lf[197],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,4,lf[198],C_retrieve(lf[199]),t4,t6));}

/* k1696 in k1692 in k1688 in k1684 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[184]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 432  append */
t5=*((C_word*)lf[195]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[196]);}

/* k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 453  debugging */
t6=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[193],lf[194]);}

/* k1677 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 454  display-real-name-table */
t2=C_retrieve(lf[192]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1217(2,t2,C_SCHEME_UNDEFINED);}}

/* k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1673,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 455  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[190],lf[191]);}

/* k1671 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 456  display-line-number-database */
t2=C_retrieve(lf[189]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1220(2,t2,C_SCHEME_UNDEFINED);}}

/* k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[187]))?C_retrieve(lf[184]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 459  compiler-warning */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[185],lf[188],C_retrieve(lf[184]));}
else{
t4=t2;
f_1223(2,t4,C_SCHEME_UNDEFINED);}}

/* k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[184]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 465  compiler-warning */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[185],lf[186],C_retrieve(lf[184]));}
else{
t4=t2;
f_1226(2,t4,C_SCHEME_UNDEFINED);}}

/* k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1652,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[146]))){
/* batch-driver.scm: 467  feature? */
t4=C_retrieve(lf[182]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[183]);}
else{
t4=t3;
f_1652(2,t4,C_SCHEME_FALSE);}}

/* k1650 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 468  compiler-warning */
t2=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[180],lf[181]);}
else{
t2=((C_word*)t0)[2];
f_1229(2,t2,C_SCHEME_UNDEFINED);}}

/* k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1229,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,C_retrieve(lf[85]));
t3=C_set_block_item(lf[85],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 475  end-time */
t5=((C_word*)t0)[17];
f_795(t5,t4,lf[178]);}

/* k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 476  print-expr */
t3=((C_word*)t0)[2];
f_614(t3,t2,lf[176],lf[177],((C_word*)((C_word*)t0)[4])[1]);}

/* k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[175],((C_word*)t0)[2]))){
/* batch-driver.scm: 478  exit */
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1240(2,t3,C_SCHEME_UNDEFINED);}}

/* k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 480  user-pass */
t3=C_retrieve(lf[174]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1630,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[12])){
/* batch-driver.scm: 482  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[173]);}
else{
t4=t3;
f_1630(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1246(2,t3,C_SCHEME_UNDEFINED);}}

/* k1628 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=f_785(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k1635 in k1628 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 485  end-time */
t3=((C_word*)t0)[3];
f_795(t3,((C_word*)t0)[2],lf[171]);}

/* k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1627,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 490  canonicalize-begin-body */
t4=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1625 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 489  build-node-graph */
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[86],lf[87],lf[88],t2);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1255,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 491  user-pass-2 */
t5=C_retrieve(lf[168]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1258,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 492  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[166],lf[167]);}

/* k1610 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 493  ##sys#hash-table->alist */
t3=C_retrieve(lf[164]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[165]));}
else{
t2=((C_word*)t0)[2];
f_1258(2,t2,C_SCHEME_UNDEFINED);}}

/* k1617 in k1610 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 493  pretty-print */
t2=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],a[8]=t2,a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[13])){
/* batch-driver.scm: 495  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[163]);}
else{
t4=t3;
f_1580(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1261(t3,C_SCHEME_UNDEFINED);}}

/* k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=f_785(((C_word*)t0)[9]);
t3=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 498  analyze */
t5=((C_word*)t0)[2];
f_818(t5,t4,lf[162],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k1585 in k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 499  print-db */
t3=((C_word*)t0)[2];
f_599(t3,t2,lf[161],lf[155],t1,C_fix(0));}

/* k1588 in k1585 in k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 500  end-time */
t3=((C_word*)t0)[3];
f_795(t3,t2,lf[160]);}

/* k1591 in k1588 in k1585 in k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1593,2,t0,t1);}
t2=f_785(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 502  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1597 in k1591 in k1588 in k1585 in k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 503  end-time */
t3=((C_word*)t0)[2];
f_795(t3,t2,lf[159]);}

/* k1600 in k1597 in k1591 in k1588 in k1585 in k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 504  print-node */
t3=((C_word*)t0)[3];
f_577(t3,t2,lf[157],lf[158],((C_word*)t0)[2]);}

/* k1603 in k1600 in k1597 in k1591 in k1588 in k1585 in k1578 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1261(t3,t2);}

/* k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1261,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[148]))){
t3=f_785(((C_word*)t0)[16]);
t4=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 510  analyze */
t6=((C_word*)t0)[14];
f_818(t6,t5,lf[156],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1264(t3,C_SCHEME_UNDEFINED);}}

/* k1556 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1561,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 511  print-db */
t3=((C_word*)t0)[2];
f_599(t3,t2,lf[154],lf[155],t1,C_fix(0));}

/* k1559 in k1556 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 512  end-time */
t3=((C_word*)t0)[3];
f_795(t3,t2,lf[153]);}

/* k1562 in k1559 in k1556 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1564,2,t0,t1);}
t2=f_785(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 514  perform-lambda-lifting! */
t4=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1568 in k1562 in k1559 in k1556 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 515  end-time */
t3=((C_word*)t0)[2];
f_795(t3,t2,lf[151]);}

/* k1571 in k1568 in k1562 in k1559 in k1556 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 516  print-node */
t3=((C_word*)t0)[3];
f_577(t3,t2,lf[149],lf[150],((C_word*)t0)[2]);}

/* k1574 in k1571 in k1568 in k1562 in k1559 in k1556 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1264(t3,t2);}

/* k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1264,NULL,2,t0,t1);}
t2=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[89],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[90],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[146]))){
t6=t5;
f_1270(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
/* batch-driver.scm: 523  scan-toplevel-assignments */
t8=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}}

/* k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1270,2,t0,t1);}
t2=f_785(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 526  perform-cps-conversion */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1279,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 527  end-time */
t3=((C_word*)t0)[14];
f_795(t3,t2,lf[144]);}

/* k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 528  print-node */
t3=((C_word*)t0)[13];
f_577(t3,t2,lf[142],lf[143],((C_word*)t0)[2]);}

/* k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1287(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1287(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1287,NULL,5,t0,t1,t2,t3,t4);}
t5=f_785(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[15],a[19]=t4,tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 534  analyze */
t7=((C_word*)t0)[12];
f_818(t7,t6,lf[141],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep(C_retrieve(lf[91]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1525,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* batch-driver.scm: 536  check-global-imports */
t4=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t4=t3;
f_1525(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1297(2,t3,C_SCHEME_UNDEFINED);}}

/* k1523 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 537  check-global-exports */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1526 in k1523 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[137],C_retrieve(lf[29])))){
/* batch-driver.scm: 539  dump-undefined-globals */
t2=C_retrieve(lf[138]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1297(2,t2,C_SCHEME_UNDEFINED);}}

/* k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 541  end-time */
t4=((C_word*)t0)[14];
f_795(t4,t3,lf[136]);}

/* k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 542  print-db */
t3=((C_word*)t0)[2];
f_599(t3,t2,lf[134],lf[135],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_memq(lf[132],C_retrieve(lf[29])))){
/* batch-driver.scm: 544  print-program-statistics */
t3=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1307(2,t3,C_SCHEME_UNDEFINED);}}

/* k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
if(C_truep(((C_word*)t0)[20])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 547  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[100],lf[105],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[18],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 570  print-node */
t3=((C_word*)t0)[12];
f_577(t3,t2,lf[130],lf[131],((C_word*)t0)[18]);}}

/* k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=f_785(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 573  perform-closure-conversion */
t4=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 574  end-time */
t3=((C_word*)t0)[13];
f_795(t3,t2,lf[128]);}

/* k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 575  print-db */
t3=((C_word*)t0)[3];
f_599(t3,t2,lf[126],lf[127],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[125]))){
t4=f_553();
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_1502(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_1502(t4,C_SCHEME_FALSE);}}

/* k1500 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_1502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 577  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[124]);}
else{
t2=((C_word*)t0)[2];
f_1414(2,t2,C_SCHEME_UNDEFINED);}}

/* k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[122]))){
/* batch-driver.scm: 579  dump-exported-globals */
t3=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[11],C_retrieve(lf[122]));}
else{
t3=t2;
f_1417(2,t3,C_SCHEME_UNDEFINED);}}

/* k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 580  exit */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_1420(2,t3,C_SCHEME_UNDEFINED);}}

/* k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 581  print-node */
t3=((C_word*)t0)[2];
f_577(t3,t2,lf[119],lf[120],((C_word*)t0)[11]);}

/* k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=f_785(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 584  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1437,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 586  end-time */
t7=((C_word*)t0)[7];
f_795(t7,t6,lf[118]);}

/* k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=f_785(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 589  open-output-file */
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 589  current-output-port */
t4=*((C_word*)lf[117]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_1450(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 591  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[115],((C_word*)t0)[9]);}}

/* k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 592  generate-code */
t3=C_retrieve(lf[114]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1451 in k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 593  close-output-port */
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1456(2,t3,C_SCHEME_UNDEFINED);}}

/* k1454 in k1451 in k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 594  end-time */
t3=((C_word*)t0)[2];
f_795(t3,t2,lf[112]);}

/* k1457 in k1454 in k1451 in k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[29])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 595  ##sys#stop-timer */
t4=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1462(2,t3,C_SCHEME_UNDEFINED);}}

/* k1479 in k1457 in k1454 in k1451 in k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 595  ##sys#display-times */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 596  compiler-cleanup-hook */
t3=C_retrieve(lf[108]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in k1445 in k1439 in a1436 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 598  printf */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a1430 in k1421 in k1418 in k1415 in k1412 in k1409 in k1406 in k1403 in k1397 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
/* batch-driver.scm: 585  prepare-for-code-generation */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=f_785(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 550  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1327,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 551  end-time */
t5=((C_word*)t0)[4];
f_795(t5,t4,lf[104]);}

/* k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 552  print-node */
t3=((C_word*)t0)[2];
f_577(t3,t2,lf[102],lf[103],((C_word*)t0)[6]);}

/* k1332 in k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1334,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 554  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1287(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[93]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[94]))){
t3=f_785(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 561  analyze */
t5=((C_word*)t0)[2];
f_818(t5,t4,lf[98],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 567  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1287(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 556  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[100],lf[101]);}}}

/* k1351 in k1332 in k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[93],0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 558  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1287(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1368 in k1332 in k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1373,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 562  end-time */
t3=((C_word*)t0)[2];
f_795(t3,t2,lf[97]);}

/* k1371 in k1368 in k1332 in k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=f_785(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 564  transform-direct-lambdas! */
t4=C_retrieve(lf[96]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1377 in k1371 in k1368 in k1332 in k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1382,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 565  end-time */
t3=((C_word*)t0)[2];
f_795(t3,t2,lf[95]);}

/* k1380 in k1377 in k1371 in k1368 in k1332 in k1329 in a1326 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 566  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1287(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1320 in k1311 in k1305 in k1302 in k1299 in k1295 in k1292 in loop in k1280 in k1277 in k1274 in k1268 in k1262 in k1259 in k1256 in k1253 in k1621 in k1244 in k1241 in k1238 in k1235 in k1232 in k1227 in k1224 in k1221 in k1218 in k1215 in k1212 in k1206 in k1203 in k1200 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in k1170 in k1162 in k1159 in k1156 in k1153 in k1149 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
/* batch-driver.scm: 550  perform-high-level-optimizations */
t2=C_retrieve(lf[92]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1131 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 371  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1124 in k1112 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 372  newline */
t2=*((C_word*)lf[76]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1100 in k1091 in k1088 in k1085 in k1082 in k1071 in k1067 in k1063 in k1059 in k1055 in k1051 in k1048 in k1044 in k1041 in k1038 in k1034 in k1030 in k1019 in k1015 in k1012 in k1009 in k1002 in k999 in k996 in k992 in k989 in k983 in k980 in k977 in k974 in k968 in k965 in k962 in k959 in k956 in k953 in k950 in k947 in k944 in k941 in k937 in k934 in k927 in k924 in k921 in k915 in k912 in k909 in k906 in k899 in k895 in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 367  newline */
t2=*((C_word*)lf[76]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_818,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_820,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no120140 */
t8=t7;
f_848(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf121138 */
t10=t6;
f_843(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body118123 */
t12=t5;
f_820(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[1],t11);}}}}

/* def-no120 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_848,NULL,2,t0,t1);}
/* def-contf121138 */
t2=((C_word*)t0)[2];
f_843(t2,t1,C_fix(0));}

/* def-contf121 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_843(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_843,NULL,3,t0,t1,t2);}
/* body118123 */
t3=((C_word*)t0)[2];
f_820(t3,t1,t2,C_SCHEME_TRUE);}

/* body118 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_820(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_820,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_824,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 197  analyze-expression */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k822 in body118 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_827,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_832,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 199  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_827(2,t3,C_SCHEME_UNDEFINED);}}

/* a837 in k822 in body118 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_838,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[50]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a831 in k822 in body118 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_832,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k825 in k822 in body118 in analyze in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_812(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_812,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 193  ##sys#read */
t3=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_795(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_795,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_553();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 190  printf */
t5=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[47],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static C_word C_fcall f_785(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_553();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_755,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_761,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_761(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_761,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 182  option-arg */
f_451(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k773 in loop in collect-options in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 182  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_761(t4,t2,t3);}

/* k777 in k773 in loop in collect-options in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_779,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_675(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_675,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_685,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 173  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_716,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_724,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 175  substring */
t11=*((C_word*)lf[46]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_744,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 176  substring */
t13=*((C_word*)lf[46]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 177  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k742 in arg-val in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 176  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k738 in arg-val in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_685(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k722 in arg-val in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 175  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k714 in arg-val in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_685(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k683 in arg-val in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 178  quit */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[45],((C_word*)t0)[2]);}}

/* infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_626,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_630,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[44]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_672,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_672 in infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_672,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k628 in infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_633,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_636,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[43],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_636(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_636(t5,C_SCHEME_FALSE);}}

/* k634 in k628 in infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_636,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_647,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 165  ##sys#hash-table-ref */
t6=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[40]),t5);}
else{
t2=((C_word*)t0)[3];
f_633(2,t2,C_SCHEME_UNDEFINED);}}

/* k649 in k634 in k628 in infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 164  alist-cons */
t3=C_retrieve(lf[41]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k645 in k634 in k628 in infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 161  ##sys#hash-table-set! */
t2=C_retrieve(lf[39]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[40]),((C_word*)t0)[2],t1);}

/* k631 in k628 in infohook in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_614(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_614,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_621,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 155  print-header */
t6=((C_word*)t0)[2];
f_559(t6,t5,t2,t3);}

/* k619 in print-expr in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[34]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_599(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_599,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_606,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 150  print-header */
t7=((C_word*)t0)[2];
f_559(t7,t6,t2,t3);}

/* k604 in print-db in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_606,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 151  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[37],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k607 in k604 in print-db in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 152  display-analysis-database */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_577,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_584,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 144  print-header */
t6=((C_word*)t0)[2];
f_559(t6,t5,t2,t3);}

/* k582 in print-node in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_584,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 146  dump-nodes */
t2=C_retrieve(lf[33]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_597,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 147  build-expression-tree */
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k595 in k582 in print-node in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 147  pretty-print */
t2=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_559(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_559,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_563,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 137  printf */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[32],t2);}
else{
t5=t4;
f_563(2,t5,C_SCHEME_UNDEFINED);}}

/* k561 in print-header in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_563,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[29])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_572,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 140  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[31],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k570 in k561 in print-header in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_ccall f_572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k507 in k501 in k498 in k2448 in k482 in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static C_word C_fcall f_553(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file in k440 in k437 in k434 in k431 in k428 in k425 */
static void C_fcall f_451(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_451,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 88   quit */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[7],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 91   quit */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[8],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[282] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_427batch-driver.scm",(void*)f_427},
{"f_430batch-driver.scm",(void*)f_430},
{"f_433batch-driver.scm",(void*)f_433},
{"f_436batch-driver.scm",(void*)f_436},
{"f_439batch-driver.scm",(void*)f_439},
{"f_442batch-driver.scm",(void*)f_442},
{"f_448batch-driver.scm",(void*)f_448},
{"f_484batch-driver.scm",(void*)f_484},
{"f_2464batch-driver.scm",(void*)f_2464},
{"f_2460batch-driver.scm",(void*)f_2460},
{"f_2452batch-driver.scm",(void*)f_2452},
{"f_2450batch-driver.scm",(void*)f_2450},
{"f_2439batch-driver.scm",(void*)f_2439},
{"f_2417batch-driver.scm",(void*)f_2417},
{"f_500batch-driver.scm",(void*)f_500},
{"f_2411batch-driver.scm",(void*)f_2411},
{"f_2407batch-driver.scm",(void*)f_2407},
{"f_503batch-driver.scm",(void*)f_503},
{"f_509batch-driver.scm",(void*)f_509},
{"f_2388batch-driver.scm",(void*)f_2388},
{"f_2384batch-driver.scm",(void*)f_2384},
{"f_2380batch-driver.scm",(void*)f_2380},
{"f_897batch-driver.scm",(void*)f_897},
{"f_2376batch-driver.scm",(void*)f_2376},
{"f_2354batch-driver.scm",(void*)f_2354},
{"f_2372batch-driver.scm",(void*)f_2372},
{"f_2360batch-driver.scm",(void*)f_2360},
{"f_901batch-driver.scm",(void*)f_901},
{"f_908batch-driver.scm",(void*)f_908},
{"f_911batch-driver.scm",(void*)f_911},
{"f_914batch-driver.scm",(void*)f_914},
{"f_917batch-driver.scm",(void*)f_917},
{"f_923batch-driver.scm",(void*)f_923},
{"f_926batch-driver.scm",(void*)f_926},
{"f_929batch-driver.scm",(void*)f_929},
{"f_936batch-driver.scm",(void*)f_936},
{"f_939batch-driver.scm",(void*)f_939},
{"f_2313batch-driver.scm",(void*)f_2313},
{"f_943batch-driver.scm",(void*)f_943},
{"f_2305batch-driver.scm",(void*)f_2305},
{"f_946batch-driver.scm",(void*)f_946},
{"f_949batch-driver.scm",(void*)f_949},
{"f_952batch-driver.scm",(void*)f_952},
{"f_955batch-driver.scm",(void*)f_955},
{"f_958batch-driver.scm",(void*)f_958},
{"f_961batch-driver.scm",(void*)f_961},
{"f_964batch-driver.scm",(void*)f_964},
{"f_967batch-driver.scm",(void*)f_967},
{"f_970batch-driver.scm",(void*)f_970},
{"f_2252batch-driver.scm",(void*)f_2252},
{"f_2255batch-driver.scm",(void*)f_2255},
{"f_2258batch-driver.scm",(void*)f_2258},
{"f_976batch-driver.scm",(void*)f_976},
{"f_2239batch-driver.scm",(void*)f_2239},
{"f_2242batch-driver.scm",(void*)f_2242},
{"f_979batch-driver.scm",(void*)f_979},
{"f_982batch-driver.scm",(void*)f_982},
{"f_2197batch-driver.scm",(void*)f_2197},
{"f_985batch-driver.scm",(void*)f_985},
{"f_2194batch-driver.scm",(void*)f_2194},
{"f_2190batch-driver.scm",(void*)f_2190},
{"f_991batch-driver.scm",(void*)f_991},
{"f_994batch-driver.scm",(void*)f_994},
{"f_2174batch-driver.scm",(void*)f_2174},
{"f_2166batch-driver.scm",(void*)f_2166},
{"f_2164batch-driver.scm",(void*)f_2164},
{"f_998batch-driver.scm",(void*)f_998},
{"f_1001batch-driver.scm",(void*)f_1001},
{"f_2156batch-driver.scm",(void*)f_2156},
{"f_2148batch-driver.scm",(void*)f_2148},
{"f_2146batch-driver.scm",(void*)f_2146},
{"f_1004batch-driver.scm",(void*)f_1004},
{"f_1011batch-driver.scm",(void*)f_1011},
{"f_2139batch-driver.scm",(void*)f_2139},
{"f_1014batch-driver.scm",(void*)f_1014},
{"f_2128batch-driver.scm",(void*)f_2128},
{"f_2136batch-driver.scm",(void*)f_2136},
{"f_1017batch-driver.scm",(void*)f_1017},
{"f_1021batch-driver.scm",(void*)f_1021},
{"f_1032batch-driver.scm",(void*)f_1032},
{"f_1036batch-driver.scm",(void*)f_1036},
{"f_1040batch-driver.scm",(void*)f_1040},
{"f_2114batch-driver.scm",(void*)f_2114},
{"f_2110batch-driver.scm",(void*)f_2110},
{"f_2098batch-driver.scm",(void*)f_2098},
{"f_1043batch-driver.scm",(void*)f_1043},
{"f_2091batch-driver.scm",(void*)f_2091},
{"f_2083batch-driver.scm",(void*)f_2083},
{"f_2081batch-driver.scm",(void*)f_2081},
{"f_2077batch-driver.scm",(void*)f_2077},
{"f_1046batch-driver.scm",(void*)f_1046},
{"f_2065batch-driver.scm",(void*)f_2065},
{"f_2063batch-driver.scm",(void*)f_2063},
{"f_1050batch-driver.scm",(void*)f_1050},
{"f_1053batch-driver.scm",(void*)f_1053},
{"f_2042batch-driver.scm",(void*)f_2042},
{"f_1057batch-driver.scm",(void*)f_1057},
{"f_2035batch-driver.scm",(void*)f_2035},
{"f_1061batch-driver.scm",(void*)f_1061},
{"f_2028batch-driver.scm",(void*)f_2028},
{"f_1065batch-driver.scm",(void*)f_1065},
{"f_2021batch-driver.scm",(void*)f_2021},
{"f_1069batch-driver.scm",(void*)f_1069},
{"f_2001batch-driver.scm",(void*)f_2001},
{"f_1073batch-driver.scm",(void*)f_1073},
{"f_1084batch-driver.scm",(void*)f_1084},
{"f_1087batch-driver.scm",(void*)f_1087},
{"f_1090batch-driver.scm",(void*)f_1090},
{"f_1954batch-driver.scm",(void*)f_1954},
{"f_1093batch-driver.scm",(void*)f_1093},
{"f_1114batch-driver.scm",(void*)f_1114},
{"f_1145batch-driver.scm",(void*)f_1145},
{"f_1151batch-driver.scm",(void*)f_1151},
{"f_1155batch-driver.scm",(void*)f_1155},
{"f_1158batch-driver.scm",(void*)f_1158},
{"f_1161batch-driver.scm",(void*)f_1161},
{"f_1164batch-driver.scm",(void*)f_1164},
{"f_1172batch-driver.scm",(void*)f_1172},
{"f_1175batch-driver.scm",(void*)f_1175},
{"f_1178batch-driver.scm",(void*)f_1178},
{"f_1919batch-driver.scm",(void*)f_1919},
{"f_1927batch-driver.scm",(void*)f_1927},
{"f_1181batch-driver.scm",(void*)f_1181},
{"f_1184batch-driver.scm",(void*)f_1184},
{"f_1828batch-driver.scm",(void*)f_1828},
{"f_1857batch-driver.scm",(void*)f_1857},
{"f_1909batch-driver.scm",(void*)f_1909},
{"f_1877batch-driver.scm",(void*)f_1877},
{"f_1881batch-driver.scm",(void*)f_1881},
{"f_1886batch-driver.scm",(void*)f_1886},
{"f_1907batch-driver.scm",(void*)f_1907},
{"f_1869batch-driver.scm",(void*)f_1869},
{"f_1860batch-driver.scm",(void*)f_1860},
{"f_1843batch-driver.scm",(void*)f_1843},
{"f_1847batch-driver.scm",(void*)f_1847},
{"f_1851batch-driver.scm",(void*)f_1851},
{"f_1839batch-driver.scm",(void*)f_1839},
{"f_1816batch-driver.scm",(void*)f_1816},
{"f_1820batch-driver.scm",(void*)f_1820},
{"f_1187batch-driver.scm",(void*)f_1187},
{"f_1190batch-driver.scm",(void*)f_1190},
{"f_1806batch-driver.scm",(void*)f_1806},
{"f_1810batch-driver.scm",(void*)f_1810},
{"f_1193batch-driver.scm",(void*)f_1193},
{"f_1196batch-driver.scm",(void*)f_1196},
{"f_1791batch-driver.scm",(void*)f_1791},
{"f_1202batch-driver.scm",(void*)f_1202},
{"f_1784batch-driver.scm",(void*)f_1784},
{"f_1205batch-driver.scm",(void*)f_1205},
{"f_1208batch-driver.scm",(void*)f_1208},
{"f_1764batch-driver.scm",(void*)f_1764},
{"f_1686batch-driver.scm",(void*)f_1686},
{"f_1758batch-driver.scm",(void*)f_1758},
{"f_1690batch-driver.scm",(void*)f_1690},
{"f_1694batch-driver.scm",(void*)f_1694},
{"f_1713batch-driver.scm",(void*)f_1713},
{"f_1698batch-driver.scm",(void*)f_1698},
{"f_1214batch-driver.scm",(void*)f_1214},
{"f_1679batch-driver.scm",(void*)f_1679},
{"f_1217batch-driver.scm",(void*)f_1217},
{"f_1673batch-driver.scm",(void*)f_1673},
{"f_1220batch-driver.scm",(void*)f_1220},
{"f_1223batch-driver.scm",(void*)f_1223},
{"f_1226batch-driver.scm",(void*)f_1226},
{"f_1652batch-driver.scm",(void*)f_1652},
{"f_1229batch-driver.scm",(void*)f_1229},
{"f_1234batch-driver.scm",(void*)f_1234},
{"f_1237batch-driver.scm",(void*)f_1237},
{"f_1240batch-driver.scm",(void*)f_1240},
{"f_1243batch-driver.scm",(void*)f_1243},
{"f_1630batch-driver.scm",(void*)f_1630},
{"f_1637batch-driver.scm",(void*)f_1637},
{"f_1246batch-driver.scm",(void*)f_1246},
{"f_1627batch-driver.scm",(void*)f_1627},
{"f_1623batch-driver.scm",(void*)f_1623},
{"f_1255batch-driver.scm",(void*)f_1255},
{"f_1612batch-driver.scm",(void*)f_1612},
{"f_1619batch-driver.scm",(void*)f_1619},
{"f_1258batch-driver.scm",(void*)f_1258},
{"f_1580batch-driver.scm",(void*)f_1580},
{"f_1587batch-driver.scm",(void*)f_1587},
{"f_1590batch-driver.scm",(void*)f_1590},
{"f_1593batch-driver.scm",(void*)f_1593},
{"f_1599batch-driver.scm",(void*)f_1599},
{"f_1602batch-driver.scm",(void*)f_1602},
{"f_1605batch-driver.scm",(void*)f_1605},
{"f_1261batch-driver.scm",(void*)f_1261},
{"f_1558batch-driver.scm",(void*)f_1558},
{"f_1561batch-driver.scm",(void*)f_1561},
{"f_1564batch-driver.scm",(void*)f_1564},
{"f_1570batch-driver.scm",(void*)f_1570},
{"f_1573batch-driver.scm",(void*)f_1573},
{"f_1576batch-driver.scm",(void*)f_1576},
{"f_1264batch-driver.scm",(void*)f_1264},
{"f_1270batch-driver.scm",(void*)f_1270},
{"f_1276batch-driver.scm",(void*)f_1276},
{"f_1279batch-driver.scm",(void*)f_1279},
{"f_1282batch-driver.scm",(void*)f_1282},
{"f_1287batch-driver.scm",(void*)f_1287},
{"f_1294batch-driver.scm",(void*)f_1294},
{"f_1525batch-driver.scm",(void*)f_1525},
{"f_1528batch-driver.scm",(void*)f_1528},
{"f_1297batch-driver.scm",(void*)f_1297},
{"f_1301batch-driver.scm",(void*)f_1301},
{"f_1304batch-driver.scm",(void*)f_1304},
{"f_1307batch-driver.scm",(void*)f_1307},
{"f_1399batch-driver.scm",(void*)f_1399},
{"f_1405batch-driver.scm",(void*)f_1405},
{"f_1408batch-driver.scm",(void*)f_1408},
{"f_1411batch-driver.scm",(void*)f_1411},
{"f_1502batch-driver.scm",(void*)f_1502},
{"f_1414batch-driver.scm",(void*)f_1414},
{"f_1417batch-driver.scm",(void*)f_1417},
{"f_1420batch-driver.scm",(void*)f_1420},
{"f_1423batch-driver.scm",(void*)f_1423},
{"f_1437batch-driver.scm",(void*)f_1437},
{"f_1441batch-driver.scm",(void*)f_1441},
{"f_1447batch-driver.scm",(void*)f_1447},
{"f_1450batch-driver.scm",(void*)f_1450},
{"f_1453batch-driver.scm",(void*)f_1453},
{"f_1456batch-driver.scm",(void*)f_1456},
{"f_1459batch-driver.scm",(void*)f_1459},
{"f_1481batch-driver.scm",(void*)f_1481},
{"f_1462batch-driver.scm",(void*)f_1462},
{"f_1465batch-driver.scm",(void*)f_1465},
{"f_1431batch-driver.scm",(void*)f_1431},
{"f_1313batch-driver.scm",(void*)f_1313},
{"f_1327batch-driver.scm",(void*)f_1327},
{"f_1331batch-driver.scm",(void*)f_1331},
{"f_1334batch-driver.scm",(void*)f_1334},
{"f_1353batch-driver.scm",(void*)f_1353},
{"f_1370batch-driver.scm",(void*)f_1370},
{"f_1373batch-driver.scm",(void*)f_1373},
{"f_1379batch-driver.scm",(void*)f_1379},
{"f_1382batch-driver.scm",(void*)f_1382},
{"f_1321batch-driver.scm",(void*)f_1321},
{"f_1133batch-driver.scm",(void*)f_1133},
{"f_1126batch-driver.scm",(void*)f_1126},
{"f_1102batch-driver.scm",(void*)f_1102},
{"f_818batch-driver.scm",(void*)f_818},
{"f_848batch-driver.scm",(void*)f_848},
{"f_843batch-driver.scm",(void*)f_843},
{"f_820batch-driver.scm",(void*)f_820},
{"f_824batch-driver.scm",(void*)f_824},
{"f_838batch-driver.scm",(void*)f_838},
{"f_832batch-driver.scm",(void*)f_832},
{"f_827batch-driver.scm",(void*)f_827},
{"f_812batch-driver.scm",(void*)f_812},
{"f_795batch-driver.scm",(void*)f_795},
{"f_785batch-driver.scm",(void*)f_785},
{"f_755batch-driver.scm",(void*)f_755},
{"f_761batch-driver.scm",(void*)f_761},
{"f_775batch-driver.scm",(void*)f_775},
{"f_779batch-driver.scm",(void*)f_779},
{"f_675batch-driver.scm",(void*)f_675},
{"f_744batch-driver.scm",(void*)f_744},
{"f_740batch-driver.scm",(void*)f_740},
{"f_724batch-driver.scm",(void*)f_724},
{"f_716batch-driver.scm",(void*)f_716},
{"f_685batch-driver.scm",(void*)f_685},
{"f_626batch-driver.scm",(void*)f_626},
{"f_672batch-driver.scm",(void*)f_672},
{"f_630batch-driver.scm",(void*)f_630},
{"f_636batch-driver.scm",(void*)f_636},
{"f_651batch-driver.scm",(void*)f_651},
{"f_647batch-driver.scm",(void*)f_647},
{"f_633batch-driver.scm",(void*)f_633},
{"f_614batch-driver.scm",(void*)f_614},
{"f_621batch-driver.scm",(void*)f_621},
{"f_599batch-driver.scm",(void*)f_599},
{"f_606batch-driver.scm",(void*)f_606},
{"f_609batch-driver.scm",(void*)f_609},
{"f_577batch-driver.scm",(void*)f_577},
{"f_584batch-driver.scm",(void*)f_584},
{"f_597batch-driver.scm",(void*)f_597},
{"f_559batch-driver.scm",(void*)f_559},
{"f_563batch-driver.scm",(void*)f_563},
{"f_572batch-driver.scm",(void*)f_572},
{"f_553batch-driver.scm",(void*)f_553},
{"f_451batch-driver.scm",(void*)f_451},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
