/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:50
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: batch-driver.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[359];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_fcall f_3148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_fcall f_1080(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_fcall f_1471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_fcall f_1474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_fcall f_1492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_fcall f_1498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_fcall f_1504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_fcall f_1507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_fcall f_1513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_fcall f_1520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_fcall f_1523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_fcall f_1526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_fcall f_1529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_fcall f_1532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_fcall f_1535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_fcall f_1541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_fcall f_1544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_fcall f_1550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_fcall f_1556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_fcall f_1581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_fcall f_1630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_fcall f_1664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_fcall f_1697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_fcall f_2555(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_fcall f_1773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_fcall f_1782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_fcall f_2304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_fcall f_1841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_fcall f_1844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_fcall f_1867(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_fcall f_2073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_fcall f_1392(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1422)
static void C_fcall f_1422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1394)
static void C_fcall f_1394(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_fcall f_1386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1359)
static C_word C_fcall f_1359(C_word t0);
C_noret_decl(f_1329)
static void C_fcall f_1329(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1335)
static void C_fcall f_1335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_fcall f_1210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_fcall f_1173(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_fcall f_1151(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_fcall f_1136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_fcall f_1127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1022)
static void C_fcall f_1022(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3148)
static void C_fcall trf_3148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3148(t0,t1);}

C_noret_decl(trf_1080)
static void C_fcall trf_1080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1080(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1080(t0,t1);}

C_noret_decl(trf_1471)
static void C_fcall trf_1471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1471(t0,t1);}

C_noret_decl(trf_1474)
static void C_fcall trf_1474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1474(t0,t1);}

C_noret_decl(trf_1492)
static void C_fcall trf_1492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1492(t0,t1);}

C_noret_decl(trf_1498)
static void C_fcall trf_1498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1498(t0,t1);}

C_noret_decl(trf_1504)
static void C_fcall trf_1504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1504(t0,t1);}

C_noret_decl(trf_1507)
static void C_fcall trf_1507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1507(t0,t1);}

C_noret_decl(trf_1510)
static void C_fcall trf_1510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1510(t0,t1);}

C_noret_decl(trf_1513)
static void C_fcall trf_1513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1513(t0,t1);}

C_noret_decl(trf_1520)
static void C_fcall trf_1520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1520(t0,t1);}

C_noret_decl(trf_1523)
static void C_fcall trf_1523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1523(t0,t1);}

C_noret_decl(trf_1526)
static void C_fcall trf_1526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1526(t0,t1);}

C_noret_decl(trf_1529)
static void C_fcall trf_1529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1529(t0,t1);}

C_noret_decl(trf_1532)
static void C_fcall trf_1532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1532(t0,t1);}

C_noret_decl(trf_1535)
static void C_fcall trf_1535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1535(t0,t1);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1538(t0,t1);}

C_noret_decl(trf_1541)
static void C_fcall trf_1541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1541(t0,t1);}

C_noret_decl(trf_1544)
static void C_fcall trf_1544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1544(t0,t1);}

C_noret_decl(trf_1550)
static void C_fcall trf_1550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1550(t0,t1);}

C_noret_decl(trf_1556)
static void C_fcall trf_1556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1556(t0,t1);}

C_noret_decl(trf_1581)
static void C_fcall trf_1581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1581(t0,t1);}

C_noret_decl(trf_1630)
static void C_fcall trf_1630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1630(t0,t1);}

C_noret_decl(trf_1664)
static void C_fcall trf_1664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1664(t0,t1);}

C_noret_decl(trf_1697)
static void C_fcall trf_1697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1697(t0,t1);}

C_noret_decl(trf_2500)
static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2500(t0,t1,t2);}

C_noret_decl(trf_2555)
static void C_fcall trf_2555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2555(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2555(t0,t1,t2);}

C_noret_decl(trf_1773)
static void C_fcall trf_1773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1773(t0,t1);}

C_noret_decl(trf_1782)
static void C_fcall trf_1782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1782(t0,t1);}

C_noret_decl(trf_2304)
static void C_fcall trf_2304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2304(t0,t1);}

C_noret_decl(trf_1841)
static void C_fcall trf_1841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1841(t0,t1);}

C_noret_decl(trf_1844)
static void C_fcall trf_1844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1844(t0,t1);}

C_noret_decl(trf_1867)
static void C_fcall trf_1867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1867(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1867(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2073)
static void C_fcall trf_2073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2073(t0,t1);}

C_noret_decl(trf_1392)
static void C_fcall trf_1392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1392(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1392(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1422)
static void C_fcall trf_1422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1422(t0,t1);}

C_noret_decl(trf_1417)
static void C_fcall trf_1417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1417(t0,t1,t2);}

C_noret_decl(trf_1394)
static void C_fcall trf_1394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1394(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1394(t0,t1,t2,t3);}

C_noret_decl(trf_1386)
static void C_fcall trf_1386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1386(t0,t1,t2);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1369(t0,t1,t2);}

C_noret_decl(trf_1329)
static void C_fcall trf_1329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1329(t0,t1,t2);}

C_noret_decl(trf_1335)
static void C_fcall trf_1335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1335(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1335(t0,t1,t2);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1249(t0,t1);}

C_noret_decl(trf_1210)
static void C_fcall trf_1210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1210(t0,t1);}

C_noret_decl(trf_1188)
static void C_fcall trf_1188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1188(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1188(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1173)
static void C_fcall trf_1173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1173(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1173(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1151)
static void C_fcall trf_1151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1151(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1151(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1136)
static void C_fcall trf_1136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1136(t0,t1,t2,t3);}

C_noret_decl(trf_1127)
static void C_fcall trf_1127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1127(t0,t1,t2,t3);}

C_noret_decl(trf_1022)
static void C_fcall trf_1022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1022(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2770)){
C_save(t1);
C_rereclaim2(2770*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,359);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],11,"user-pass-2");
lf[5]=C_h_intern(&lf[5],23,"user-post-analysis-pass");
lf[6]=C_h_intern(&lf[6],19,"compile-source-file");
lf[7]=C_h_intern(&lf[7],4,"quit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],26,"\010compilerexplicit-use-flag");
lf[12]=C_h_intern(&lf[12],12,"\004coredeclare");
lf[13]=C_h_intern(&lf[13],7,"verbose");
lf[14]=C_h_intern(&lf[14],11,"output-file");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[20]=C_h_intern(&lf[20],9,"heap-size");
lf[21]=C_h_intern(&lf[21],17,"heap-initial-size");
lf[22]=C_h_intern(&lf[22],11,"heap-growth");
lf[23]=C_h_intern(&lf[23],14,"heap-shrinkage");
lf[24]=C_h_intern(&lf[24],13,"keyword-style");
lf[25]=C_h_intern(&lf[25],4,"unit");
lf[26]=C_h_intern(&lf[26],12,"analyze-only");
lf[27]=C_h_intern(&lf[27],7,"dynamic");
lf[28]=C_h_intern(&lf[28],7,"nursery");
lf[29]=C_h_intern(&lf[29],10,"stack-size");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006~\077~%~!");
lf[32]=C_h_intern(&lf[32],26,"\010compilerdebugging-chicken");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[35]=C_h_intern(&lf[35],19,"\010compilerdump-nodes");
lf[36]=C_h_intern(&lf[36],12,"pretty-print");
lf[37]=C_h_intern(&lf[37],30,"\010compilerbuild-expression-tree");
lf[38]=C_h_intern(&lf[38],34,"\010compilerdisplay-analysis-database");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[40]=C_h_intern(&lf[40],12,"\003sysfor-each");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_h_intern(&lf[42],24,"\003sysline-number-database");
lf[43]=C_h_intern(&lf[43],10,"alist-cons");
lf[44]=C_h_intern(&lf[44],18,"\003syshash-table-ref");
lf[45]=C_h_intern(&lf[45],9,"list-info");
lf[46]=C_h_intern(&lf[46],26,"\003sysdefault-read-info-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[50]=C_h_intern(&lf[50],8,"\003sysread");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],28,"\003sysexplicit-library-modules");
lf[68]=C_h_intern(&lf[68],25,"\010compilertarget-heap-size");
lf[69]=C_h_intern(&lf[69],33,"\010compilertarget-initial-heap-size");
lf[70]=C_h_intern(&lf[70],27,"\010compilertarget-heap-growth");
lf[71]=C_h_intern(&lf[71],30,"\010compilertarget-heap-shrinkage");
lf[72]=C_h_intern(&lf[72],26,"\010compilertarget-stack-size");
lf[73]=C_h_intern(&lf[73],8,"no-trace");
lf[74]=C_h_intern(&lf[74],24,"\010compileremit-trace-info");
lf[75]=C_h_intern(&lf[75],29,"disable-stack-overflow-checks");
lf[76]=C_h_intern(&lf[76],40,"\010compilerdisable-stack-overflow-checking");
lf[77]=C_h_intern(&lf[77],7,"version");
lf[78]=C_h_intern(&lf[78],7,"newline");
lf[79]=C_h_intern(&lf[79],22,"\010compilerprint-version");
lf[80]=C_h_intern(&lf[80],4,"help");
lf[81]=C_h_intern(&lf[81],20,"\010compilerprint-usage");
lf[82]=C_h_intern(&lf[82],7,"release");
lf[83]=C_h_intern(&lf[83],7,"display");
lf[84]=C_h_intern(&lf[84],15,"chicken-version");
lf[85]=C_h_intern(&lf[85],24,"\010compilersource-filename");
lf[86]=C_h_intern(&lf[86],28,"\010compilerprofile-lambda-list");
lf[87]=C_h_intern(&lf[87],31,"\010compilerline-number-database-2");
lf[88]=C_h_intern(&lf[88],23,"\010compilerconstant-table");
lf[89]=C_h_intern(&lf[89],21,"\010compilerinline-table");
lf[90]=C_h_intern(&lf[90],23,"\010compilerfirst-analysis");
lf[91]=C_h_intern(&lf[91],41,"\010compilerperform-high-level-optimizations");
lf[92]=C_h_intern(&lf[92],37,"\010compilerinline-substitutions-enabled");
lf[93]=C_h_intern(&lf[93],22,"optimize-leaf-routines");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[95]=C_h_intern(&lf[95],34,"\010compilertransform-direct-lambdas!");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[97]=C_h_intern(&lf[97],4,"leaf");
lf[98]=C_h_intern(&lf[98],18,"\010compilerdebugging");
lf[99]=C_h_intern(&lf[99],1,"p");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[102]=C_h_intern(&lf[102],1,"5");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[105]=C_h_intern(&lf[105],36,"\010compilerprepare-for-code-generation");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[107]=C_h_intern(&lf[107],30,"\010compilercompiler-cleanup-hook");
lf[108]=C_h_intern(&lf[108],1,"t");
lf[109]=C_h_intern(&lf[109],17,"\003sysdisplay-times");
lf[110]=C_h_intern(&lf[110],14,"\003sysstop-timer");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[112]=C_h_intern(&lf[112],17,"close-output-port");
lf[113]=C_h_intern(&lf[113],22,"\010compilergenerate-code");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[115]=C_h_intern(&lf[115],16,"open-output-file");
lf[116]=C_h_intern(&lf[116],19,"current-output-port");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[119]=C_h_intern(&lf[119],1,"9");
lf[120]=C_h_intern(&lf[120],4,"exit");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[122]=C_h_intern(&lf[122],20,"\003syswarnings-enabled");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[124]=C_h_intern(&lf[124],1,"8");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[126]=C_h_intern(&lf[126],35,"\010compilerperform-closure-conversion");
lf[127]=C_h_intern(&lf[127],27,"\010compilerinline-output-file");
lf[128]=C_h_intern(&lf[128],32,"\010compileremit-global-inline-file");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[131]=C_h_intern(&lf[131],1,"7");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],33,"\010compilerprint-program-statistics");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[135]=C_h_intern(&lf[135],1,"4");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[137]=C_h_intern(&lf[137],1,"u");
lf[138]=C_h_intern(&lf[138],31,"\010compilerdump-undefined-globals");
lf[139]=C_h_intern(&lf[139],3,"opt");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[141]=C_h_intern(&lf[141],1,"3");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[143]=C_h_intern(&lf[143],31,"\010compilerperform-cps-conversion");
lf[144]=C_h_intern(&lf[144],6,"unsafe");
lf[145]=C_h_intern(&lf[145],34,"\010compilerscan-toplevel-assignments");
lf[146]=C_h_intern(&lf[146],26,"\010compilerdo-lambda-lifting");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[148]=C_h_intern(&lf[148],1,"L");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[150]=C_h_intern(&lf[150],32,"\010compilerperform-lambda-lifting!");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[153]=C_h_intern(&lf[153],1,"0");
lf[154]=C_h_intern(&lf[154],4,"lift");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[156]=C_h_intern(&lf[156],1,"U");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[160]=C_h_intern(&lf[160],4,"user");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\026Secondary user pass...");
lf[162]=C_h_intern(&lf[162],4,"node");
lf[163]=C_h_intern(&lf[163],6,"lambda");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[165]=C_h_intern(&lf[165],25,"\010compilerbuild-node-graph");
lf[166]=C_h_intern(&lf[166],32,"\010compilercanonicalize-begin-body");
lf[167]=C_h_intern(&lf[167],24,"\010compilerinline-globally");
lf[168]=C_h_intern(&lf[168],25,"\010compilerload-inline-file");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[170]=C_h_intern(&lf[170],12,"file-exists\077");
lf[171]=C_h_intern(&lf[171],28,"\003sysresolve-include-filename");
lf[172]=C_h_intern(&lf[172],13,"make-pathname");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[174]=C_h_intern(&lf[174],14,"symbol->string");
lf[175]=C_h_intern(&lf[175],11,"concatenate");
lf[176]=C_h_intern(&lf[176],7,"\003sysmap");
lf[177]=C_h_intern(&lf[177],3,"cdr");
lf[178]=C_h_intern(&lf[178],2,"pp");
lf[179]=C_h_intern(&lf[179],1,"M");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[181]=C_h_intern(&lf[181],12,"vector->list");
lf[182]=C_h_intern(&lf[182],26,"\010compilerfile-requirements");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[185]=C_h_intern(&lf[185],12,"check-syntax");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[187]=C_h_intern(&lf[187],1,"2");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[189]=C_h_intern(&lf[189],25,"\010compilercompiler-warning");
lf[190]=C_h_intern(&lf[190],5,"style");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[192]=C_h_intern(&lf[192],8,"feature\077");
lf[193]=C_h_intern(&lf[193],19,"compiling-extension");
lf[194]=C_h_intern(&lf[194],18,"\010compilerunit-name");
lf[195]=C_h_intern(&lf[195],5,"usage");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[197]=C_h_intern(&lf[197],37,"\010compilerdisplay-line-number-database");
lf[198]=C_h_intern(&lf[198],1,"n");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[200]=C_h_intern(&lf[200],32,"\010compilerdisplay-real-name-table");
lf[201]=C_h_intern(&lf[201],1,"N");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[203]=C_h_intern(&lf[203],6,"append");
lf[204]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[205]=C_h_intern(&lf[205],5,"quote");
lf[206]=C_h_intern(&lf[206],33,"\010compilerprofile-info-vector-name");
lf[207]=C_h_intern(&lf[207],28,"\003sysset-profile-info-vector!");
lf[208]=C_h_intern(&lf[208],21,"\010compileremit-profile");
lf[209]=C_h_intern(&lf[209],25,"\003sysregister-profile-info");
lf[210]=C_h_intern(&lf[210],4,"set!");
lf[211]=C_h_intern(&lf[211],13,"\004corecallunit");
lf[212]=C_h_intern(&lf[212],19,"\010compilerused-units");
lf[213]=C_h_intern(&lf[213],28,"\010compilerimmutable-constants");
lf[214]=C_h_intern(&lf[214],6,"gensym");
lf[215]=C_h_intern(&lf[215],32,"\010compilercanonicalize-expression");
lf[216]=C_h_intern(&lf[216],4,"uses");
lf[217]=C_h_intern(&lf[217],7,"declare");
lf[218]=C_h_intern(&lf[218],10,"\003sysappend");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[220]=C_h_intern(&lf[220],1,"1");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[223]=C_h_intern(&lf[223],21,"\010compilerstring->expr");
lf[224]=C_h_intern(&lf[224],7,"reverse");
lf[225]=C_h_intern(&lf[225],27,"\003syscurrent-source-filename");
lf[226]=C_h_intern(&lf[226],33,"\010compilerclose-checked-input-file");
lf[227]=C_h_intern(&lf[227],16,"\003sysdynamic-wind");
lf[228]=C_h_intern(&lf[228],34,"\010compilercheck-and-open-input-file");
lf[229]=C_h_intern(&lf[229],8,"epilogue");
lf[230]=C_h_intern(&lf[230],8,"prologue");
lf[231]=C_h_intern(&lf[231],8,"postlude");
lf[232]=C_h_intern(&lf[232],7,"prelude");
lf[233]=C_h_intern(&lf[233],11,"make-vector");
lf[234]=C_h_intern(&lf[234],34,"\010compilerline-number-database-size");
lf[235]=C_h_intern(&lf[235],1,"r");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[242]=C_h_intern(&lf[242],5,"-help");
lf[243]=C_h_intern(&lf[243],1,"h");
lf[244]=C_h_intern(&lf[244],2,"-h");
lf[245]=C_h_intern(&lf[245],8,"\003sysput!");
lf[246]=C_h_intern(&lf[246],7,"\004coredb");
lf[247]=C_h_intern(&lf[247],7,"\003sysget");
lf[248]=C_h_intern(&lf[248],9,"read-file");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\027loading database ~a ...");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[251]=C_h_intern(&lf[251],15,"repository-path");
lf[252]=C_h_intern(&lf[252],18,"accumulate-profile");
lf[253]=C_h_intern(&lf[253],28,"\010compilerprofiled-procedures");
lf[254]=C_h_intern(&lf[254],3,"all");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[258]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[259]=C_h_intern(&lf[259],39,"\010compilerdefault-profiling-declarations");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[263]=C_h_intern(&lf[263],21,"no-usual-integrations");
lf[264]=C_h_intern(&lf[264],17,"standard-bindings");
lf[265]=C_h_intern(&lf[265],34,"\010compilerdefault-standard-bindings");
lf[266]=C_h_intern(&lf[266],17,"extended-bindings");
lf[267]=C_h_intern(&lf[267],34,"\010compilerdefault-extended-bindings");
lf[268]=C_h_intern(&lf[268],1,"m");
lf[269]=C_h_intern(&lf[269],14,"set-gc-report!");
lf[270]=C_h_intern(&lf[270],42,"\010compilerdefault-default-target-stack-size");
lf[271]=C_h_intern(&lf[271],41,"\010compilerdefault-default-target-heap-size");
lf[272]=C_h_intern(&lf[272],14,"compile-syntax");
lf[273]=C_h_intern(&lf[273],25,"\003sysenable-runtime-macros");
lf[274]=C_h_intern(&lf[274],22,"\004corerequire-extension");
lf[275]=C_h_intern(&lf[275],17,"require-extension");
lf[276]=C_h_intern(&lf[276],14,"string->symbol");
lf[277]=C_h_intern(&lf[277],16,"static-extension");
lf[278]=C_h_intern(&lf[278],28,"\010compilerpostponed-initforms");
lf[279]=C_h_intern(&lf[279],6,"delete");
lf[280]=C_h_intern(&lf[280],3,"eq\077");
lf[281]=C_h_intern(&lf[281],4,"load");
lf[282]=C_h_intern(&lf[282],12,"load-verbose");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[284]=C_h_intern(&lf[284],6,"extend");
lf[285]=C_h_intern(&lf[285],17,"register-feature!");
lf[286]=C_h_intern(&lf[286],12,"string-split");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[288]=C_h_intern(&lf[288],10,"append-map");
lf[289]=C_h_intern(&lf[289],7,"feature");
lf[290]=C_h_intern(&lf[290],20,"keep-shadowed-macros");
lf[291]=C_h_intern(&lf[291],33,"\010compilerundefine-shadowed-macros");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[293]=C_h_intern(&lf[293],23,"\010compilerchop-separator");
lf[294]=C_h_intern(&lf[294],12,"include-path");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[296]=C_h_intern(&lf[296],7,"\000prefix");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[298]=C_h_intern(&lf[298],5,"\000none");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[300]=C_h_intern(&lf[300],7,"\000suffix");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[302]=C_h_intern(&lf[302],17,"compress-literals");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[304]=C_h_intern(&lf[304],16,"case-insensitive");
lf[305]=C_h_intern(&lf[305],14,"case-sensitive");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[307]=C_h_intern(&lf[307],24,"\010compilerinline-max-size");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[309]=C_h_intern(&lf[309],23,"\010compilerinline-locally");
lf[310]=C_h_intern(&lf[310],26,"\010compilerlocal-definitions");
lf[311]=C_h_intern(&lf[311],6,"inline");
lf[312]=C_h_intern(&lf[312],30,"emit-external-prototypes-first");
lf[313]=C_h_intern(&lf[313],30,"\010compilerexternal-protos-first");
lf[314]=C_h_intern(&lf[314],5,"block");
lf[315]=C_h_intern(&lf[315],26,"\010compilerblock-compilation");
lf[316]=C_h_intern(&lf[316],17,"fixnum-arithmetic");
lf[317]=C_h_intern(&lf[317],11,"number-type");
lf[318]=C_h_intern(&lf[318],6,"fixnum");
lf[319]=C_h_intern(&lf[319],18,"disable-interrupts");
lf[320]=C_h_intern(&lf[320],28,"\010compilerinsert-timer-checks");
lf[321]=C_h_intern(&lf[321],16,"unsafe-libraries");
lf[322]=C_h_intern(&lf[322],27,"\010compileremit-unsafe-marker");
lf[323]=C_h_intern(&lf[323],11,"no-warnings");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[325]=C_h_intern(&lf[325],15,"disable-warning");
lf[326]=C_h_intern(&lf[326],13,"inline-global");
lf[327]=C_h_intern(&lf[327],5,"local");
lf[328]=C_h_intern(&lf[328],14,"no-lambda-info");
lf[329]=C_h_intern(&lf[329],26,"\010compileremit-closure-info");
lf[330]=C_h_intern(&lf[330],3,"raw");
lf[331]=C_h_intern(&lf[331],12,"emit-exports");
lf[332]=C_h_intern(&lf[332],7,"warning");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[334]=C_h_intern(&lf[334],1,"b");
lf[335]=C_h_intern(&lf[335],15,"\003sysstart-timer");
lf[336]=C_h_intern(&lf[336],11,"lambda-lift");
lf[337]=C_h_intern(&lf[337],13,"string-append");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[339]=C_h_intern(&lf[339],19,"emit-import-library");
lf[340]=C_h_intern(&lf[340],16,"\003sysstring->list");
lf[341]=C_h_intern(&lf[341],5,"debug");
lf[342]=C_h_intern(&lf[342],17,"ignore-repository");
lf[343]=C_h_intern(&lf[343],18,"\003sysdload-disabled");
lf[344]=C_h_intern(&lf[344],30,"\010compilerstandalone-executable");
lf[345]=C_h_intern(&lf[345],29,"\010compilerstring->c-identifier");
lf[346]=C_h_intern(&lf[346],18,"\010compilerstringify");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[349]=C_h_intern(&lf[349],6,"getenv");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[351]=C_h_intern(&lf[351],9,"to-stdout");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[353]=C_h_intern(&lf[353],13,"pathname-file");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[355]=C_h_intern(&lf[355],29,"\010compilerdefault-declarations");
lf[356]=C_h_intern(&lf[356],30,"\010compilerunits-used-by-default");
lf[357]=C_h_intern(&lf[357],28,"\010compilerinitialize-compiler");
lf[358]=C_h_intern(&lf[358],14,"make-parameter");
C_register_lf2(lf,359,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k975 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k978 in k975 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k981 in k978 in k975 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k984 in k981 in k978 in k975 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 80   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t2,C_SCHEME_FALSE);}

/* k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 81   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,C_SCHEME_FALSE);}

/* k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,C_SCHEME_FALSE);}

/* k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,C_SCHEME_FALSE);}

/* k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,C_SCHEME_FALSE);}

/* k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,C_SCHEME_FALSE);}

/* k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1019,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1019r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1019r(t0,t1,t2,t3);}}

static void C_ccall f_1019r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1022,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1055,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 98   initialize-compiler */
((C_proc2)C_retrieve_symbol_proc(lf[357]))(2,*((C_word*)lf[357]+1),t5);}

/* k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(C_word)C_i_memq(lf[10],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[11]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[11]))){
t7=t6;
f_3148(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3159,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[356]),C_SCHEME_END_OF_LIST);}}

/* k3157 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[216],t1);
t3=((C_word*)t0)[2];
f_3148(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3146 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_3148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 101  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[2],C_retrieve(lf[355]),t1);}

/* k3142 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3107,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 109  option-arg */
f_1022(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[351],((C_word*)t0)[5]))){
t9=t8;
f_1071(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 114  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[353]))(3,*((C_word*)lf[353]+1),t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3129(2,t10,lf[354]);}}}}

/* k3127 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 114  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[172]))(5,*((C_word*)lf[172]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[352]);}

/* k3105 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 111  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[174]+1)))(3,*((C_word*)lf[174]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1071(2,t2,t1);}}

/* k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1074,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 115  getenv */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t4,lf[350]);}

/* k3099 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[347]);
/* batch-driver.scm: 115  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[286]))(4,*((C_word*)lf[286]+1),((C_word*)t0)[2],t2,lf[348]);}

/* k3095 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[293]),t1);}

/* k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=C_retrieve(lf[15]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[16];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[17],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1080,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1080(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[252],((C_word*)t0)[8]);
t14=t12;
f_1080(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[18],((C_word*)t0)[8])));}}

/* k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1080,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[19]);
t5=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t22=(C_truep(t21)?t21:(C_word)C_i_memq(lf[29],((C_word*)t0)[13]));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1151,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1188,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1200,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1249,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1386,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t22,a[12]=t1,a[13]=t30,a[14]=t33,a[15]=((C_word*)t0)[3],a[16]=t4,a[17]=((C_word*)t0)[4],a[18]=t27,a[19]=t26,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t23,a[24]=t25,a[25]=t34,a[26]=t32,a[27]=t31,a[28]=t18,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t20,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3074,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 212  option-arg */
f_1022(t38,t12);}
else{
t36=t35;
f_1471(t36,C_SCHEME_UNDEFINED);}}

/* k3076 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 212  stringify */
((C_proc3)C_retrieve_symbol_proc(lf[346]))(3,*((C_word*)lf[346]+1),((C_word*)t0)[2],t1);}

/* k3072 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 212  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[345]))(3,*((C_word*)lf[345]+1),((C_word*)t0)[2],t1);}

/* k3068 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[194]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1471(t3,t2);}

/* k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1471,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[194]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[344] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1474(t6,t5);}
else{
t5=t2;
f_1474(t5,C_SCHEME_UNDEFINED);}}

/* k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1474,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[342],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[343] /* dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm: 217  repository-path */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1477(2,t3,C_SCHEME_UNDEFINED);}}

/* k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3033,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3055,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 223  collect-options */
t5=((C_word*)t0)[13];
f_1329(t5,t4,lf[341]);}

/* k3053 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 219  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[288]))(4,*((C_word*)lf[288]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3032 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3033,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3039,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3051,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[340]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3049 in a3032 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3038 in a3032 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3039,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 221  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[276]+1)))(3,*((C_word*)lf[276]+1),t1,t3);}

/* k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[32]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3015,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3031,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 229  collect-options */
t8=((C_word*)t0)[13];
f_1329(t8,t7,lf[339]);}

/* k3029 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3014 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3015,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3023,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 227  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[276]+1)))(3,*((C_word*)lf[276]+1),t3,t2);}

/* k3021 in a3014 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 228  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[337]+1)))(4,*((C_word*)lf[337]+1),t2,((C_word*)t0)[2],lf[338]);}

/* k3025 in k3021 in a3014 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[336],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[146] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1492(t5,t4);}
else{
t4=t3;
f_1492(t4,C_SCHEME_UNDEFINED);}}

/* k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1492,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[108],C_retrieve(lf[32])))){
/* batch-driver.scm: 231  ##sys#start-timer */
t3=*((C_word*)lf[335]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1495(2,t3,C_SCHEME_UNDEFINED);}}

/* k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[334],C_retrieve(lf[32])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1498(t4,t3);}
else{
t3=t2;
f_1498(t3,C_SCHEME_UNDEFINED);}}

/* k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1498(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1498,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[331],((C_word*)t0)[34]))){
/* batch-driver.scm: 234  warning */
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t2,lf[333]);}
else{
t3=t2;
f_1501(2,t3,C_SCHEME_UNDEFINED);}}

/* k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[11] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[16],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1504(t6,t5);}
else{
t3=t2;
f_1504(t3,C_SCHEME_UNDEFINED);}}

/* k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1504,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[329] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1507(t4,t3);}
else{
t3=t2;
f_1507(t3,C_SCHEME_UNDEFINED);}}

/* k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1507,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[327],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[310] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1510(t4,t3);}
else{
t3=t2;
f_1510(t3,C_SCHEME_UNDEFINED);}}

/* k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1510,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[326],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[309] /* inline-locally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[167] /* inline-globally */,0,C_SCHEME_TRUE);
t5=t2;
f_1513(t5,t4);}
else{
t3=t2;
f_1513(t3,C_SCHEME_UNDEFINED);}}

/* k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1513,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 246  collect-options */
t4=((C_word*)t0)[12];
f_1329(t4,t3,lf[325]);}

/* k2972 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[276]+1),t1);}

/* k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[323],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 248  dribble */
t5=((C_word*)t0)[22];
f_1127(t5,t4,lf[324],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1520(t4,C_SCHEME_UNDEFINED);}}

/* k2967 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[122] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1520(t3,t2);}

/* k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1520,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[93],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[93] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1523(t4,t3);}
else{
t3=t2;
f_1523(t3,C_SCHEME_UNDEFINED);}}

/* k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1523,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[144],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[144] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1526(t4,t3);}
else{
t3=t2;
f_1526(t3,C_SCHEME_UNDEFINED);}}

/* k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1526,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[321],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[322] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1529(t5,t4);}
else{
t4=t2;
f_1529(t4,C_SCHEME_UNDEFINED);}}

/* k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1529,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[319],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[320] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1532(t4,t3);}
else{
t3=t2;
f_1532(t3,C_SCHEME_UNDEFINED);}}

/* k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1532,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[316],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[317]+1 /* (set! number-type ...) */,lf[318]);
t4=t2;
f_1535(t4,t3);}
else{
t3=t2;
f_1535(t3,C_SCHEME_UNDEFINED);}}

/* k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1535,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[314],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[315] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1538(t4,t3);}
else{
t3=t2;
f_1538(t3,C_SCHEME_UNDEFINED);}}

/* k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[313] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1541(t4,t3);}
else{
t3=t2;
f_1541(t3,C_SCHEME_UNDEFINED);}}

/* k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1541,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[311],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[309] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1544(t4,t3);}
else{
t3=t2;
f_1544(t3,C_SCHEME_UNDEFINED);}}

/* k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1544,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[309] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[310] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 264  option-arg */
f_1022(t6,t2);}
else{
t4=t3;
f_1550(t4,C_SCHEME_FALSE);}}

/* k2926 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[127]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1550(t3,t2);}

/* k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1550,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2913,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 267  option-arg */
f_1022(t4,t2);}
else{
t4=t3;
f_1556(t4,C_SCHEME_FALSE);}}

/* k2911 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 268  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2914 in k2911 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2919(2,t3,t1);}
else{
/* batch-driver.scm: 269  quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[308],((C_word*)t0)[2]);}}

/* k2917 in k2914 in k2911 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[307]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1556(t3,t2);}

/* k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1556,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[304],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2903,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 271  dribble */
t4=((C_word*)t0)[22];
f_1127(t4,t3,lf[306],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1559(2,t3,C_SCHEME_UNDEFINED);}}

/* k2901 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 272  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[285]))(3,*((C_word*)lf[285]+1),t2,lf[304]);}

/* k2904 in k2901 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 273  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[302],((C_word*)t0)[30]))){
/* batch-driver.scm: 275  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[189]))(4,*((C_word*)lf[189]+1),t2,lf[195],lf[303]);}
else{
t3=t2;
f_1562(2,t3,C_SCHEME_UNDEFINED);}}

/* k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2861,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 277  option-arg */
f_1022(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1565(2,t3,C_SCHEME_UNDEFINED);}}

/* k2859 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[295],t1))){
/* batch-driver.scm: 278  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[296]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[297],t1))){
/* batch-driver.scm: 279  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[298]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[299],t1))){
/* batch-driver.scm: 280  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[2],lf[300]);}
else{
/* batch-driver.scm: 281  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[301]);}}}}

/* k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2858,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 285  collect-options */
t7=((C_word*)t0)[11];
f_1329(t7,t6,lf[294]);}

/* k2856 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[293]),t1);}

/* k2852 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 285  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 289  quit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t3,lf[292]);}
else{
t5=t3;
f_1574(2,t5,C_SCHEME_UNDEFINED);}}

/* k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 290  collect-options */
t4=((C_word*)t0)[11];
f_1329(t4,t3,lf[216]);}

/* k2836 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[276]+1),t1);}

/* k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[32],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[290],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[291] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1581(t5,t4);}
else{
t4=t3;
f_1581(t4,C_SCHEME_UNDEFINED);}}

/* k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1581,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2820,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2822,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2830,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 297  collect-options */
t6=((C_word*)t0)[11];
f_1329(t6,t5,lf[289]);}

/* k2828 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 297  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[288]))(4,*((C_word*)lf[288]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2821 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2822,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[286]))(4,*((C_word*)lf[286]+1),t1,t2,lf[287]);}

/* k2818 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[285]),t1);}

/* k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 301  collect-options */
t5=((C_word*)t0)[11];
f_1329(t5,t4,lf[284]);}

/* k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 302  dribble */
t3=((C_word*)t0)[22];
f_1127(t3,t2,lf[283],C_SCHEME_END_OF_LIST);}

/* k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 303  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1597(2,t3,C_SCHEME_UNDEFINED);}}

/* k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2805,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2804 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2805,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2813,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 305  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[171]))(5,*((C_word*)lf[171]+1),t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2811 in a2804 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 305  load */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),((C_word*)t0)[2],t1);}

/* k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 307  delete */
((C_proc5)C_retrieve_symbol_proc(lf[279]))(5,*((C_word*)lf[279]+1),t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[280]+1));}

/* k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 310  user-post-analysis-pass */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t5);}

/* k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 313  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[278]));}

/* k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 315  collect-options */
t5=((C_word*)t0)[10];
f_1329(t5,t4,lf[277]);}

/* k2801 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[276]+1),t1);}

/* k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1623,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2775,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2795,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 321  collect-options */
t7=((C_word*)t0)[10];
f_1329(t7,t6,lf[275]);}

/* k2797 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 321  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2793 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2774 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2775,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[274],t5));}

/* k2771 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 318  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1623,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[31],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 325  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t3,C_retrieve(lf[67]),((C_word*)t0)[2]);}

/* k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1627,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[272],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[273] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1630(t5,t4);}
else{
t4=t3;
f_1630(t4,C_SCHEME_UNDEFINED);}}

/* k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1630,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2752,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 331  option-arg */
f_1022(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[271]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1634(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1634(2,t4,C_SCHEME_FALSE);}}}

/* k2750 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 331  arg-val */
f_1249(((C_word*)t0)[2],t1);}

/* k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 335  option-arg */
f_1022(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1638(2,t4,C_SCHEME_FALSE);}}

/* k2743 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 335  arg-val */
f_1249(((C_word*)t0)[2],t1);}

/* k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1638,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 336  option-arg */
f_1022(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1642(2,t4,C_SCHEME_FALSE);}}

/* k2736 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 336  arg-val */
f_1249(((C_word*)t0)[2],t1);}

/* k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2731,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 337  option-arg */
f_1022(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1646(2,t4,C_SCHEME_FALSE);}}

/* k2729 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 337  arg-val */
f_1249(((C_word*)t0)[2],t1);}

/* k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 340  option-arg */
f_1022(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[270]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1650(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1650(2,t5,C_SCHEME_FALSE);}}}

/* k2709 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 340  arg-val */
f_1249(((C_word*)t0)[2],t1);}

/* k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[73],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[74]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[75],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[76]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[268],C_retrieve(lf[32])))){
/* batch-driver.scm: 346  set-gc-report! */
((C_proc3)C_retrieve_symbol_proc(lf[269]))(3,*((C_word*)lf[269]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1661(2,t9,C_SCHEME_UNDEFINED);}}

/* k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[263],((C_word*)t0)[23]))){
t3=t2;
f_1664(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[264]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[265]));
t4=C_mutate((C_word*)lf[266]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[267]));
t5=t2;
f_1664(t5,t4);}}

/* k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1664,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(C_truep(C_retrieve(lf[74]))?lf[260]:lf[261]);
/* batch-driver.scm: 350  dribble */
t4=((C_word*)t0)[15];
f_1127(t4,t2,lf[262],(C_word)C_a_i_list(&a,1,t3));}

/* k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[252],t3);
t5=C_set_block_item(lf[208] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[253]+1 /* (set! profiled-procedures ...) */,lf[254]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2670,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[258]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 359  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),t7,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[259]),t8);}
else{
t3=t2;
f_1670(2,t3,C_SCHEME_UNDEFINED);}}

/* k2668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_truep(((C_word*)t0)[4])?lf[255]:lf[256]);
/* batch-driver.scm: 365  dribble */
t4=((C_word*)t0)[3];
f_1127(t4,((C_word*)t0)[2],lf[257],(C_word)C_a_i_list(&a,1,t3));}

/* k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 368  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[251]))(2,*((C_word*)lf[251]+1),t2);}

/* k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[14],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 369  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[172]))(4,*((C_word*)lf[172]+1),t4,t1,lf[250]);}
else{
t3=t2;
f_1676(2,t3,C_SCHEME_FALSE);}}

/* k2659 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 369  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),((C_word*)t0)[2],t1);}

/* k2609 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 370  dribble */
t3=((C_word*)t0)[2];
f_1127(t3,t2,lf[249],(C_word)C_a_i_list(&a,1,t1));}
else{
t2=((C_word*)t0)[3];
f_1676(2,t2,C_SCHEME_FALSE);}}

/* k2615 in k2609 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2622,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2657,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 376  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[248]))(3,*((C_word*)lf[248]+1),t3,((C_word*)t0)[2]);}

/* k2655 in k2615 in k2609 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2621 in k2615 in k2609 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2622,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2634,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* batch-driver.scm: 375  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[247]))(4,*((C_word*)lf[247]+1),t5,t6,lf[246]);}

/* k2636 in a2621 in k2615 in k2609 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* batch-driver.scm: 375  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),((C_word*)t0)[2],t2,t4);}

/* k2632 in a2621 in k2615 in k2609 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 373  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[245]))(5,*((C_word*)lf[245]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[246],t1);}

/* k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[77],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 379  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[80],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1697(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[242],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1697(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[243],((C_word*)t0)[22]);
t6=t3;
f_1697(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[244],((C_word*)t0)[22])));}}}}

/* k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1697,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 382  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),((C_word*)t0)[22]);}
else{
if(C_truep((C_word)C_i_memq(lf[82],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1716,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 384  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[84]))(2,*((C_word*)lf[84]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 392  dribble */
t4=((C_word*)t0)[14];
f_1127(t4,t3,lf[240],(C_word)C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 387  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,C_SCHEME_TRUE);}}}}

/* k1723 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 388  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[241]);}

/* k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 394  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t3,lf[235],lf[239],((C_word*)t0)[10]);}

/* k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 395  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[235],lf[238],C_retrieve(lf[32]));}

/* k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 396  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[235],lf[237],C_retrieve(lf[68]));}

/* k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 397  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[235],lf[236],C_retrieve(lf[72]));}

/* k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[22],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 401  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[233]+1)))(4,*((C_word*)lf[233]+1),t4,C_retrieve(lf[234]),C_SCHEME_END_OF_LIST);}

/* k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1752,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 402  collect-options */
t4=((C_word*)t0)[2];
f_1329(t4,t3,lf[232]);}

/* k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 403  collect-options */
t3=((C_word*)t0)[2];
f_1329(t3,t2,lf[231]);}

/* k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 405  collect-options */
t4=((C_word*)t0)[2];
f_1329(t4,t3,lf[230]);}

/* k2583 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2593,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 407  collect-options */
t4=((C_word*)t0)[2];
f_1329(t4,t3,lf[229]);}

/* k2591 in k2583 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 404  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 409  user-read-pass */
((C_proc2)C_retrieve_symbol_proc(lf[1]))(2,*((C_word*)lf[1]+1),t2);}

/* k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 411  dribble */
t4=((C_word*)t0)[20];
f_1127(t4,t3,lf[222],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2500(t6,t2,((C_word*)t0)[4]);}}

/* doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2511,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[223]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 421  check-and-open-input-file */
((C_proc3)C_retrieve_symbol_proc(lf[228]))(3,*((C_word*)lf[228]+1),t4,t3);}}

/* k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2529,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2541,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2578,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[227]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2577 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[225]));
t3=C_mutate((C_word*)lf[225]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2545 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2550,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 423  read-form */
t3=((C_word*)t0)[2];
f_1386(t3,t2,((C_word*)t0)[5]);}

/* k2548 in a2545 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2555(t5,((C_word*)t0)[2],t1);}

/* doloop609 in k2548 in a2545 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_2555(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2555,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 426  close-checked-input-file */
((C_proc4)C_retrieve_symbol_proc(lf[226]))(4,*((C_word*)lf[226]+1),t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2576,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 424  read-form */
t6=((C_word*)t0)[2];
f_1386(t6,t5,((C_word*)t0)[6]);}}

/* k2574 in doloop609 in k2548 in a2545 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2555(t2,((C_word*)t0)[2],t1);}

/* a2540 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[225]));
t3=C_mutate((C_word*)lf[225]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2530 in k2527 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2500(t3,((C_word*)t0)[2],t2);}

/* k2513 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 418  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[224]+1)))(3,*((C_word*)lf[224]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2517 in k2513 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2523,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[223]),((C_word*)t0)[2]);}

/* k2521 in k2517 in k2513 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 417  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[203]+1)))(5,*((C_word*)lf[203]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2509 in doloop580 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2489 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 412  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2493 in k2489 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1767(2,t3,t2);}

/* k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 430  user-preprocessor-pass */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2484,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 432  dribble */
t4=((C_word*)t0)[16];
f_1127(t4,t3,lf[221],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1773(t3,C_SCHEME_UNDEFINED);}}

/* k2482 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2486 in k2482 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1773(t3,t2);}

/* k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1773,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 435  print-expr */
t3=((C_word*)t0)[7];
f_1188(t3,t2,lf[219],lf[220],((C_word*)((C_word*)t0)[3])[1]);}

/* k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=f_1359(((C_word*)t0)[20]);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1782(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 438  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t4,C_retrieve(lf[67]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2459 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[218]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2479 in k2459 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2481,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[216],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[217],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1782(t7,t6);}

/* k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1782,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2454,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 440  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2452 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[215]),t1);}

/* k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 441  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[214]))(2,*((C_word*)lf[214]+1),t2);}

/* k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[86]));
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],tmp=(C_word)a,a+=16,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2422,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[213]));}

/* a2421 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2422,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[205],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[210],t8));}

/* k2294 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2412,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[212]));}

/* a2411 in k2294 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2412,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[211],t3));}

/* k2298 in k2294 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[208]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[205],t3);
t5=(C_truep(C_retrieve(lf[194]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[205],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[209],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[206]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[210],t12);
t14=t2;
f_2304(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2304(t3,C_SCHEME_END_OF_LIST);}}

/* k2302 in k2298 in k2294 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_2304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2304,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2323,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[86]));}

/* a2322 in k2302 in k2298 in k2294 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2323,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[205],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[205],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[206]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[207],t11));}

/* k2306 in k2302 in k2298 in k2294 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[194]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 443  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[203]+1)))(9,*((C_word*)lf[203]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[204]);}

/* k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 464  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t5,lf[201],lf[202]);}

/* k2287 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 465  display-real-name-table */
((C_proc2)C_retrieve_symbol_proc(lf[200]))(2,*((C_word*)lf[200]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1797(2,t2,C_SCHEME_UNDEFINED);}}

/* k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 466  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[198],lf[199]);}

/* k2281 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 467  display-line-number-database */
((C_proc2)C_retrieve_symbol_proc(lf[197]))(2,*((C_word*)lf[197]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1800(2,t2,C_SCHEME_UNDEFINED);}}

/* k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(C_retrieve(lf[194]))?((C_word*)t0)[9]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 470  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[189]))(5,*((C_word*)lf[189]+1),t2,lf[195],lf[196],C_retrieve(lf[194]));}
else{
t4=t2;
f_1803(2,t4,C_SCHEME_UNDEFINED);}}

/* k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[144]))){
/* batch-driver.scm: 472  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),t3,lf[193]);}
else{
t4=t3;
f_2268(2,t4,C_SCHEME_FALSE);}}

/* k2266 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 473  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[189]))(4,*((C_word*)lf[189]+1),((C_word*)t0)[2],lf[190],lf[191]);}
else{
t2=((C_word*)t0)[2];
f_1806(2,t2,C_SCHEME_UNDEFINED);}}

/* k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,C_retrieve(lf[87]));
t3=C_set_block_item(lf[87] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 480  end-time */
t5=((C_word*)t0)[15];
f_1369(t5,t4,lf[188]);}

/* k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 481  print-expr */
t3=((C_word*)t0)[2];
f_1188(t3,t2,lf[186],lf[187],((C_word*)((C_word*)t0)[4])[1]);}

/* k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_memq(lf[185],((C_word*)t0)[2]))){
/* batch-driver.scm: 483  exit */
((C_proc2)C_retrieve_symbol_proc(lf[120]))(2,*((C_word*)lf[120]+1),t2);}
else{
t3=t2;
f_1817(2,t3,C_SCHEME_UNDEFINED);}}

/* k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 485  user-pass */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2249,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 487  dribble */
t4=((C_word*)t0)[10];
f_1127(t4,t3,lf[184],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1823(2,t3,C_SCHEME_UNDEFINED);}}

/* k2247 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=f_1359(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2254 in k2247 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 490  end-time */
t3=((C_word*)t0)[3];
f_1369(t3,((C_word*)t0)[2],lf[183]);}

/* k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 492  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[181]+1)))(3,*((C_word*)lf[181]+1),t3,C_retrieve(lf[182]));}

/* k2244 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 492  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1);}

/* k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1829,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2239,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 493  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[179],lf[180]);}

/* k2237 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 494  pp */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1829(2,t2,C_SCHEME_UNDEFINED);}}

/* k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[167]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[176]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[177]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1832(2,t3,C_SCHEME_UNDEFINED);}}

/* k2234 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 504  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),((C_word*)t0)[2],t1);}

/* k2230 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2200 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2224,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 499  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[174]+1)))(3,*((C_word*)lf[174]+1),t5,t2);}

/* k2226 in a2200 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 499  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[172]))(5,*((C_word*)lf[172]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[173]);}

/* k2222 in a2200 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 498  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[171]))(5,*((C_word*)lf[171]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2203 in a2200 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 501  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2212 in k2203 in a2200 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 502  dribble */
t3=((C_word*)t0)[2];
f_1127(t3,t2,lf[169],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2215 in k2212 in k2203 in a2200 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 503  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2192,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 509  canonicalize-begin-body */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2194 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 508  build-node-graph */
((C_proc3)C_retrieve_symbol_proc(lf[165]))(3,*((C_word*)lf[165]+1),((C_word*)t0)[2],t1);}

/* k2190 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2184,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[163],lf[164],t2);}

/* f_2184 in k2190 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2184,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[162],t2,t3,t4));}

/* k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1838,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 510  user-pass-2 */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t2);}

/* k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[11],a[8]=t2,a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 512  dribble */
t4=((C_word*)t0)[10];
f_1127(t4,t3,lf[161],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1841(t3,C_SCHEME_UNDEFINED);}}

/* k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=f_1359(((C_word*)t0)[9]);
t3=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 515  analyze */
t5=((C_word*)t0)[2];
f_1392(t5,t4,lf[160],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2158 in k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 516  print-db */
t3=((C_word*)t0)[2];
f_1173(t3,t2,lf[159],lf[153],t1,C_fix(0));}

/* k2161 in k2158 in k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 517  end-time */
t3=((C_word*)t0)[3];
f_1369(t3,t2,lf[158]);}

/* k2164 in k2161 in k2158 in k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=f_1359(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 519  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2170 in k2164 in k2161 in k2158 in k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 520  end-time */
t3=((C_word*)t0)[2];
f_1369(t3,t2,lf[157]);}

/* k2173 in k2170 in k2164 in k2161 in k2158 in k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 521  print-node */
t3=((C_word*)t0)[3];
f_1151(t3,t2,lf[155],lf[156],((C_word*)t0)[2]);}

/* k2176 in k2173 in k2170 in k2164 in k2161 in k2158 in k2151 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1841(t3,t2);}

/* k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1841,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[146]))){
t3=f_1359(((C_word*)t0)[14]);
t4=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 527  analyze */
t6=((C_word*)t0)[12];
f_1392(t6,t5,lf[154],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1844(t3,C_SCHEME_UNDEFINED);}}

/* k2129 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2134,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 528  print-db */
t3=((C_word*)t0)[2];
f_1173(t3,t2,lf[152],lf[153],t1,C_fix(0));}

/* k2132 in k2129 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 529  end-time */
t3=((C_word*)t0)[3];
f_1369(t3,t2,lf[151]);}

/* k2135 in k2132 in k2129 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=f_1359(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 531  perform-lambda-lifting! */
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2141 in k2135 in k2132 in k2129 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 532  end-time */
t3=((C_word*)t0)[2];
f_1369(t3,t2,lf[149]);}

/* k2144 in k2141 in k2135 in k2132 in k2129 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 533  print-node */
t3=((C_word*)t0)[3];
f_1151(t3,t2,lf[147],lf[148],((C_word*)t0)[2]);}

/* k2147 in k2144 in k2141 in k2135 in k2132 in k2129 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1844(t3,t2);}

/* k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1844,NULL,2,t0,t1);}
t2=C_set_block_item(lf[42] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[88] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[89] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[144]))){
t6=t5;
f_1850(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2120,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2120 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2120,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2117 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* batch-driver.scm: 540  scan-toplevel-assignments */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t2);}

/* k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=f_1359(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 543  perform-cps-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[143]))(3,*((C_word*)lf[143]+1),t3,((C_word*)t0)[2]);}

/* k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1859,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 544  end-time */
t3=((C_word*)t0)[12];
f_1369(t3,t2,lf[142]);}

/* k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 545  print-node */
t3=((C_word*)t0)[11];
f_1151(t3,t2,lf[140],lf[141],((C_word*)t0)[2]);}

/* k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t3,a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp));
t5=((C_word*)t3)[1];
f_1867(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1867(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1867,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1359(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=t3,a[16]=((C_word*)t0)[13],a[17]=t4,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 551  analyze */
t7=((C_word*)t0)[10];
f_1392(t7,t6,lf[139],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(C_retrieve(lf[90]))){
if(C_truep((C_word)C_i_memq(lf[137],C_retrieve(lf[32])))){
/* batch-driver.scm: 554  dump-undefined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[138]))(3,*((C_word*)lf[138]+1),t2,t1);}
else{
t3=t2;
f_1877(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1877(2,t3,C_SCHEME_UNDEFINED);}}

/* k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=C_set_block_item(lf[90] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 556  end-time */
t4=((C_word*)t0)[12];
f_1369(t4,t3,lf[136]);}

/* k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 557  print-db */
t3=((C_word*)t0)[2];
f_1173(t3,t2,lf[134],lf[135],((C_word*)t0)[15],((C_word*)t0)[14]);}

/* k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_memq(lf[132],C_retrieve(lf[32])))){
/* batch-driver.scm: 559  print-program-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t2,((C_word*)t0)[15]);}
else{
t3=t2;
f_1887(2,t3,C_SCHEME_UNDEFINED);}}

/* k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
if(C_truep(((C_word*)t0)[18])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 562  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t2,lf[99],lf[104],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 586  print-node */
t3=((C_word*)t0)[10];
f_1151(t3,t2,lf[130],lf[131],((C_word*)t0)[16]);}}

/* k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[127]))){
t3=C_retrieve(lf[127]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 590  dribble */
t5=((C_word*)t0)[13];
f_1127(t5,t4,lf[129],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_1982(2,t3,C_SCHEME_UNDEFINED);}}

/* k2088 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 591  emit-global-inline-file */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=f_1359(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 594  perform-closure-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t3,((C_word*)t0)[2],((C_word*)t0)[14]);}

/* k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 595  end-time */
t3=((C_word*)t0)[11];
f_1369(t3,t2,lf[125]);}

/* k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 596  print-db */
t3=((C_word*)t0)[3];
f_1173(t3,t2,lf[123],lf[124],((C_word*)t0)[13],((C_word*)t0)[2]);}

/* k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[122]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2073(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2073(t4,C_SCHEME_FALSE);}}

/* k2071 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_2073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 598  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[121]);}
else{
t2=((C_word*)t0)[2];
f_1997(2,t2,C_SCHEME_UNDEFINED);}}

/* k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 599  exit */
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),t2,C_fix(0));}
else{
t3=t2;
f_2000(2,t3,C_SCHEME_UNDEFINED);}}

/* k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 600  print-node */
t3=((C_word*)t0)[2];
f_1151(t3,t2,lf[118],lf[119],((C_word*)t0)[10]);}

/* k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=f_1359(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2017,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 605  end-time */
t7=((C_word*)t0)[6];
f_1369(t7,t6,lf[117]);}

/* k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=f_1359(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm: 608  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),t3,((C_word*)t0)[8]);}
else{
/* batch-driver.scm: 608  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[116]+1)))(2,*((C_word*)lf[116]+1),t3);}}

/* k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 609  dribble */
t3=((C_word*)t0)[11];
f_1127(t3,t2,lf[114],(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 610  generate-code */
((C_proc9)C_retrieve_symbol_proc(lf[113]))(9,*((C_word*)lf[113]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2031 in k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 611  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2036(2,t3,C_SCHEME_UNDEFINED);}}

/* k2034 in k2031 in k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 612  end-time */
t3=((C_word*)t0)[2];
f_1369(t3,t2,lf[111]);}

/* k2037 in k2034 in k2031 in k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[108],C_retrieve(lf[32])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 613  ##sys#stop-timer */
t4=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2042(2,t3,C_SCHEME_UNDEFINED);}}

/* k2056 in k2037 in k2034 in k2031 in k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 613  ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1);}

/* k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 614  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[107]))(2,*((C_word*)lf[107]+1),t2);}

/* k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2019 in a2016 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 615  dribble */
t2=((C_word*)t0)[3];
f_1127(t2,((C_word*)t0)[2],lf[106],C_SCHEME_END_OF_LIST);}

/* a2010 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1980 in k1977 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
/* batch-driver.scm: 604  prepare-for-code-generation */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=f_1359(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1907,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 567  end-time */
t5=((C_word*)t0)[4];
f_1369(t5,t4,lf[103]);}

/* k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 568  print-node */
t3=((C_word*)t0)[2];
f_1151(t3,t2,lf[101],lf[102],((C_word*)t0)[6]);}

/* k1912 in k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 570  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1867(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[92]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[93]))){
t3=f_1359(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 577  analyze */
t5=((C_word*)t0)[2];
f_1392(t5,t4,lf[97],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 583  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1867(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 572  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,lf[99],lf[100]);}}}

/* k1931 in k1912 in k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[92] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 574  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1867(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1948 in k1912 in k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1953,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 578  end-time */
t3=((C_word*)t0)[2];
f_1369(t3,t2,lf[96]);}

/* k1951 in k1948 in k1912 in k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1953,2,t0,t1);}
t2=f_1359(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 580  transform-direct-lambdas! */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1957 in k1951 in k1948 in k1912 in k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1962,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 581  end-time */
t3=((C_word*)t0)[2];
f_1369(t3,t2,lf[94]);}

/* k1960 in k1957 in k1951 in k1948 in k1912 in k1909 in a1906 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 582  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1867(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1900 in k1891 in k1885 in k1882 in k1879 in k1875 in k1872 in loop in k1860 in k1857 in k1854 in k1848 in k1842 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1804 in k1801 in k1798 in k1795 in k1792 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1765 in k1762 in k1759 in k1756 in k1753 in k1750 in k1742 in k1739 in k1736 in k1733 in k1729 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
/* batch-driver.scm: 566  perform-high-level-optimizations */
((C_proc4)C_retrieve_symbol_proc(lf[91]))(4,*((C_word*)lf[91]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1714 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 384  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],t1);}

/* k1707 in k1695 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 385  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* k1683 in k1674 in k1671 in k1668 in k1665 in k1662 in k1659 in k1648 in k1644 in k1640 in k1636 in k1632 in k1628 in k1625 in k1621 in k1617 in k1614 in k1610 in k1602 in k1598 in k1595 in k1592 in k1589 in k1582 in k1579 in k1576 in k1572 in k1569 in k1563 in k1560 in k1557 in k1554 in k1548 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1518 in k1515 in k1511 in k1508 in k1505 in k1502 in k1499 in k1496 in k1493 in k1490 in k1487 in k1479 in k1475 in k1472 in k1469 in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 380  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1392(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1392,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1394,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1422,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no305353 */
t8=t7;
f_1422(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf306349 */
t10=t6;
f_1417(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body303312 */
t12=t5;
f_1394(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[55],t11);}}}}

/* def-no305 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1422,NULL,2,t0,t1);}
/* def-contf306349 */
t2=((C_word*)t0)[2];
f_1417(t2,t1,C_fix(0));}

/* def-contf306 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1417,NULL,3,t0,t1,t2);}
/* body303312 */
t3=((C_word*)t0)[2];
f_1394(t3,t1,t2,C_SCHEME_TRUE);}

/* body303 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1394(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1394,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1398,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 203  analyze-expression */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t4,((C_word*)t0)[2]);}

/* k1396 in body303 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1401,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 205  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1401(2,t3,C_SCHEME_UNDEFINED);}}

/* a1411 in k1396 in body303 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1412,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[52]))(6,*((C_word*)lf[52]+1),t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1405 in k1396 in body303 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1406,4,t0,t1,t2,t3);}
/* ##compiler#get */
((C_proc5)C_retrieve_symbol_proc(lf[51]))(5,*((C_word*)lf[51]+1),t1,((C_word*)t0)[2],t2,t3);}

/* k1399 in k1396 in body303 in analyze in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1386,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 199  ##sys#read */
((C_proc4)C_retrieve_symbol_proc(lf[50]))(4,*((C_word*)lf[50]+1),t1,t2,((C_word*)t0)[2]);}

/* end-time in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 196  printf */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t1,lf[49],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static C_word C_fcall f_1359(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1329,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1335(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1335,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 188  option-arg */
f_1022(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1347 in loop in collect-options in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1353,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 188  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1335(t4,t2,t3);}

/* k1351 in k1347 in loop in collect-options in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1353,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1249(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1249,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1259,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 179  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1290,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 181  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 182  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 183  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1316 in arg-val in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1312 in arg-val in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1259(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1296 in arg-val in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 181  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1288 in arg-val in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1259(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1257 in arg-val in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 184  quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1200,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1204,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[46]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1246,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1246 in infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1246,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1202 in infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1207,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[45],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1210(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1210(t5,C_SCHEME_FALSE);}}

/* k1208 in k1202 in infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1221,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 171  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t4,C_retrieve(lf[42]),t5);}
else{
t2=((C_word*)t0)[3];
f_1207(2,t2,C_SCHEME_UNDEFINED);}}

/* k1223 in k1208 in k1202 in infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 170  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1219 in k1208 in k1202 in infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 167  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),((C_word*)t0)[3],C_retrieve(lf[42]),((C_word*)t0)[2],t1);}

/* k1205 in k1202 in infohook in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1188,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1195,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 161  print-header */
t6=((C_word*)t0)[2];
f_1136(t6,t5,t2,t3);}

/* k1193 in print-expr in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[36]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1173(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1173,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1180,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 156  print-header */
t7=((C_word*)t0)[2];
f_1136(t7,t6,t2,t3);}

/* k1178 in print-db in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1180,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 157  printf */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[39],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1181 in k1178 in print-db in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 158  display-analysis-database */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1151(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1151,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1158,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 150  print-header */
t6=((C_word*)t0)[2];
f_1136(t6,t5,t2,t3);}

/* k1156 in print-node in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 152  dump-nodes */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 153  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1169 in k1156 in print-node in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 153  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* print-header in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1136,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1140,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 143  dribble */
t5=((C_word*)t0)[2];
f_1127(t5,t4,lf[34],(C_word)C_a_i_list(&a,1,t2));}

/* k1138 in print-header in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[32])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 146  printf */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,lf[33],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1147 in k1138 in print-header in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1078 in k1072 in k1069 in k3138 in k1053 in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1127(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1127,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 140  printf */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t1,lf[31],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* option-arg in compile-source-file in k1015 in k1011 in k1007 in k1003 in k999 in k995 in k990 in k987 in k984 in k981 in k978 in k975 */
static void C_fcall f_1022(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1022,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 93   quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t1,lf[8],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 96   quit */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t1,lf[9],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[311] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_977:batch_driver_scm",(void*)f_977},
{"f_980:batch_driver_scm",(void*)f_980},
{"f_983:batch_driver_scm",(void*)f_983},
{"f_986:batch_driver_scm",(void*)f_986},
{"f_989:batch_driver_scm",(void*)f_989},
{"f_992:batch_driver_scm",(void*)f_992},
{"f_997:batch_driver_scm",(void*)f_997},
{"f_1001:batch_driver_scm",(void*)f_1001},
{"f_1005:batch_driver_scm",(void*)f_1005},
{"f_1009:batch_driver_scm",(void*)f_1009},
{"f_1013:batch_driver_scm",(void*)f_1013},
{"f_1017:batch_driver_scm",(void*)f_1017},
{"f_1019:batch_driver_scm",(void*)f_1019},
{"f_1055:batch_driver_scm",(void*)f_1055},
{"f_3159:batch_driver_scm",(void*)f_3159},
{"f_3148:batch_driver_scm",(void*)f_3148},
{"f_3144:batch_driver_scm",(void*)f_3144},
{"f_3140:batch_driver_scm",(void*)f_3140},
{"f_3129:batch_driver_scm",(void*)f_3129},
{"f_3107:batch_driver_scm",(void*)f_3107},
{"f_1071:batch_driver_scm",(void*)f_1071},
{"f_3101:batch_driver_scm",(void*)f_3101},
{"f_3097:batch_driver_scm",(void*)f_3097},
{"f_1074:batch_driver_scm",(void*)f_1074},
{"f_1080:batch_driver_scm",(void*)f_1080},
{"f_3078:batch_driver_scm",(void*)f_3078},
{"f_3074:batch_driver_scm",(void*)f_3074},
{"f_3070:batch_driver_scm",(void*)f_3070},
{"f_1471:batch_driver_scm",(void*)f_1471},
{"f_1474:batch_driver_scm",(void*)f_1474},
{"f_1477:batch_driver_scm",(void*)f_1477},
{"f_3055:batch_driver_scm",(void*)f_3055},
{"f_3033:batch_driver_scm",(void*)f_3033},
{"f_3051:batch_driver_scm",(void*)f_3051},
{"f_3039:batch_driver_scm",(void*)f_3039},
{"f_1481:batch_driver_scm",(void*)f_1481},
{"f_3031:batch_driver_scm",(void*)f_3031},
{"f_3015:batch_driver_scm",(void*)f_3015},
{"f_3023:batch_driver_scm",(void*)f_3023},
{"f_3027:batch_driver_scm",(void*)f_3027},
{"f_1489:batch_driver_scm",(void*)f_1489},
{"f_1492:batch_driver_scm",(void*)f_1492},
{"f_1495:batch_driver_scm",(void*)f_1495},
{"f_1498:batch_driver_scm",(void*)f_1498},
{"f_1501:batch_driver_scm",(void*)f_1501},
{"f_1504:batch_driver_scm",(void*)f_1504},
{"f_1507:batch_driver_scm",(void*)f_1507},
{"f_1510:batch_driver_scm",(void*)f_1510},
{"f_1513:batch_driver_scm",(void*)f_1513},
{"f_2974:batch_driver_scm",(void*)f_2974},
{"f_1517:batch_driver_scm",(void*)f_1517},
{"f_2969:batch_driver_scm",(void*)f_2969},
{"f_1520:batch_driver_scm",(void*)f_1520},
{"f_1523:batch_driver_scm",(void*)f_1523},
{"f_1526:batch_driver_scm",(void*)f_1526},
{"f_1529:batch_driver_scm",(void*)f_1529},
{"f_1532:batch_driver_scm",(void*)f_1532},
{"f_1535:batch_driver_scm",(void*)f_1535},
{"f_1538:batch_driver_scm",(void*)f_1538},
{"f_1541:batch_driver_scm",(void*)f_1541},
{"f_1544:batch_driver_scm",(void*)f_1544},
{"f_2928:batch_driver_scm",(void*)f_2928},
{"f_1550:batch_driver_scm",(void*)f_1550},
{"f_2913:batch_driver_scm",(void*)f_2913},
{"f_2916:batch_driver_scm",(void*)f_2916},
{"f_2919:batch_driver_scm",(void*)f_2919},
{"f_1556:batch_driver_scm",(void*)f_1556},
{"f_2903:batch_driver_scm",(void*)f_2903},
{"f_2906:batch_driver_scm",(void*)f_2906},
{"f_1559:batch_driver_scm",(void*)f_1559},
{"f_1562:batch_driver_scm",(void*)f_1562},
{"f_2861:batch_driver_scm",(void*)f_2861},
{"f_1565:batch_driver_scm",(void*)f_1565},
{"f_2858:batch_driver_scm",(void*)f_2858},
{"f_2854:batch_driver_scm",(void*)f_2854},
{"f_1571:batch_driver_scm",(void*)f_1571},
{"f_1574:batch_driver_scm",(void*)f_1574},
{"f_2838:batch_driver_scm",(void*)f_2838},
{"f_1578:batch_driver_scm",(void*)f_1578},
{"f_1581:batch_driver_scm",(void*)f_1581},
{"f_2830:batch_driver_scm",(void*)f_2830},
{"f_2822:batch_driver_scm",(void*)f_2822},
{"f_2820:batch_driver_scm",(void*)f_2820},
{"f_1584:batch_driver_scm",(void*)f_1584},
{"f_1591:batch_driver_scm",(void*)f_1591},
{"f_1594:batch_driver_scm",(void*)f_1594},
{"f_1597:batch_driver_scm",(void*)f_1597},
{"f_2805:batch_driver_scm",(void*)f_2805},
{"f_2813:batch_driver_scm",(void*)f_2813},
{"f_1600:batch_driver_scm",(void*)f_1600},
{"f_1604:batch_driver_scm",(void*)f_1604},
{"f_1612:batch_driver_scm",(void*)f_1612},
{"f_1616:batch_driver_scm",(void*)f_1616},
{"f_2803:batch_driver_scm",(void*)f_2803},
{"f_1619:batch_driver_scm",(void*)f_1619},
{"f_2799:batch_driver_scm",(void*)f_2799},
{"f_2795:batch_driver_scm",(void*)f_2795},
{"f_2775:batch_driver_scm",(void*)f_2775},
{"f_2773:batch_driver_scm",(void*)f_2773},
{"f_1623:batch_driver_scm",(void*)f_1623},
{"f_1627:batch_driver_scm",(void*)f_1627},
{"f_1630:batch_driver_scm",(void*)f_1630},
{"f_2752:batch_driver_scm",(void*)f_2752},
{"f_1634:batch_driver_scm",(void*)f_1634},
{"f_2745:batch_driver_scm",(void*)f_2745},
{"f_1638:batch_driver_scm",(void*)f_1638},
{"f_2738:batch_driver_scm",(void*)f_2738},
{"f_1642:batch_driver_scm",(void*)f_1642},
{"f_2731:batch_driver_scm",(void*)f_2731},
{"f_1646:batch_driver_scm",(void*)f_1646},
{"f_2711:batch_driver_scm",(void*)f_2711},
{"f_1650:batch_driver_scm",(void*)f_1650},
{"f_1661:batch_driver_scm",(void*)f_1661},
{"f_1664:batch_driver_scm",(void*)f_1664},
{"f_1667:batch_driver_scm",(void*)f_1667},
{"f_2670:batch_driver_scm",(void*)f_2670},
{"f_1670:batch_driver_scm",(void*)f_1670},
{"f_1673:batch_driver_scm",(void*)f_1673},
{"f_2661:batch_driver_scm",(void*)f_2661},
{"f_2611:batch_driver_scm",(void*)f_2611},
{"f_2617:batch_driver_scm",(void*)f_2617},
{"f_2657:batch_driver_scm",(void*)f_2657},
{"f_2622:batch_driver_scm",(void*)f_2622},
{"f_2638:batch_driver_scm",(void*)f_2638},
{"f_2634:batch_driver_scm",(void*)f_2634},
{"f_1676:batch_driver_scm",(void*)f_1676},
{"f_1697:batch_driver_scm",(void*)f_1697},
{"f_1725:batch_driver_scm",(void*)f_1725},
{"f_1731:batch_driver_scm",(void*)f_1731},
{"f_1735:batch_driver_scm",(void*)f_1735},
{"f_1738:batch_driver_scm",(void*)f_1738},
{"f_1741:batch_driver_scm",(void*)f_1741},
{"f_1744:batch_driver_scm",(void*)f_1744},
{"f_1752:batch_driver_scm",(void*)f_1752},
{"f_1755:batch_driver_scm",(void*)f_1755},
{"f_1758:batch_driver_scm",(void*)f_1758},
{"f_2585:batch_driver_scm",(void*)f_2585},
{"f_2593:batch_driver_scm",(void*)f_2593},
{"f_1761:batch_driver_scm",(void*)f_1761},
{"f_1764:batch_driver_scm",(void*)f_1764},
{"f_2500:batch_driver_scm",(void*)f_2500},
{"f_2529:batch_driver_scm",(void*)f_2529},
{"f_2578:batch_driver_scm",(void*)f_2578},
{"f_2546:batch_driver_scm",(void*)f_2546},
{"f_2550:batch_driver_scm",(void*)f_2550},
{"f_2555:batch_driver_scm",(void*)f_2555},
{"f_2576:batch_driver_scm",(void*)f_2576},
{"f_2541:batch_driver_scm",(void*)f_2541},
{"f_2532:batch_driver_scm",(void*)f_2532},
{"f_2515:batch_driver_scm",(void*)f_2515},
{"f_2519:batch_driver_scm",(void*)f_2519},
{"f_2523:batch_driver_scm",(void*)f_2523},
{"f_2511:batch_driver_scm",(void*)f_2511},
{"f_2491:batch_driver_scm",(void*)f_2491},
{"f_2495:batch_driver_scm",(void*)f_2495},
{"f_1767:batch_driver_scm",(void*)f_1767},
{"f_1770:batch_driver_scm",(void*)f_1770},
{"f_2484:batch_driver_scm",(void*)f_2484},
{"f_2488:batch_driver_scm",(void*)f_2488},
{"f_1773:batch_driver_scm",(void*)f_1773},
{"f_1776:batch_driver_scm",(void*)f_1776},
{"f_2461:batch_driver_scm",(void*)f_2461},
{"f_2481:batch_driver_scm",(void*)f_2481},
{"f_1782:batch_driver_scm",(void*)f_1782},
{"f_2454:batch_driver_scm",(void*)f_2454},
{"f_1785:batch_driver_scm",(void*)f_1785},
{"f_1788:batch_driver_scm",(void*)f_1788},
{"f_2422:batch_driver_scm",(void*)f_2422},
{"f_2296:batch_driver_scm",(void*)f_2296},
{"f_2412:batch_driver_scm",(void*)f_2412},
{"f_2300:batch_driver_scm",(void*)f_2300},
{"f_2304:batch_driver_scm",(void*)f_2304},
{"f_2323:batch_driver_scm",(void*)f_2323},
{"f_2308:batch_driver_scm",(void*)f_2308},
{"f_1794:batch_driver_scm",(void*)f_1794},
{"f_2289:batch_driver_scm",(void*)f_2289},
{"f_1797:batch_driver_scm",(void*)f_1797},
{"f_2283:batch_driver_scm",(void*)f_2283},
{"f_1800:batch_driver_scm",(void*)f_1800},
{"f_1803:batch_driver_scm",(void*)f_1803},
{"f_2268:batch_driver_scm",(void*)f_2268},
{"f_1806:batch_driver_scm",(void*)f_1806},
{"f_1811:batch_driver_scm",(void*)f_1811},
{"f_1814:batch_driver_scm",(void*)f_1814},
{"f_1817:batch_driver_scm",(void*)f_1817},
{"f_1820:batch_driver_scm",(void*)f_1820},
{"f_2249:batch_driver_scm",(void*)f_2249},
{"f_2256:batch_driver_scm",(void*)f_2256},
{"f_1823:batch_driver_scm",(void*)f_1823},
{"f_2246:batch_driver_scm",(void*)f_2246},
{"f_1826:batch_driver_scm",(void*)f_1826},
{"f_2239:batch_driver_scm",(void*)f_2239},
{"f_1829:batch_driver_scm",(void*)f_1829},
{"f_2236:batch_driver_scm",(void*)f_2236},
{"f_2232:batch_driver_scm",(void*)f_2232},
{"f_2201:batch_driver_scm",(void*)f_2201},
{"f_2228:batch_driver_scm",(void*)f_2228},
{"f_2224:batch_driver_scm",(void*)f_2224},
{"f_2205:batch_driver_scm",(void*)f_2205},
{"f_2214:batch_driver_scm",(void*)f_2214},
{"f_2217:batch_driver_scm",(void*)f_2217},
{"f_1832:batch_driver_scm",(void*)f_1832},
{"f_2196:batch_driver_scm",(void*)f_2196},
{"f_2192:batch_driver_scm",(void*)f_2192},
{"f_2184:batch_driver_scm",(void*)f_2184},
{"f_1835:batch_driver_scm",(void*)f_1835},
{"f_1838:batch_driver_scm",(void*)f_1838},
{"f_2153:batch_driver_scm",(void*)f_2153},
{"f_2160:batch_driver_scm",(void*)f_2160},
{"f_2163:batch_driver_scm",(void*)f_2163},
{"f_2166:batch_driver_scm",(void*)f_2166},
{"f_2172:batch_driver_scm",(void*)f_2172},
{"f_2175:batch_driver_scm",(void*)f_2175},
{"f_2178:batch_driver_scm",(void*)f_2178},
{"f_1841:batch_driver_scm",(void*)f_1841},
{"f_2131:batch_driver_scm",(void*)f_2131},
{"f_2134:batch_driver_scm",(void*)f_2134},
{"f_2137:batch_driver_scm",(void*)f_2137},
{"f_2143:batch_driver_scm",(void*)f_2143},
{"f_2146:batch_driver_scm",(void*)f_2146},
{"f_2149:batch_driver_scm",(void*)f_2149},
{"f_1844:batch_driver_scm",(void*)f_1844},
{"f_2120:batch_driver_scm",(void*)f_2120},
{"f_2119:batch_driver_scm",(void*)f_2119},
{"f_1850:batch_driver_scm",(void*)f_1850},
{"f_1856:batch_driver_scm",(void*)f_1856},
{"f_1859:batch_driver_scm",(void*)f_1859},
{"f_1862:batch_driver_scm",(void*)f_1862},
{"f_1867:batch_driver_scm",(void*)f_1867},
{"f_1874:batch_driver_scm",(void*)f_1874},
{"f_1877:batch_driver_scm",(void*)f_1877},
{"f_1881:batch_driver_scm",(void*)f_1881},
{"f_1884:batch_driver_scm",(void*)f_1884},
{"f_1887:batch_driver_scm",(void*)f_1887},
{"f_1979:batch_driver_scm",(void*)f_1979},
{"f_2090:batch_driver_scm",(void*)f_2090},
{"f_1982:batch_driver_scm",(void*)f_1982},
{"f_1988:batch_driver_scm",(void*)f_1988},
{"f_1991:batch_driver_scm",(void*)f_1991},
{"f_1994:batch_driver_scm",(void*)f_1994},
{"f_2073:batch_driver_scm",(void*)f_2073},
{"f_1997:batch_driver_scm",(void*)f_1997},
{"f_2000:batch_driver_scm",(void*)f_2000},
{"f_2003:batch_driver_scm",(void*)f_2003},
{"f_2017:batch_driver_scm",(void*)f_2017},
{"f_2021:batch_driver_scm",(void*)f_2021},
{"f_2027:batch_driver_scm",(void*)f_2027},
{"f_2030:batch_driver_scm",(void*)f_2030},
{"f_2033:batch_driver_scm",(void*)f_2033},
{"f_2036:batch_driver_scm",(void*)f_2036},
{"f_2039:batch_driver_scm",(void*)f_2039},
{"f_2058:batch_driver_scm",(void*)f_2058},
{"f_2042:batch_driver_scm",(void*)f_2042},
{"f_2045:batch_driver_scm",(void*)f_2045},
{"f_2011:batch_driver_scm",(void*)f_2011},
{"f_1893:batch_driver_scm",(void*)f_1893},
{"f_1907:batch_driver_scm",(void*)f_1907},
{"f_1911:batch_driver_scm",(void*)f_1911},
{"f_1914:batch_driver_scm",(void*)f_1914},
{"f_1933:batch_driver_scm",(void*)f_1933},
{"f_1950:batch_driver_scm",(void*)f_1950},
{"f_1953:batch_driver_scm",(void*)f_1953},
{"f_1959:batch_driver_scm",(void*)f_1959},
{"f_1962:batch_driver_scm",(void*)f_1962},
{"f_1901:batch_driver_scm",(void*)f_1901},
{"f_1716:batch_driver_scm",(void*)f_1716},
{"f_1709:batch_driver_scm",(void*)f_1709},
{"f_1685:batch_driver_scm",(void*)f_1685},
{"f_1392:batch_driver_scm",(void*)f_1392},
{"f_1422:batch_driver_scm",(void*)f_1422},
{"f_1417:batch_driver_scm",(void*)f_1417},
{"f_1394:batch_driver_scm",(void*)f_1394},
{"f_1398:batch_driver_scm",(void*)f_1398},
{"f_1412:batch_driver_scm",(void*)f_1412},
{"f_1406:batch_driver_scm",(void*)f_1406},
{"f_1401:batch_driver_scm",(void*)f_1401},
{"f_1386:batch_driver_scm",(void*)f_1386},
{"f_1369:batch_driver_scm",(void*)f_1369},
{"f_1359:batch_driver_scm",(void*)f_1359},
{"f_1329:batch_driver_scm",(void*)f_1329},
{"f_1335:batch_driver_scm",(void*)f_1335},
{"f_1349:batch_driver_scm",(void*)f_1349},
{"f_1353:batch_driver_scm",(void*)f_1353},
{"f_1249:batch_driver_scm",(void*)f_1249},
{"f_1318:batch_driver_scm",(void*)f_1318},
{"f_1314:batch_driver_scm",(void*)f_1314},
{"f_1298:batch_driver_scm",(void*)f_1298},
{"f_1290:batch_driver_scm",(void*)f_1290},
{"f_1259:batch_driver_scm",(void*)f_1259},
{"f_1200:batch_driver_scm",(void*)f_1200},
{"f_1246:batch_driver_scm",(void*)f_1246},
{"f_1204:batch_driver_scm",(void*)f_1204},
{"f_1210:batch_driver_scm",(void*)f_1210},
{"f_1225:batch_driver_scm",(void*)f_1225},
{"f_1221:batch_driver_scm",(void*)f_1221},
{"f_1207:batch_driver_scm",(void*)f_1207},
{"f_1188:batch_driver_scm",(void*)f_1188},
{"f_1195:batch_driver_scm",(void*)f_1195},
{"f_1173:batch_driver_scm",(void*)f_1173},
{"f_1180:batch_driver_scm",(void*)f_1180},
{"f_1183:batch_driver_scm",(void*)f_1183},
{"f_1151:batch_driver_scm",(void*)f_1151},
{"f_1158:batch_driver_scm",(void*)f_1158},
{"f_1171:batch_driver_scm",(void*)f_1171},
{"f_1136:batch_driver_scm",(void*)f_1136},
{"f_1140:batch_driver_scm",(void*)f_1140},
{"f_1149:batch_driver_scm",(void*)f_1149},
{"f_1127:batch_driver_scm",(void*)f_1127},
{"f_1022:batch_driver_scm",(void*)f_1022},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
