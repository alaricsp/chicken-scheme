/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-22 09:26
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[346];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_ccall f_426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_429)
static void C_ccall f_429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_fcall f_2450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_487)
static void C_ccall f_487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_fcall f_496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_884)
static void C_fcall f_884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_fcall f_895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_fcall f_898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_fcall f_904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_910)
static void C_fcall f_910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_fcall f_913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_916)
static void C_fcall f_916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_fcall f_933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_fcall f_936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_fcall f_942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_fcall f_945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_fcall f_948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_fcall f_951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_fcall f_954(C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_fcall f_957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_fcall f_963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_fcall f_988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_fcall f_1030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_fcall f_1040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_fcall f_1074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_fcall f_1101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_ccall f_1168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_fcall f_1815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_fcall f_1873(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_fcall f_1180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_fcall f_1189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_fcall f_1681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_fcall f_1248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_fcall f_1251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_fcall f_1489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_fcall f_805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_835)
static void C_fcall f_835(C_word t0,C_word t1) C_noret;
C_noret_decl(f_830)
static void C_fcall f_830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_807)
static void C_fcall f_807(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_819)
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_799)
static void C_fcall f_799(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_782)
static void C_fcall f_782(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_772)
static C_word C_fcall f_772(C_word t0);
C_noret_decl(f_742)
static void C_fcall f_742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_748)
static void C_fcall f_748(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_766)
static void C_ccall f_766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_662)
static void C_fcall f_662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_617)
static void C_ccall f_617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_fcall f_623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_638)
static void C_ccall f_638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_634)
static void C_ccall f_634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_601)
static void C_fcall f_601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_fcall f_586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_593)
static void C_ccall f_593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_564)
static void C_fcall f_564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_fcall f_546(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_540)
static C_word C_fcall f_540();
C_noret_decl(f_438)
static void C_fcall f_438(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2450)
static void C_fcall trf_2450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2450(t0,t1);}

C_noret_decl(trf_496)
static void C_fcall trf_496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_496(t0,t1);}

C_noret_decl(trf_884)
static void C_fcall trf_884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_884(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_884(t0,t1);}

C_noret_decl(trf_895)
static void C_fcall trf_895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_895(t0,t1);}

C_noret_decl(trf_898)
static void C_fcall trf_898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_898(t0,t1);}

C_noret_decl(trf_904)
static void C_fcall trf_904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_904(t0,t1);}

C_noret_decl(trf_910)
static void C_fcall trf_910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_910(t0,t1);}

C_noret_decl(trf_913)
static void C_fcall trf_913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_913(t0,t1);}

C_noret_decl(trf_916)
static void C_fcall trf_916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_916(t0,t1);}

C_noret_decl(trf_933)
static void C_fcall trf_933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_933(t0,t1);}

C_noret_decl(trf_936)
static void C_fcall trf_936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_936(t0,t1);}

C_noret_decl(trf_942)
static void C_fcall trf_942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_942(t0,t1);}

C_noret_decl(trf_945)
static void C_fcall trf_945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_945(t0,t1);}

C_noret_decl(trf_948)
static void C_fcall trf_948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_948(t0,t1);}

C_noret_decl(trf_951)
static void C_fcall trf_951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_951(t0,t1);}

C_noret_decl(trf_954)
static void C_fcall trf_954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_954(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_954(t0,t1);}

C_noret_decl(trf_957)
static void C_fcall trf_957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_957(t0,t1);}

C_noret_decl(trf_963)
static void C_fcall trf_963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_963(t0,t1);}

C_noret_decl(trf_988)
static void C_fcall trf_988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_988(t0,t1);}

C_noret_decl(trf_1030)
static void C_fcall trf_1030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1030(t0,t1);}

C_noret_decl(trf_1040)
static void C_fcall trf_1040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1040(t0,t1);}

C_noret_decl(trf_1074)
static void C_fcall trf_1074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1074(t0,t1);}

C_noret_decl(trf_1101)
static void C_fcall trf_1101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1101(t0,t1);}

C_noret_decl(trf_1815)
static void C_fcall trf_1815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1815(t0,t1,t2);}

C_noret_decl(trf_1873)
static void C_fcall trf_1873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1873(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1873(t0,t1,t2);}

C_noret_decl(trf_1180)
static void C_fcall trf_1180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1180(t0,t1);}

C_noret_decl(trf_1189)
static void C_fcall trf_1189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1189(t0,t1);}

C_noret_decl(trf_1681)
static void C_fcall trf_1681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1681(t0,t1);}

C_noret_decl(trf_1248)
static void C_fcall trf_1248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1248(t0,t1);}

C_noret_decl(trf_1251)
static void C_fcall trf_1251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1251(t0,t1);}

C_noret_decl(trf_1274)
static void C_fcall trf_1274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1274(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1274(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1489)
static void C_fcall trf_1489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1489(t0,t1);}

C_noret_decl(trf_805)
static void C_fcall trf_805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_805(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_805(t0,t1,t2,t3,t4);}

C_noret_decl(trf_835)
static void C_fcall trf_835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_835(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_835(t0,t1);}

C_noret_decl(trf_830)
static void C_fcall trf_830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_830(t0,t1,t2);}

C_noret_decl(trf_807)
static void C_fcall trf_807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_807(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_807(t0,t1,t2,t3);}

C_noret_decl(trf_799)
static void C_fcall trf_799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_799(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_799(t0,t1,t2);}

C_noret_decl(trf_782)
static void C_fcall trf_782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_782(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_782(t0,t1,t2);}

C_noret_decl(trf_742)
static void C_fcall trf_742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_742(t0,t1,t2);}

C_noret_decl(trf_748)
static void C_fcall trf_748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_748(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_748(t0,t1,t2);}

C_noret_decl(trf_662)
static void C_fcall trf_662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_662(t0,t1);}

C_noret_decl(trf_623)
static void C_fcall trf_623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_623(t0,t1);}

C_noret_decl(trf_601)
static void C_fcall trf_601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_601(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_601(t0,t1,t2,t3,t4);}

C_noret_decl(trf_586)
static void C_fcall trf_586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_586(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_586(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_564)
static void C_fcall trf_564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_564(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_564(t0,t1,t2,t3,t4);}

C_noret_decl(trf_546)
static void C_fcall trf_546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_546(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_546(t0,t1,t2,t3);}

C_noret_decl(trf_438)
static void C_fcall trf_438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_438(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2660)){
C_save(t1);
C_rereclaim2(2660*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,346);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],19,"\003sysundefined-value");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[5]=C_h_intern(&lf[5],19,"compile-source-file");
lf[6]=C_h_intern(&lf[6],4,"quit");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[9]=C_h_intern(&lf[9],12,"explicit-use");
lf[10]=C_h_intern(&lf[10],26,"\010compilerexplicit-use-flag");
lf[11]=C_h_intern(&lf[11],12,"\004coredeclare");
lf[12]=C_h_intern(&lf[12],7,"verbose");
lf[13]=C_h_intern(&lf[13],11,"output-file");
lf[14]=C_h_intern(&lf[14],36,"\010compilerdefault-optimization-passes");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[16]=C_h_intern(&lf[16],7,"profile");
lf[17]=C_h_intern(&lf[17],12,"profile-name");
lf[18]=C_h_intern(&lf[18],9,"heap-size");
lf[19]=C_h_intern(&lf[19],17,"heap-initial-size");
lf[20]=C_h_intern(&lf[20],11,"heap-growth");
lf[21]=C_h_intern(&lf[21],14,"heap-shrinkage");
lf[22]=C_h_intern(&lf[22],13,"keyword-style");
lf[23]=C_h_intern(&lf[23],4,"unit");
lf[24]=C_h_intern(&lf[24],12,"analyze-only");
lf[25]=C_h_intern(&lf[25],7,"dynamic");
lf[26]=C_h_intern(&lf[26],5,"quiet");
lf[27]=C_h_intern(&lf[27],7,"nursery");
lf[28]=C_h_intern(&lf[28],10,"stack-size");
lf[29]=C_h_intern(&lf[29],26,"\010compilerdebugging-chicken");
lf[30]=C_h_intern(&lf[30],6,"printf");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[33]=C_h_intern(&lf[33],19,"\010compilerdump-nodes");
lf[34]=C_h_intern(&lf[34],12,"pretty-print");
lf[35]=C_h_intern(&lf[35],30,"\010compilerbuild-expression-tree");
lf[36]=C_h_intern(&lf[36],34,"\010compilerdisplay-analysis-database");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[38]=C_h_intern(&lf[38],12,"\003sysfor-each");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],24,"\003sysline-number-database");
lf[41]=C_h_intern(&lf[41],10,"alist-cons");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],9,"list-info");
lf[44]=C_h_intern(&lf[44],26,"\003sysdefault-read-info-hook");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[46]=C_h_intern(&lf[46],9,"substring");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[48]=C_h_intern(&lf[48],8,"\003sysread");
lf[49]=C_h_intern(&lf[49],12,"\010compilerget");
lf[50]=C_h_intern(&lf[50],13,"\010compilerput!");
lf[51]=C_h_intern(&lf[51],27,"\010compileranalyze-expression");
lf[52]=C_h_intern(&lf[52],9,"\003syserror");
lf[53]=C_h_intern(&lf[53],1,"D");
lf[54]=C_h_intern(&lf[54],12,"emit-exports");
lf[55]=C_h_intern(&lf[55],13,"check-imports");
lf[56]=C_h_intern(&lf[56],25,"\010compileruse-import-table");
lf[57]=C_h_intern(&lf[57],26,"\010compilerdisabled-warnings");
lf[58]=C_h_intern(&lf[58],12,"inline-limit");
lf[59]=C_h_intern(&lf[59],21,"\010compilerverbose-mode");
lf[60]=C_h_intern(&lf[60],31,"\003sysread-error-with-line-number");
lf[61]=C_h_intern(&lf[61],21,"\003sysinclude-pathnames");
lf[62]=C_h_intern(&lf[62],19,"\000compiler-extension");
lf[63]=C_h_intern(&lf[63],12,"\003sysfeatures");
lf[64]=C_h_intern(&lf[64],10,"\000compiling");
lf[65]=C_h_intern(&lf[65],6,"\000match");
lf[66]=C_h_intern(&lf[66],25,"\010compilertarget-heap-size");
lf[67]=C_h_intern(&lf[67],33,"\010compilertarget-initial-heap-size");
lf[68]=C_h_intern(&lf[68],27,"\010compilertarget-heap-growth");
lf[69]=C_h_intern(&lf[69],30,"\010compilertarget-heap-shrinkage");
lf[70]=C_h_intern(&lf[70],26,"\010compilertarget-stack-size");
lf[71]=C_h_intern(&lf[71],8,"no-trace");
lf[72]=C_h_intern(&lf[72],24,"\010compileremit-trace-info");
lf[73]=C_h_intern(&lf[73],29,"disable-stack-overflow-checks");
lf[74]=C_h_intern(&lf[74],40,"\010compilerdisable-stack-overflow-checking");
lf[75]=C_h_intern(&lf[75],7,"version");
lf[76]=C_h_intern(&lf[76],7,"newline");
lf[77]=C_h_intern(&lf[77],22,"\010compilerprint-version");
lf[78]=C_h_intern(&lf[78],4,"help");
lf[79]=C_h_intern(&lf[79],20,"\010compilerprint-usage");
lf[80]=C_h_intern(&lf[80],7,"release");
lf[81]=C_h_intern(&lf[81],7,"display");
lf[82]=C_h_intern(&lf[82],15,"chicken-version");
lf[83]=C_h_intern(&lf[83],24,"\010compilersource-filename");
lf[84]=C_h_intern(&lf[84],28,"\010compilerprofile-lambda-list");
lf[85]=C_h_intern(&lf[85],31,"\010compilerline-number-database-2");
lf[86]=C_h_intern(&lf[86],4,"node");
lf[87]=C_h_intern(&lf[87],6,"lambda");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[89]=C_h_intern(&lf[89],23,"\010compilerconstant-table");
lf[90]=C_h_intern(&lf[90],21,"\010compilerinline-table");
lf[91]=C_h_intern(&lf[91],23,"\010compilerfirst-analysis");
lf[92]=C_h_intern(&lf[92],41,"\010compilerperform-high-level-optimizations");
lf[93]=C_h_intern(&lf[93],37,"\010compilerinline-substitutions-enabled");
lf[94]=C_h_intern(&lf[94],22,"optimize-leaf-routines");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[96]=C_h_intern(&lf[96],34,"\010compilertransform-direct-lambdas!");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[98]=C_h_intern(&lf[98],4,"leaf");
lf[99]=C_h_intern(&lf[99],18,"\010compilerdebugging");
lf[100]=C_h_intern(&lf[100],1,"p");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[103]=C_h_intern(&lf[103],1,"5");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[106]=C_h_intern(&lf[106],36,"\010compilerprepare-for-code-generation");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[108]=C_h_intern(&lf[108],30,"\010compilercompiler-cleanup-hook");
lf[109]=C_h_intern(&lf[109],1,"t");
lf[110]=C_h_intern(&lf[110],17,"\003sysdisplay-times");
lf[111]=C_h_intern(&lf[111],14,"\003sysstop-timer");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[113]=C_h_intern(&lf[113],17,"close-output-port");
lf[114]=C_h_intern(&lf[114],22,"\010compilergenerate-code");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[116]=C_h_intern(&lf[116],16,"open-output-file");
lf[117]=C_h_intern(&lf[117],19,"current-output-port");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[120]=C_h_intern(&lf[120],1,"9");
lf[121]=C_h_intern(&lf[121],4,"exit");
lf[122]=C_h_intern(&lf[122],25,"\010compilerexport-file-name");
lf[123]=C_h_intern(&lf[123],30,"\010compilerdump-exported-globals");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000$(do not worry - still compiling...)\012");
lf[125]=C_h_intern(&lf[125],20,"\003syswarnings-enabled");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[127]=C_h_intern(&lf[127],1,"8");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[129]=C_h_intern(&lf[129],35,"\010compilerperform-closure-conversion");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[131]=C_h_intern(&lf[131],1,"7");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],33,"\010compilerprint-program-statistics");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[135]=C_h_intern(&lf[135],1,"4");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[137]=C_h_intern(&lf[137],1,"u");
lf[138]=C_h_intern(&lf[138],31,"\010compilerdump-undefined-globals");
lf[139]=C_h_intern(&lf[139],29,"\010compilercheck-global-exports");
lf[140]=C_h_intern(&lf[140],29,"\010compilercheck-global-imports");
lf[141]=C_h_intern(&lf[141],3,"opt");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[143]=C_h_intern(&lf[143],1,"3");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[145]=C_h_intern(&lf[145],31,"\010compilerperform-cps-conversion");
lf[146]=C_h_intern(&lf[146],6,"unsafe");
lf[147]=C_h_intern(&lf[147],34,"\010compilerscan-toplevel-assignments");
lf[148]=C_h_intern(&lf[148],26,"\010compilerdo-lambda-lifting");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[150]=C_h_intern(&lf[150],1,"L");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[152]=C_h_intern(&lf[152],32,"\010compilerperform-lambda-lifting!");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[155]=C_h_intern(&lf[155],1,"0");
lf[156]=C_h_intern(&lf[156],4,"lift");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[158]=C_h_intern(&lf[158],1,"U");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[162]=C_h_intern(&lf[162],4,"user");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[164]=C_h_intern(&lf[164],17,"hash-table->alist");
lf[165]=C_h_intern(&lf[165],26,"\010compilerfile-requirements");
lf[166]=C_h_intern(&lf[166],1,"M");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[168]=C_h_intern(&lf[168],11,"user-pass-2");
lf[169]=C_h_intern(&lf[169],25,"\010compilerbuild-node-graph");
lf[170]=C_h_intern(&lf[170],32,"\010compilercanonicalize-begin-body");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[172]=C_h_intern(&lf[172],7,"\003sysmap");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[174]=C_h_intern(&lf[174],9,"user-pass");
lf[175]=C_h_intern(&lf[175],12,"check-syntax");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[177]=C_h_intern(&lf[177],1,"2");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[179]=C_h_intern(&lf[179],25,"\010compilercompiler-warning");
lf[180]=C_h_intern(&lf[180],5,"style");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[182]=C_h_intern(&lf[182],8,"feature\077");
lf[183]=C_h_intern(&lf[183],19,"compiling-extension");
lf[184]=C_h_intern(&lf[184],18,"\010compilerunit-name");
lf[185]=C_h_intern(&lf[185],5,"usage");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[187]=C_h_intern(&lf[187],26,"\010compilerblock-compilation");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[189]=C_h_intern(&lf[189],37,"\010compilerdisplay-line-number-database");
lf[190]=C_h_intern(&lf[190],1,"n");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[192]=C_h_intern(&lf[192],32,"\010compilerdisplay-real-name-table");
lf[193]=C_h_intern(&lf[193],1,"N");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[195]=C_h_intern(&lf[195],6,"append");
lf[196]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[197]=C_h_intern(&lf[197],5,"quote");
lf[198]=C_h_intern(&lf[198],28,"\003sysset-profile-info-vector!");
lf[199]=C_h_intern(&lf[199],33,"\010compilerprofile-info-vector-name");
lf[200]=C_h_intern(&lf[200],21,"\010compileremit-profile");
lf[201]=C_h_intern(&lf[201],25,"\003sysregister-profile-info");
lf[202]=C_h_intern(&lf[202],4,"set!");
lf[203]=C_h_intern(&lf[203],13,"\004corecallunit");
lf[204]=C_h_intern(&lf[204],19,"\010compilerused-units");
lf[205]=C_h_intern(&lf[205],28,"\010compilerimmutable-constants");
lf[206]=C_h_intern(&lf[206],6,"gensym");
lf[207]=C_h_intern(&lf[207],32,"\010compilercanonicalize-expression");
lf[208]=C_h_intern(&lf[208],28,"\003sysexplicit-library-modules");
lf[209]=C_h_intern(&lf[209],4,"uses");
lf[210]=C_h_intern(&lf[210],7,"declare");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[212]=C_h_intern(&lf[212],1,"1");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[214]=C_h_intern(&lf[214],22,"user-preprocessor-pass");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[216]=C_h_intern(&lf[216],21,"\010compilerstring->expr");
lf[217]=C_h_intern(&lf[217],7,"reverse");
lf[218]=C_h_intern(&lf[218],27,"\003syscurrent-source-filename");
lf[219]=C_h_intern(&lf[219],33,"\010compilerclose-checked-input-file");
lf[220]=C_h_intern(&lf[220],16,"\003sysdynamic-wind");
lf[221]=C_h_intern(&lf[221],34,"\010compilercheck-and-open-input-file");
lf[222]=C_h_intern(&lf[222],14,"user-read-pass");
lf[223]=C_h_intern(&lf[223],8,"epilogue");
lf[224]=C_h_intern(&lf[224],8,"prologue");
lf[225]=C_h_intern(&lf[225],8,"postlude");
lf[226]=C_h_intern(&lf[226],7,"prelude");
lf[227]=C_h_intern(&lf[227],11,"make-vector");
lf[228]=C_h_intern(&lf[228],34,"\010compilerline-number-database-size");
lf[229]=C_h_intern(&lf[229],1,"r");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000:\012\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[236]=C_h_intern(&lf[236],5,"-help");
lf[237]=C_h_intern(&lf[237],1,"h");
lf[238]=C_h_intern(&lf[238],2,"-h");
lf[239]=C_h_intern(&lf[239],18,"accumulate-profile");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[244]=C_h_intern(&lf[244],39,"\010compilerdefault-profiling-declarations");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\012stacktrace");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[248]=C_h_intern(&lf[248],21,"no-usual-integrations");
lf[249]=C_h_intern(&lf[249],17,"standard-bindings");
lf[250]=C_h_intern(&lf[250],34,"\010compilerdefault-standard-bindings");
lf[251]=C_h_intern(&lf[251],17,"extended-bindings");
lf[252]=C_h_intern(&lf[252],34,"\010compilerdefault-extended-bindings");
lf[253]=C_h_intern(&lf[253],1,"m");
lf[254]=C_h_intern(&lf[254],14,"set-gc-report!");
lf[255]=C_h_intern(&lf[255],42,"\010compilerdefault-default-target-stack-size");
lf[256]=C_h_intern(&lf[256],41,"\010compilerdefault-default-target-heap-size");
lf[257]=C_h_intern(&lf[257],15,"run-time-macros");
lf[258]=C_h_intern(&lf[258],25,"\003sysenable-runtime-macros");
lf[259]=C_h_intern(&lf[259],22,"\004corerequire-extension");
lf[260]=C_h_intern(&lf[260],15,"lset-difference");
lf[261]=C_h_intern(&lf[261],3,"eq\077");
lf[262]=C_h_intern(&lf[262],14,"string->symbol");
lf[263]=C_h_intern(&lf[263],12,"string-split");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[265]=C_h_intern(&lf[265],10,"append-map");
lf[266]=C_h_intern(&lf[266],17,"require-extension");
lf[267]=C_h_intern(&lf[267],9,"extension");
lf[268]=C_h_intern(&lf[268],16,"define-extension");
lf[269]=C_h_intern(&lf[269],13,"pathname-file");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[271]=C_h_intern(&lf[271],28,"\010compilerpostponed-initforms");
lf[272]=C_h_intern(&lf[272],23,"user-post-analysis-pass");
lf[273]=C_h_intern(&lf[273],11,"\003sysprovide");
lf[274]=C_h_intern(&lf[274],5,"match");
lf[275]=C_h_intern(&lf[275],6,"delete");
lf[276]=C_h_intern(&lf[276],4,"load");
lf[277]=C_h_intern(&lf[277],28,"\003sysresolve-include-filename");
lf[278]=C_h_intern(&lf[278],12,"load-verbose");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[280]=C_h_intern(&lf[280],6,"extend");
lf[281]=C_h_intern(&lf[281],17,"register-feature!");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[283]=C_h_intern(&lf[283],7,"feature");
lf[284]=C_h_intern(&lf[284],20,"keep-shadowed-macros");
lf[285]=C_h_intern(&lf[285],33,"\010compilerundefine-shadowed-macros");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[288]=C_h_intern(&lf[288],23,"\010compilerchop-separator");
lf[289]=C_h_intern(&lf[289],12,"include-path");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[291]=C_h_intern(&lf[291],7,"\000prefix");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[293]=C_h_intern(&lf[293],5,"\000none");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[295]=C_h_intern(&lf[295],7,"\000suffix");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[297]=C_h_intern(&lf[297],17,"compress-literals");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[299]=C_h_intern(&lf[299],16,"case-insensitive");
lf[300]=C_h_intern(&lf[300],14,"case-sensitive");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[302]=C_h_intern(&lf[302],24,"\010compilerinline-max-size");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[304]=C_h_intern(&lf[304],6,"inline");
lf[305]=C_h_intern(&lf[305],30,"emit-external-prototypes-first");
lf[306]=C_h_intern(&lf[306],30,"\010compilerexternal-protos-first");
lf[307]=C_h_intern(&lf[307],5,"block");
lf[308]=C_h_intern(&lf[308],17,"fixnum-arithmetic");
lf[309]=C_h_intern(&lf[309],11,"number-type");
lf[310]=C_h_intern(&lf[310],6,"fixnum");
lf[311]=C_h_intern(&lf[311],18,"disable-interrupts");
lf[312]=C_h_intern(&lf[312],28,"\010compilerinsert-timer-checks");
lf[313]=C_h_intern(&lf[313],16,"unsafe-libraries");
lf[314]=C_h_intern(&lf[314],27,"\010compileremit-unsafe-marker");
lf[315]=C_h_intern(&lf[315],23,"\005matchset-error-control");
lf[316]=C_h_intern(&lf[316],5,"\000fail");
lf[317]=C_h_intern(&lf[317],11,"no-warnings");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[319]=C_h_intern(&lf[319],15,"disable-warning");
lf[320]=C_h_intern(&lf[320],28,"\010compilerlookup-exports-file");
lf[321]=C_h_intern(&lf[321],6,"import");
lf[322]=C_h_intern(&lf[322],14,"no-lambda-info");
lf[323]=C_h_intern(&lf[323],26,"\010compileremit-closure-info");
lf[324]=C_h_intern(&lf[324],3,"raw");
lf[325]=C_h_intern(&lf[325],1,"b");
lf[326]=C_h_intern(&lf[326],15,"\003sysstart-timer");
lf[327]=C_h_intern(&lf[327],23,"disable-compiler-macros");
lf[328]=C_h_intern(&lf[328],32,"\010compilercompiler-macros-enabled");
lf[329]=C_h_intern(&lf[329],11,"lambda-lift");
lf[330]=C_h_intern(&lf[330],16,"\003sysstring->list");
lf[331]=C_h_intern(&lf[331],5,"debug");
lf[332]=C_h_intern(&lf[332],29,"\010compilerstring->c-identifier");
lf[333]=C_h_intern(&lf[333],18,"\010compilerstringify");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[336]=C_h_intern(&lf[336],6,"getenv");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[338]=C_h_intern(&lf[338],14,"symbol->string");
lf[339]=C_h_intern(&lf[339],9,"to-stdout");
lf[340]=C_h_intern(&lf[340],13,"make-pathname");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[343]=C_h_intern(&lf[343],29,"\010compilerdefault-declarations");
lf[344]=C_h_intern(&lf[344],30,"\010compilerunits-used-by-default");
lf[345]=C_h_intern(&lf[345],28,"\010compilerinitialize-compiler");
C_register_lf2(lf,346,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_423,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k421 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k424 in k421 */
static void C_ccall f_426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_429,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k427 in k424 in k421 */
static void C_ccall f_429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_429,2,t0,t1);}
t2=C_retrieve(lf[2]);
t3=C_mutate(&lf[3],lf[4]);
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_435,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* compile-source-file in k427 in k424 in k421 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_435r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_435r(t0,t1,t2,t3);}}

static void C_ccall f_435r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_438,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_471,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 101  initialize-compiler */
t6=C_retrieve(lf[345]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(C_word)C_i_memq(lf[9],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[10]+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2438,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[10]))){
t8=t7;
f_2450(t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_a_i_cons(&a,2,lf[209],C_retrieve(lf[344]));
t9=t7;
f_2450(t9,(C_word)C_a_i_list(&a,1,t8));}}

/* k2448 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_2450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 105  append */
t2=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[343]),t1);}

/* k2444 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2437 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2438,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[197],t2));}

/* k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[11],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[12],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 113  option-arg */
f_438(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[339],((C_word*)t0)[5]))){
t9=t8;
f_487(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2425,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 118  pathname-file */
t10=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_2425(2,t10,lf[342]);}}}}

/* k2423 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 118  make-pathname */
t2=C_retrieve(lf[340]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[341]);}

/* k2401 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 115  symbol->string */
t2=*((C_word*)lf[338]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_487(2,t2,t1);}}

/* k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_490,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 119  getenv */
t5=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[337]);}

/* k2395 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[334]);
/* batch-driver.scm: 119  string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[335]);}

/* k2391 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[288]),t1);}

/* k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_490,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[15];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[16],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_496,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_496(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[239],((C_word*)t0)[8]);
t14=t12;
f_496(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[17],((C_word*)t0)[8])));}}

/* k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_496,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[17],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[4]);
t5=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[28],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_540,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_546,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_564,a[2]=t25,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_586,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_601,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_613,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_662,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_799,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_805,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_884,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t30,a[11]=t23,a[12]=t1,a[13]=t31,a[14]=t34,a[15]=((C_word*)t0)[3],a[16]=t4,a[17]=((C_word*)t0)[4],a[18]=t28,a[19]=t27,a[20]=t13,a[21]=t17,a[22]=t14,a[23]=((C_word*)t0)[5],a[24]=t26,a[25]=t35,a[26]=t33,a[27]=t32,a[28]=t19,a[29]=t24,a[30]=((C_word*)t0)[6],a[31]=((C_word*)t0)[7],a[32]=((C_word*)t0)[8],a[33]=t21,a[34]=t11,a[35]=((C_word*)t0)[12],a[36]=((C_word*)t0)[13],a[37]=t16,tmp=(C_word)a,a+=38,tmp);
if(C_truep(t12)){
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2370,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2374,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 214  option-arg */
f_438(t39,t12);}
else{
t37=t36;
f_884(t37,C_SCHEME_UNDEFINED);}}

/* k2372 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 214  stringify */
t2=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2368 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 214  string->c-identifier */
t2=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2364 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[184]+1,t1);
t3=((C_word*)t0)[2];
f_884(t3,t2);}

/* k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_884,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2340,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 220  collect-options */
t5=((C_word*)t0)[13];
f_742(t5,t4,lf[331]);}

/* k2360 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 216  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2339 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2340,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2346,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[330]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2356 in a2339 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2345 in a2339 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2346,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 218  string->symbol */
t4=*((C_word*)lf[262]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_888,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(C_word)C_i_memq(lf[53],C_retrieve(lf[29]));
t4=C_mutate(((C_word *)((C_word*)t0)[37])+1,t3);
t5=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[329],((C_word*)t0)[36]))){
t6=C_set_block_item(lf[148],0,C_SCHEME_TRUE);
t7=t5;
f_895(t7,t6);}
else{
t6=t5;
f_895(t6,C_SCHEME_UNDEFINED);}}

/* k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_895,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[327],((C_word*)t0)[36]))){
t3=C_set_block_item(lf[328],0,C_SCHEME_FALSE);
t4=t2;
f_898(t4,t3);}
else{
t3=t2;
f_898(t3,C_SCHEME_UNDEFINED);}}

/* k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_898,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[29])))){
/* batch-driver.scm: 224  ##sys#start-timer */
t3=*((C_word*)lf[326]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_901(2,t3,C_SCHEME_UNDEFINED);}}

/* k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[325],C_retrieve(lf[29])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_904(t4,t3);}
else{
t3=t2;
f_904(t3,C_SCHEME_UNDEFINED);}}

/* k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_904,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[54],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cadr(t2);
t5=C_mutate((C_word*)lf[122]+1,t4);
t6=t3;
f_910(t6,t5);}
else{
t4=t3;
f_910(t4,C_SCHEME_FALSE);}}

/* k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_910,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[324],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[10],0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[16],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[31],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_913(t6,t5);}
else{
t3=t2;
f_913(t3,C_SCHEME_UNDEFINED);}}

/* k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_913,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[323],0,C_SCHEME_FALSE);
t4=t2;
f_916(t4,t3);}
else{
t3=t2;
f_916(t3,C_SCHEME_UNDEFINED);}}

/* k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_916,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[55],((C_word*)t0)[35]);
t3=C_mutate((C_word*)lf[56]+1,t2);
t4=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
/* batch-driver.scm: 235  collect-options */
t5=((C_word*)t0)[12];
f_742(t5,t4,lf[321]);}

/* k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=C_set_block_item(lf[56],0,C_SCHEME_TRUE);
/* for-each */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve(lf[320]),t1);}
else{
t3=t2;
f_926(2,t3,C_SCHEME_UNDEFINED);}}

/* k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 239  collect-options */
t4=((C_word*)t0)[12];
f_742(t4,t3,lf[319]);}

/* k2297 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[262]+1),t1);}

/* k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_930,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[35]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 241  printf */
t5=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[318]);}
else{
t5=t4;
f_2291(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_933(t4,C_SCHEME_UNDEFINED);}}

/* k2289 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_933(t3,t2);}

/* k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_933,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[94],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[94],0,C_SCHEME_TRUE);
t4=t2;
f_936(t4,t3);}
else{
t3=t2;
f_936(t3,C_SCHEME_UNDEFINED);}}

/* k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_936,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[146],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[146],0,C_SCHEME_TRUE);
/* batch-driver.scm: 246  ##match#set-error-control */
t4=C_retrieve(lf[315]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[316]);}
else{
t3=t2;
f_939(2,t3,C_SCHEME_UNDEFINED);}}

/* k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(C_truep(((C_word*)t0)[21])?(C_word)C_i_memq(lf[313],((C_word*)t0)[35]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[314],0,C_SCHEME_TRUE);
t5=t2;
f_942(t5,t4);}
else{
t4=t2;
f_942(t4,C_SCHEME_UNDEFINED);}}

/* k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_942,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[311],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[312],0,C_SCHEME_FALSE);
t4=t2;
f_945(t4,t3);}
else{
t3=t2;
f_945(t3,C_SCHEME_UNDEFINED);}}

/* k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_945,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[308],((C_word*)t0)[35]))){
t3=C_mutate((C_word*)lf[309]+1,lf[310]);
t4=t2;
f_948(t4,t3);}
else{
t3=t2;
f_948(t3,C_SCHEME_UNDEFINED);}}

/* k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_948,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[307],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[187],0,C_SCHEME_TRUE);
t4=t2;
f_951(t4,t3);}
else{
t3=t2;
f_951(t3,C_SCHEME_UNDEFINED);}}

/* k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_951,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[305],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[306],0,C_SCHEME_TRUE);
t4=t2;
f_954(t4,t3);}
else{
t3=t2;
f_954(t3,C_SCHEME_UNDEFINED);}}

/* k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_954(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_954,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[304],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[302],0,C_fix(10));
t4=t2;
f_957(t4,t3);}
else{
t3=t2;
f_957(t3,C_SCHEME_UNDEFINED);}}

/* k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_957,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[58],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[35],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2238,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 256  option-arg */
f_438(t4,t2);}
else{
t4=t3;
f_963(t4,C_SCHEME_FALSE);}}

/* k2236 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 257  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2239 in k2236 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2244(2,t3,t1);}
else{
/* batch-driver.scm: 258  quit */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[303],((C_word*)t0)[2]);}}

/* k2242 in k2239 in k2236 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[302]+1,t1);
t3=((C_word*)t0)[2];
f_963(t3,t2);}

/* k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_963,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[299],((C_word*)t0)[31]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2225,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[35])){
/* batch-driver.scm: 260  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[301]);}
else{
t4=t3;
f_2225(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_966(2,t3,C_SCHEME_UNDEFINED);}}

/* k2223 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 261  register-feature! */
t3=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[299]);}

/* k2226 in k2223 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 262  case-sensitive */
t2=C_retrieve(lf[300]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[297],((C_word*)t0)[31]))){
/* batch-driver.scm: 264  compiler-warning */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[185],lf[298]);}
else{
t3=t2;
f_969(2,t3,C_SCHEME_UNDEFINED);}}

/* k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2183,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 266  option-arg */
f_438(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_972(2,t3,C_SCHEME_UNDEFINED);}}

/* k2181 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[290],t1))){
/* batch-driver.scm: 267  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[291]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[292],t1))){
/* batch-driver.scm: 268  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[293]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[294],t1))){
/* batch-driver.scm: 269  keyword-style */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[295]);}
else{
/* batch-driver.scm: 270  quit */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[296]);}}}}

/* k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1,((C_word*)t0)[34]);
t3=C_set_block_item(lf[60],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[34],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 274  collect-options */
t7=((C_word*)t0)[11];
f_742(t7,t6,lf[289]);}

/* k2178 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[288]),t1);}

/* k2174 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 274  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[61]),((C_word*)t0)[2]);}

/* k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[28])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[28]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 278  quit */
t5=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[287]);}
else{
t5=t3;
f_981(2,t5,C_SCHEME_UNDEFINED);}}

/* k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2152,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2160,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 283  collect-options */
t6=((C_word*)t0)[10];
f_742(t6,t5,lf[209]);}

/* k2158 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 281  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2151 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2152,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[286]);}

/* k2148 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[262]+1),t1);}

/* k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[33],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[284],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[285],0,C_SCHEME_FALSE);
t5=t3;
f_988(t5,t4);}
else{
t4=t3;
f_988(t4,C_SCHEME_UNDEFINED);}}

/* k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_988,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2134,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 290  collect-options */
t6=((C_word*)t0)[10];
f_742(t6,t5,lf[283]);}

/* k2140 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 290  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2133 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2134,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[282]);}

/* k2130 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[281]),t1);}

/* k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],C_retrieve(lf[63]));
t3=C_mutate((C_word*)lf[63]+1,t2);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 294  collect-options */
t5=((C_word*)t0)[10];
f_742(t5,t4,lf[280]);}

/* k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1001,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[22])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 296  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[279]);}
else{
t3=t2;
f_1001(2,t3,C_SCHEME_UNDEFINED);}}

/* k2123 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 297  load-verbose */
t2=C_retrieve(lf[278]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2114,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2113 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2114,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2122,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 298  ##sys#resolve-include-filename */
t4=C_retrieve(lf[277]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2120 in a2113 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 298  load */
t2=C_retrieve(lf[276]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 299  delete */
t3=C_retrieve(lf[275]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[62],C_retrieve(lf[63]),*((C_word*)lf[261]+1));}

/* k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[63]));
t4=C_mutate((C_word*)lf[63]+1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[65],C_retrieve(lf[63]));
t6=C_mutate((C_word*)lf[63]+1,t5);
t7=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 303  ##sys#provide */
t8=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[274]);}

/* k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 304  user-post-analysis-pass */
t3=C_retrieve(lf[272]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 307  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[32])[1],C_retrieve(lf[271]));}

/* k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[267],((C_word*)t0)[31]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2084,a[2]=t3,a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[32],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2100,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[21])){
/* batch-driver.scm: 316  pathname-file */
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[21]);}
else{
if(C_truep(((C_word*)t0)[29])){
/* batch-driver.scm: 317  pathname-file */
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[29]);}
else{
/* batch-driver.scm: 318  quit */
t7=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[270]);}}}
else{
t4=t3;
f_1030(t4,C_SCHEME_UNDEFINED);}}

/* k2098 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 315  string->symbol */
t2=*((C_word*)lf[262]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2094 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[268],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* batch-driver.scm: 312  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* k2082 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1030(t3,t2);}

/* k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1030,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2067,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2069,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 326  collect-options */
t7=((C_word*)t0)[10];
f_742(t7,t6,lf[266]);}

/* k2075 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 324  append-map */
t2=C_retrieve(lf[265]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2068 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2069,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[264]);}

/* k2065 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[262]+1),t1);}

/* k2061 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 321  lset-difference */
t2=C_retrieve(lf[260]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[261]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[32],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2051,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a2050 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2051,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[197],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[259],t3));}

/* k2047 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 329  append */
t2=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[32],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[257],((C_word*)t0)[31]))){
t4=C_set_block_item(lf[258],0,C_SCHEME_TRUE);
t5=t3;
f_1040(t5,t4);}
else{
t4=t3;
f_1040(t4,C_SCHEME_UNDEFINED);}}

/* k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1040,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2028,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 335  option-arg */
f_438(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[256]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1044(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1044(2,t4,C_SCHEME_FALSE);}}}

/* k2026 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 335  arg-val */
f_662(((C_word*)t0)[2],t1);}

/* k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 339  option-arg */
f_438(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1048(2,t4,C_SCHEME_FALSE);}}

/* k2019 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 339  arg-val */
f_662(((C_word*)t0)[2],t1);}

/* k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 340  option-arg */
f_438(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1052(2,t4,C_SCHEME_FALSE);}}

/* k2012 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 340  arg-val */
f_662(((C_word*)t0)[2],t1);}

/* k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 341  option-arg */
f_438(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1056(2,t4,C_SCHEME_FALSE);}}

/* k2005 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 341  arg-val */
f_662(((C_word*)t0)[2],t1);}

/* k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1056,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1,t1);
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1987,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 344  option-arg */
f_438(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[255]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1060(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1060(2,t5,C_SCHEME_FALSE);}}}

/* k1985 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 344  arg-val */
f_662(((C_word*)t0)[2],t1);}

/* k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1,t1);
t3=(C_word)C_i_memq(lf[71],((C_word*)t0)[25]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[72]+1,t4);
t6=(C_word)C_i_memq(lf[73],((C_word*)t0)[25]);
t7=C_mutate((C_word*)lf[74]+1,t6);
t8=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[253],C_retrieve(lf[29])))){
/* batch-driver.scm: 350  set-gc-report! */
t9=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1071(2,t9,C_SCHEME_UNDEFINED);}}

/* k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[248],((C_word*)t0)[25]))){
t3=t2;
f_1074(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[249]+1,C_retrieve(lf[250]));
t4=C_mutate((C_word*)lf[251]+1,C_retrieve(lf[252]));
t5=t2;
f_1074(t5,t4);}}

/* k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1074,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[72]))?lf[245]:lf[246]);
/* batch-driver.scm: 355  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[247],t3);}
else{
t3=t2;
f_1077(2,t3,C_SCHEME_UNDEFINED);}}

/* k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[239],t3);
t5=C_set_block_item(lf[200],0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1940,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(t4)?lf[243]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 363  append */
t8=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[244]),t7);}
else{
t3=t2;
f_1080(2,t3,C_SCHEME_UNDEFINED);}}

/* k1938 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[240]:lf[241]);
/* batch-driver.scm: 370  printf */
t4=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[242],t3,C_retrieve(lf[200]));}
else{
t3=((C_word*)t0)[2];
f_1080(2,t3,C_SCHEME_UNDEFINED);}}

/* k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[75],((C_word*)t0)[24]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 373  print-version */
t3=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[78],((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(t2)){
t4=t3;
f_1101(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[236],((C_word*)t0)[24]);
if(C_truep(t4)){
t5=t3;
f_1101(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[237],((C_word*)t0)[24]);
t6=t3;
f_1101(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[238],((C_word*)t0)[24])));}}}}

/* k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1101,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 376  print-usage */
t2=C_retrieve(lf[79]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[24]);}
else{
if(C_truep((C_word)C_i_memq(lf[80],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 378  chicken-version */
t4=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[22];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1138(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 388  printf */
t4=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[234],((C_word*)t0)[22]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 382  print-version */
t4=C_retrieve(lf[77]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1130 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 383  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[235]);}

/* k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[24],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 390  debugging */
t4=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[229],lf[233],((C_word*)t0)[10]);}

/* k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 391  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[232],C_retrieve(lf[29]));}

/* k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 392  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[231],C_retrieve(lf[66]));}

/* k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 393  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[229],lf[230],C_retrieve(lf[70]));}

/* k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=f_540();
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 397  make-vector */
t5=*((C_word*)lf[227]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[228]),C_SCHEME_END_OF_LIST);}

/* k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 398  collect-options */
t4=((C_word*)t0)[2];
f_742(t4,t3,lf[226]);}

/* k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 399  collect-options */
t3=((C_word*)t0)[2];
f_742(t3,t2,lf[225]);}

/* k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1168,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 401  collect-options */
t4=((C_word*)t0)[2];
f_742(t4,t3,lf[224]);}

/* k1904 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 403  collect-options */
t4=((C_word*)t0)[2];
f_742(t4,t3,lf[223]);}

/* k1912 in k1904 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 400  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm: 405  user-read-pass */
t3=C_retrieve(lf[222]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1174,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],a[22]=((C_word*)t0)[26],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[22])){
/* batch-driver.scm: 407  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[215]);}
else{
t4=t3;
f_1803(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1815(t6,t2,((C_word*)t0)[4]);}}

/* do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1815,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1826,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[216]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 417  check-and-open-input-file */
t5=C_retrieve(lf[221]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1856,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[220]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a1895 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[218]));
t3=C_mutate((C_word*)lf[218]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* a1863 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1868,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 419  read-form */
t3=((C_word*)t0)[2];
f_799(t3,t2,((C_word*)t0)[5]);}

/* k1866 in a1863 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1873(t5,((C_word*)t0)[2],t1);}

/* do206 in k1866 in a1863 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1873(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1873,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 422  close-checked-input-file */
t3=C_retrieve(lf[219]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 420  read-form */
t6=((C_word*)t0)[2];
f_799(t6,t5,((C_word*)t0)[6]);}}

/* k1892 in do206 in k1866 in a1863 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1873(t2,((C_word*)t0)[2],t1);}

/* a1855 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[218]));
t3=C_mutate((C_word*)lf[218]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[2]));}

/* k1845 in k1842 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1815(t3,((C_word*)t0)[2],t2);}

/* k1828 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 414  reverse */
t3=*((C_word*)lf[217]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1832 in k1828 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1838,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[216]),((C_word*)t0)[2]);}

/* k1836 in k1832 in k1828 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 413  append */
t2=*((C_word*)lf[195]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1824 in do194 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1801 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 408  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1805 in k1801 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1174(2,t3,t2);}

/* k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 426  user-preprocessor-pass */
t3=C_retrieve(lf[214]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1793,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[18])){
/* batch-driver.scm: 428  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[213]);}
else{
t4=t3;
f_1793(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1180(t3,C_SCHEME_UNDEFINED);}}

/* k1791 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1795 in k1791 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1180(t3,t2);}

/* k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1180,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 431  print-expr */
t3=((C_word*)t0)[7];
f_601(t3,t2,lf[211],lf[212],((C_word*)((C_word*)t0)[3])[1]);}

/* k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=f_772(((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1189(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1778,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 434  append */
t5=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[208]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k1776 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[209],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,2,lf[210],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1189(t7,t6);}

/* k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1189,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 436  append */
t4=*((C_word*)lf[195]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1769 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[207]),t1);}

/* k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 437  gensym */
t3=C_retrieve(lf[206]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[84]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1201,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1751,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[205]));}

/* a1750 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1751,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,2,lf[197],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[202],t3,t5));}

/* k1671 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1745,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[204]));}

/* a1744 in k1671 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1745,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[203],t2));}

/* k1675 in k1671 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[200]))){
t3=(C_word)C_a_i_list(&a,2,lf[197],((C_word*)t0)[3]);
t4=(C_truep(C_retrieve(lf[184]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[197],t4);
t6=(C_word)C_a_i_list(&a,3,lf[201],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[202],C_retrieve(lf[199]),t6);
t8=t2;
f_1681(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t3=t2;
f_1681(t3,C_SCHEME_END_OF_LIST);}}

/* k1679 in k1675 in k1671 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1681,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1700,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[84]));}

/* a1699 in k1679 in k1675 in k1671 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1700,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,2,lf[197],t3);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_list(&a,2,lf[197],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,4,lf[198],C_retrieve(lf[199]),t4,t6));}

/* k1683 in k1679 in k1675 in k1671 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[184]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 439  append */
t5=*((C_word*)lf[195]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[196]);}

/* k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1201,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 460  debugging */
t6=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[193],lf[194]);}

/* k1664 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 461  display-real-name-table */
t2=C_retrieve(lf[192]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1204(2,t2,C_SCHEME_UNDEFINED);}}

/* k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 462  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[190],lf[191]);}

/* k1658 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 463  display-line-number-database */
t2=C_retrieve(lf[189]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1207(2,t2,C_SCHEME_UNDEFINED);}}

/* k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[187]))?C_retrieve(lf[184]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 466  compiler-warning */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[185],lf[188],C_retrieve(lf[184]));}
else{
t4=t2;
f_1210(2,t4,C_SCHEME_UNDEFINED);}}

/* k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[184]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 472  compiler-warning */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[185],lf[186],C_retrieve(lf[184]));}
else{
t4=t2;
f_1213(2,t4,C_SCHEME_UNDEFINED);}}

/* k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[146]))){
/* batch-driver.scm: 474  feature? */
t4=C_retrieve(lf[182]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[183]);}
else{
t4=t3;
f_1639(2,t4,C_SCHEME_FALSE);}}

/* k1637 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 475  compiler-warning */
t2=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[180],lf[181]);}
else{
t2=((C_word*)t0)[2];
f_1216(2,t2,C_SCHEME_UNDEFINED);}}

/* k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1216,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1,C_retrieve(lf[85]));
t3=C_set_block_item(lf[85],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 482  end-time */
t5=((C_word*)t0)[17];
f_782(t5,t4,lf[178]);}

/* k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 483  print-expr */
t3=((C_word*)t0)[2];
f_601(t3,t2,lf[176],lf[177],((C_word*)((C_word*)t0)[4])[1]);}

/* k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[175],((C_word*)t0)[2]))){
/* batch-driver.scm: 485  exit */
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1227(2,t3,C_SCHEME_UNDEFINED);}}

/* k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 487  user-pass */
t3=C_retrieve(lf[174]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1617,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[12])){
/* batch-driver.scm: 489  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[173]);}
else{
t4=t3;
f_1617(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1233(2,t3,C_SCHEME_UNDEFINED);}}

/* k1615 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1617,2,t0,t1);}
t2=f_772(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k1622 in k1615 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 492  end-time */
t3=((C_word*)t0)[3];
f_782(t3,((C_word*)t0)[2],lf[171]);}

/* k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 497  canonicalize-begin-body */
t4=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1612 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 496  build-node-graph */
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[86],lf[87],lf[88],t2);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1242,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 498  user-pass-2 */
t5=C_retrieve(lf[168]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1245,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 499  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[166],lf[167]);}

/* k1597 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 500  hash-table->alist */
t3=C_retrieve(lf[164]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[165]));}
else{
t2=((C_word*)t0)[2];
f_1245(2,t2,C_SCHEME_UNDEFINED);}}

/* k1604 in k1597 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 500  pretty-print */
t2=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],a[8]=t2,a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[13])){
/* batch-driver.scm: 502  printf */
t4=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[163]);}
else{
t4=t3;
f_1567(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1248(t3,C_SCHEME_UNDEFINED);}}

/* k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1567,2,t0,t1);}
t2=f_772(((C_word*)t0)[9]);
t3=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 505  analyze */
t5=((C_word*)t0)[2];
f_805(t5,t4,lf[162],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k1572 in k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 506  print-db */
t3=((C_word*)t0)[2];
f_586(t3,t2,lf[161],lf[155],t1,C_fix(0));}

/* k1575 in k1572 in k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 507  end-time */
t3=((C_word*)t0)[3];
f_782(t3,t2,lf[160]);}

/* k1578 in k1575 in k1572 in k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=f_772(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 509  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1584 in k1578 in k1575 in k1572 in k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 510  end-time */
t3=((C_word*)t0)[2];
f_782(t3,t2,lf[159]);}

/* k1587 in k1584 in k1578 in k1575 in k1572 in k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 511  print-node */
t3=((C_word*)t0)[3];
f_564(t3,t2,lf[157],lf[158],((C_word*)t0)[2]);}

/* k1590 in k1587 in k1584 in k1578 in k1575 in k1572 in k1565 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1248(t3,t2);}

/* k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[148]))){
t3=f_772(((C_word*)t0)[16]);
t4=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 517  analyze */
t6=((C_word*)t0)[14];
f_805(t6,t5,lf[156],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1251(t3,C_SCHEME_UNDEFINED);}}

/* k1543 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1548,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 518  print-db */
t3=((C_word*)t0)[2];
f_586(t3,t2,lf[154],lf[155],t1,C_fix(0));}

/* k1546 in k1543 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 519  end-time */
t3=((C_word*)t0)[3];
f_782(t3,t2,lf[153]);}

/* k1549 in k1546 in k1543 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=f_772(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 521  perform-lambda-lifting! */
t4=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1555 in k1549 in k1546 in k1543 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 522  end-time */
t3=((C_word*)t0)[2];
f_782(t3,t2,lf[151]);}

/* k1558 in k1555 in k1549 in k1546 in k1543 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 523  print-node */
t3=((C_word*)t0)[3];
f_564(t3,t2,lf[149],lf[150],((C_word*)t0)[2]);}

/* k1561 in k1558 in k1555 in k1549 in k1546 in k1543 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1251(t3,t2);}

/* k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1251,NULL,2,t0,t1);}
t2=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[89],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[90],0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[146]))){
t6=t5;
f_1257(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
/* batch-driver.scm: 530  scan-toplevel-assignments */
t8=C_retrieve(lf[147]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}}

/* k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
t2=f_772(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 533  perform-cps-conversion */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1266,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 534  end-time */
t3=((C_word*)t0)[14];
f_782(t3,t2,lf[144]);}

/* k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 535  print-node */
t3=((C_word*)t0)[13];
f_564(t3,t2,lf[142],lf[143],((C_word*)t0)[2]);}

/* k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1274(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1274,NULL,5,t0,t1,t2,t3,t4);}
t5=f_772(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[15],a[19]=t4,tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 541  analyze */
t7=((C_word*)t0)[12];
f_805(t7,t6,lf[141],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep(C_retrieve(lf[91]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1512,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[56]))){
/* batch-driver.scm: 543  check-global-imports */
t4=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t4=t3;
f_1512(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1284(2,t3,C_SCHEME_UNDEFINED);}}

/* k1510 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 544  check-global-exports */
t3=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1513 in k1510 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[137],C_retrieve(lf[29])))){
/* batch-driver.scm: 546  dump-undefined-globals */
t2=C_retrieve(lf[138]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1284(2,t2,C_SCHEME_UNDEFINED);}}

/* k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=C_set_block_item(lf[91],0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 548  end-time */
t4=((C_word*)t0)[14];
f_782(t4,t3,lf[136]);}

/* k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 549  print-db */
t3=((C_word*)t0)[2];
f_586(t3,t2,lf[134],lf[135],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_memq(lf[132],C_retrieve(lf[29])))){
/* batch-driver.scm: 551  print-program-statistics */
t3=C_retrieve(lf[133]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1294(2,t3,C_SCHEME_UNDEFINED);}}

/* k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
if(C_truep(((C_word*)t0)[20])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 554  debugging */
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[100],lf[105],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[18],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 577  print-node */
t3=((C_word*)t0)[12];
f_564(t3,t2,lf[130],lf[131],((C_word*)t0)[18]);}}

/* k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
t2=f_772(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 580  perform-closure-conversion */
t4=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 581  end-time */
t3=((C_word*)t0)[13];
f_782(t3,t2,lf[128]);}

/* k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 582  print-db */
t3=((C_word*)t0)[3];
f_586(t3,t2,lf[126],lf[127],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[125]))){
t4=f_540();
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_1489(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_1489(t4,C_SCHEME_FALSE);}}

/* k1487 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_1489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 584  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[124]);}
else{
t2=((C_word*)t0)[2];
f_1401(2,t2,C_SCHEME_UNDEFINED);}}

/* k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_retrieve(lf[122]))){
/* batch-driver.scm: 586  dump-exported-globals */
t3=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[11],C_retrieve(lf[122]));}
else{
t3=t2;
f_1404(2,t3,C_SCHEME_UNDEFINED);}}

/* k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 587  exit */
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_1407(2,t3,C_SCHEME_UNDEFINED);}}

/* k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 588  print-node */
t3=((C_word*)t0)[2];
f_564(t3,t2,lf[119],lf[120],((C_word*)t0)[11]);}

/* k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1410,2,t0,t1);}
t2=f_772(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 591  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1424,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 593  end-time */
t7=((C_word*)t0)[7];
f_782(t7,t6,lf[118]);}

/* k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=f_772(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 596  open-output-file */
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 596  current-output-port */
t4=*((C_word*)lf[117]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_1437(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 598  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[115],((C_word*)t0)[9]);}}

/* k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 599  generate-code */
t3=C_retrieve(lf[114]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1438 in k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 600  close-output-port */
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1443(2,t3,C_SCHEME_UNDEFINED);}}

/* k1441 in k1438 in k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 601  end-time */
t3=((C_word*)t0)[2];
f_782(t3,t2,lf[112]);}

/* k1444 in k1441 in k1438 in k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[29])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 602  ##sys#stop-timer */
t4=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1449(2,t3,C_SCHEME_UNDEFINED);}}

/* k1466 in k1444 in k1441 in k1438 in k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 602  ##sys#display-times */
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1447 in k1444 in k1441 in k1438 in k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 603  compiler-cleanup-hook */
t3=C_retrieve(lf[108]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1450 in k1447 in k1444 in k1441 in k1438 in k1435 in k1432 in k1426 in a1423 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 605  printf */
t2=C_retrieve(lf[30]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a1417 in k1408 in k1405 in k1402 in k1399 in k1396 in k1393 in k1390 in k1384 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
/* batch-driver.scm: 592  prepare-for-code-generation */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=f_772(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 557  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1314,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 558  end-time */
t5=((C_word*)t0)[4];
f_782(t5,t4,lf[104]);}

/* k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 559  print-node */
t3=((C_word*)t0)[2];
f_564(t3,t2,lf[102],lf[103],((C_word*)t0)[6]);}

/* k1319 in k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 561  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1274(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[93]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[94]))){
t3=f_772(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 568  analyze */
t5=((C_word*)t0)[2];
f_805(t5,t4,lf[98],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 574  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1274(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 563  debugging */
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[100],lf[101]);}}}

/* k1338 in k1319 in k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[93],0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 565  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1274(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1355 in k1319 in k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1360,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 569  end-time */
t3=((C_word*)t0)[2];
f_782(t3,t2,lf[97]);}

/* k1358 in k1355 in k1319 in k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
t2=f_772(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 571  transform-direct-lambdas! */
t4=C_retrieve(lf[96]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1364 in k1358 in k1355 in k1319 in k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1369,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 572  end-time */
t3=((C_word*)t0)[2];
f_782(t3,t2,lf[95]);}

/* k1367 in k1364 in k1358 in k1355 in k1319 in k1316 in a1313 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 573  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1274(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1307 in k1298 in k1292 in k1289 in k1286 in k1282 in k1279 in loop in k1267 in k1264 in k1261 in k1255 in k1249 in k1246 in k1243 in k1240 in k1608 in k1231 in k1228 in k1225 in k1222 in k1219 in k1214 in k1211 in k1208 in k1205 in k1202 in k1199 in k1193 in k1190 in k1187 in k1181 in k1178 in k1175 in k1172 in k1169 in k1166 in k1163 in k1160 in k1157 in k1149 in k1146 in k1143 in k1140 in k1136 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
/* batch-driver.scm: 557  perform-high-level-optimizations */
t2=C_retrieve(lf[92]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1118 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 378  display */
t2=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1111 in k1099 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 379  newline */
t2=*((C_word*)lf[76]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1087 in k1078 in k1075 in k1072 in k1069 in k1058 in k1054 in k1050 in k1046 in k1042 in k1038 in k1035 in k1031 in k1028 in k1025 in k1021 in k1017 in k1006 in k1002 in k999 in k996 in k989 in k986 in k983 in k979 in k976 in k970 in k967 in k964 in k961 in k955 in k952 in k949 in k946 in k943 in k940 in k937 in k934 in k931 in k928 in k924 in k921 in k914 in k911 in k908 in k902 in k899 in k896 in k893 in k886 in k882 in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 374  newline */
t2=*((C_word*)lf[76]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_805,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_807,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_830,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no120140 */
t8=t7;
f_835(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf121138 */
t10=t6;
f_830(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body118123 */
t12=t5;
f_807(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[1],t11);}}}}

/* def-no120 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_835,NULL,2,t0,t1);}
/* def-contf121138 */
t2=((C_word*)t0)[2];
f_830(t2,t1,C_fix(0));}

/* def-contf121 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_830(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_830,NULL,3,t0,t1,t2);}
/* body118123 */
t3=((C_word*)t0)[2];
f_807(t3,t1,t2,C_SCHEME_TRUE);}

/* body118 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_807(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_807,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_811,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 205  analyze-expression */
t5=C_retrieve(lf[51]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k809 in body118 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_814,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_819,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_825,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 207  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_814(2,t3,C_SCHEME_UNDEFINED);}}

/* a824 in k809 in body118 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_825,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[50]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a818 in k809 in body118 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_819,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[49]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k812 in k809 in body118 in analyze in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_799(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_799,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 201  ##sys#read */
t3=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_782(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_782,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_540();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 198  printf */
t5=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[47],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static C_word C_fcall f_772(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_540();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_742(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_742,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_748,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_748(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_748(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_748,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 190  option-arg */
f_438(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k760 in loop in collect-options in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_766,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 190  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_748(t4,t2,t3);}

/* k764 in k760 in loop in collect-options in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_766,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_662(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_662,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_672,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 181  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_703,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_711,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 183  substring */
t11=*((C_word*)lf[46]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_727,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 184  substring */
t13=*((C_word*)lf[46]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 185  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k729 in arg-val in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 184  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k725 in arg-val in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_672(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k709 in arg-val in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 183  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k701 in arg-val in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_672(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k670 in arg-val in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 186  quit */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[45],((C_word*)t0)[2]);}}

/* infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_613,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_617,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[44]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_659,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_659 in infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_659,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k615 in infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_620,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_623,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[43],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_623(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_623(t5,C_SCHEME_FALSE);}}

/* k621 in k615 in infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_623,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_634,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 173  ##sys#hash-table-ref */
t6=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[40]),t5);}
else{
t2=((C_word*)t0)[3];
f_620(2,t2,C_SCHEME_UNDEFINED);}}

/* k636 in k621 in k615 in infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 172  alist-cons */
t3=C_retrieve(lf[41]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k632 in k621 in k615 in infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 169  ##sys#hash-table-set! */
t2=C_retrieve(lf[39]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[40]),((C_word*)t0)[2],t1);}

/* k618 in k615 in infohook in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_601,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_608,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 163  print-header */
t6=((C_word*)t0)[2];
f_546(t6,t5,t2,t3);}

/* k606 in print-expr in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[34]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_586,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_593,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 158  print-header */
t7=((C_word*)t0)[2];
f_546(t7,t6,t2,t3);}

/* k591 in print-db in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_593,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 159  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[37],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k594 in k591 in print-db in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 160  display-analysis-database */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_564,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_571,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 152  print-header */
t6=((C_word*)t0)[2];
f_546(t6,t5,t2,t3);}

/* k569 in print-node in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_571,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 154  dump-nodes */
t2=C_retrieve(lf[33]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_584,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 155  build-expression-tree */
t3=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k582 in k569 in print-node in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 155  pretty-print */
t2=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_546(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_546,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_550,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 145  printf */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[32],t2);}
else{
t5=t4;
f_550(2,t5,C_SCHEME_UNDEFINED);}}

/* k548 in print-header in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_550,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[29])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_559,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 148  printf */
t3=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[31],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k557 in k548 in print-header in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k494 in k488 in k485 in k2434 in k469 in compile-source-file in k427 in k424 in k421 */
static C_word C_fcall f_540(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file in k427 in k424 in k421 */
static void C_fcall f_438(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_438,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 96   quit */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[7],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 99   quit */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[8],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[279] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_423batch-driver.scm",(void*)f_423},
{"f_426batch-driver.scm",(void*)f_426},
{"f_429batch-driver.scm",(void*)f_429},
{"f_435batch-driver.scm",(void*)f_435},
{"f_471batch-driver.scm",(void*)f_471},
{"f_2450batch-driver.scm",(void*)f_2450},
{"f_2446batch-driver.scm",(void*)f_2446},
{"f_2438batch-driver.scm",(void*)f_2438},
{"f_2436batch-driver.scm",(void*)f_2436},
{"f_2425batch-driver.scm",(void*)f_2425},
{"f_2403batch-driver.scm",(void*)f_2403},
{"f_487batch-driver.scm",(void*)f_487},
{"f_2397batch-driver.scm",(void*)f_2397},
{"f_2393batch-driver.scm",(void*)f_2393},
{"f_490batch-driver.scm",(void*)f_490},
{"f_496batch-driver.scm",(void*)f_496},
{"f_2374batch-driver.scm",(void*)f_2374},
{"f_2370batch-driver.scm",(void*)f_2370},
{"f_2366batch-driver.scm",(void*)f_2366},
{"f_884batch-driver.scm",(void*)f_884},
{"f_2362batch-driver.scm",(void*)f_2362},
{"f_2340batch-driver.scm",(void*)f_2340},
{"f_2358batch-driver.scm",(void*)f_2358},
{"f_2346batch-driver.scm",(void*)f_2346},
{"f_888batch-driver.scm",(void*)f_888},
{"f_895batch-driver.scm",(void*)f_895},
{"f_898batch-driver.scm",(void*)f_898},
{"f_901batch-driver.scm",(void*)f_901},
{"f_904batch-driver.scm",(void*)f_904},
{"f_910batch-driver.scm",(void*)f_910},
{"f_913batch-driver.scm",(void*)f_913},
{"f_916batch-driver.scm",(void*)f_916},
{"f_923batch-driver.scm",(void*)f_923},
{"f_926batch-driver.scm",(void*)f_926},
{"f_2299batch-driver.scm",(void*)f_2299},
{"f_930batch-driver.scm",(void*)f_930},
{"f_2291batch-driver.scm",(void*)f_2291},
{"f_933batch-driver.scm",(void*)f_933},
{"f_936batch-driver.scm",(void*)f_936},
{"f_939batch-driver.scm",(void*)f_939},
{"f_942batch-driver.scm",(void*)f_942},
{"f_945batch-driver.scm",(void*)f_945},
{"f_948batch-driver.scm",(void*)f_948},
{"f_951batch-driver.scm",(void*)f_951},
{"f_954batch-driver.scm",(void*)f_954},
{"f_957batch-driver.scm",(void*)f_957},
{"f_2238batch-driver.scm",(void*)f_2238},
{"f_2241batch-driver.scm",(void*)f_2241},
{"f_2244batch-driver.scm",(void*)f_2244},
{"f_963batch-driver.scm",(void*)f_963},
{"f_2225batch-driver.scm",(void*)f_2225},
{"f_2228batch-driver.scm",(void*)f_2228},
{"f_966batch-driver.scm",(void*)f_966},
{"f_969batch-driver.scm",(void*)f_969},
{"f_2183batch-driver.scm",(void*)f_2183},
{"f_972batch-driver.scm",(void*)f_972},
{"f_2180batch-driver.scm",(void*)f_2180},
{"f_2176batch-driver.scm",(void*)f_2176},
{"f_978batch-driver.scm",(void*)f_978},
{"f_981batch-driver.scm",(void*)f_981},
{"f_2160batch-driver.scm",(void*)f_2160},
{"f_2152batch-driver.scm",(void*)f_2152},
{"f_2150batch-driver.scm",(void*)f_2150},
{"f_985batch-driver.scm",(void*)f_985},
{"f_988batch-driver.scm",(void*)f_988},
{"f_2142batch-driver.scm",(void*)f_2142},
{"f_2134batch-driver.scm",(void*)f_2134},
{"f_2132batch-driver.scm",(void*)f_2132},
{"f_991batch-driver.scm",(void*)f_991},
{"f_998batch-driver.scm",(void*)f_998},
{"f_2125batch-driver.scm",(void*)f_2125},
{"f_1001batch-driver.scm",(void*)f_1001},
{"f_2114batch-driver.scm",(void*)f_2114},
{"f_2122batch-driver.scm",(void*)f_2122},
{"f_1004batch-driver.scm",(void*)f_1004},
{"f_1008batch-driver.scm",(void*)f_1008},
{"f_1019batch-driver.scm",(void*)f_1019},
{"f_1023batch-driver.scm",(void*)f_1023},
{"f_1027batch-driver.scm",(void*)f_1027},
{"f_2100batch-driver.scm",(void*)f_2100},
{"f_2096batch-driver.scm",(void*)f_2096},
{"f_2084batch-driver.scm",(void*)f_2084},
{"f_1030batch-driver.scm",(void*)f_1030},
{"f_2077batch-driver.scm",(void*)f_2077},
{"f_2069batch-driver.scm",(void*)f_2069},
{"f_2067batch-driver.scm",(void*)f_2067},
{"f_2063batch-driver.scm",(void*)f_2063},
{"f_1033batch-driver.scm",(void*)f_1033},
{"f_2051batch-driver.scm",(void*)f_2051},
{"f_2049batch-driver.scm",(void*)f_2049},
{"f_1037batch-driver.scm",(void*)f_1037},
{"f_1040batch-driver.scm",(void*)f_1040},
{"f_2028batch-driver.scm",(void*)f_2028},
{"f_1044batch-driver.scm",(void*)f_1044},
{"f_2021batch-driver.scm",(void*)f_2021},
{"f_1048batch-driver.scm",(void*)f_1048},
{"f_2014batch-driver.scm",(void*)f_2014},
{"f_1052batch-driver.scm",(void*)f_1052},
{"f_2007batch-driver.scm",(void*)f_2007},
{"f_1056batch-driver.scm",(void*)f_1056},
{"f_1987batch-driver.scm",(void*)f_1987},
{"f_1060batch-driver.scm",(void*)f_1060},
{"f_1071batch-driver.scm",(void*)f_1071},
{"f_1074batch-driver.scm",(void*)f_1074},
{"f_1077batch-driver.scm",(void*)f_1077},
{"f_1940batch-driver.scm",(void*)f_1940},
{"f_1080batch-driver.scm",(void*)f_1080},
{"f_1101batch-driver.scm",(void*)f_1101},
{"f_1132batch-driver.scm",(void*)f_1132},
{"f_1138batch-driver.scm",(void*)f_1138},
{"f_1142batch-driver.scm",(void*)f_1142},
{"f_1145batch-driver.scm",(void*)f_1145},
{"f_1148batch-driver.scm",(void*)f_1148},
{"f_1151batch-driver.scm",(void*)f_1151},
{"f_1159batch-driver.scm",(void*)f_1159},
{"f_1162batch-driver.scm",(void*)f_1162},
{"f_1165batch-driver.scm",(void*)f_1165},
{"f_1906batch-driver.scm",(void*)f_1906},
{"f_1914batch-driver.scm",(void*)f_1914},
{"f_1168batch-driver.scm",(void*)f_1168},
{"f_1171batch-driver.scm",(void*)f_1171},
{"f_1815batch-driver.scm",(void*)f_1815},
{"f_1844batch-driver.scm",(void*)f_1844},
{"f_1896batch-driver.scm",(void*)f_1896},
{"f_1864batch-driver.scm",(void*)f_1864},
{"f_1868batch-driver.scm",(void*)f_1868},
{"f_1873batch-driver.scm",(void*)f_1873},
{"f_1894batch-driver.scm",(void*)f_1894},
{"f_1856batch-driver.scm",(void*)f_1856},
{"f_1847batch-driver.scm",(void*)f_1847},
{"f_1830batch-driver.scm",(void*)f_1830},
{"f_1834batch-driver.scm",(void*)f_1834},
{"f_1838batch-driver.scm",(void*)f_1838},
{"f_1826batch-driver.scm",(void*)f_1826},
{"f_1803batch-driver.scm",(void*)f_1803},
{"f_1807batch-driver.scm",(void*)f_1807},
{"f_1174batch-driver.scm",(void*)f_1174},
{"f_1177batch-driver.scm",(void*)f_1177},
{"f_1793batch-driver.scm",(void*)f_1793},
{"f_1797batch-driver.scm",(void*)f_1797},
{"f_1180batch-driver.scm",(void*)f_1180},
{"f_1183batch-driver.scm",(void*)f_1183},
{"f_1778batch-driver.scm",(void*)f_1778},
{"f_1189batch-driver.scm",(void*)f_1189},
{"f_1771batch-driver.scm",(void*)f_1771},
{"f_1192batch-driver.scm",(void*)f_1192},
{"f_1195batch-driver.scm",(void*)f_1195},
{"f_1751batch-driver.scm",(void*)f_1751},
{"f_1673batch-driver.scm",(void*)f_1673},
{"f_1745batch-driver.scm",(void*)f_1745},
{"f_1677batch-driver.scm",(void*)f_1677},
{"f_1681batch-driver.scm",(void*)f_1681},
{"f_1700batch-driver.scm",(void*)f_1700},
{"f_1685batch-driver.scm",(void*)f_1685},
{"f_1201batch-driver.scm",(void*)f_1201},
{"f_1666batch-driver.scm",(void*)f_1666},
{"f_1204batch-driver.scm",(void*)f_1204},
{"f_1660batch-driver.scm",(void*)f_1660},
{"f_1207batch-driver.scm",(void*)f_1207},
{"f_1210batch-driver.scm",(void*)f_1210},
{"f_1213batch-driver.scm",(void*)f_1213},
{"f_1639batch-driver.scm",(void*)f_1639},
{"f_1216batch-driver.scm",(void*)f_1216},
{"f_1221batch-driver.scm",(void*)f_1221},
{"f_1224batch-driver.scm",(void*)f_1224},
{"f_1227batch-driver.scm",(void*)f_1227},
{"f_1230batch-driver.scm",(void*)f_1230},
{"f_1617batch-driver.scm",(void*)f_1617},
{"f_1624batch-driver.scm",(void*)f_1624},
{"f_1233batch-driver.scm",(void*)f_1233},
{"f_1614batch-driver.scm",(void*)f_1614},
{"f_1610batch-driver.scm",(void*)f_1610},
{"f_1242batch-driver.scm",(void*)f_1242},
{"f_1599batch-driver.scm",(void*)f_1599},
{"f_1606batch-driver.scm",(void*)f_1606},
{"f_1245batch-driver.scm",(void*)f_1245},
{"f_1567batch-driver.scm",(void*)f_1567},
{"f_1574batch-driver.scm",(void*)f_1574},
{"f_1577batch-driver.scm",(void*)f_1577},
{"f_1580batch-driver.scm",(void*)f_1580},
{"f_1586batch-driver.scm",(void*)f_1586},
{"f_1589batch-driver.scm",(void*)f_1589},
{"f_1592batch-driver.scm",(void*)f_1592},
{"f_1248batch-driver.scm",(void*)f_1248},
{"f_1545batch-driver.scm",(void*)f_1545},
{"f_1548batch-driver.scm",(void*)f_1548},
{"f_1551batch-driver.scm",(void*)f_1551},
{"f_1557batch-driver.scm",(void*)f_1557},
{"f_1560batch-driver.scm",(void*)f_1560},
{"f_1563batch-driver.scm",(void*)f_1563},
{"f_1251batch-driver.scm",(void*)f_1251},
{"f_1257batch-driver.scm",(void*)f_1257},
{"f_1263batch-driver.scm",(void*)f_1263},
{"f_1266batch-driver.scm",(void*)f_1266},
{"f_1269batch-driver.scm",(void*)f_1269},
{"f_1274batch-driver.scm",(void*)f_1274},
{"f_1281batch-driver.scm",(void*)f_1281},
{"f_1512batch-driver.scm",(void*)f_1512},
{"f_1515batch-driver.scm",(void*)f_1515},
{"f_1284batch-driver.scm",(void*)f_1284},
{"f_1288batch-driver.scm",(void*)f_1288},
{"f_1291batch-driver.scm",(void*)f_1291},
{"f_1294batch-driver.scm",(void*)f_1294},
{"f_1386batch-driver.scm",(void*)f_1386},
{"f_1392batch-driver.scm",(void*)f_1392},
{"f_1395batch-driver.scm",(void*)f_1395},
{"f_1398batch-driver.scm",(void*)f_1398},
{"f_1489batch-driver.scm",(void*)f_1489},
{"f_1401batch-driver.scm",(void*)f_1401},
{"f_1404batch-driver.scm",(void*)f_1404},
{"f_1407batch-driver.scm",(void*)f_1407},
{"f_1410batch-driver.scm",(void*)f_1410},
{"f_1424batch-driver.scm",(void*)f_1424},
{"f_1428batch-driver.scm",(void*)f_1428},
{"f_1434batch-driver.scm",(void*)f_1434},
{"f_1437batch-driver.scm",(void*)f_1437},
{"f_1440batch-driver.scm",(void*)f_1440},
{"f_1443batch-driver.scm",(void*)f_1443},
{"f_1446batch-driver.scm",(void*)f_1446},
{"f_1468batch-driver.scm",(void*)f_1468},
{"f_1449batch-driver.scm",(void*)f_1449},
{"f_1452batch-driver.scm",(void*)f_1452},
{"f_1418batch-driver.scm",(void*)f_1418},
{"f_1300batch-driver.scm",(void*)f_1300},
{"f_1314batch-driver.scm",(void*)f_1314},
{"f_1318batch-driver.scm",(void*)f_1318},
{"f_1321batch-driver.scm",(void*)f_1321},
{"f_1340batch-driver.scm",(void*)f_1340},
{"f_1357batch-driver.scm",(void*)f_1357},
{"f_1360batch-driver.scm",(void*)f_1360},
{"f_1366batch-driver.scm",(void*)f_1366},
{"f_1369batch-driver.scm",(void*)f_1369},
{"f_1308batch-driver.scm",(void*)f_1308},
{"f_1120batch-driver.scm",(void*)f_1120},
{"f_1113batch-driver.scm",(void*)f_1113},
{"f_1089batch-driver.scm",(void*)f_1089},
{"f_805batch-driver.scm",(void*)f_805},
{"f_835batch-driver.scm",(void*)f_835},
{"f_830batch-driver.scm",(void*)f_830},
{"f_807batch-driver.scm",(void*)f_807},
{"f_811batch-driver.scm",(void*)f_811},
{"f_825batch-driver.scm",(void*)f_825},
{"f_819batch-driver.scm",(void*)f_819},
{"f_814batch-driver.scm",(void*)f_814},
{"f_799batch-driver.scm",(void*)f_799},
{"f_782batch-driver.scm",(void*)f_782},
{"f_772batch-driver.scm",(void*)f_772},
{"f_742batch-driver.scm",(void*)f_742},
{"f_748batch-driver.scm",(void*)f_748},
{"f_762batch-driver.scm",(void*)f_762},
{"f_766batch-driver.scm",(void*)f_766},
{"f_662batch-driver.scm",(void*)f_662},
{"f_731batch-driver.scm",(void*)f_731},
{"f_727batch-driver.scm",(void*)f_727},
{"f_711batch-driver.scm",(void*)f_711},
{"f_703batch-driver.scm",(void*)f_703},
{"f_672batch-driver.scm",(void*)f_672},
{"f_613batch-driver.scm",(void*)f_613},
{"f_659batch-driver.scm",(void*)f_659},
{"f_617batch-driver.scm",(void*)f_617},
{"f_623batch-driver.scm",(void*)f_623},
{"f_638batch-driver.scm",(void*)f_638},
{"f_634batch-driver.scm",(void*)f_634},
{"f_620batch-driver.scm",(void*)f_620},
{"f_601batch-driver.scm",(void*)f_601},
{"f_608batch-driver.scm",(void*)f_608},
{"f_586batch-driver.scm",(void*)f_586},
{"f_593batch-driver.scm",(void*)f_593},
{"f_596batch-driver.scm",(void*)f_596},
{"f_564batch-driver.scm",(void*)f_564},
{"f_571batch-driver.scm",(void*)f_571},
{"f_584batch-driver.scm",(void*)f_584},
{"f_546batch-driver.scm",(void*)f_546},
{"f_550batch-driver.scm",(void*)f_550},
{"f_559batch-driver.scm",(void*)f_559},
{"f_540batch-driver.scm",(void*)f_540},
{"f_438batch-driver.scm",(void*)f_438},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
