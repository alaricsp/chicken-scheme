/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-29 16:41
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[357];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_fcall f_3260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_fcall f_1137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1525)
static void C_fcall f_1525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_fcall f_1528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_fcall f_1558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_fcall f_1564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_fcall f_1571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_fcall f_1574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_fcall f_1577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_fcall f_1580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_fcall f_1583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_fcall f_1586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_fcall f_1589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_fcall f_1595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_fcall f_1607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_fcall f_1632(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_fcall f_1667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_fcall f_1698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_fcall f_1732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_fcall f_1759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_fcall f_2598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_fcall f_2653(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_fcall f_1847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_fcall f_2396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_fcall f_1909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_fcall f_1912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_fcall f_1935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_fcall f_2147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_ccall f_1677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1476)
static void C_fcall f_1476(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_fcall f_1471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1448)
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_fcall f_1440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1423)
static void C_fcall f_1423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1413)
static C_word C_fcall f_1413(C_word t0);
C_noret_decl(f_1383)
static void C_fcall f_1383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1389)
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_fcall f_1303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_fcall f_1264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_fcall f_1242(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_fcall f_1227(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_fcall f_1187(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_fcall f_1079(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3260)
static void C_fcall trf_3260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3260(t0,t1);}

C_noret_decl(trf_1137)
static void C_fcall trf_1137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1137(t0,t1);}

C_noret_decl(trf_1525)
static void C_fcall trf_1525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1525(t0,t1);}

C_noret_decl(trf_1528)
static void C_fcall trf_1528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1528(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1549)
static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1549(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1555(t0,t1);}

C_noret_decl(trf_1558)
static void C_fcall trf_1558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1558(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1564)
static void C_fcall trf_1564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1564(t0,t1);}

C_noret_decl(trf_1571)
static void C_fcall trf_1571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1571(t0,t1);}

C_noret_decl(trf_1574)
static void C_fcall trf_1574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1574(t0,t1);}

C_noret_decl(trf_1577)
static void C_fcall trf_1577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1577(t0,t1);}

C_noret_decl(trf_1580)
static void C_fcall trf_1580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1580(t0,t1);}

C_noret_decl(trf_1583)
static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1583(t0,t1);}

C_noret_decl(trf_1586)
static void C_fcall trf_1586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1586(t0,t1);}

C_noret_decl(trf_1589)
static void C_fcall trf_1589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1589(t0,t1);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1592(t0,t1);}

C_noret_decl(trf_1595)
static void C_fcall trf_1595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1595(t0,t1);}

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1601(t0,t1);}

C_noret_decl(trf_1607)
static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1607(t0,t1);}

C_noret_decl(trf_1632)
static void C_fcall trf_1632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1632(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1632(t0,t1);}

C_noret_decl(trf_1667)
static void C_fcall trf_1667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1667(t0,t1);}

C_noret_decl(trf_1698)
static void C_fcall trf_1698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1698(t0,t1);}

C_noret_decl(trf_1732)
static void C_fcall trf_1732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1732(t0,t1);}

C_noret_decl(trf_1759)
static void C_fcall trf_1759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1759(t0,t1);}

C_noret_decl(trf_2598)
static void C_fcall trf_2598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2598(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2598(t0,t1,t2);}

C_noret_decl(trf_2653)
static void C_fcall trf_2653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2653(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2653(t0,t1,t2);}

C_noret_decl(trf_1838)
static void C_fcall trf_1838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1838(t0,t1);}

C_noret_decl(trf_1847)
static void C_fcall trf_1847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1847(t0,t1);}

C_noret_decl(trf_2396)
static void C_fcall trf_2396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2396(t0,t1);}

C_noret_decl(trf_1909)
static void C_fcall trf_1909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1909(t0,t1);}

C_noret_decl(trf_1912)
static void C_fcall trf_1912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1912(t0,t1);}

C_noret_decl(trf_1935)
static void C_fcall trf_1935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1935(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1935(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2147)
static void C_fcall trf_2147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2147(t0,t1);}

C_noret_decl(trf_1669)
static void C_fcall trf_1669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1669(t0,t1,t2);}

C_noret_decl(trf_1446)
static void C_fcall trf_1446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1446(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1446(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1476)
static void C_fcall trf_1476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1476(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1476(t0,t1);}

C_noret_decl(trf_1471)
static void C_fcall trf_1471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1471(t0,t1,t2);}

C_noret_decl(trf_1448)
static void C_fcall trf_1448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1448(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1448(t0,t1,t2,t3);}

C_noret_decl(trf_1440)
static void C_fcall trf_1440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1440(t0,t1,t2);}

C_noret_decl(trf_1423)
static void C_fcall trf_1423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1423(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1423(t0,t1,t2);}

C_noret_decl(trf_1383)
static void C_fcall trf_1383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1383(t0,t1,t2);}

C_noret_decl(trf_1389)
static void C_fcall trf_1389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1389(t0,t1,t2);}

C_noret_decl(trf_1303)
static void C_fcall trf_1303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1303(t0,t1);}

C_noret_decl(trf_1264)
static void C_fcall trf_1264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1264(t0,t1);}

C_noret_decl(trf_1242)
static void C_fcall trf_1242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1242(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1242(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1227)
static void C_fcall trf_1227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1227(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1227(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1205(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1187)
static void C_fcall trf_1187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1187(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1187(t0,t1,t2,t3);}

C_noret_decl(trf_1079)
static void C_fcall trf_1079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1079(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2730)){
C_save(t1);
C_rereclaim2(2730*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,357);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],11,"user-pass-2");
lf[5]=C_h_intern(&lf[5],23,"user-post-analysis-pass");
lf[6]=C_h_intern(&lf[6],19,"compile-source-file");
lf[7]=C_h_intern(&lf[7],4,"quit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],26,"\010compilerexplicit-use-flag");
lf[12]=C_h_intern(&lf[12],12,"\004coredeclare");
lf[13]=C_h_intern(&lf[13],7,"verbose");
lf[14]=C_h_intern(&lf[14],11,"output-file");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[20]=C_h_intern(&lf[20],9,"heap-size");
lf[21]=C_h_intern(&lf[21],17,"heap-initial-size");
lf[22]=C_h_intern(&lf[22],11,"heap-growth");
lf[23]=C_h_intern(&lf[23],14,"heap-shrinkage");
lf[24]=C_h_intern(&lf[24],13,"keyword-style");
lf[25]=C_h_intern(&lf[25],4,"unit");
lf[26]=C_h_intern(&lf[26],12,"analyze-only");
lf[27]=C_h_intern(&lf[27],7,"dynamic");
lf[28]=C_h_intern(&lf[28],5,"quiet");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],10,"stack-size");
lf[31]=C_h_intern(&lf[31],26,"\010compilerdebugging-chicken");
lf[32]=C_h_intern(&lf[32],6,"printf");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[35]=C_h_intern(&lf[35],19,"\010compilerdump-nodes");
lf[36]=C_h_intern(&lf[36],12,"pretty-print");
lf[37]=C_h_intern(&lf[37],30,"\010compilerbuild-expression-tree");
lf[38]=C_h_intern(&lf[38],34,"\010compilerdisplay-analysis-database");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[40]=C_h_intern(&lf[40],12,"\003sysfor-each");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_h_intern(&lf[42],24,"\003sysline-number-database");
lf[43]=C_h_intern(&lf[43],10,"alist-cons");
lf[44]=C_h_intern(&lf[44],18,"\003syshash-table-ref");
lf[45]=C_h_intern(&lf[45],9,"list-info");
lf[46]=C_h_intern(&lf[46],26,"\003sysdefault-read-info-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[50]=C_h_intern(&lf[50],8,"\003sysread");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],21,"\003sysalias-global-hook");
lf[67]=C_h_intern(&lf[67],10,"\000compiling");
lf[68]=C_h_intern(&lf[68],15,"lset-difference");
lf[69]=C_h_intern(&lf[69],3,"eq\077");
lf[70]=C_h_intern(&lf[70],7,"\003sysmap");
lf[71]=C_h_intern(&lf[71],14,"string->symbol");
lf[72]=C_h_intern(&lf[72],12,"string-split");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[74]=C_h_intern(&lf[74],10,"append-map");
lf[75]=C_h_intern(&lf[75],25,"\010compilertarget-heap-size");
lf[76]=C_h_intern(&lf[76],33,"\010compilertarget-initial-heap-size");
lf[77]=C_h_intern(&lf[77],27,"\010compilertarget-heap-growth");
lf[78]=C_h_intern(&lf[78],30,"\010compilertarget-heap-shrinkage");
lf[79]=C_h_intern(&lf[79],26,"\010compilertarget-stack-size");
lf[80]=C_h_intern(&lf[80],8,"no-trace");
lf[81]=C_h_intern(&lf[81],24,"\010compileremit-trace-info");
lf[82]=C_h_intern(&lf[82],29,"disable-stack-overflow-checks");
lf[83]=C_h_intern(&lf[83],40,"\010compilerdisable-stack-overflow-checking");
lf[84]=C_h_intern(&lf[84],7,"version");
lf[85]=C_h_intern(&lf[85],7,"newline");
lf[86]=C_h_intern(&lf[86],22,"\010compilerprint-version");
lf[87]=C_h_intern(&lf[87],4,"help");
lf[88]=C_h_intern(&lf[88],20,"\010compilerprint-usage");
lf[89]=C_h_intern(&lf[89],7,"release");
lf[90]=C_h_intern(&lf[90],7,"display");
lf[91]=C_h_intern(&lf[91],15,"chicken-version");
lf[92]=C_h_intern(&lf[92],24,"\010compilersource-filename");
lf[93]=C_h_intern(&lf[93],28,"\010compilerprofile-lambda-list");
lf[94]=C_h_intern(&lf[94],31,"\010compilerline-number-database-2");
lf[95]=C_h_intern(&lf[95],23,"\010compilerconstant-table");
lf[96]=C_h_intern(&lf[96],21,"\010compilerinline-table");
lf[97]=C_h_intern(&lf[97],23,"\010compilerfirst-analysis");
lf[98]=C_h_intern(&lf[98],41,"\010compilerperform-high-level-optimizations");
lf[99]=C_h_intern(&lf[99],37,"\010compilerinline-substitutions-enabled");
lf[100]=C_h_intern(&lf[100],22,"optimize-leaf-routines");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[102]=C_h_intern(&lf[102],34,"\010compilertransform-direct-lambdas!");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[104]=C_h_intern(&lf[104],4,"leaf");
lf[105]=C_h_intern(&lf[105],18,"\010compilerdebugging");
lf[106]=C_h_intern(&lf[106],1,"p");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[109]=C_h_intern(&lf[109],1,"5");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[112]=C_h_intern(&lf[112],36,"\010compilerprepare-for-code-generation");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[114]=C_h_intern(&lf[114],30,"\010compilercompiler-cleanup-hook");
lf[115]=C_h_intern(&lf[115],1,"t");
lf[116]=C_h_intern(&lf[116],17,"\003sysdisplay-times");
lf[117]=C_h_intern(&lf[117],14,"\003sysstop-timer");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[119]=C_h_intern(&lf[119],17,"close-output-port");
lf[120]=C_h_intern(&lf[120],22,"\010compilergenerate-code");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[122]=C_h_intern(&lf[122],16,"open-output-file");
lf[123]=C_h_intern(&lf[123],19,"current-output-port");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[126]=C_h_intern(&lf[126],1,"9");
lf[127]=C_h_intern(&lf[127],4,"exit");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[129]=C_h_intern(&lf[129],20,"\003syswarnings-enabled");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[131]=C_h_intern(&lf[131],1,"8");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[133]=C_h_intern(&lf[133],35,"\010compilerperform-closure-conversion");
lf[134]=C_h_intern(&lf[134],27,"\010compilerinline-output-file");
lf[135]=C_h_intern(&lf[135],32,"\010compileremit-global-inline-file");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000(Generating global inline file `~a\047 ...~%");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[138]=C_h_intern(&lf[138],1,"7");
lf[139]=C_h_intern(&lf[139],1,"s");
lf[140]=C_h_intern(&lf[140],33,"\010compilerprint-program-statistics");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[142]=C_h_intern(&lf[142],1,"4");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[144]=C_h_intern(&lf[144],1,"u");
lf[145]=C_h_intern(&lf[145],31,"\010compilerdump-undefined-globals");
lf[146]=C_h_intern(&lf[146],3,"opt");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[148]=C_h_intern(&lf[148],1,"3");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[150]=C_h_intern(&lf[150],31,"\010compilerperform-cps-conversion");
lf[151]=C_h_intern(&lf[151],6,"unsafe");
lf[152]=C_h_intern(&lf[152],34,"\010compilerscan-toplevel-assignments");
lf[153]=C_h_intern(&lf[153],26,"\010compilerdo-lambda-lifting");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[155]=C_h_intern(&lf[155],1,"L");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[157]=C_h_intern(&lf[157],32,"\010compilerperform-lambda-lifting!");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[160]=C_h_intern(&lf[160],1,"0");
lf[161]=C_h_intern(&lf[161],4,"lift");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[163]=C_h_intern(&lf[163],1,"U");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[167]=C_h_intern(&lf[167],4,"user");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[169]=C_h_intern(&lf[169],4,"node");
lf[170]=C_h_intern(&lf[170],6,"lambda");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[172]=C_h_intern(&lf[172],25,"\010compilerbuild-node-graph");
lf[173]=C_h_intern(&lf[173],32,"\010compilercanonicalize-begin-body");
lf[174]=C_h_intern(&lf[174],24,"\010compilerinline-globally");
lf[175]=C_h_intern(&lf[175],25,"\010compilerload-inline-file");
lf[176]=C_h_intern(&lf[176],5,"print");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\024Loading inline file ");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[179]=C_h_intern(&lf[179],12,"file-exists\077");
lf[180]=C_h_intern(&lf[180],28,"\003sysresolve-include-filename");
lf[181]=C_h_intern(&lf[181],13,"make-pathname");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[183]=C_h_intern(&lf[183],14,"symbol->string");
lf[184]=C_h_intern(&lf[184],11,"concatenate");
lf[185]=C_h_intern(&lf[185],3,"cdr");
lf[186]=C_h_intern(&lf[186],2,"pp");
lf[187]=C_h_intern(&lf[187],1,"M");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[189]=C_h_intern(&lf[189],12,"vector->list");
lf[190]=C_h_intern(&lf[190],26,"\010compilerfile-requirements");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[193]=C_h_intern(&lf[193],12,"check-syntax");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[195]=C_h_intern(&lf[195],1,"2");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[197]=C_h_intern(&lf[197],25,"\010compilercompiler-warning");
lf[198]=C_h_intern(&lf[198],5,"style");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[200]=C_h_intern(&lf[200],8,"feature\077");
lf[201]=C_h_intern(&lf[201],19,"compiling-extension");
lf[202]=C_h_intern(&lf[202],18,"\010compilerunit-name");
lf[203]=C_h_intern(&lf[203],5,"usage");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[205]=C_h_intern(&lf[205],26,"\010compilerblock-compilation");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[207]=C_h_intern(&lf[207],37,"\010compilerdisplay-line-number-database");
lf[208]=C_h_intern(&lf[208],1,"n");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[210]=C_h_intern(&lf[210],32,"\010compilerdisplay-real-name-table");
lf[211]=C_h_intern(&lf[211],1,"N");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[213]=C_h_intern(&lf[213],6,"append");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[215]=C_h_intern(&lf[215],5,"quote");
lf[216]=C_h_intern(&lf[216],33,"\010compilerprofile-info-vector-name");
lf[217]=C_h_intern(&lf[217],28,"\003sysset-profile-info-vector!");
lf[218]=C_h_intern(&lf[218],21,"\010compileremit-profile");
lf[219]=C_h_intern(&lf[219],25,"\003sysregister-profile-info");
lf[220]=C_h_intern(&lf[220],4,"set!");
lf[221]=C_h_intern(&lf[221],13,"\004corecallunit");
lf[222]=C_h_intern(&lf[222],19,"\010compilerused-units");
lf[223]=C_h_intern(&lf[223],28,"\010compilerimmutable-constants");
lf[224]=C_h_intern(&lf[224],6,"gensym");
lf[225]=C_h_intern(&lf[225],32,"\010compilercanonicalize-expression");
lf[226]=C_h_intern(&lf[226],28,"\003sysexplicit-library-modules");
lf[227]=C_h_intern(&lf[227],4,"uses");
lf[228]=C_h_intern(&lf[228],7,"declare");
lf[229]=C_h_intern(&lf[229],10,"\003sysappend");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[231]=C_h_intern(&lf[231],1,"1");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[234]=C_h_intern(&lf[234],21,"\010compilerstring->expr");
lf[235]=C_h_intern(&lf[235],7,"reverse");
lf[236]=C_h_intern(&lf[236],27,"\003syscurrent-source-filename");
lf[237]=C_h_intern(&lf[237],33,"\010compilerclose-checked-input-file");
lf[238]=C_h_intern(&lf[238],16,"\003sysdynamic-wind");
lf[239]=C_h_intern(&lf[239],34,"\010compilercheck-and-open-input-file");
lf[240]=C_h_intern(&lf[240],8,"epilogue");
lf[241]=C_h_intern(&lf[241],8,"prologue");
lf[242]=C_h_intern(&lf[242],8,"postlude");
lf[243]=C_h_intern(&lf[243],7,"prelude");
lf[244]=C_h_intern(&lf[244],11,"make-vector");
lf[245]=C_h_intern(&lf[245],34,"\010compilerline-number-database-size");
lf[246]=C_h_intern(&lf[246],1,"r");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[253]=C_h_intern(&lf[253],5,"-help");
lf[254]=C_h_intern(&lf[254],1,"h");
lf[255]=C_h_intern(&lf[255],2,"-h");
lf[256]=C_h_intern(&lf[256],18,"accumulate-profile");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[261]=C_h_intern(&lf[261],39,"\010compilerdefault-profiling-declarations");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[265]=C_h_intern(&lf[265],21,"no-usual-integrations");
lf[266]=C_h_intern(&lf[266],17,"standard-bindings");
lf[267]=C_h_intern(&lf[267],34,"\010compilerdefault-standard-bindings");
lf[268]=C_h_intern(&lf[268],17,"extended-bindings");
lf[269]=C_h_intern(&lf[269],34,"\010compilerdefault-extended-bindings");
lf[270]=C_h_intern(&lf[270],1,"m");
lf[271]=C_h_intern(&lf[271],14,"set-gc-report!");
lf[272]=C_h_intern(&lf[272],42,"\010compilerdefault-default-target-stack-size");
lf[273]=C_h_intern(&lf[273],41,"\010compilerdefault-default-target-heap-size");
lf[274]=C_h_intern(&lf[274],14,"compile-syntax");
lf[275]=C_h_intern(&lf[275],25,"\003sysenable-runtime-macros");
lf[276]=C_h_intern(&lf[276],22,"\004corerequire-extension");
lf[277]=C_h_intern(&lf[277],17,"require-extension");
lf[278]=C_h_intern(&lf[278],9,"extension");
lf[279]=C_h_intern(&lf[279],16,"define-extension");
lf[280]=C_h_intern(&lf[280],13,"pathname-file");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[282]=C_h_intern(&lf[282],28,"\010compilerpostponed-initforms");
lf[283]=C_h_intern(&lf[283],6,"delete");
lf[284]=C_h_intern(&lf[284],4,"load");
lf[285]=C_h_intern(&lf[285],12,"load-verbose");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[287]=C_h_intern(&lf[287],6,"extend");
lf[288]=C_h_intern(&lf[288],17,"register-feature!");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[290]=C_h_intern(&lf[290],7,"feature");
lf[291]=C_h_intern(&lf[291],20,"keep-shadowed-macros");
lf[292]=C_h_intern(&lf[292],33,"\010compilerundefine-shadowed-macros");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[295]=C_h_intern(&lf[295],23,"\010compilerchop-separator");
lf[296]=C_h_intern(&lf[296],12,"include-path");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[298]=C_h_intern(&lf[298],7,"\000prefix");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[300]=C_h_intern(&lf[300],5,"\000none");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[302]=C_h_intern(&lf[302],7,"\000suffix");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[304]=C_h_intern(&lf[304],17,"compress-literals");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[306]=C_h_intern(&lf[306],16,"case-insensitive");
lf[307]=C_h_intern(&lf[307],14,"case-sensitive");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[309]=C_h_intern(&lf[309],24,"\010compilerinline-max-size");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[311]=C_h_intern(&lf[311],23,"\010compilerinline-locally");
lf[312]=C_h_intern(&lf[312],26,"\010compilerlocal-definitions");
lf[313]=C_h_intern(&lf[313],6,"inline");
lf[314]=C_h_intern(&lf[314],30,"emit-external-prototypes-first");
lf[315]=C_h_intern(&lf[315],30,"\010compilerexternal-protos-first");
lf[316]=C_h_intern(&lf[316],5,"block");
lf[317]=C_h_intern(&lf[317],17,"fixnum-arithmetic");
lf[318]=C_h_intern(&lf[318],11,"number-type");
lf[319]=C_h_intern(&lf[319],6,"fixnum");
lf[320]=C_h_intern(&lf[320],18,"disable-interrupts");
lf[321]=C_h_intern(&lf[321],28,"\010compilerinsert-timer-checks");
lf[322]=C_h_intern(&lf[322],16,"unsafe-libraries");
lf[323]=C_h_intern(&lf[323],27,"\010compileremit-unsafe-marker");
lf[324]=C_h_intern(&lf[324],11,"no-warnings");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[326]=C_h_intern(&lf[326],15,"disable-warning");
lf[327]=C_h_intern(&lf[327],13,"inline-global");
lf[328]=C_h_intern(&lf[328],5,"local");
lf[329]=C_h_intern(&lf[329],14,"no-lambda-info");
lf[330]=C_h_intern(&lf[330],26,"\010compileremit-closure-info");
lf[331]=C_h_intern(&lf[331],3,"raw");
lf[332]=C_h_intern(&lf[332],12,"emit-exports");
lf[333]=C_h_intern(&lf[333],7,"warning");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[335]=C_h_intern(&lf[335],1,"b");
lf[336]=C_h_intern(&lf[336],15,"\003sysstart-timer");
lf[337]=C_h_intern(&lf[337],11,"lambda-lift");
lf[338]=C_h_intern(&lf[338],13,"string-append");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[340]=C_h_intern(&lf[340],19,"emit-import-library");
lf[341]=C_h_intern(&lf[341],16,"\003sysstring->list");
lf[342]=C_h_intern(&lf[342],5,"debug");
lf[343]=C_h_intern(&lf[343],30,"\010compilerstandalone-executable");
lf[344]=C_h_intern(&lf[344],29,"\010compilerstring->c-identifier");
lf[345]=C_h_intern(&lf[345],18,"\010compilerstringify");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[348]=C_h_intern(&lf[348],6,"getenv");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[350]=C_h_intern(&lf[350],9,"to-stdout");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[353]=C_h_intern(&lf[353],29,"\010compilerdefault-declarations");
lf[354]=C_h_intern(&lf[354],30,"\010compilerunits-used-by-default");
lf[355]=C_h_intern(&lf[355],28,"\010compilerinitialize-compiler");
lf[356]=C_h_intern(&lf[356],14,"make-parameter");
C_register_lf2(lf,357,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1032 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1035 in k1032 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1038 in k1035 in k1032 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 81   make-parameter */
t3=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_FALSE);}

/* k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
t4=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
t4=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
t4=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1066,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
t4=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1074,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 86   make-parameter */
t4=C_retrieve(lf[356]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1076,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1076r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1076r(t0,t1,t2,t3);}}

static void C_ccall f_1076r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1079,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1112,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 99   initialize-compiler */
t6=C_retrieve(lf[355]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=(C_word)C_i_memq(lf[10],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[11]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[11]))){
t7=t6;
f_3260(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3271,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[354]),C_SCHEME_END_OF_LIST);}}

/* k3269 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[227],t1);
t3=((C_word*)t0)[2];
f_3260(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3258 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_3260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 102  append */
t2=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[353]),t1);}

/* k3254 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 110  option-arg */
f_1079(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[350],((C_word*)t0)[5]))){
t9=t8;
f_1128(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 115  pathname-file */
t10=C_retrieve(lf[280]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3241(2,t10,lf[352]);}}}}

/* k3239 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 115  make-pathname */
t2=C_retrieve(lf[181]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[351]);}

/* k3217 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 112  symbol->string */
t2=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1128(2,t2,t1);}}

/* k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1131,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 116  getenv */
t5=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[349]);}

/* k3211 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[346]);
/* batch-driver.scm: 116  string-split */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[347]);}

/* k3207 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[295]),t1);}

/* k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=C_retrieve(lf[15]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[16];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[17],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1137,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1137(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[256],((C_word*)t0)[8]);
t14=t12;
f_1137(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[18],((C_word*)t0)[8])));}}

/* k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[89],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1137,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[19]);
t5=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[30],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1205,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1227,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1254,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1303,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t23,a[12]=t1,a[13]=t33,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t27,a[18]=t26,a[19]=t13,a[20]=t17,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t25,a[24]=t34,a[25]=t32,a[26]=t31,a[27]=t19,a[28]=((C_word*)t0)[6],a[29]=((C_word*)t0)[7],a[30]=t30,a[31]=((C_word*)t0)[8],a[32]=t21,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3182,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 211  option-arg */
f_1079(t38,t12);}
else{
t36=t35;
f_1525(t36,C_SCHEME_UNDEFINED);}}

/* k3188 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 211  stringify */
t2=C_retrieve(lf[345]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3184 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 211  string->c-identifier */
t2=C_retrieve(lf[344]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3180 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[202]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1525(t3,t2);}

/* k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1525,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[202]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[343] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1528(t6,t5);}
else{
t5=t2;
f_1528(t5,C_SCHEME_UNDEFINED);}}

/* k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1528,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3152,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3174,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 219  collect-options */
t5=((C_word*)t0)[30];
f_1383(t5,t4,lf[342]);}

/* k3172 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 215  append-map */
t2=C_retrieve(lf[74]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3151 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3158,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3170,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[341]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3168 in a3151 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3157 in a3151 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3158,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 217  string->symbol */
t4=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1532,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[31]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3134,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3150,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 225  collect-options */
t8=((C_word*)t0)[30];
f_1383(t8,t7,lf[340]);}

/* k3148 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3133 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3134,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3142,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 223  string->symbol */
t4=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3140 in a3133 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 224  string-append */
t3=*((C_word*)lf[338]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[339]);}

/* k3144 in k3140 in a3133 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[337],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[153] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1543(t5,t4);}
else{
t4=t3;
f_1543(t4,C_SCHEME_UNDEFINED);}}

/* k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[115],C_retrieve(lf[31])))){
/* batch-driver.scm: 227  ##sys#start-timer */
t3=*((C_word*)lf[336]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1546(2,t3,C_SCHEME_UNDEFINED);}}

/* k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[335],C_retrieve(lf[31])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1549(t4,t3);}
else{
t3=t2;
f_1549(t3,C_SCHEME_UNDEFINED);}}

/* k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[332],((C_word*)t0)[34]))){
/* batch-driver.scm: 230  warning */
t3=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[334]);}
else{
t3=t2;
f_1552(2,t3,C_SCHEME_UNDEFINED);}}

/* k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[331],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[11] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1555(t6,t5);}
else{
t3=t2;
f_1555(t3,C_SCHEME_UNDEFINED);}}

/* k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[329],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[330] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1558(t4,t3);}
else{
t3=t2;
f_1558(t3,C_SCHEME_UNDEFINED);}}

/* k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[312] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1561(t4,t3);}
else{
t3=t2;
f_1561(t3,C_SCHEME_UNDEFINED);}}

/* k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[327],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[311] /* inline-locally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[174] /* inline-globally */,0,C_SCHEME_TRUE);
t5=t2;
f_1564(t5,t4);}
else{
t3=t2;
f_1564(t3,C_SCHEME_UNDEFINED);}}

/* k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1564,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 242  collect-options */
t4=((C_word*)t0)[29];
f_1383(t4,t3,lf[326]);}

/* k3091 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[71]+1),t1);}

/* k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[324],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3085,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[33])){
/* batch-driver.scm: 244  printf */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[325]);}
else{
t5=t4;
f_3085(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1571(t4,C_SCHEME_UNDEFINED);}}

/* k3083 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[129] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1571(t3,t2);}

/* k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1571,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[100],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[100] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1574(t4,t3);}
else{
t3=t2;
f_1574(t3,C_SCHEME_UNDEFINED);}}

/* k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1574,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[151],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[151] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1577(t4,t3);}
else{
t3=t2;
f_1577(t3,C_SCHEME_UNDEFINED);}}

/* k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1577,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[322],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[323] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1580(t5,t4);}
else{
t4=t2;
f_1580(t4,C_SCHEME_UNDEFINED);}}

/* k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1580,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[320],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[321] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1583(t4,t3);}
else{
t3=t2;
f_1583(t3,C_SCHEME_UNDEFINED);}}

/* k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1583,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[318]+1 /* (set! number-type ...) */,lf[319]);
t4=t2;
f_1586(t4,t3);}
else{
t3=t2;
f_1586(t3,C_SCHEME_UNDEFINED);}}

/* k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1586,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[316],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[205] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1589(t4,t3);}
else{
t3=t2;
f_1589(t3,C_SCHEME_UNDEFINED);}}

/* k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1589,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[314],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[315] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1592(t4,t3);}
else{
t3=t2;
f_1592(t3,C_SCHEME_UNDEFINED);}}

/* k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[313],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[311] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1595(t4,t3);}
else{
t3=t2;
f_1595(t3,C_SCHEME_UNDEFINED);}}

/* k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1595,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[311] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[312] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 260  option-arg */
f_1079(t6,t2);}
else{
t4=t3;
f_1601(t4,C_SCHEME_FALSE);}}

/* k3042 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[134]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1601(t3,t2);}

/* k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1601(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1601,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[34],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3029,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 263  option-arg */
f_1079(t4,t2);}
else{
t4=t3;
f_1607(t4,C_SCHEME_FALSE);}}

/* k3027 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3032,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 264  string->number */
C_string_to_number(3,0,t2,t1);}

/* k3030 in k3027 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3035(2,t3,t1);}
else{
/* batch-driver.scm: 265  quit */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[310],((C_word*)t0)[2]);}}

/* k3033 in k3030 in k3027 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[309]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1607(t3,t2);}

/* k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[306],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 267  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[308]);}
else{
t4=t3;
f_3016(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1610(2,t3,C_SCHEME_UNDEFINED);}}

/* k3014 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 268  register-feature! */
t3=C_retrieve(lf[288]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[306]);}

/* k3017 in k3014 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 269  case-sensitive */
t2=C_retrieve(lf[307]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[304],((C_word*)t0)[29]))){
/* batch-driver.scm: 271  compiler-warning */
t3=C_retrieve(lf[197]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[203],lf[305]);}
else{
t3=t2;
f_1613(2,t3,C_SCHEME_UNDEFINED);}}

/* k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 273  option-arg */
f_1079(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1616(2,t3,C_SCHEME_UNDEFINED);}}

/* k2972 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[297],t1))){
/* batch-driver.scm: 274  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[298]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[299],t1))){
/* batch-driver.scm: 275  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[300]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[301],t1))){
/* batch-driver.scm: 276  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[302]);}
else{
/* batch-driver.scm: 277  quit */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[303]);}}}}

/* k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[33],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2971,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 281  collect-options */
t7=((C_word*)t0)[29];
f_1383(t7,t6,lf[296]);}

/* k2969 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[295]),t1);}

/* k2965 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 281  append */
t2=*((C_word*)lf[213]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[19])?(C_truep(((C_word*)t0)[26])?(C_word)C_i_string_equal_p(((C_word*)t0)[19],((C_word*)t0)[26]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 285  quit */
t5=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[294]);}
else{
t5=t3;
f_1625(2,t5,C_SCHEME_UNDEFINED);}}

/* k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2943,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2951,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 290  collect-options */
t6=((C_word*)t0)[29];
f_1383(t6,t5,lf[227]);}

/* k2949 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 288  append-map */
t2=C_retrieve(lf[74]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2942 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2943,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[293]);}

/* k2939 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[71]+1),t1);}

/* k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[291],((C_word*)t0)[28]))){
t4=C_set_block_item(lf[292] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1632(t5,t4);}
else{
t4=t3;
f_1632(t4,C_SCHEME_UNDEFINED);}}

/* k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1632(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1632,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2923,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2925,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 297  collect-options */
t6=((C_word*)t0)[29];
f_1383(t6,t5,lf[290]);}

/* k2931 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 297  append-map */
t2=C_retrieve(lf[74]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2924 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2925,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[289]);}

/* k2921 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[288]),t1);}

/* k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 301  collect-options */
t5=((C_word*)t0)[29];
f_1383(t5,t4,lf[287]);}

/* k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1645,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[20])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2916,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 303  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[286]);}
else{
t3=t2;
f_1645(2,t3,C_SCHEME_UNDEFINED);}}

/* k2914 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 304  load-verbose */
t2=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=C_retrieve(lf[66]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2910,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2909 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[66]));
t3=C_mutate((C_word*)lf[66]+1 /* (set! alias-global-hook ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2893 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2900,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2899 in a2893 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2908,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 308  ##sys#resolve-include-filename */
t4=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2906 in a2899 in a2893 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 308  load */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a2888 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[66]));
t3=C_mutate((C_word*)lf[66]+1 /* (set! alias-global-hook ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 310  delete */
t3=C_retrieve(lf[283]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[69]+1));}

/* k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[67],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 313  user-post-analysis-pass */
t6=C_retrieve(lf[5]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 316  append */
t4=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[31])[1],C_retrieve(lf[282]));}

/* k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
if(C_truep((C_word)C_i_memq(lf[278],((C_word*)t0)[28]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2855,a[2]=t3,a[3]=((C_word*)t0)[31],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[31],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2875,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[19])){
/* batch-driver.scm: 325  pathname-file */
t7=C_retrieve(lf[280]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[19]);}
else{
if(C_truep(((C_word*)t0)[26])){
/* batch-driver.scm: 326  pathname-file */
t7=C_retrieve(lf[280]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[26]);}
else{
/* batch-driver.scm: 327  quit */
t7=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[281]);}}}
else{
t4=t3;
f_1667(t4,C_SCHEME_UNDEFINED);}}

/* k2873 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 324  string->symbol */
t2=*((C_word*)lf[71]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2869 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[279],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 321  append */
t5=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}

/* k2853 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1667(t3,t2);}

/* k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1667,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[30],a[3]=((C_word*)t0)[31],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[30],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[31],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],tmp=(C_word)a,a+=32,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[29],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2828,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2848,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 343  ids */
t7=t2;
f_1669(t7,t6,lf[277]);}

/* k2846 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2827 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2828,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[276],t5));}

/* k2824 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 340  append */
t2=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[31],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
if(C_truep((C_word)C_i_memq(lf[274],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[275] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1698(t5,t4);}
else{
t4=t3;
f_1698(t4,C_SCHEME_UNDEFINED);}}

/* k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1698,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2805,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 349  option-arg */
f_1079(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[273]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1702(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1702(2,t4,C_SCHEME_FALSE);}}}

/* k2803 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 349  arg-val */
f_1303(((C_word*)t0)[2],t1);}

/* k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2798,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 353  option-arg */
f_1079(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1706(2,t4,C_SCHEME_FALSE);}}

/* k2796 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 353  arg-val */
f_1303(((C_word*)t0)[2],t1);}

/* k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 354  option-arg */
f_1079(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1710(2,t4,C_SCHEME_FALSE);}}

/* k2789 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 354  arg-val */
f_1303(((C_word*)t0)[2],t1);}

/* k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 355  option-arg */
f_1079(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1714(2,t4,C_SCHEME_FALSE);}}

/* k2782 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 355  arg-val */
f_1303(((C_word*)t0)[2],t1);}

/* k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2764,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 358  option-arg */
f_1079(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[272]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1718(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1718(2,t5,C_SCHEME_FALSE);}}}

/* k2762 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 358  arg-val */
f_1303(((C_word*)t0)[2],t1);}

/* k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[80],((C_word*)t0)[24]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[81]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[82],((C_word*)t0)[24]);
t7=C_mutate((C_word*)lf[83]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep((C_word)C_i_memq(lf[270],C_retrieve(lf[31])))){
/* batch-driver.scm: 364  set-gc-report! */
t9=C_retrieve(lf[271]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1729(2,t9,C_SCHEME_UNDEFINED);}}

/* k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep((C_word)C_i_memq(lf[265],((C_word*)t0)[24]))){
t3=t2;
f_1732(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[266]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[267]));
t4=C_mutate((C_word*)lf[268]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[269]));
t5=t2;
f_1732(t5,t4);}}

/* k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1732,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[81]))?lf[262]:lf[263]);
/* batch-driver.scm: 369  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[264],t3);}
else{
t3=t2;
f_1735(2,t3,C_SCHEME_UNDEFINED);}}

/* k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[256],t3);
t5=C_set_block_item(lf[218] /* emit-profile */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2717,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(t4)?lf[260]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 377  append */
t8=*((C_word*)lf[213]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[261]),t7);}
else{
t3=t2;
f_1738(2,t3,C_SCHEME_UNDEFINED);}}

/* k2715 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[257]:lf[258]);
/* batch-driver.scm: 384  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[259],t3);}
else{
t3=((C_word*)t0)[2];
f_1738(2,t3,C_SCHEME_UNDEFINED);}}

/* k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[84],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 387  print-version */
t3=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[87],((C_word*)t0)[23]);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(t2)){
t4=t3;
f_1759(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[253],((C_word*)t0)[23]);
if(C_truep(t4)){
t5=t3;
f_1759(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[254],((C_word*)t0)[23]);
t6=t3;
f_1759(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[255],((C_word*)t0)[23])));}}}}

/* k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1759,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 390  print-usage */
t2=C_retrieve(lf[88]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[23]);}
else{
if(C_truep((C_word)C_i_memq(lf[89],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 392  chicken-version */
t4=C_retrieve(lf[91]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[21];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[22],a[11]=((C_word*)t0)[23],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1796(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 402  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[251],((C_word*)t0)[21]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[23];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 396  print-version */
t4=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1788 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 397  display */
t2=*((C_word*)lf[90]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[252]);}

/* k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1 /* (set! source-filename ...) */,((C_word*)t0)[23]);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[23],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 404  debugging */
t4=C_retrieve(lf[105]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[246],lf[250],((C_word*)t0)[10]);}

/* k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 405  debugging */
t3=C_retrieve(lf[105]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[246],lf[249],C_retrieve(lf[31]));}

/* k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 406  debugging */
t3=C_retrieve(lf[105]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[246],lf[248],C_retrieve(lf[75]));}

/* k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 407  debugging */
t3=C_retrieve(lf[105]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[246],lf[247],C_retrieve(lf[79]));}

/* k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 411  make-vector */
t5=*((C_word*)lf[244]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[245]),C_SCHEME_END_OF_LIST);}

/* k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 412  collect-options */
t4=((C_word*)t0)[2];
f_1383(t4,t3,lf[243]);}

/* k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 413  collect-options */
t3=((C_word*)t0)[2];
f_1383(t3,t2,lf[242]);}

/* k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[18],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 415  collect-options */
t4=((C_word*)t0)[2];
f_1383(t4,t3,lf[241]);}

/* k2681 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2691,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 417  collect-options */
t4=((C_word*)t0)[2];
f_1383(t4,t3,lf[240]);}

/* k2689 in k2681 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 414  append */
t2=*((C_word*)lf[213]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 419  user-read-pass */
t3=C_retrieve(lf[1]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[21])){
/* batch-driver.scm: 421  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[233]);}
else{
t4=t3;
f_2586(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2598(t6,t2,((C_word*)t0)[4]);}}

/* doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_2598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2598,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[234]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 431  check-and-open-input-file */
t5=C_retrieve(lf[239]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2639,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2676,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2675 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[236]));
t3=C_mutate((C_word*)lf[236]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2643 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2648,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 433  read-form */
t3=((C_word*)t0)[2];
f_1440(t3,t2,((C_word*)t0)[5]);}

/* k2646 in a2643 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2653(t5,((C_word*)t0)[2],t1);}

/* doloop648 in k2646 in a2643 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_2653(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2653,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 436  close-checked-input-file */
t3=C_retrieve(lf[237]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 434  read-form */
t6=((C_word*)t0)[2];
f_1440(t6,t5,((C_word*)t0)[6]);}}

/* k2672 in doloop648 in k2646 in a2643 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2653(t2,((C_word*)t0)[2],t1);}

/* a2638 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[236]));
t3=C_mutate((C_word*)lf[236]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2628 in k2625 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2598(t3,((C_word*)t0)[2],t2);}

/* k2611 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 428  reverse */
t3=*((C_word*)lf[235]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2615 in k2611 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2621,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[234]),((C_word*)t0)[2]);}

/* k2619 in k2615 in k2611 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 427  append */
t2=*((C_word*)lf[213]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2607 in doloop619 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2584 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 422  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2588 in k2584 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1832(2,t3,t2);}

/* k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 440  user-preprocessor-pass */
t3=C_retrieve(lf[2]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2576,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[17])){
/* batch-driver.scm: 442  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[232]);}
else{
t4=t3;
f_2576(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1838(t3,C_SCHEME_UNDEFINED);}}

/* k2574 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2578 in k2574 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1838(t3,t2);}

/* k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1838,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 445  print-expr */
t3=((C_word*)t0)[7];
f_1242(t3,t2,lf[230],lf[231],((C_word*)((C_word*)t0)[3])[1]);}

/* k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=f_1413(((C_word*)t0)[21]);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1847(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 448  append */
t5=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[226]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2551 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=C_mutate((C_word*)lf[226]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2571 in k2551 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[227],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[228],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1847(t7,t6);}

/* k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1847,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 450  append */
t4=*((C_word*)lf[213]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2544 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[225]),t1);}

/* k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 451  gensym */
t3=C_retrieve(lf[224]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1853,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[93]));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2514,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[223]));}

/* a2513 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2514,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[215],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[220],t8));}

/* k2386 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2504,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[222]));}

/* a2503 in k2386 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2504,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[221],t3));}

/* k2390 in k2386 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2396,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[218]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[215],t3);
t5=(C_truep(C_retrieve(lf[202]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[219],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[216]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[220],t12);
t14=t2;
f_2396(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2396(t3,C_SCHEME_END_OF_LIST);}}

/* k2394 in k2390 in k2386 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_2396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2396,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2415,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[93]));}

/* a2414 in k2394 in k2390 in k2386 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2415,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[215],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[215],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[216]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[217],t11));}

/* k2398 in k2394 in k2390 in k2386 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[202]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 453  append */
t5=*((C_word*)lf[213]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[214]);}

/* k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2381,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 474  debugging */
t6=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[211],lf[212]);}

/* k2379 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 475  display-real-name-table */
t2=C_retrieve(lf[210]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1862(2,t2,C_SCHEME_UNDEFINED);}}

/* k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 476  debugging */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[208],lf[209]);}

/* k2373 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 477  display-line-number-database */
t2=C_retrieve(lf[207]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1865(2,t2,C_SCHEME_UNDEFINED);}}

/* k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[205]))?C_retrieve(lf[202]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 480  compiler-warning */
t4=C_retrieve(lf[197]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[203],lf[206],C_retrieve(lf[202]));}
else{
t4=t2;
f_1868(2,t4,C_SCHEME_UNDEFINED);}}

/* k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[202]))?((C_word*)t0)[10]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 486  compiler-warning */
t4=C_retrieve(lf[197]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[203],lf[204],C_retrieve(lf[202]));}
else{
t4=t2;
f_1871(2,t4,C_SCHEME_UNDEFINED);}}

/* k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[151]))){
/* batch-driver.scm: 488  feature? */
t4=C_retrieve(lf[200]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[201]);}
else{
t4=t3;
f_2354(2,t4,C_SCHEME_FALSE);}}

/* k2352 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 489  compiler-warning */
t2=C_retrieve(lf[197]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[198],lf[199]);}
else{
t2=((C_word*)t0)[2];
f_1874(2,t2,C_SCHEME_UNDEFINED);}}

/* k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,C_retrieve(lf[94]));
t3=C_set_block_item(lf[94] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 496  end-time */
t5=((C_word*)t0)[16];
f_1423(t5,t4,lf[196]);}

/* k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 497  print-expr */
t3=((C_word*)t0)[2];
f_1242(t3,t2,lf[194],lf[195],((C_word*)((C_word*)t0)[4])[1]);}

/* k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_memq(lf[193],((C_word*)t0)[2]))){
/* batch-driver.scm: 499  exit */
t3=C_retrieve(lf[127]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1885(2,t3,C_SCHEME_UNDEFINED);}}

/* k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 501  user-pass */
t3=C_retrieve(lf[3]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2332,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[11])){
/* batch-driver.scm: 503  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[192]);}
else{
t4=t3;
f_2332(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1891(2,t3,C_SCHEME_UNDEFINED);}}

/* k2330 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=f_1413(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2337 in k2330 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 506  end-time */
t3=((C_word*)t0)[3];
f_1423(t3,((C_word*)t0)[2],lf[191]);}

/* k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 508  vector->list */
t4=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[190]));}

/* k2327 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 508  concatenate */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1897,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2322,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 509  debugging */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[187],lf[188]);}

/* k2320 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 510  pp */
t2=C_retrieve(lf[186]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1897(2,t2,C_SCHEME_UNDEFINED);}}

/* k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[174]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2319,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[185]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1900(2,t3,C_SCHEME_UNDEFINED);}}

/* k2317 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 521  concatenate */
t2=C_retrieve(lf[184]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2313 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2280 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2281,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 515  symbol->string */
t6=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2309 in a2280 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 515  make-pathname */
t2=C_retrieve(lf[181]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[182]);}

/* k2305 in a2280 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 514  ##sys#resolve-include-filename */
t2=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2283 in a2280 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 517  file-exists? */
t3=C_retrieve(lf[179]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2292 in k2283 in a2280 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2294,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 519  print */
t3=*((C_word*)lf[176]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[177],((C_word*)t0)[3],lf[178]);}
else{
t3=t2;
f_2297(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2295 in k2292 in k2283 in a2280 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 520  load-inline-file */
t2=C_retrieve(lf[175]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 526  canonicalize-begin-body */
t5=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2274 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 525  build-node-graph */
t2=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2270 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2264,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[170],lf[171],t2);}

/* f_2264 in k2270 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2264,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[169],t2,t3,t4));}

/* k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1906,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 527  user-pass-2 */
t3=C_retrieve(lf[4]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[12],a[8]=t2,a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[11])){
/* batch-driver.scm: 529  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[168]);}
else{
t4=t3;
f_2230(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1909(t3,C_SCHEME_UNDEFINED);}}

/* k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=f_1413(((C_word*)t0)[9]);
t3=C_set_block_item(lf[97] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 532  analyze */
t5=((C_word*)t0)[2];
f_1446(t5,t4,lf[167],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2235 in k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 533  print-db */
t3=((C_word*)t0)[2];
f_1227(t3,t2,lf[166],lf[160],t1,C_fix(0));}

/* k2238 in k2235 in k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 534  end-time */
t3=((C_word*)t0)[3];
f_1423(t3,t2,lf[165]);}

/* k2241 in k2238 in k2235 in k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=f_1413(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 536  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2247 in k2241 in k2238 in k2235 in k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 537  end-time */
t3=((C_word*)t0)[2];
f_1423(t3,t2,lf[164]);}

/* k2250 in k2247 in k2241 in k2238 in k2235 in k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 538  print-node */
t3=((C_word*)t0)[3];
f_1205(t3,t2,lf[162],lf[163],((C_word*)t0)[2]);}

/* k2253 in k2250 in k2247 in k2241 in k2238 in k2235 in k2228 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[97] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1909(t3,t2);}

/* k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1909,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[153]))){
t3=f_1413(((C_word*)t0)[15]);
t4=C_set_block_item(lf[97] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],a[6]=t2,a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 544  analyze */
t6=((C_word*)t0)[13];
f_1446(t6,t5,lf[161],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1912(t3,C_SCHEME_UNDEFINED);}}

/* k2206 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2211,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 545  print-db */
t3=((C_word*)t0)[2];
f_1227(t3,t2,lf[159],lf[160],t1,C_fix(0));}

/* k2209 in k2206 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 546  end-time */
t3=((C_word*)t0)[3];
f_1423(t3,t2,lf[158]);}

/* k2212 in k2209 in k2206 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=f_1413(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 548  perform-lambda-lifting! */
t4=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2218 in k2212 in k2209 in k2206 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 549  end-time */
t3=((C_word*)t0)[2];
f_1423(t3,t2,lf[156]);}

/* k2221 in k2218 in k2212 in k2209 in k2206 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 550  print-node */
t3=((C_word*)t0)[3];
f_1205(t3,t2,lf[154],lf[155],((C_word*)t0)[2]);}

/* k2224 in k2221 in k2218 in k2212 in k2209 in k2206 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[97] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1912(t3,t2);}

/* k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1912,NULL,2,t0,t1);}
t2=C_set_block_item(lf[42] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[95] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[96] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[151]))){
t6=t5;
f_1918(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2197,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2197 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2197,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2194 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* batch-driver.scm: 557  scan-toplevel-assignments */
t3=C_retrieve(lf[152]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=f_1413(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 560  perform-cps-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1927,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 561  end-time */
t3=((C_word*)t0)[13];
f_1423(t3,t2,lf[149]);}

/* k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 562  print-node */
t3=((C_word*)t0)[12];
f_1205(t3,t2,lf[147],lf[148],((C_word*)t0)[2]);}

/* k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=t3,a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_1935(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1935,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1413(((C_word*)t0)[14]);
t6=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=t2,a[16]=t3,a[17]=((C_word*)t0)[14],a[18]=t4,tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 568  analyze */
t7=((C_word*)t0)[11];
f_1446(t7,t6,lf[146],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(C_retrieve(lf[97]))){
if(C_truep((C_word)C_i_memq(lf[144],C_retrieve(lf[31])))){
/* batch-driver.scm: 571  dump-undefined-globals */
t3=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t3=t2;
f_1945(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1945(2,t3,C_SCHEME_UNDEFINED);}}

/* k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=C_set_block_item(lf[97] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 573  end-time */
t4=((C_word*)t0)[13];
f_1423(t4,t3,lf[143]);}

/* k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 574  print-db */
t3=((C_word*)t0)[2];
f_1227(t3,t2,lf[141],lf[142],((C_word*)t0)[16],((C_word*)t0)[15]);}

/* k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_memq(lf[139],C_retrieve(lf[31])))){
/* batch-driver.scm: 576  print-program-statistics */
t3=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}
else{
t3=t2;
f_1955(2,t3,C_SCHEME_UNDEFINED);}}

/* k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
if(C_truep(((C_word*)t0)[19])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[18],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 579  debugging */
t3=C_retrieve(lf[105]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[106],lf[111],((C_word*)t0)[15]);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[17],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[18],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 603  print-node */
t3=((C_word*)t0)[11];
f_1205(t3,t2,lf[137],lf[138],((C_word*)t0)[17]);}}

/* k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[134]))){
t3=C_retrieve(lf[134]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[15],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[14])){
/* batch-driver.scm: 608  printf */
t5=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[136],t3);}
else{
t5=t4;
f_2164(2,t5,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2050(2,t3,C_SCHEME_UNDEFINED);}}

/* k2162 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 609  emit-global-inline-file */
t2=C_retrieve(lf[135]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=f_1413(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 612  perform-closure-conversion */
t4=C_retrieve(lf[133]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[15]);}

/* k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 613  end-time */
t3=((C_word*)t0)[12];
f_1423(t3,t2,lf[132]);}

/* k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 614  print-db */
t3=((C_word*)t0)[3];
f_1227(t3,t2,lf[130],lf[131],((C_word*)t0)[14],((C_word*)t0)[2]);}

/* k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[129]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2147(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2147(t4,C_SCHEME_FALSE);}}

/* k2145 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_2147(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 616  display */
t2=*((C_word*)lf[90]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[128]);}
else{
t2=((C_word*)t0)[2];
f_2065(2,t2,C_SCHEME_UNDEFINED);}}

/* k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 617  exit */
t3=C_retrieve(lf[127]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_2068(2,t3,C_SCHEME_UNDEFINED);}}

/* k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 618  print-node */
t3=((C_word*)t0)[2];
f_1205(t3,t2,lf[125],lf[126],((C_word*)t0)[11]);}

/* k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=f_1413(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2085,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 623  end-time */
t7=((C_word*)t0)[7];
f_1423(t7,t6,lf[124]);}

/* k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=f_1413(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 626  open-output-file */
t4=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 626  current-output-port */
t4=*((C_word*)lf[123]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2098(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 628  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[121],((C_word*)t0)[9]);}}

/* k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 629  generate-code */
t3=C_retrieve(lf[120]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2099 in k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 630  close-output-port */
t3=*((C_word*)lf[119]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2104(2,t3,C_SCHEME_UNDEFINED);}}

/* k2102 in k2099 in k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 631  end-time */
t3=((C_word*)t0)[2];
f_1423(t3,t2,lf[118]);}

/* k2105 in k2102 in k2099 in k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[115],C_retrieve(lf[31])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2129,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 632  ##sys#stop-timer */
t4=*((C_word*)lf[117]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2110(2,t3,C_SCHEME_UNDEFINED);}}

/* k2127 in k2105 in k2102 in k2099 in k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 632  ##sys#display-times */
t2=C_retrieve(lf[116]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2108 in k2105 in k2102 in k2099 in k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 633  compiler-cleanup-hook */
t3=C_retrieve(lf[114]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2111 in k2108 in k2105 in k2102 in k2099 in k2096 in k2093 in k2087 in a2084 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 635  printf */
t2=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[113]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2078 in k2069 in k2066 in k2063 in k2060 in k2057 in k2054 in k2048 in k2045 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
/* batch-driver.scm: 622  prepare-for-code-generation */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=f_1413(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1975,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 584  end-time */
t5=((C_word*)t0)[4];
f_1423(t5,t4,lf[110]);}

/* k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 585  print-node */
t3=((C_word*)t0)[2];
f_1205(t3,t2,lf[108],lf[109],((C_word*)t0)[6]);}

/* k1980 in k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 587  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1935(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[99]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[100]))){
t3=f_1413(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 594  analyze */
t5=((C_word*)t0)[2];
f_1446(t5,t4,lf[104],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 600  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1935(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 589  debugging */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[106],lf[107]);}}}

/* k1999 in k1980 in k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[99] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 591  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1935(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2016 in k1980 in k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2021,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 595  end-time */
t3=((C_word*)t0)[2];
f_1423(t3,t2,lf[103]);}

/* k2019 in k2016 in k1980 in k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=f_1413(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 597  transform-direct-lambdas! */
t4=C_retrieve(lf[102]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2025 in k2019 in k2016 in k1980 in k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2030,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 598  end-time */
t3=((C_word*)t0)[2];
f_1423(t3,t2,lf[101]);}

/* k2028 in k2025 in k2019 in k2016 in k1980 in k1977 in a1974 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 599  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1935(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1968 in k1959 in k1953 in k1950 in k1947 in k1943 in k1940 in loop in k1928 in k1925 in k1922 in k1916 in k1910 in k1907 in k1904 in k1901 in k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1880 in k1877 in k1872 in k1869 in k1866 in k1863 in k1860 in k1857 in k1851 in k1848 in k1845 in k1839 in k1836 in k1833 in k1830 in k1827 in k1824 in k1821 in k1818 in k1815 in k1807 in k1804 in k1801 in k1798 in k1794 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
/* batch-driver.scm: 583  perform-high-level-optimizations */
t2=C_retrieve(lf[98]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1776 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 392  display */
t2=*((C_word*)lf[90]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1769 in k1757 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 393  newline */
t2=*((C_word*)lf[85]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1745 in k1736 in k1733 in k1730 in k1727 in k1716 in k1712 in k1708 in k1704 in k1700 in k1696 in k1693 in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 388  newline */
t2=*((C_word*)lf[85]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ids in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1669,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1683,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1691,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 337  collect-options */
t7=((C_word*)t0)[2];
f_1383(t7,t6,t2);}

/* k1689 in ids in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 335  append-map */
t2=C_retrieve(lf[74]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1682 in ids in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1683,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[73]);}

/* k1679 in ids in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[71]+1),t1);}

/* k1675 in ids in k1665 in k1662 in k1658 in k1650 in k1646 in k1643 in k1640 in k1633 in k1630 in k1627 in k1623 in k1620 in k1614 in k1611 in k1608 in k1605 in k1599 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1575 in k1572 in k1569 in k1566 in k1562 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1530 in k1526 in k1523 in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 332  lset-difference */
t2=C_retrieve(lf[68]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[69]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1446,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1448,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no302350 */
t8=t7;
f_1476(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf303346 */
t10=t6;
f_1471(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body300309 */
t12=t5;
f_1448(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[55],t11);}}}}

/* def-no302 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1476(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1476,NULL,2,t0,t1);}
/* def-contf303346 */
t2=((C_word*)t0)[2];
f_1471(t2,t1,C_fix(0));}

/* def-contf303 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1471,NULL,3,t0,t1,t2);}
/* body300309 */
t3=((C_word*)t0)[2];
f_1448(t3,t1,t2,C_SCHEME_TRUE);}

/* body300 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1448,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1452,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 202  analyze-expression */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1450 in body300 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1455,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 204  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1455(2,t3,C_SCHEME_UNDEFINED);}}

/* a1465 in k1450 in body300 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1466,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[52]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1459 in k1450 in body300 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1460,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k1453 in k1450 in body300 in analyze in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1440,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 198  ##sys#read */
t3=C_retrieve(lf[50]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1423,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 195  printf */
t5=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[49],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static C_word C_fcall f_1413(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1383,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1389(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1389,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 187  option-arg */
f_1079(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1401 in loop in collect-options in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1389(t4,t2,t3);}

/* k1405 in k1401 in loop in collect-options in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1303(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1303,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1313,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 178  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1344,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 180  substring */
t11=*((C_word*)lf[48]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1372,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 181  substring */
t13=*((C_word*)lf[48]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1370 in arg-val in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 181  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1366 in arg-val in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1313(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1350 in arg-val in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 180  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1342 in arg-val in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1313(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1311 in arg-val in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 183  quit */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1254,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1258,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[46]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1300,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1300 in infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1300,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1256 in infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1261,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[45],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1264(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1264(t5,C_SCHEME_FALSE);}}

/* k1262 in k1256 in infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1264,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 170  ##sys#hash-table-ref */
t6=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[42]),t5);}
else{
t2=((C_word*)t0)[3];
f_1261(2,t2,C_SCHEME_UNDEFINED);}}

/* k1277 in k1262 in k1256 in infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 169  alist-cons */
t3=C_retrieve(lf[43]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1273 in k1262 in k1256 in infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 166  ##sys#hash-table-set! */
t2=C_retrieve(lf[41]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[42]),((C_word*)t0)[2],t1);}

/* k1259 in k1256 in infohook in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1242(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1242,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1249,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 160  print-header */
t6=((C_word*)t0)[2];
f_1187(t6,t5,t2,t3);}

/* k1247 in print-expr in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[36]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1227(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1227,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1234,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 155  print-header */
t7=((C_word*)t0)[2];
f_1187(t7,t6,t2,t3);}

/* k1232 in print-db in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 156  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[39],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1235 in k1232 in print-db in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 157  display-analysis-database */
t2=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 149  print-header */
t6=((C_word*)t0)[2];
f_1187(t6,t5,t2,t3);}

/* k1210 in print-node in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 151  dump-nodes */
t2=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 152  build-expression-tree */
t3=C_retrieve(lf[37]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1223 in k1210 in print-node in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 152  pretty-print */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1187(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1187,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1191,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 142  printf */
t5=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[34],t2);}
else{
t5=t4;
f_1191(2,t5,C_SCHEME_UNDEFINED);}}

/* k1189 in print-header in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[31])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 145  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[33],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1198 in k1189 in print-header in k1135 in k1129 in k1126 in k3250 in k1110 in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* option-arg in compile-source-file in k1072 in k1068 in k1064 in k1060 in k1056 in k1052 in k1047 in k1044 in k1041 in k1038 in k1035 in k1032 */
static void C_fcall f_1079(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1079,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 94   quit */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[8],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 97   quit */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[9],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[311] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_1034batch-driver.scm",(void*)f_1034},
{"f_1037batch-driver.scm",(void*)f_1037},
{"f_1040batch-driver.scm",(void*)f_1040},
{"f_1043batch-driver.scm",(void*)f_1043},
{"f_1046batch-driver.scm",(void*)f_1046},
{"f_1049batch-driver.scm",(void*)f_1049},
{"f_1054batch-driver.scm",(void*)f_1054},
{"f_1058batch-driver.scm",(void*)f_1058},
{"f_1062batch-driver.scm",(void*)f_1062},
{"f_1066batch-driver.scm",(void*)f_1066},
{"f_1070batch-driver.scm",(void*)f_1070},
{"f_1074batch-driver.scm",(void*)f_1074},
{"f_1076batch-driver.scm",(void*)f_1076},
{"f_1112batch-driver.scm",(void*)f_1112},
{"f_3271batch-driver.scm",(void*)f_3271},
{"f_3260batch-driver.scm",(void*)f_3260},
{"f_3256batch-driver.scm",(void*)f_3256},
{"f_3252batch-driver.scm",(void*)f_3252},
{"f_3241batch-driver.scm",(void*)f_3241},
{"f_3219batch-driver.scm",(void*)f_3219},
{"f_1128batch-driver.scm",(void*)f_1128},
{"f_3213batch-driver.scm",(void*)f_3213},
{"f_3209batch-driver.scm",(void*)f_3209},
{"f_1131batch-driver.scm",(void*)f_1131},
{"f_1137batch-driver.scm",(void*)f_1137},
{"f_3190batch-driver.scm",(void*)f_3190},
{"f_3186batch-driver.scm",(void*)f_3186},
{"f_3182batch-driver.scm",(void*)f_3182},
{"f_1525batch-driver.scm",(void*)f_1525},
{"f_1528batch-driver.scm",(void*)f_1528},
{"f_3174batch-driver.scm",(void*)f_3174},
{"f_3152batch-driver.scm",(void*)f_3152},
{"f_3170batch-driver.scm",(void*)f_3170},
{"f_3158batch-driver.scm",(void*)f_3158},
{"f_1532batch-driver.scm",(void*)f_1532},
{"f_3150batch-driver.scm",(void*)f_3150},
{"f_3134batch-driver.scm",(void*)f_3134},
{"f_3142batch-driver.scm",(void*)f_3142},
{"f_3146batch-driver.scm",(void*)f_3146},
{"f_1540batch-driver.scm",(void*)f_1540},
{"f_1543batch-driver.scm",(void*)f_1543},
{"f_1546batch-driver.scm",(void*)f_1546},
{"f_1549batch-driver.scm",(void*)f_1549},
{"f_1552batch-driver.scm",(void*)f_1552},
{"f_1555batch-driver.scm",(void*)f_1555},
{"f_1558batch-driver.scm",(void*)f_1558},
{"f_1561batch-driver.scm",(void*)f_1561},
{"f_1564batch-driver.scm",(void*)f_1564},
{"f_3093batch-driver.scm",(void*)f_3093},
{"f_1568batch-driver.scm",(void*)f_1568},
{"f_3085batch-driver.scm",(void*)f_3085},
{"f_1571batch-driver.scm",(void*)f_1571},
{"f_1574batch-driver.scm",(void*)f_1574},
{"f_1577batch-driver.scm",(void*)f_1577},
{"f_1580batch-driver.scm",(void*)f_1580},
{"f_1583batch-driver.scm",(void*)f_1583},
{"f_1586batch-driver.scm",(void*)f_1586},
{"f_1589batch-driver.scm",(void*)f_1589},
{"f_1592batch-driver.scm",(void*)f_1592},
{"f_1595batch-driver.scm",(void*)f_1595},
{"f_3044batch-driver.scm",(void*)f_3044},
{"f_1601batch-driver.scm",(void*)f_1601},
{"f_3029batch-driver.scm",(void*)f_3029},
{"f_3032batch-driver.scm",(void*)f_3032},
{"f_3035batch-driver.scm",(void*)f_3035},
{"f_1607batch-driver.scm",(void*)f_1607},
{"f_3016batch-driver.scm",(void*)f_3016},
{"f_3019batch-driver.scm",(void*)f_3019},
{"f_1610batch-driver.scm",(void*)f_1610},
{"f_1613batch-driver.scm",(void*)f_1613},
{"f_2974batch-driver.scm",(void*)f_2974},
{"f_1616batch-driver.scm",(void*)f_1616},
{"f_2971batch-driver.scm",(void*)f_2971},
{"f_2967batch-driver.scm",(void*)f_2967},
{"f_1622batch-driver.scm",(void*)f_1622},
{"f_1625batch-driver.scm",(void*)f_1625},
{"f_2951batch-driver.scm",(void*)f_2951},
{"f_2943batch-driver.scm",(void*)f_2943},
{"f_2941batch-driver.scm",(void*)f_2941},
{"f_1629batch-driver.scm",(void*)f_1629},
{"f_1632batch-driver.scm",(void*)f_1632},
{"f_2933batch-driver.scm",(void*)f_2933},
{"f_2925batch-driver.scm",(void*)f_2925},
{"f_2923batch-driver.scm",(void*)f_2923},
{"f_1635batch-driver.scm",(void*)f_1635},
{"f_1642batch-driver.scm",(void*)f_1642},
{"f_2916batch-driver.scm",(void*)f_2916},
{"f_1645batch-driver.scm",(void*)f_1645},
{"f_2910batch-driver.scm",(void*)f_2910},
{"f_2894batch-driver.scm",(void*)f_2894},
{"f_2900batch-driver.scm",(void*)f_2900},
{"f_2908batch-driver.scm",(void*)f_2908},
{"f_2889batch-driver.scm",(void*)f_2889},
{"f_1648batch-driver.scm",(void*)f_1648},
{"f_1652batch-driver.scm",(void*)f_1652},
{"f_1660batch-driver.scm",(void*)f_1660},
{"f_1664batch-driver.scm",(void*)f_1664},
{"f_2875batch-driver.scm",(void*)f_2875},
{"f_2871batch-driver.scm",(void*)f_2871},
{"f_2855batch-driver.scm",(void*)f_2855},
{"f_1667batch-driver.scm",(void*)f_1667},
{"f_2848batch-driver.scm",(void*)f_2848},
{"f_2828batch-driver.scm",(void*)f_2828},
{"f_2826batch-driver.scm",(void*)f_2826},
{"f_1695batch-driver.scm",(void*)f_1695},
{"f_1698batch-driver.scm",(void*)f_1698},
{"f_2805batch-driver.scm",(void*)f_2805},
{"f_1702batch-driver.scm",(void*)f_1702},
{"f_2798batch-driver.scm",(void*)f_2798},
{"f_1706batch-driver.scm",(void*)f_1706},
{"f_2791batch-driver.scm",(void*)f_2791},
{"f_1710batch-driver.scm",(void*)f_1710},
{"f_2784batch-driver.scm",(void*)f_2784},
{"f_1714batch-driver.scm",(void*)f_1714},
{"f_2764batch-driver.scm",(void*)f_2764},
{"f_1718batch-driver.scm",(void*)f_1718},
{"f_1729batch-driver.scm",(void*)f_1729},
{"f_1732batch-driver.scm",(void*)f_1732},
{"f_1735batch-driver.scm",(void*)f_1735},
{"f_2717batch-driver.scm",(void*)f_2717},
{"f_1738batch-driver.scm",(void*)f_1738},
{"f_1759batch-driver.scm",(void*)f_1759},
{"f_1790batch-driver.scm",(void*)f_1790},
{"f_1796batch-driver.scm",(void*)f_1796},
{"f_1800batch-driver.scm",(void*)f_1800},
{"f_1803batch-driver.scm",(void*)f_1803},
{"f_1806batch-driver.scm",(void*)f_1806},
{"f_1809batch-driver.scm",(void*)f_1809},
{"f_1817batch-driver.scm",(void*)f_1817},
{"f_1820batch-driver.scm",(void*)f_1820},
{"f_1823batch-driver.scm",(void*)f_1823},
{"f_2683batch-driver.scm",(void*)f_2683},
{"f_2691batch-driver.scm",(void*)f_2691},
{"f_1826batch-driver.scm",(void*)f_1826},
{"f_1829batch-driver.scm",(void*)f_1829},
{"f_2598batch-driver.scm",(void*)f_2598},
{"f_2627batch-driver.scm",(void*)f_2627},
{"f_2676batch-driver.scm",(void*)f_2676},
{"f_2644batch-driver.scm",(void*)f_2644},
{"f_2648batch-driver.scm",(void*)f_2648},
{"f_2653batch-driver.scm",(void*)f_2653},
{"f_2674batch-driver.scm",(void*)f_2674},
{"f_2639batch-driver.scm",(void*)f_2639},
{"f_2630batch-driver.scm",(void*)f_2630},
{"f_2613batch-driver.scm",(void*)f_2613},
{"f_2617batch-driver.scm",(void*)f_2617},
{"f_2621batch-driver.scm",(void*)f_2621},
{"f_2609batch-driver.scm",(void*)f_2609},
{"f_2586batch-driver.scm",(void*)f_2586},
{"f_2590batch-driver.scm",(void*)f_2590},
{"f_1832batch-driver.scm",(void*)f_1832},
{"f_1835batch-driver.scm",(void*)f_1835},
{"f_2576batch-driver.scm",(void*)f_2576},
{"f_2580batch-driver.scm",(void*)f_2580},
{"f_1838batch-driver.scm",(void*)f_1838},
{"f_1841batch-driver.scm",(void*)f_1841},
{"f_2553batch-driver.scm",(void*)f_2553},
{"f_2573batch-driver.scm",(void*)f_2573},
{"f_1847batch-driver.scm",(void*)f_1847},
{"f_2546batch-driver.scm",(void*)f_2546},
{"f_1850batch-driver.scm",(void*)f_1850},
{"f_1853batch-driver.scm",(void*)f_1853},
{"f_2514batch-driver.scm",(void*)f_2514},
{"f_2388batch-driver.scm",(void*)f_2388},
{"f_2504batch-driver.scm",(void*)f_2504},
{"f_2392batch-driver.scm",(void*)f_2392},
{"f_2396batch-driver.scm",(void*)f_2396},
{"f_2415batch-driver.scm",(void*)f_2415},
{"f_2400batch-driver.scm",(void*)f_2400},
{"f_1859batch-driver.scm",(void*)f_1859},
{"f_2381batch-driver.scm",(void*)f_2381},
{"f_1862batch-driver.scm",(void*)f_1862},
{"f_2375batch-driver.scm",(void*)f_2375},
{"f_1865batch-driver.scm",(void*)f_1865},
{"f_1868batch-driver.scm",(void*)f_1868},
{"f_1871batch-driver.scm",(void*)f_1871},
{"f_2354batch-driver.scm",(void*)f_2354},
{"f_1874batch-driver.scm",(void*)f_1874},
{"f_1879batch-driver.scm",(void*)f_1879},
{"f_1882batch-driver.scm",(void*)f_1882},
{"f_1885batch-driver.scm",(void*)f_1885},
{"f_1888batch-driver.scm",(void*)f_1888},
{"f_2332batch-driver.scm",(void*)f_2332},
{"f_2339batch-driver.scm",(void*)f_2339},
{"f_1891batch-driver.scm",(void*)f_1891},
{"f_2329batch-driver.scm",(void*)f_2329},
{"f_1894batch-driver.scm",(void*)f_1894},
{"f_2322batch-driver.scm",(void*)f_2322},
{"f_1897batch-driver.scm",(void*)f_1897},
{"f_2319batch-driver.scm",(void*)f_2319},
{"f_2315batch-driver.scm",(void*)f_2315},
{"f_2281batch-driver.scm",(void*)f_2281},
{"f_2311batch-driver.scm",(void*)f_2311},
{"f_2307batch-driver.scm",(void*)f_2307},
{"f_2285batch-driver.scm",(void*)f_2285},
{"f_2294batch-driver.scm",(void*)f_2294},
{"f_2297batch-driver.scm",(void*)f_2297},
{"f_1900batch-driver.scm",(void*)f_1900},
{"f_2276batch-driver.scm",(void*)f_2276},
{"f_2272batch-driver.scm",(void*)f_2272},
{"f_2264batch-driver.scm",(void*)f_2264},
{"f_1903batch-driver.scm",(void*)f_1903},
{"f_1906batch-driver.scm",(void*)f_1906},
{"f_2230batch-driver.scm",(void*)f_2230},
{"f_2237batch-driver.scm",(void*)f_2237},
{"f_2240batch-driver.scm",(void*)f_2240},
{"f_2243batch-driver.scm",(void*)f_2243},
{"f_2249batch-driver.scm",(void*)f_2249},
{"f_2252batch-driver.scm",(void*)f_2252},
{"f_2255batch-driver.scm",(void*)f_2255},
{"f_1909batch-driver.scm",(void*)f_1909},
{"f_2208batch-driver.scm",(void*)f_2208},
{"f_2211batch-driver.scm",(void*)f_2211},
{"f_2214batch-driver.scm",(void*)f_2214},
{"f_2220batch-driver.scm",(void*)f_2220},
{"f_2223batch-driver.scm",(void*)f_2223},
{"f_2226batch-driver.scm",(void*)f_2226},
{"f_1912batch-driver.scm",(void*)f_1912},
{"f_2197batch-driver.scm",(void*)f_2197},
{"f_2196batch-driver.scm",(void*)f_2196},
{"f_1918batch-driver.scm",(void*)f_1918},
{"f_1924batch-driver.scm",(void*)f_1924},
{"f_1927batch-driver.scm",(void*)f_1927},
{"f_1930batch-driver.scm",(void*)f_1930},
{"f_1935batch-driver.scm",(void*)f_1935},
{"f_1942batch-driver.scm",(void*)f_1942},
{"f_1945batch-driver.scm",(void*)f_1945},
{"f_1949batch-driver.scm",(void*)f_1949},
{"f_1952batch-driver.scm",(void*)f_1952},
{"f_1955batch-driver.scm",(void*)f_1955},
{"f_2047batch-driver.scm",(void*)f_2047},
{"f_2164batch-driver.scm",(void*)f_2164},
{"f_2050batch-driver.scm",(void*)f_2050},
{"f_2056batch-driver.scm",(void*)f_2056},
{"f_2059batch-driver.scm",(void*)f_2059},
{"f_2062batch-driver.scm",(void*)f_2062},
{"f_2147batch-driver.scm",(void*)f_2147},
{"f_2065batch-driver.scm",(void*)f_2065},
{"f_2068batch-driver.scm",(void*)f_2068},
{"f_2071batch-driver.scm",(void*)f_2071},
{"f_2085batch-driver.scm",(void*)f_2085},
{"f_2089batch-driver.scm",(void*)f_2089},
{"f_2095batch-driver.scm",(void*)f_2095},
{"f_2098batch-driver.scm",(void*)f_2098},
{"f_2101batch-driver.scm",(void*)f_2101},
{"f_2104batch-driver.scm",(void*)f_2104},
{"f_2107batch-driver.scm",(void*)f_2107},
{"f_2129batch-driver.scm",(void*)f_2129},
{"f_2110batch-driver.scm",(void*)f_2110},
{"f_2113batch-driver.scm",(void*)f_2113},
{"f_2079batch-driver.scm",(void*)f_2079},
{"f_1961batch-driver.scm",(void*)f_1961},
{"f_1975batch-driver.scm",(void*)f_1975},
{"f_1979batch-driver.scm",(void*)f_1979},
{"f_1982batch-driver.scm",(void*)f_1982},
{"f_2001batch-driver.scm",(void*)f_2001},
{"f_2018batch-driver.scm",(void*)f_2018},
{"f_2021batch-driver.scm",(void*)f_2021},
{"f_2027batch-driver.scm",(void*)f_2027},
{"f_2030batch-driver.scm",(void*)f_2030},
{"f_1969batch-driver.scm",(void*)f_1969},
{"f_1778batch-driver.scm",(void*)f_1778},
{"f_1771batch-driver.scm",(void*)f_1771},
{"f_1747batch-driver.scm",(void*)f_1747},
{"f_1669batch-driver.scm",(void*)f_1669},
{"f_1691batch-driver.scm",(void*)f_1691},
{"f_1683batch-driver.scm",(void*)f_1683},
{"f_1681batch-driver.scm",(void*)f_1681},
{"f_1677batch-driver.scm",(void*)f_1677},
{"f_1446batch-driver.scm",(void*)f_1446},
{"f_1476batch-driver.scm",(void*)f_1476},
{"f_1471batch-driver.scm",(void*)f_1471},
{"f_1448batch-driver.scm",(void*)f_1448},
{"f_1452batch-driver.scm",(void*)f_1452},
{"f_1466batch-driver.scm",(void*)f_1466},
{"f_1460batch-driver.scm",(void*)f_1460},
{"f_1455batch-driver.scm",(void*)f_1455},
{"f_1440batch-driver.scm",(void*)f_1440},
{"f_1423batch-driver.scm",(void*)f_1423},
{"f_1413batch-driver.scm",(void*)f_1413},
{"f_1383batch-driver.scm",(void*)f_1383},
{"f_1389batch-driver.scm",(void*)f_1389},
{"f_1403batch-driver.scm",(void*)f_1403},
{"f_1407batch-driver.scm",(void*)f_1407},
{"f_1303batch-driver.scm",(void*)f_1303},
{"f_1372batch-driver.scm",(void*)f_1372},
{"f_1368batch-driver.scm",(void*)f_1368},
{"f_1352batch-driver.scm",(void*)f_1352},
{"f_1344batch-driver.scm",(void*)f_1344},
{"f_1313batch-driver.scm",(void*)f_1313},
{"f_1254batch-driver.scm",(void*)f_1254},
{"f_1300batch-driver.scm",(void*)f_1300},
{"f_1258batch-driver.scm",(void*)f_1258},
{"f_1264batch-driver.scm",(void*)f_1264},
{"f_1279batch-driver.scm",(void*)f_1279},
{"f_1275batch-driver.scm",(void*)f_1275},
{"f_1261batch-driver.scm",(void*)f_1261},
{"f_1242batch-driver.scm",(void*)f_1242},
{"f_1249batch-driver.scm",(void*)f_1249},
{"f_1227batch-driver.scm",(void*)f_1227},
{"f_1234batch-driver.scm",(void*)f_1234},
{"f_1237batch-driver.scm",(void*)f_1237},
{"f_1205batch-driver.scm",(void*)f_1205},
{"f_1212batch-driver.scm",(void*)f_1212},
{"f_1225batch-driver.scm",(void*)f_1225},
{"f_1187batch-driver.scm",(void*)f_1187},
{"f_1191batch-driver.scm",(void*)f_1191},
{"f_1200batch-driver.scm",(void*)f_1200},
{"f_1079batch-driver.scm",(void*)f_1079},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
