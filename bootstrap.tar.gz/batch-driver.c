/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:21
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[345];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_fcall f_3112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_fcall f_1063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_fcall f_1451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_fcall f_1454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_fcall f_1469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_fcall f_1472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_fcall f_1478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_fcall f_1484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_fcall f_1487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_fcall f_1500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_fcall f_1503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_fcall f_1512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_fcall f_1515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_fcall f_1518(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_fcall f_1530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_fcall f_1590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_fcall f_1621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_fcall f_1655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_fcall f_1682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_fcall f_2464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_fcall f_2519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_ccall f_1755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_fcall f_1761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_fcall f_1770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_fcall f_2262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_fcall f_1826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_fcall f_1829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_fcall f_2061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1402)
static void C_fcall f_1402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_fcall f_1397(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1374)
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_fcall f_1366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1349)
static void C_fcall f_1349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1339)
static C_word C_fcall f_1339(C_word t0);
C_noret_decl(f_1309)
static void C_fcall f_1309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1315)
static void C_fcall f_1315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1229)
static void C_fcall f_1229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_fcall f_1190(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1168)
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_fcall f_1113(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static C_word C_fcall f_1107();
C_noret_decl(f_1005)
static void C_fcall f_1005(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3112)
static void C_fcall trf_3112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3112(t0,t1);}

C_noret_decl(trf_1063)
static void C_fcall trf_1063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1063(t0,t1);}

C_noret_decl(trf_1451)
static void C_fcall trf_1451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1451(t0,t1);}

C_noret_decl(trf_1454)
static void C_fcall trf_1454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1454(t0,t1);}

C_noret_decl(trf_1469)
static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1469(t0,t1);}

C_noret_decl(trf_1472)
static void C_fcall trf_1472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1472(t0,t1);}

C_noret_decl(trf_1478)
static void C_fcall trf_1478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1478(t0,t1);}

C_noret_decl(trf_1484)
static void C_fcall trf_1484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1484(t0,t1);}

C_noret_decl(trf_1487)
static void C_fcall trf_1487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1487(t0,t1);}

C_noret_decl(trf_1500)
static void C_fcall trf_1500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1500(t0,t1);}

C_noret_decl(trf_1503)
static void C_fcall trf_1503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1503(t0,t1);}

C_noret_decl(trf_1506)
static void C_fcall trf_1506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1506(t0,t1);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1509(t0,t1);}

C_noret_decl(trf_1512)
static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1512(t0,t1);}

C_noret_decl(trf_1515)
static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1515(t0,t1);}

C_noret_decl(trf_1518)
static void C_fcall trf_1518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1518(t0,t1);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1521(t0,t1);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1524(t0,t1);}

C_noret_decl(trf_1530)
static void C_fcall trf_1530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1530(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1555(t0,t1);}

C_noret_decl(trf_1590)
static void C_fcall trf_1590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1590(t0,t1);}

C_noret_decl(trf_1621)
static void C_fcall trf_1621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1621(t0,t1);}

C_noret_decl(trf_1655)
static void C_fcall trf_1655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1655(t0,t1);}

C_noret_decl(trf_1682)
static void C_fcall trf_1682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1682(t0,t1);}

C_noret_decl(trf_2464)
static void C_fcall trf_2464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2464(t0,t1,t2);}

C_noret_decl(trf_2519)
static void C_fcall trf_2519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2519(t0,t1,t2);}

C_noret_decl(trf_1761)
static void C_fcall trf_1761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1761(t0,t1);}

C_noret_decl(trf_1770)
static void C_fcall trf_1770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1770(t0,t1);}

C_noret_decl(trf_2262)
static void C_fcall trf_2262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2262(t0,t1);}

C_noret_decl(trf_1826)
static void C_fcall trf_1826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1826(t0,t1);}

C_noret_decl(trf_1829)
static void C_fcall trf_1829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1829(t0,t1);}

C_noret_decl(trf_1852)
static void C_fcall trf_1852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1852(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1852(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2061)
static void C_fcall trf_2061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2061(t0,t1);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1592(t0,t1,t2);}

C_noret_decl(trf_1372)
static void C_fcall trf_1372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1372(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1372(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1402)
static void C_fcall trf_1402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1402(t0,t1);}

C_noret_decl(trf_1397)
static void C_fcall trf_1397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1397(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1397(t0,t1,t2);}

C_noret_decl(trf_1374)
static void C_fcall trf_1374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1374(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1374(t0,t1,t2,t3);}

C_noret_decl(trf_1366)
static void C_fcall trf_1366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1366(t0,t1,t2);}

C_noret_decl(trf_1349)
static void C_fcall trf_1349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1349(t0,t1,t2);}

C_noret_decl(trf_1309)
static void C_fcall trf_1309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1309(t0,t1,t2);}

C_noret_decl(trf_1315)
static void C_fcall trf_1315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1315(t0,t1,t2);}

C_noret_decl(trf_1229)
static void C_fcall trf_1229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1229(t0,t1);}

C_noret_decl(trf_1190)
static void C_fcall trf_1190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1190(t0,t1);}

C_noret_decl(trf_1168)
static void C_fcall trf_1168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1168(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1168(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1153)
static void C_fcall trf_1153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1153(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1153(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1131)
static void C_fcall trf_1131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1131(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1131(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1113)
static void C_fcall trf_1113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1113(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1113(t0,t1,t2,t3);}

C_noret_decl(trf_1005)
static void C_fcall trf_1005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1005(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2610)){
C_save(t1);
C_rereclaim2(2610*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,345);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[4]=C_h_intern(&lf[4],19,"compile-source-file");
lf[5]=C_h_intern(&lf[5],4,"quit");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[8]=C_h_intern(&lf[8],12,"explicit-use");
lf[9]=C_h_intern(&lf[9],26,"\010compilerexplicit-use-flag");
lf[10]=C_h_intern(&lf[10],12,"\004coredeclare");
lf[11]=C_h_intern(&lf[11],7,"verbose");
lf[12]=C_h_intern(&lf[12],11,"output-file");
lf[13]=C_h_intern(&lf[13],36,"\010compilerdefault-optimization-passes");
lf[14]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[15]=C_h_intern(&lf[15],7,"profile");
lf[16]=C_h_intern(&lf[16],12,"profile-name");
lf[17]=C_h_intern(&lf[17],9,"heap-size");
lf[18]=C_h_intern(&lf[18],17,"heap-initial-size");
lf[19]=C_h_intern(&lf[19],11,"heap-growth");
lf[20]=C_h_intern(&lf[20],14,"heap-shrinkage");
lf[21]=C_h_intern(&lf[21],13,"keyword-style");
lf[22]=C_h_intern(&lf[22],4,"unit");
lf[23]=C_h_intern(&lf[23],12,"analyze-only");
lf[24]=C_h_intern(&lf[24],7,"dynamic");
lf[25]=C_h_intern(&lf[25],5,"quiet");
lf[26]=C_h_intern(&lf[26],7,"nursery");
lf[27]=C_h_intern(&lf[27],10,"stack-size");
lf[28]=C_h_intern(&lf[28],26,"\010compilerdebugging-chicken");
lf[29]=C_h_intern(&lf[29],6,"printf");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[32]=C_h_intern(&lf[32],19,"\010compilerdump-nodes");
lf[33]=C_h_intern(&lf[33],12,"pretty-print");
lf[34]=C_h_intern(&lf[34],30,"\010compilerbuild-expression-tree");
lf[35]=C_h_intern(&lf[35],34,"\010compilerdisplay-analysis-database");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[37]=C_h_intern(&lf[37],12,"\003sysfor-each");
lf[38]=C_h_intern(&lf[38],19,"\003syshash-table-set!");
lf[39]=C_h_intern(&lf[39],24,"\003sysline-number-database");
lf[40]=C_h_intern(&lf[40],10,"alist-cons");
lf[41]=C_h_intern(&lf[41],18,"\003syshash-table-ref");
lf[42]=C_h_intern(&lf[42],9,"list-info");
lf[43]=C_h_intern(&lf[43],26,"\003sysdefault-read-info-hook");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[45]=C_h_intern(&lf[45],9,"substring");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[47]=C_h_intern(&lf[47],8,"\003sysread");
lf[48]=C_h_intern(&lf[48],12,"\010compilerget");
lf[49]=C_h_intern(&lf[49],13,"\010compilerput!");
lf[50]=C_h_intern(&lf[50],27,"\010compileranalyze-expression");
lf[51]=C_h_intern(&lf[51],9,"\003syserror");
lf[52]=C_h_intern(&lf[52],1,"D");
lf[53]=C_h_intern(&lf[53],25,"\010compilerimport-libraries");
lf[54]=C_h_intern(&lf[54],26,"\010compilerdisabled-warnings");
lf[55]=C_h_intern(&lf[55],12,"inline-limit");
lf[56]=C_h_intern(&lf[56],21,"\010compilerverbose-mode");
lf[57]=C_h_intern(&lf[57],31,"\003sysread-error-with-line-number");
lf[58]=C_h_intern(&lf[58],21,"\003sysinclude-pathnames");
lf[59]=C_h_intern(&lf[59],19,"\000compiler-extension");
lf[60]=C_h_intern(&lf[60],12,"\003sysfeatures");
lf[61]=C_h_intern(&lf[61],10,"\000compiling");
lf[62]=C_h_intern(&lf[62],15,"lset-difference");
lf[63]=C_h_intern(&lf[63],3,"eq\077");
lf[64]=C_h_intern(&lf[64],7,"\003sysmap");
lf[65]=C_h_intern(&lf[65],14,"string->symbol");
lf[66]=C_h_intern(&lf[66],12,"string-split");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[68]=C_h_intern(&lf[68],10,"append-map");
lf[69]=C_h_intern(&lf[69],25,"\010compilertarget-heap-size");
lf[70]=C_h_intern(&lf[70],33,"\010compilertarget-initial-heap-size");
lf[71]=C_h_intern(&lf[71],27,"\010compilertarget-heap-growth");
lf[72]=C_h_intern(&lf[72],30,"\010compilertarget-heap-shrinkage");
lf[73]=C_h_intern(&lf[73],26,"\010compilertarget-stack-size");
lf[74]=C_h_intern(&lf[74],8,"no-trace");
lf[75]=C_h_intern(&lf[75],24,"\010compileremit-trace-info");
lf[76]=C_h_intern(&lf[76],29,"disable-stack-overflow-checks");
lf[77]=C_h_intern(&lf[77],40,"\010compilerdisable-stack-overflow-checking");
lf[78]=C_h_intern(&lf[78],7,"version");
lf[79]=C_h_intern(&lf[79],7,"newline");
lf[80]=C_h_intern(&lf[80],22,"\010compilerprint-version");
lf[81]=C_h_intern(&lf[81],4,"help");
lf[82]=C_h_intern(&lf[82],20,"\010compilerprint-usage");
lf[83]=C_h_intern(&lf[83],7,"release");
lf[84]=C_h_intern(&lf[84],7,"display");
lf[85]=C_h_intern(&lf[85],15,"chicken-version");
lf[86]=C_h_intern(&lf[86],24,"\010compilersource-filename");
lf[87]=C_h_intern(&lf[87],28,"\010compilerprofile-lambda-list");
lf[88]=C_h_intern(&lf[88],31,"\010compilerline-number-database-2");
lf[89]=C_h_intern(&lf[89],23,"\010compilerconstant-table");
lf[90]=C_h_intern(&lf[90],21,"\010compilerinline-table");
lf[91]=C_h_intern(&lf[91],23,"\010compilerfirst-analysis");
lf[92]=C_h_intern(&lf[92],41,"\010compilerperform-high-level-optimizations");
lf[93]=C_h_intern(&lf[93],37,"\010compilerinline-substitutions-enabled");
lf[94]=C_h_intern(&lf[94],22,"optimize-leaf-routines");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[96]=C_h_intern(&lf[96],34,"\010compilertransform-direct-lambdas!");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[98]=C_h_intern(&lf[98],4,"leaf");
lf[99]=C_h_intern(&lf[99],18,"\010compilerdebugging");
lf[100]=C_h_intern(&lf[100],1,"p");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[103]=C_h_intern(&lf[103],1,"5");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[106]=C_h_intern(&lf[106],36,"\010compilerprepare-for-code-generation");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[108]=C_h_intern(&lf[108],30,"\010compilercompiler-cleanup-hook");
lf[109]=C_h_intern(&lf[109],1,"t");
lf[110]=C_h_intern(&lf[110],17,"\003sysdisplay-times");
lf[111]=C_h_intern(&lf[111],14,"\003sysstop-timer");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[113]=C_h_intern(&lf[113],17,"close-output-port");
lf[114]=C_h_intern(&lf[114],22,"\010compilergenerate-code");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[116]=C_h_intern(&lf[116],16,"open-output-file");
lf[117]=C_h_intern(&lf[117],19,"current-output-port");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[120]=C_h_intern(&lf[120],1,"9");
lf[121]=C_h_intern(&lf[121],4,"exit");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000$(do not worry - still compiling...)\012");
lf[123]=C_h_intern(&lf[123],20,"\003syswarnings-enabled");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[125]=C_h_intern(&lf[125],1,"8");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[127]=C_h_intern(&lf[127],35,"\010compilerperform-closure-conversion");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[129]=C_h_intern(&lf[129],1,"7");
lf[130]=C_h_intern(&lf[130],1,"s");
lf[131]=C_h_intern(&lf[131],33,"\010compilerprint-program-statistics");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[133]=C_h_intern(&lf[133],1,"4");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[135]=C_h_intern(&lf[135],1,"u");
lf[136]=C_h_intern(&lf[136],31,"\010compilerdump-undefined-globals");
lf[137]=C_h_intern(&lf[137],3,"opt");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[139]=C_h_intern(&lf[139],1,"3");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[141]=C_h_intern(&lf[141],31,"\010compilerperform-cps-conversion");
lf[142]=C_h_intern(&lf[142],6,"unsafe");
lf[143]=C_h_intern(&lf[143],34,"\010compilerscan-toplevel-assignments");
lf[144]=C_h_intern(&lf[144],26,"\010compilerdo-lambda-lifting");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[146]=C_h_intern(&lf[146],1,"L");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[148]=C_h_intern(&lf[148],32,"\010compilerperform-lambda-lifting!");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[151]=C_h_intern(&lf[151],1,"0");
lf[152]=C_h_intern(&lf[152],4,"lift");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[154]=C_h_intern(&lf[154],1,"U");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[158]=C_h_intern(&lf[158],4,"user");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[160]=C_h_intern(&lf[160],6,"append");
lf[161]=C_h_intern(&lf[161],12,"vector->list");
lf[162]=C_h_intern(&lf[162],26,"\010compilerfile-requirements");
lf[163]=C_h_intern(&lf[163],1,"M");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[165]=C_h_intern(&lf[165],11,"user-pass-2");
lf[166]=C_h_intern(&lf[166],4,"node");
lf[167]=C_h_intern(&lf[167],6,"lambda");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[169]=C_h_intern(&lf[169],25,"\010compilerbuild-node-graph");
lf[170]=C_h_intern(&lf[170],32,"\010compilercanonicalize-begin-body");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[173]=C_h_intern(&lf[173],9,"user-pass");
lf[174]=C_h_intern(&lf[174],12,"check-syntax");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[176]=C_h_intern(&lf[176],1,"2");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[178]=C_h_intern(&lf[178],25,"\010compilercompiler-warning");
lf[179]=C_h_intern(&lf[179],5,"style");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[181]=C_h_intern(&lf[181],8,"feature\077");
lf[182]=C_h_intern(&lf[182],19,"compiling-extension");
lf[183]=C_h_intern(&lf[183],18,"\010compilerunit-name");
lf[184]=C_h_intern(&lf[184],5,"usage");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[186]=C_h_intern(&lf[186],26,"\010compilerblock-compilation");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[188]=C_h_intern(&lf[188],37,"\010compilerdisplay-line-number-database");
lf[189]=C_h_intern(&lf[189],1,"n");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[191]=C_h_intern(&lf[191],32,"\010compilerdisplay-real-name-table");
lf[192]=C_h_intern(&lf[192],1,"N");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[194]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[195]=C_h_intern(&lf[195],5,"quote");
lf[196]=C_h_intern(&lf[196],33,"\010compilerprofile-info-vector-name");
lf[197]=C_h_intern(&lf[197],28,"\003sysset-profile-info-vector!");
lf[198]=C_h_intern(&lf[198],21,"\010compileremit-profile");
lf[199]=C_h_intern(&lf[199],25,"\003sysregister-profile-info");
lf[200]=C_h_intern(&lf[200],4,"set!");
lf[201]=C_h_intern(&lf[201],13,"\004corecallunit");
lf[202]=C_h_intern(&lf[202],19,"\010compilerused-units");
lf[203]=C_h_intern(&lf[203],28,"\010compilerimmutable-constants");
lf[204]=C_h_intern(&lf[204],6,"gensym");
lf[205]=C_h_intern(&lf[205],32,"\010compilercanonicalize-expression");
lf[206]=C_h_intern(&lf[206],28,"\003sysexplicit-library-modules");
lf[207]=C_h_intern(&lf[207],4,"uses");
lf[208]=C_h_intern(&lf[208],7,"declare");
lf[209]=C_h_intern(&lf[209],10,"\003sysappend");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[211]=C_h_intern(&lf[211],1,"1");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[213]=C_h_intern(&lf[213],22,"user-preprocessor-pass");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[215]=C_h_intern(&lf[215],21,"\010compilerstring->expr");
lf[216]=C_h_intern(&lf[216],7,"reverse");
lf[217]=C_h_intern(&lf[217],27,"\003syscurrent-source-filename");
lf[218]=C_h_intern(&lf[218],33,"\010compilerclose-checked-input-file");
lf[219]=C_h_intern(&lf[219],16,"\003sysdynamic-wind");
lf[220]=C_h_intern(&lf[220],34,"\010compilercheck-and-open-input-file");
lf[221]=C_h_intern(&lf[221],14,"user-read-pass");
lf[222]=C_h_intern(&lf[222],8,"epilogue");
lf[223]=C_h_intern(&lf[223],8,"prologue");
lf[224]=C_h_intern(&lf[224],8,"postlude");
lf[225]=C_h_intern(&lf[225],7,"prelude");
lf[226]=C_h_intern(&lf[226],11,"make-vector");
lf[227]=C_h_intern(&lf[227],34,"\010compilerline-number-database-size");
lf[228]=C_h_intern(&lf[228],1,"r");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[235]=C_h_intern(&lf[235],5,"-help");
lf[236]=C_h_intern(&lf[236],1,"h");
lf[237]=C_h_intern(&lf[237],2,"-h");
lf[238]=C_h_intern(&lf[238],18,"accumulate-profile");
lf[239]=C_h_intern(&lf[239],28,"\010compilerprofiled-procedures");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[244]=C_h_intern(&lf[244],39,"\010compilerdefault-profiling-declarations");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\012stacktrace");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[248]=C_h_intern(&lf[248],21,"no-usual-integrations");
lf[249]=C_h_intern(&lf[249],17,"standard-bindings");
lf[250]=C_h_intern(&lf[250],34,"\010compilerdefault-standard-bindings");
lf[251]=C_h_intern(&lf[251],17,"extended-bindings");
lf[252]=C_h_intern(&lf[252],34,"\010compilerdefault-extended-bindings");
lf[253]=C_h_intern(&lf[253],1,"m");
lf[254]=C_h_intern(&lf[254],14,"set-gc-report!");
lf[255]=C_h_intern(&lf[255],42,"\010compilerdefault-default-target-stack-size");
lf[256]=C_h_intern(&lf[256],41,"\010compilerdefault-default-target-heap-size");
lf[257]=C_h_intern(&lf[257],14,"compile-syntax");
lf[258]=C_h_intern(&lf[258],25,"\003sysenable-runtime-macros");
lf[259]=C_h_intern(&lf[259],22,"\004corerequire-extension");
lf[260]=C_h_intern(&lf[260],17,"require-extension");
lf[261]=C_h_intern(&lf[261],9,"extension");
lf[262]=C_h_intern(&lf[262],16,"define-extension");
lf[263]=C_h_intern(&lf[263],13,"pathname-file");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[265]=C_h_intern(&lf[265],28,"\010compilerpostponed-initforms");
lf[266]=C_h_intern(&lf[266],23,"user-post-analysis-pass");
lf[267]=C_h_intern(&lf[267],6,"delete");
lf[268]=C_h_intern(&lf[268],4,"load");
lf[269]=C_h_intern(&lf[269],28,"\003sysresolve-include-filename");
lf[270]=C_h_intern(&lf[270],12,"load-verbose");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[272]=C_h_intern(&lf[272],6,"extend");
lf[273]=C_h_intern(&lf[273],17,"register-feature!");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[275]=C_h_intern(&lf[275],7,"feature");
lf[276]=C_h_intern(&lf[276],20,"keep-shadowed-macros");
lf[277]=C_h_intern(&lf[277],33,"\010compilerundefine-shadowed-macros");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[280]=C_h_intern(&lf[280],23,"\010compilerchop-separator");
lf[281]=C_h_intern(&lf[281],12,"include-path");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[283]=C_h_intern(&lf[283],7,"\000prefix");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[285]=C_h_intern(&lf[285],5,"\000none");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[287]=C_h_intern(&lf[287],7,"\000suffix");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[289]=C_h_intern(&lf[289],17,"compress-literals");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[291]=C_h_intern(&lf[291],16,"case-insensitive");
lf[292]=C_h_intern(&lf[292],14,"case-sensitive");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[294]=C_h_intern(&lf[294],24,"\010compilerinline-max-size");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[296]=C_h_intern(&lf[296],6,"inline");
lf[297]=C_h_intern(&lf[297],30,"emit-external-prototypes-first");
lf[298]=C_h_intern(&lf[298],30,"\010compilerexternal-protos-first");
lf[299]=C_h_intern(&lf[299],5,"block");
lf[300]=C_h_intern(&lf[300],17,"fixnum-arithmetic");
lf[301]=C_h_intern(&lf[301],11,"number-type");
lf[302]=C_h_intern(&lf[302],6,"fixnum");
lf[303]=C_h_intern(&lf[303],18,"disable-interrupts");
lf[304]=C_h_intern(&lf[304],28,"\010compilerinsert-timer-checks");
lf[305]=C_h_intern(&lf[305],16,"unsafe-libraries");
lf[306]=C_h_intern(&lf[306],27,"\010compileremit-unsafe-marker");
lf[307]=C_h_intern(&lf[307],11,"no-warnings");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[309]=C_h_intern(&lf[309],15,"disable-warning");
lf[310]=C_h_intern(&lf[310],6,"import");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000#deprecated compiler option: -import");
lf[312]=C_h_intern(&lf[312],13,"check-imports");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000*deprecated compiler option: -check-imports");
lf[314]=C_h_intern(&lf[314],14,"no-lambda-info");
lf[315]=C_h_intern(&lf[315],26,"\010compileremit-closure-info");
lf[316]=C_h_intern(&lf[316],3,"raw");
lf[317]=C_h_intern(&lf[317],12,"emit-exports");
lf[318]=C_h_intern(&lf[318],7,"warning");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[320]=C_h_intern(&lf[320],1,"b");
lf[321]=C_h_intern(&lf[321],15,"\003sysstart-timer");
lf[322]=C_h_intern(&lf[322],23,"disable-compiler-macros");
lf[323]=C_h_intern(&lf[323],32,"\010compilercompiler-macros-enabled");
lf[324]=C_h_intern(&lf[324],11,"lambda-lift");
lf[325]=C_h_intern(&lf[325],13,"string-append");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[327]=C_h_intern(&lf[327],19,"emit-import-library");
lf[328]=C_h_intern(&lf[328],16,"\003sysstring->list");
lf[329]=C_h_intern(&lf[329],5,"debug");
lf[330]=C_h_intern(&lf[330],30,"\010compilerstandalone-executable");
lf[331]=C_h_intern(&lf[331],29,"\010compilerstring->c-identifier");
lf[332]=C_h_intern(&lf[332],18,"\010compilerstringify");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[335]=C_h_intern(&lf[335],6,"getenv");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[337]=C_h_intern(&lf[337],14,"symbol->string");
lf[338]=C_h_intern(&lf[338],9,"to-stdout");
lf[339]=C_h_intern(&lf[339],13,"make-pathname");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[342]=C_h_intern(&lf[342],29,"\010compilerdefault-declarations");
lf[343]=C_h_intern(&lf[343],30,"\010compilerunits-used-by-default");
lf[344]=C_h_intern(&lf[344],28,"\010compilerinitialize-compiler");
C_register_lf2(lf,345,create_ptable());
t2=C_mutate(&lf[0] /* c354 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k982 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k985 in k982 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k988 in k985 in k982 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k991 in k988 in k985 in k982 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=C_mutate(&lf[2] /* constant49 ...) */,lf[3]);
t3=C_mutate((C_word*)lf[4]+1 /* compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1002,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1002r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1002r(t0,t1,t2,t3);}}

static void C_ccall f_1002r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1005,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1038,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 93   initialize-compiler");
t6=C_retrieve(lf[344]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(C_word)C_i_memq(lf[8],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[9]+1 /* explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3108,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[9]))){
t7=t6;
f_3112(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3123,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#append");
t8=*((C_word*)lf[209]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[343]),C_SCHEME_END_OF_LIST);}}

/* k3121 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3123,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[207],t1);
t3=((C_word*)t0)[2];
f_3112(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3110 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_3112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 96   append");
t2=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[342]),t1);}

/* k3106 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[209]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[11],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[12],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 104  option-arg");
f_1005(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[338],((C_word*)t0)[5]))){
t9=t8;
f_1054(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("batch-driver.scm: 109  pathname-file");
t10=C_retrieve(lf[263]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3093(2,t10,lf[341]);}}}}

/* k3091 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 109  make-pathname");
t2=C_retrieve(lf[339]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[340]);}

/* k3069 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
C_trace("batch-driver.scm: 106  symbol->string");
t2=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1054(2,t2,t1);}}

/* k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1057,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 110  getenv");
t5=C_retrieve(lf[335]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[336]);}

/* k3063 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[333]);
C_trace("batch-driver.scm: 110  string-split");
t3=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[334]);}

/* k3059 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[280]),t1);}

/* k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=C_retrieve(lf[13]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[14];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[15],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1063,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1063(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[238],((C_word*)t0)[8]);
t14=t12;
f_1063(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[16],((C_word*)t0)[8])));}}

/* k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1063,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[16],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[3]);
t5=(C_word)C_i_memq(lf[17],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[27],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1107,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1131,a[2]=t25,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1168,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1180,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1229,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1372,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t30,a[11]=t23,a[12]=t1,a[13]=t34,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t28,a[18]=t27,a[19]=t13,a[20]=t17,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t26,a[24]=t35,a[25]=t33,a[26]=t32,a[27]=t19,a[28]=t24,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=t31,a[32]=((C_word*)t0)[8],a[33]=t21,a[34]=t11,a[35]=((C_word*)t0)[12],a[36]=((C_word*)t0)[13],a[37]=t16,tmp=(C_word)a,a+=38,tmp);
if(C_truep(t12)){
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3038,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 205  option-arg");
f_1005(t39,t12);}
else{
t37=t36;
f_1451(t37,C_SCHEME_UNDEFINED);}}

/* k3040 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 205  stringify");
t2=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3036 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 205  string->c-identifier");
t2=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3032 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[183]+1 /* unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1451(t3,t2);}

/* k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1451,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=C_retrieve(lf[183]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[330] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1454(t6,t5);}
else{
t5=t2;
f_1454(t5,C_SCHEME_UNDEFINED);}}

/* k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1454,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3004,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3026,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 213  collect-options");
t5=((C_word*)t0)[31];
f_1309(t5,t4,lf[329]);}

/* k3024 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 209  append-map");
t2=C_retrieve(lf[68]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3003 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3004,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3010,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3022,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("string->list");
t5=C_retrieve(lf[328]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3020 in a3003 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3009 in a3003 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3010,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
C_trace("batch-driver.scm: 211  string->symbol");
t4=*((C_word*)lf[65]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[52],C_retrieve(lf[28]));
t4=C_mutate(((C_word *)((C_word*)t0)[37])+1,t3);
t5=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2986,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3002,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 219  collect-options");
t8=((C_word*)t0)[31];
f_1309(t8,t7,lf[327]);}

/* k3000 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2985 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 217  string->symbol");
t4=*((C_word*)lf[65]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2992 in a2985 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2998,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 218  string-append");
t3=*((C_word*)lf[325]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[326]);}

/* k2996 in k2992 in a2985 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
t2=C_mutate((C_word*)lf[53]+1 /* import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[324],((C_word*)t0)[36]))){
t4=C_set_block_item(lf[144] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1469(t5,t4);}
else{
t4=t3;
f_1469(t4,C_SCHEME_UNDEFINED);}}

/* k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1469,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[36]))){
t3=C_set_block_item(lf[323] /* compiler-macros-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_1472(t4,t3);}
else{
t3=t2;
f_1472(t3,C_SCHEME_UNDEFINED);}}

/* k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1472,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[28])))){
C_trace("batch-driver.scm: 222  ##sys#start-timer");
t3=*((C_word*)lf[321]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1475(2,t3,C_SCHEME_UNDEFINED);}}

/* k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[320],C_retrieve(lf[28])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1478(t4,t3);}
else{
t3=t2;
f_1478(t3,C_SCHEME_UNDEFINED);}}

/* k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1478,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[35]))){
C_trace("batch-driver.scm: 225  warning");
t3=C_retrieve(lf[318]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[319]);}
else{
t3=t2;
f_1481(2,t3,C_SCHEME_UNDEFINED);}}

/* k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[316],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[9] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[31],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1484(t6,t5);}
else{
t3=t2;
f_1484(t3,C_SCHEME_UNDEFINED);}}

/* k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1484,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[314],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[315] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1487(t4,t3);}
else{
t3=t2;
f_1487(t3,C_SCHEME_UNDEFINED);}}

/* k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1487,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[35]))){
C_trace("batch-driver.scm: 233  compiler-warning");
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[184],lf[313]);}
else{
t3=t2;
f_1490(2,t3,C_SCHEME_UNDEFINED);}}

/* k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[310],((C_word*)t0)[35]))){
C_trace("batch-driver.scm: 235  compiler-warning");
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[184],lf[311]);}
else{
t3=t2;
f_1493(2,t3,C_SCHEME_UNDEFINED);}}

/* k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 236  collect-options");
t4=((C_word*)t0)[30];
f_1309(t4,t3,lf[309]);}

/* k2936 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[65]+1),t1);}

/* k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=C_mutate((C_word*)lf[54]+1 /* disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[307],((C_word*)t0)[35]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2930,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
C_trace("batch-driver.scm: 238  printf");
t5=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[308]);}
else{
t5=t4;
f_2930(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1500(t4,C_SCHEME_UNDEFINED);}}

/* k2928 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[123] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1500(t3,t2);}

/* k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1500,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[94],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[94] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1503(t4,t3);}
else{
t3=t2;
f_1503(t3,C_SCHEME_UNDEFINED);}}

/* k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1503,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[142],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[142] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1506(t4,t3);}
else{
t3=t2;
f_1506(t3,C_SCHEME_UNDEFINED);}}

/* k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1506,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[305],((C_word*)t0)[35]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[306] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1509(t5,t4);}
else{
t4=t2;
f_1509(t4,C_SCHEME_UNDEFINED);}}

/* k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[303],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[304] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1512(t4,t3);}
else{
t3=t2;
f_1512(t3,C_SCHEME_UNDEFINED);}}

/* k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[300],((C_word*)t0)[35]))){
t3=C_mutate((C_word*)lf[301]+1 /* number-type ...) */,lf[302]);
t4=t2;
f_1515(t4,t3);}
else{
t3=t2;
f_1515(t3,C_SCHEME_UNDEFINED);}}

/* k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1515,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[299],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[186] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1518(t4,t3);}
else{
t3=t2;
f_1518(t3,C_SCHEME_UNDEFINED);}}

/* k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1518,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[297],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[298] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1521(t4,t3);}
else{
t3=t2;
f_1521(t3,C_SCHEME_UNDEFINED);}}

/* k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[296],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[294] /* inline-max-size */,0,C_fix(10));
t4=t2;
f_1524(t4,t3);}
else{
t3=t2;
f_1524(t3,C_SCHEME_UNDEFINED);}}

/* k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[55],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[35],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 252  option-arg");
f_1005(t4,t2);}
else{
t4=t3;
f_1530(t4,C_SCHEME_FALSE);}}

/* k2878 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2883,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 253  string->number");
C_string_to_number(3,0,t2,t1);}

/* k2881 in k2878 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2886(2,t3,t1);}
else{
C_trace("batch-driver.scm: 254  quit");
t3=C_retrieve(lf[5]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[295],((C_word*)t0)[2]);}}

/* k2884 in k2881 in k2878 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[294]+1 /* inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1530(t3,t2);}

/* k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1530,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[291],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2867,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[35])){
C_trace("batch-driver.scm: 256  printf");
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[293]);}
else{
t4=t3;
f_2867(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1533(2,t3,C_SCHEME_UNDEFINED);}}

/* k2865 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 257  register-feature!");
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[291]);}

/* k2868 in k2865 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 258  case-sensitive");
t2=C_retrieve(lf[292]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[289],((C_word*)t0)[30]))){
C_trace("batch-driver.scm: 260  compiler-warning");
t3=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[184],lf[290]);}
else{
t3=t2;
f_1536(2,t3,C_SCHEME_UNDEFINED);}}

/* k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2825,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 262  option-arg");
f_1005(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1539(2,t3,C_SCHEME_UNDEFINED);}}

/* k2823 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[282],t1))){
C_trace("batch-driver.scm: 263  keyword-style");
t2=C_retrieve(lf[21]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[283]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[284],t1))){
C_trace("batch-driver.scm: 264  keyword-style");
t2=C_retrieve(lf[21]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[285]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[286],t1))){
C_trace("batch-driver.scm: 265  keyword-style");
t2=C_retrieve(lf[21]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[287]);}
else{
C_trace("batch-driver.scm: 266  quit");
t2=C_retrieve(lf[5]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[288]);}}}}

/* k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* verbose-mode ...) */,((C_word*)t0)[34]);
t3=C_set_block_item(lf[57] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[34],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 270  collect-options");
t7=((C_word*)t0)[30];
f_1309(t7,t6,lf[281]);}

/* k2820 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[280]),t1);}

/* k2816 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 270  append");
t2=*((C_word*)lf[160]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[58]),((C_word*)t0)[2]);}

/* k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t4=(C_truep(((C_word*)t0)[19])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[19],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
C_trace("batch-driver.scm: 274  quit");
t5=C_retrieve(lf[5]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[279]);}
else{
t5=t3;
f_1548(2,t5,C_SCHEME_UNDEFINED);}}

/* k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2792,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2794,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2802,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 279  collect-options");
t6=((C_word*)t0)[30];
f_1309(t6,t5,lf[207]);}

/* k2800 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 277  append-map");
t2=C_retrieve(lf[68]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2793 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2794,3,t0,t1,t2);}
C_trace("string-split");
t3=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[278]);}

/* k2790 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[65]+1),t1);}

/* k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[276],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[277] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1555(t5,t4);}
else{
t4=t3;
f_1555(t4,C_SCHEME_UNDEFINED);}}

/* k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2774,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2776,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 286  collect-options");
t6=((C_word*)t0)[30];
f_1309(t6,t5,lf[275]);}

/* k2782 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 286  append-map");
t2=C_retrieve(lf[68]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2775 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2776,3,t0,t1,t2);}
C_trace("string-split");
t3=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[274]);}

/* k2772 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[273]),t1);}

/* k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[59],C_retrieve(lf[60]));
t3=C_mutate((C_word*)lf[60]+1 /* features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
C_trace("batch-driver.scm: 290  collect-options");
t5=((C_word*)t0)[30];
f_1309(t5,t4,lf[272]);}

/* k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1568,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[20])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 292  printf");
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[271]);}
else{
t3=t2;
f_1568(2,t3,C_SCHEME_UNDEFINED);}}

/* k2765 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 293  load-verbose");
t2=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2756,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t4=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2755 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2756,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 294  ##sys#resolve-include-filename");
t4=C_retrieve(lf[269]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2762 in a2755 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 294  load");
t2=C_retrieve(lf[268]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
C_trace("batch-driver.scm: 295  delete");
t3=C_retrieve(lf[267]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[59],C_retrieve(lf[60]),*((C_word*)lf[63]+1));}

/* k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],C_retrieve(lf[60]));
t4=C_mutate((C_word*)lf[60]+1 /* features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
C_trace("batch-driver.scm: 298  user-post-analysis-pass");
t6=C_retrieve(lf[266]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
C_trace("batch-driver.scm: 301  append");
t4=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[32])[1],C_retrieve(lf[265]));}

/* k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[261],((C_word*)t0)[29]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2722,a[2]=t3,a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[32],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2742,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[19])){
C_trace("batch-driver.scm: 310  pathname-file");
t7=C_retrieve(lf[263]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[19]);}
else{
if(C_truep(((C_word*)t0)[27])){
C_trace("batch-driver.scm: 311  pathname-file");
t7=C_retrieve(lf[263]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[27]);}
else{
C_trace("batch-driver.scm: 312  quit");
t7=C_retrieve(lf[5]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[264]);}}}
else{
t4=t3;
f_1590(t4,C_SCHEME_UNDEFINED);}}

/* k2740 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 309  string->symbol");
t2=*((C_word*)lf[65]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2736 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2738,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[262],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
C_trace("batch-driver.scm: 306  append");
t5=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}

/* k2720 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1590(t3,t2);}

/* k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1590,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[31],a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[31],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],tmp=(C_word)a,a+=33,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[30],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2695,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2715,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 328  ids");
t7=t2;
f_1592(t7,t6,lf[260]);}

/* k2713 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2694 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2695,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[259],t5));}

/* k2691 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 325  append");
t2=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[32],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[257],((C_word*)t0)[31]))){
t4=C_set_block_item(lf[258] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1621(t5,t4);}
else{
t4=t3;
f_1621(t4,C_SCHEME_UNDEFINED);}}

/* k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1621,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2672,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 334  option-arg");
f_1005(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[256]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1625(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1625(2,t4,C_SCHEME_FALSE);}}}

/* k2670 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 334  arg-val");
f_1229(((C_word*)t0)[2],t1);}

/* k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2665,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 338  option-arg");
f_1005(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1629(2,t4,C_SCHEME_FALSE);}}

/* k2663 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 338  arg-val");
f_1229(((C_word*)t0)[2],t1);}

/* k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 339  option-arg");
f_1005(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1633(2,t4,C_SCHEME_FALSE);}}

/* k2656 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 339  arg-val");
f_1229(((C_word*)t0)[2],t1);}

/* k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2651,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 340  option-arg");
f_1005(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1637(2,t4,C_SCHEME_FALSE);}}

/* k2649 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 340  arg-val");
f_1229(((C_word*)t0)[2],t1);}

/* k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2631,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 343  option-arg");
f_1005(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[255]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1641(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1641(2,t5,C_SCHEME_FALSE);}}}

/* k2629 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 343  arg-val");
f_1229(((C_word*)t0)[2],t1);}

/* k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[74],((C_word*)t0)[25]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[75]+1 /* emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[76],((C_word*)t0)[25]);
t7=C_mutate((C_word*)lf[77]+1 /* disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[253],C_retrieve(lf[28])))){
C_trace("batch-driver.scm: 349  set-gc-report!");
t9=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1652(2,t9,C_SCHEME_UNDEFINED);}}

/* k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[248],((C_word*)t0)[25]))){
t3=t2;
f_1655(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[249]+1 /* standard-bindings ...) */,C_retrieve(lf[250]));
t4=C_mutate((C_word*)lf[251]+1 /* extended-bindings ...) */,C_retrieve(lf[252]));
t5=t2;
f_1655(t5,t4);}}

/* k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1655,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[75]))?lf[245]:lf[246]);
C_trace("batch-driver.scm: 354  printf");
t4=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[247],t3);}
else{
t3=t2;
f_1658(2,t3,C_SCHEME_UNDEFINED);}}

/* k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[238],t3);
t5=C_set_block_item(lf[198] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_set_block_item(lf[239] /* profiled-procedures */,0,C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2584,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[243]:C_SCHEME_END_OF_LIST);
C_trace("batch-driver.scm: 363  append");
t9=*((C_word*)lf[160]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[244]),t8);}
else{
t3=t2;
f_1661(2,t3,C_SCHEME_UNDEFINED);}}

/* k2582 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[240]:lf[241]);
C_trace("batch-driver.scm: 370  printf");
t4=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[242],t3);}
else{
t3=((C_word*)t0)[2];
f_1661(2,t3,C_SCHEME_UNDEFINED);}}

/* k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1661,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[78],((C_word*)t0)[24]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 373  print-version");
t3=C_retrieve(lf[80]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[81],((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(t2)){
t4=t3;
f_1682(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[235],((C_word*)t0)[24]);
if(C_truep(t4)){
t5=t3;
f_1682(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[236],((C_word*)t0)[24]);
t6=t3;
f_1682(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[237],((C_word*)t0)[24])));}}}}

/* k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1682,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("batch-driver.scm: 376  print-usage");
t2=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[24]);}
else{
if(C_truep((C_word)C_i_memq(lf[83],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 378  chicken-version");
t4=C_retrieve(lf[85]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[22];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1719(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("batch-driver.scm: 388  printf");
t4=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[233],((C_word*)t0)[22]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 382  print-version");
t4=C_retrieve(lf[80]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1711 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 383  display");
t2=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[234]);}

/* k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* source-filename ...) */,((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[24],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
C_trace("batch-driver.scm: 390  debugging");
t4=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[228],lf[232],((C_word*)t0)[10]);}

/* k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("batch-driver.scm: 391  debugging");
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[228],lf[231],C_retrieve(lf[28]));}

/* k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("batch-driver.scm: 392  debugging");
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[228],lf[230],C_retrieve(lf[69]));}

/* k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("batch-driver.scm: 393  debugging");
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[228],lf[229],C_retrieve(lf[73]));}

/* k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=f_1107();
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
C_trace("batch-driver.scm: 397  make-vector");
t5=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[227]),C_SCHEME_END_OF_LIST);}

/* k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1740,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1 /* line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("batch-driver.scm: 398  collect-options");
t4=((C_word*)t0)[2];
f_1309(t4,t3,lf[225]);}

/* k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
C_trace("batch-driver.scm: 399  collect-options");
t3=((C_word*)t0)[2];
f_1309(t3,t2,lf[224]);}

/* k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 401  collect-options");
t4=((C_word*)t0)[2];
f_1309(t4,t3,lf[223]);}

/* k2547 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2557,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 403  collect-options");
t4=((C_word*)t0)[2];
f_1309(t4,t3,lf[222]);}

/* k2555 in k2547 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 400  append");
t2=*((C_word*)lf[160]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
C_trace("batch-driver.scm: 405  user-read-pass");
t3=C_retrieve(lf[221]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],a[22]=((C_word*)t0)[26],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[22])){
C_trace("batch-driver.scm: 407  printf");
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[214]);}
else{
t4=t3;
f_2452(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2464(t6,t2,((C_word*)t0)[4]);}}

/* doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_2464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2464,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2475,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[215]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 417  check-and-open-input-file");
t5=C_retrieve(lf[220]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2542,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#dynamic-wind");
t10=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2541 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[217]));
t3=C_mutate((C_word*)lf[217]+1 /* current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2509 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2514,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 419  read-form");
t3=((C_word*)t0)[2];
f_1366(t3,t2,((C_word*)t0)[5]);}

/* k2512 in a2509 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2519(t5,((C_word*)t0)[2],t1);}

/* doloop623 in k2512 in a2509 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_2519(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2519,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
C_trace("batch-driver.scm: 422  close-checked-input-file");
t3=C_retrieve(lf[218]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 420  read-form");
t6=((C_word*)t0)[2];
f_1366(t6,t5,((C_word*)t0)[6]);}}

/* k2538 in doloop623 in k2512 in a2509 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2519(t2,((C_word*)t0)[2],t1);}

/* a2504 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[217]));
t3=C_mutate((C_word*)lf[217]+1 /* current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2494 in k2491 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2464(t3,((C_word*)t0)[2],t2);}

/* k2477 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 414  reverse");
t3=*((C_word*)lf[216]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2481 in k2477 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2487,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[215]),((C_word*)t0)[2]);}

/* k2485 in k2481 in k2477 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 413  append");
t2=*((C_word*)lf[160]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2473 in doloop592 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2450 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 408  proc");
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2454 in k2450 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1755(2,t3,t2);}

/* k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 426  user-preprocessor-pass");
t3=C_retrieve(lf[213]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2442,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[18])){
C_trace("batch-driver.scm: 428  printf");
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[212]);}
else{
t4=t3;
f_2442(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1761(t3,C_SCHEME_UNDEFINED);}}

/* k2440 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2444 in k2440 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1761(t3,t2);}

/* k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1761,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 431  print-expr");
t3=((C_word*)t0)[7];
f_1168(t3,t2,lf[210],lf[211],((C_word*)((C_word*)t0)[3])[1]);}

/* k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=f_1339(((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1770(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 434  append");
t5=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[206]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2417 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=C_mutate((C_word*)lf[206]+1 /* explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[209]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2437 in k2417 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[207],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[208],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1770(t7,t6);}

/* k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1770,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2412,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 436  append");
t4=*((C_word*)lf[160]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2410 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[205]),t1);}

/* k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
C_trace("batch-driver.scm: 437  gensym");
t3=C_retrieve(lf[204]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[87]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2380,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[203]));}

/* a2379 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2380,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[195],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[200],t8));}

/* k2252 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2370,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[202]));}

/* a2369 in k2252 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2370,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[201],t3));}

/* k2256 in k2252 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[198]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[195],t3);
t5=(C_truep(C_retrieve(lf[183]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[195],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[199],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[196]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[200],t12);
t14=t2;
f_2262(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2262(t3,C_SCHEME_END_OF_LIST);}}

/* k2260 in k2256 in k2252 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_2262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2262,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2281,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[87]));}

/* a2280 in k2260 in k2256 in k2252 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2281,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[195],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[195],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[196]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[197],t11));}

/* k2264 in k2260 in k2256 in k2252 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[183]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
C_trace("batch-driver.scm: 439  append");
t5=*((C_word*)lf[160]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[194]);}

/* k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 460  debugging");
t6=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[192],lf[193]);}

/* k2245 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 461  display-real-name-table");
t2=C_retrieve(lf[191]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1785(2,t2,C_SCHEME_UNDEFINED);}}

/* k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2241,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 462  debugging");
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[189],lf[190]);}

/* k2239 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 463  display-line-number-database");
t2=C_retrieve(lf[188]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1788(2,t2,C_SCHEME_UNDEFINED);}}

/* k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[186]))?C_retrieve(lf[183]):C_SCHEME_FALSE);
if(C_truep(t3)){
C_trace("batch-driver.scm: 466  compiler-warning");
t4=C_retrieve(lf[178]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[184],lf[187],C_retrieve(lf[183]));}
else{
t4=t2;
f_1791(2,t4,C_SCHEME_UNDEFINED);}}

/* k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[183]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
C_trace("batch-driver.scm: 472  compiler-warning");
t4=C_retrieve(lf[178]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[184],lf[185],C_retrieve(lf[183]));}
else{
t4=t2;
f_1794(2,t4,C_SCHEME_UNDEFINED);}}

/* k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2220,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[142]))){
C_trace("batch-driver.scm: 474  feature?");
t4=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[182]);}
else{
t4=t3;
f_2220(2,t4,C_SCHEME_FALSE);}}

/* k2218 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 475  compiler-warning");
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[179],lf[180]);}
else{
t2=((C_word*)t0)[2];
f_1797(2,t2,C_SCHEME_UNDEFINED);}}

/* k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1 /* line-number-database ...) */,C_retrieve(lf[88]));
t3=C_set_block_item(lf[88] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
C_trace("batch-driver.scm: 482  end-time");
t5=((C_word*)t0)[17];
f_1349(t5,t4,lf[177]);}

/* k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 483  print-expr");
t3=((C_word*)t0)[2];
f_1168(t3,t2,lf[175],lf[176],((C_word*)((C_word*)t0)[4])[1]);}

/* k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[174],((C_word*)t0)[2]))){
C_trace("batch-driver.scm: 485  exit");
t3=C_retrieve(lf[121]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1808(2,t3,C_SCHEME_UNDEFINED);}}

/* k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 487  user-pass");
t3=C_retrieve(lf[173]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2198,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[12])){
C_trace("batch-driver.scm: 489  printf");
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[172]);}
else{
t4=t3;
f_2198(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1814(2,t3,C_SCHEME_UNDEFINED);}}

/* k2196 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=f_1339(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2203 in k2196 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
C_trace("batch-driver.scm: 492  end-time");
t3=((C_word*)t0)[3];
f_1349(t3,((C_word*)t0)[2],lf[171]);}

/* k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 497  canonicalize-begin-body");
t5=C_retrieve(lf[170]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2193 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 496  build-node-graph");
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2189 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2183,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[167],lf[168],t2);}

/* f_2183 in k2189 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2183,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[166],t2,t3,t4));}

/* k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1820,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 498  user-pass-2");
t3=C_retrieve(lf[165]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1823,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2167,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 499  debugging");
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[163],lf[164]);}

/* k2165 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 500  vector->list");
t4=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[162]));}
else{
t2=((C_word*)t0)[2];
f_1823(2,t2,C_SCHEME_UNDEFINED);}}

/* k2176 in k2165 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[160]+1),t1);}

/* k2172 in k2165 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 500  pretty-print");
t2=C_retrieve(lf[33]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],a[8]=t2,a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[13])){
C_trace("batch-driver.scm: 502  printf");
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[159]);}
else{
t4=t3;
f_2135(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1826(t3,C_SCHEME_UNDEFINED);}}

/* k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=f_1339(((C_word*)t0)[9]);
t3=C_set_block_item(lf[91] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("batch-driver.scm: 505  analyze");
t5=((C_word*)t0)[2];
f_1372(t5,t4,lf[158],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2140 in k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 506  print-db");
t3=((C_word*)t0)[2];
f_1153(t3,t2,lf[157],lf[151],t1,C_fix(0));}

/* k2143 in k2140 in k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 507  end-time");
t3=((C_word*)t0)[3];
f_1349(t3,t2,lf[156]);}

/* k2146 in k2143 in k2140 in k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=f_1339(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 509  proc");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2152 in k2146 in k2143 in k2140 in k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 510  end-time");
t3=((C_word*)t0)[2];
f_1349(t3,t2,lf[155]);}

/* k2155 in k2152 in k2146 in k2143 in k2140 in k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 511  print-node");
t3=((C_word*)t0)[3];
f_1131(t3,t2,lf[153],lf[154],((C_word*)t0)[2]);}

/* k2158 in k2155 in k2152 in k2146 in k2143 in k2140 in k2133 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1826(t3,t2);}

/* k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1826,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[144]))){
t3=f_1339(((C_word*)t0)[16]);
t4=C_set_block_item(lf[91] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 517  analyze");
t6=((C_word*)t0)[14];
f_1372(t6,t5,lf[152],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1829(t3,C_SCHEME_UNDEFINED);}}

/* k2111 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2116,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 518  print-db");
t3=((C_word*)t0)[2];
f_1153(t3,t2,lf[150],lf[151],t1,C_fix(0));}

/* k2114 in k2111 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 519  end-time");
t3=((C_word*)t0)[3];
f_1349(t3,t2,lf[149]);}

/* k2117 in k2114 in k2111 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=f_1339(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 521  perform-lambda-lifting!");
t4=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2123 in k2117 in k2114 in k2111 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 522  end-time");
t3=((C_word*)t0)[2];
f_1349(t3,t2,lf[147]);}

/* k2126 in k2123 in k2117 in k2114 in k2111 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 523  print-node");
t3=((C_word*)t0)[3];
f_1131(t3,t2,lf[145],lf[146],((C_word*)t0)[2]);}

/* k2129 in k2126 in k2123 in k2117 in k2114 in k2111 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[91] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1829(t3,t2);}

/* k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1829,NULL,2,t0,t1);}
t2=C_set_block_item(lf[39] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[89] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[90] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[142]))){
t6=t5;
f_1835(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2101,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2102,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2102 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2102,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2099 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
C_trace("batch-driver.scm: 530  scan-toplevel-assignments");
t3=C_retrieve(lf[143]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=f_1339(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
C_trace("batch-driver.scm: 533  perform-cps-conversion");
t4=C_retrieve(lf[141]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1844,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 534  end-time");
t3=((C_word*)t0)[14];
f_1349(t3,t2,lf[140]);}

/* k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 535  print-node");
t3=((C_word*)t0)[13];
f_1131(t3,t2,lf[138],lf[139],((C_word*)t0)[2]);}

/* k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1852(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1852(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1852,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1339(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[15],a[19]=t4,tmp=(C_word)a,a+=20,tmp);
C_trace("batch-driver.scm: 541  analyze");
t7=((C_word*)t0)[12];
f_1372(t7,t6,lf[137],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep(C_retrieve(lf[91]))){
if(C_truep((C_word)C_i_memq(lf[135],C_retrieve(lf[28])))){
C_trace("batch-driver.scm: 544  dump-undefined-globals");
t3=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t3=t2;
f_1862(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1862(2,t3,C_SCHEME_UNDEFINED);}}

/* k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=C_set_block_item(lf[91] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
C_trace("batch-driver.scm: 546  end-time");
t4=((C_word*)t0)[14];
f_1349(t4,t3,lf[134]);}

/* k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
C_trace("batch-driver.scm: 547  print-db");
t3=((C_word*)t0)[2];
f_1153(t3,t2,lf[132],lf[133],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_memq(lf[130],C_retrieve(lf[28])))){
C_trace("batch-driver.scm: 549  print-program-statistics");
t3=C_retrieve(lf[131]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1872(2,t3,C_SCHEME_UNDEFINED);}}

/* k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
if(C_truep(((C_word*)t0)[20])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
C_trace("batch-driver.scm: 552  debugging");
t3=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[100],lf[105],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[18],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 575  print-node");
t3=((C_word*)t0)[12];
f_1131(t3,t2,lf[128],lf[129],((C_word*)t0)[18]);}}

/* k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=f_1339(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 578  perform-closure-conversion");
t4=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 579  end-time");
t3=((C_word*)t0)[13];
f_1349(t3,t2,lf[126]);}

/* k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
C_trace("batch-driver.scm: 580  print-db");
t3=((C_word*)t0)[3];
f_1153(t3,t2,lf[124],lf[125],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[123]))){
t4=f_1107();
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2061(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2061(t4,C_SCHEME_FALSE);}}

/* k2059 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_2061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 582  display");
t2=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[122]);}
else{
t2=((C_word*)t0)[2];
f_1979(2,t2,C_SCHEME_UNDEFINED);}}

/* k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("batch-driver.scm: 583  exit");
t3=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_1982(2,t3,C_SCHEME_UNDEFINED);}}

/* k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_trace("batch-driver.scm: 584  print-node");
t3=((C_word*)t0)[2];
f_1131(t3,t2,lf[119],lf[120],((C_word*)t0)[11]);}

/* k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=f_1339(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1999,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
C_trace("batch-driver.scm: 589  end-time");
t7=((C_word*)t0)[7];
f_1349(t7,t6,lf[118]);}

/* k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=f_1339(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
C_trace("batch-driver.scm: 592  open-output-file");
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
C_trace("batch-driver.scm: 592  current-output-port");
t4=*((C_word*)lf[117]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2012(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("batch-driver.scm: 594  printf");
t3=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[115],((C_word*)t0)[9]);}}

/* k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 595  generate-code");
t3=C_retrieve(lf[114]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2013 in k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("batch-driver.scm: 596  close-output-port");
t3=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2018(2,t3,C_SCHEME_UNDEFINED);}}

/* k2016 in k2013 in k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 597  end-time");
t3=((C_word*)t0)[2];
f_1349(t3,t2,lf[112]);}

/* k2019 in k2016 in k2013 in k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[109],C_retrieve(lf[28])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 598  ##sys#stop-timer");
t4=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2024(2,t3,C_SCHEME_UNDEFINED);}}

/* k2041 in k2019 in k2016 in k2013 in k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 598  ##sys#display-times");
t2=C_retrieve(lf[110]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 599  compiler-cleanup-hook");
t3=C_retrieve(lf[108]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2001 in a1998 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
C_trace("batch-driver.scm: 601  printf");
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a1992 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1962 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
C_trace("batch-driver.scm: 588  prepare-for-code-generation");
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=f_1339(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1892,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("batch-driver.scm: 556  end-time");
t5=((C_word*)t0)[4];
f_1349(t5,t4,lf[104]);}

/* k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("batch-driver.scm: 557  print-node");
t3=((C_word*)t0)[2];
f_1131(t3,t2,lf[102],lf[103],((C_word*)t0)[6]);}

/* k1897 in k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
C_trace("batch-driver.scm: 559  loop");
t3=((C_word*)((C_word*)t0)[7])[1];
f_1852(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[93]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[94]))){
t3=f_1339(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 566  analyze");
t5=((C_word*)t0)[2];
f_1372(t5,t4,lf[98],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
C_trace("batch-driver.scm: 572  loop");
t4=((C_word*)((C_word*)t0)[7])[1];
f_1852(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 561  debugging");
t4=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[100],lf[101]);}}}

/* k1916 in k1897 in k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[93] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
C_trace("batch-driver.scm: 563  loop");
t4=((C_word*)((C_word*)t0)[4])[1];
f_1852(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1933 in k1897 in k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1938,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("batch-driver.scm: 567  end-time");
t3=((C_word*)t0)[2];
f_1349(t3,t2,lf[97]);}

/* k1936 in k1933 in k1897 in k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=f_1339(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 569  transform-direct-lambdas!");
t4=C_retrieve(lf[96]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1942 in k1936 in k1933 in k1897 in k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1947,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 570  end-time");
t3=((C_word*)t0)[2];
f_1349(t3,t2,lf[95]);}

/* k1945 in k1942 in k1936 in k1933 in k1897 in k1894 in a1891 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
C_trace("batch-driver.scm: 571  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_1852(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1885 in k1876 in k1870 in k1867 in k1864 in k1860 in k1857 in loop in k1845 in k1842 in k1839 in k1833 in k1827 in k1824 in k1821 in k1818 in k1815 in k1812 in k1809 in k1806 in k1803 in k1800 in k1795 in k1792 in k1789 in k1786 in k1783 in k1780 in k1774 in k1771 in k1768 in k1762 in k1759 in k1756 in k1753 in k1750 in k1747 in k1744 in k1741 in k1738 in k1730 in k1727 in k1724 in k1721 in k1717 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
C_trace("batch-driver.scm: 555  perform-high-level-optimizations");
t2=C_retrieve(lf[92]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1699 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 378  display");
t2=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1692 in k1680 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 379  newline");
t2=*((C_word*)lf[79]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1668 in k1659 in k1656 in k1653 in k1650 in k1639 in k1635 in k1631 in k1627 in k1623 in k1619 in k1616 in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 374  newline");
t2=*((C_word*)lf[79]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ids in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1604,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1606,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1614,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 322  collect-options");
t7=((C_word*)t0)[2];
f_1309(t7,t6,t2);}

/* k1612 in ids in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 320  append-map");
t2=C_retrieve(lf[68]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1605 in ids in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1606,3,t0,t1,t2);}
C_trace("string-split");
t3=C_retrieve(lf[66]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[67]);}

/* k1602 in ids in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[65]+1),t1);}

/* k1598 in ids in k1588 in k1585 in k1581 in k1573 in k1569 in k1566 in k1563 in k1556 in k1553 in k1550 in k1546 in k1543 in k1537 in k1534 in k1531 in k1528 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1501 in k1498 in k1495 in k1491 in k1488 in k1485 in k1482 in k1479 in k1476 in k1473 in k1470 in k1467 in k1464 in k1456 in k1452 in k1449 in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 317  lset-difference");
t2=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[63]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1372,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1374,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-no296344");
t8=t7;
f_1402(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-contf297340");
t10=t6;
f_1397(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body294303");
t12=t5;
f_1374(t12,t1,t8,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[1],t11);}}}}

/* def-no296 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1402,NULL,2,t0,t1);}
C_trace("def-contf297340");
t2=((C_word*)t0)[2];
f_1397(t2,t1,C_fix(0));}

/* def-contf297 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1397(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1397,NULL,3,t0,t1,t2);}
C_trace("body294303");
t3=((C_word*)t0)[2];
f_1374(t3,t1,t2,C_SCHEME_TRUE);}

/* body294 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1374,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1378,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 196  analyze-expression");
t5=C_retrieve(lf[50]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1376 in body294 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1381,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1386,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 198  upap");
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1381(2,t3,C_SCHEME_UNDEFINED);}}

/* a1391 in k1376 in body294 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1392,5,t0,t1,t2,t3,t4);}
C_trace("##compiler#put!");
t5=C_retrieve(lf[49]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1385 in k1376 in body294 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1386,4,t0,t1,t2,t3);}
C_trace("##compiler#get");
t4=C_retrieve(lf[48]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k1379 in k1376 in body294 in analyze in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1366,NULL,3,t0,t1,t2);}
C_trace("batch-driver.scm: 192  ##sys#read");
t3=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1349,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_1107();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
C_trace("batch-driver.scm: 189  printf");
t5=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[46],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static C_word C_fcall f_1339(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_1107();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1309,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1315(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1315,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 181  option-arg");
f_1005(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1327 in loop in collect-options in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1333,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("batch-driver.scm: 181  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_1315(t4,t2,t3);}

/* k1331 in k1327 in loop in collect-options in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1229(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1229,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
C_trace("batch-driver.scm: 172  string->number");
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1278,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 174  substring");
t11=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 175  substring");
t13=*((C_word*)lf[45]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
C_trace("batch-driver.scm: 176  string->number");
C_string_to_number(3,0,t5,t2);}}}}

/* k1296 in arg-val in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 175  string->number");
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1292 in arg-val in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1239(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1276 in arg-val in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 174  string->number");
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1268 in arg-val in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1239(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1237 in arg-val in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
C_trace("batch-driver.scm: 177  quit");
t2=C_retrieve(lf[5]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[44],((C_word*)t0)[2]);}}

/* infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1180,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1184,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[43]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1226,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1226 in infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1226,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1182 in infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1187,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[42],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1190(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1190(t5,C_SCHEME_FALSE);}}

/* k1188 in k1182 in infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1190,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1201,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("batch-driver.scm: 164  ##sys#hash-table-ref");
t6=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[39]),t5);}
else{
t2=((C_word*)t0)[3];
f_1187(2,t2,C_SCHEME_UNDEFINED);}}

/* k1203 in k1188 in k1182 in infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
C_trace("batch-driver.scm: 163  alist-cons");
t3=C_retrieve(lf[40]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1199 in k1188 in k1182 in infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 160  ##sys#hash-table-set!");
t2=C_retrieve(lf[38]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[39]),((C_word*)t0)[2],t1);}

/* k1185 in k1182 in infohook in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1168,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1175,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 154  print-header");
t6=((C_word*)t0)[2];
f_1113(t6,t5,t2,t3);}

/* k1173 in print-expr in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("for-each");
t2=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[33]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1153,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1160,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 149  print-header");
t7=((C_word*)t0)[2];
f_1113(t7,t6,t2,t3);}

/* k1158 in print-db in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 150  printf");
t3=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[36],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1161 in k1158 in print-db in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 151  display-analysis-database");
t2=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1131,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1138,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 143  print-header");
t6=((C_word*)t0)[2];
f_1113(t6,t5,t2,t3);}

/* k1136 in print-node in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
C_trace("batch-driver.scm: 145  dump-nodes");
t2=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 146  build-expression-tree");
t3=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1149 in k1136 in print-node in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 146  pretty-print");
t2=C_retrieve(lf[33]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1113(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1113,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1117,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("batch-driver.scm: 136  printf");
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[31],t2);}
else{
t5=t4;
f_1117(2,t5,C_SCHEME_UNDEFINED);}}

/* k1115 in print-header in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[28])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 139  printf");
t3=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[30],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1124 in k1115 in print-header in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k1061 in k1055 in k1052 in k3102 in k1036 in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static C_word C_fcall f_1107(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file in k997 in k994 in k991 in k988 in k985 in k982 */
static void C_fcall f_1005(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1005,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
C_trace("batch-driver.scm: 88   quit");
t5=C_retrieve(lf[5]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[6],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
C_trace("batch-driver.scm: 91   quit");
t5=C_retrieve(lf[5]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[7],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[291] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_984batch-driver.scm",(void*)f_984},
{"f_987batch-driver.scm",(void*)f_987},
{"f_990batch-driver.scm",(void*)f_990},
{"f_993batch-driver.scm",(void*)f_993},
{"f_996batch-driver.scm",(void*)f_996},
{"f_999batch-driver.scm",(void*)f_999},
{"f_1002batch-driver.scm",(void*)f_1002},
{"f_1038batch-driver.scm",(void*)f_1038},
{"f_3123batch-driver.scm",(void*)f_3123},
{"f_3112batch-driver.scm",(void*)f_3112},
{"f_3108batch-driver.scm",(void*)f_3108},
{"f_3104batch-driver.scm",(void*)f_3104},
{"f_3093batch-driver.scm",(void*)f_3093},
{"f_3071batch-driver.scm",(void*)f_3071},
{"f_1054batch-driver.scm",(void*)f_1054},
{"f_3065batch-driver.scm",(void*)f_3065},
{"f_3061batch-driver.scm",(void*)f_3061},
{"f_1057batch-driver.scm",(void*)f_1057},
{"f_1063batch-driver.scm",(void*)f_1063},
{"f_3042batch-driver.scm",(void*)f_3042},
{"f_3038batch-driver.scm",(void*)f_3038},
{"f_3034batch-driver.scm",(void*)f_3034},
{"f_1451batch-driver.scm",(void*)f_1451},
{"f_1454batch-driver.scm",(void*)f_1454},
{"f_3026batch-driver.scm",(void*)f_3026},
{"f_3004batch-driver.scm",(void*)f_3004},
{"f_3022batch-driver.scm",(void*)f_3022},
{"f_3010batch-driver.scm",(void*)f_3010},
{"f_1458batch-driver.scm",(void*)f_1458},
{"f_3002batch-driver.scm",(void*)f_3002},
{"f_2986batch-driver.scm",(void*)f_2986},
{"f_2994batch-driver.scm",(void*)f_2994},
{"f_2998batch-driver.scm",(void*)f_2998},
{"f_1466batch-driver.scm",(void*)f_1466},
{"f_1469batch-driver.scm",(void*)f_1469},
{"f_1472batch-driver.scm",(void*)f_1472},
{"f_1475batch-driver.scm",(void*)f_1475},
{"f_1478batch-driver.scm",(void*)f_1478},
{"f_1481batch-driver.scm",(void*)f_1481},
{"f_1484batch-driver.scm",(void*)f_1484},
{"f_1487batch-driver.scm",(void*)f_1487},
{"f_1490batch-driver.scm",(void*)f_1490},
{"f_1493batch-driver.scm",(void*)f_1493},
{"f_2938batch-driver.scm",(void*)f_2938},
{"f_1497batch-driver.scm",(void*)f_1497},
{"f_2930batch-driver.scm",(void*)f_2930},
{"f_1500batch-driver.scm",(void*)f_1500},
{"f_1503batch-driver.scm",(void*)f_1503},
{"f_1506batch-driver.scm",(void*)f_1506},
{"f_1509batch-driver.scm",(void*)f_1509},
{"f_1512batch-driver.scm",(void*)f_1512},
{"f_1515batch-driver.scm",(void*)f_1515},
{"f_1518batch-driver.scm",(void*)f_1518},
{"f_1521batch-driver.scm",(void*)f_1521},
{"f_1524batch-driver.scm",(void*)f_1524},
{"f_2880batch-driver.scm",(void*)f_2880},
{"f_2883batch-driver.scm",(void*)f_2883},
{"f_2886batch-driver.scm",(void*)f_2886},
{"f_1530batch-driver.scm",(void*)f_1530},
{"f_2867batch-driver.scm",(void*)f_2867},
{"f_2870batch-driver.scm",(void*)f_2870},
{"f_1533batch-driver.scm",(void*)f_1533},
{"f_1536batch-driver.scm",(void*)f_1536},
{"f_2825batch-driver.scm",(void*)f_2825},
{"f_1539batch-driver.scm",(void*)f_1539},
{"f_2822batch-driver.scm",(void*)f_2822},
{"f_2818batch-driver.scm",(void*)f_2818},
{"f_1545batch-driver.scm",(void*)f_1545},
{"f_1548batch-driver.scm",(void*)f_1548},
{"f_2802batch-driver.scm",(void*)f_2802},
{"f_2794batch-driver.scm",(void*)f_2794},
{"f_2792batch-driver.scm",(void*)f_2792},
{"f_1552batch-driver.scm",(void*)f_1552},
{"f_1555batch-driver.scm",(void*)f_1555},
{"f_2784batch-driver.scm",(void*)f_2784},
{"f_2776batch-driver.scm",(void*)f_2776},
{"f_2774batch-driver.scm",(void*)f_2774},
{"f_1558batch-driver.scm",(void*)f_1558},
{"f_1565batch-driver.scm",(void*)f_1565},
{"f_2767batch-driver.scm",(void*)f_2767},
{"f_1568batch-driver.scm",(void*)f_1568},
{"f_2756batch-driver.scm",(void*)f_2756},
{"f_2764batch-driver.scm",(void*)f_2764},
{"f_1571batch-driver.scm",(void*)f_1571},
{"f_1575batch-driver.scm",(void*)f_1575},
{"f_1583batch-driver.scm",(void*)f_1583},
{"f_1587batch-driver.scm",(void*)f_1587},
{"f_2742batch-driver.scm",(void*)f_2742},
{"f_2738batch-driver.scm",(void*)f_2738},
{"f_2722batch-driver.scm",(void*)f_2722},
{"f_1590batch-driver.scm",(void*)f_1590},
{"f_2715batch-driver.scm",(void*)f_2715},
{"f_2695batch-driver.scm",(void*)f_2695},
{"f_2693batch-driver.scm",(void*)f_2693},
{"f_1618batch-driver.scm",(void*)f_1618},
{"f_1621batch-driver.scm",(void*)f_1621},
{"f_2672batch-driver.scm",(void*)f_2672},
{"f_1625batch-driver.scm",(void*)f_1625},
{"f_2665batch-driver.scm",(void*)f_2665},
{"f_1629batch-driver.scm",(void*)f_1629},
{"f_2658batch-driver.scm",(void*)f_2658},
{"f_1633batch-driver.scm",(void*)f_1633},
{"f_2651batch-driver.scm",(void*)f_2651},
{"f_1637batch-driver.scm",(void*)f_1637},
{"f_2631batch-driver.scm",(void*)f_2631},
{"f_1641batch-driver.scm",(void*)f_1641},
{"f_1652batch-driver.scm",(void*)f_1652},
{"f_1655batch-driver.scm",(void*)f_1655},
{"f_1658batch-driver.scm",(void*)f_1658},
{"f_2584batch-driver.scm",(void*)f_2584},
{"f_1661batch-driver.scm",(void*)f_1661},
{"f_1682batch-driver.scm",(void*)f_1682},
{"f_1713batch-driver.scm",(void*)f_1713},
{"f_1719batch-driver.scm",(void*)f_1719},
{"f_1723batch-driver.scm",(void*)f_1723},
{"f_1726batch-driver.scm",(void*)f_1726},
{"f_1729batch-driver.scm",(void*)f_1729},
{"f_1732batch-driver.scm",(void*)f_1732},
{"f_1740batch-driver.scm",(void*)f_1740},
{"f_1743batch-driver.scm",(void*)f_1743},
{"f_1746batch-driver.scm",(void*)f_1746},
{"f_2549batch-driver.scm",(void*)f_2549},
{"f_2557batch-driver.scm",(void*)f_2557},
{"f_1749batch-driver.scm",(void*)f_1749},
{"f_1752batch-driver.scm",(void*)f_1752},
{"f_2464batch-driver.scm",(void*)f_2464},
{"f_2493batch-driver.scm",(void*)f_2493},
{"f_2542batch-driver.scm",(void*)f_2542},
{"f_2510batch-driver.scm",(void*)f_2510},
{"f_2514batch-driver.scm",(void*)f_2514},
{"f_2519batch-driver.scm",(void*)f_2519},
{"f_2540batch-driver.scm",(void*)f_2540},
{"f_2505batch-driver.scm",(void*)f_2505},
{"f_2496batch-driver.scm",(void*)f_2496},
{"f_2479batch-driver.scm",(void*)f_2479},
{"f_2483batch-driver.scm",(void*)f_2483},
{"f_2487batch-driver.scm",(void*)f_2487},
{"f_2475batch-driver.scm",(void*)f_2475},
{"f_2452batch-driver.scm",(void*)f_2452},
{"f_2456batch-driver.scm",(void*)f_2456},
{"f_1755batch-driver.scm",(void*)f_1755},
{"f_1758batch-driver.scm",(void*)f_1758},
{"f_2442batch-driver.scm",(void*)f_2442},
{"f_2446batch-driver.scm",(void*)f_2446},
{"f_1761batch-driver.scm",(void*)f_1761},
{"f_1764batch-driver.scm",(void*)f_1764},
{"f_2419batch-driver.scm",(void*)f_2419},
{"f_2439batch-driver.scm",(void*)f_2439},
{"f_1770batch-driver.scm",(void*)f_1770},
{"f_2412batch-driver.scm",(void*)f_2412},
{"f_1773batch-driver.scm",(void*)f_1773},
{"f_1776batch-driver.scm",(void*)f_1776},
{"f_2380batch-driver.scm",(void*)f_2380},
{"f_2254batch-driver.scm",(void*)f_2254},
{"f_2370batch-driver.scm",(void*)f_2370},
{"f_2258batch-driver.scm",(void*)f_2258},
{"f_2262batch-driver.scm",(void*)f_2262},
{"f_2281batch-driver.scm",(void*)f_2281},
{"f_2266batch-driver.scm",(void*)f_2266},
{"f_1782batch-driver.scm",(void*)f_1782},
{"f_2247batch-driver.scm",(void*)f_2247},
{"f_1785batch-driver.scm",(void*)f_1785},
{"f_2241batch-driver.scm",(void*)f_2241},
{"f_1788batch-driver.scm",(void*)f_1788},
{"f_1791batch-driver.scm",(void*)f_1791},
{"f_1794batch-driver.scm",(void*)f_1794},
{"f_2220batch-driver.scm",(void*)f_2220},
{"f_1797batch-driver.scm",(void*)f_1797},
{"f_1802batch-driver.scm",(void*)f_1802},
{"f_1805batch-driver.scm",(void*)f_1805},
{"f_1808batch-driver.scm",(void*)f_1808},
{"f_1811batch-driver.scm",(void*)f_1811},
{"f_2198batch-driver.scm",(void*)f_2198},
{"f_2205batch-driver.scm",(void*)f_2205},
{"f_1814batch-driver.scm",(void*)f_1814},
{"f_2195batch-driver.scm",(void*)f_2195},
{"f_2191batch-driver.scm",(void*)f_2191},
{"f_2183batch-driver.scm",(void*)f_2183},
{"f_1817batch-driver.scm",(void*)f_1817},
{"f_1820batch-driver.scm",(void*)f_1820},
{"f_2167batch-driver.scm",(void*)f_2167},
{"f_2178batch-driver.scm",(void*)f_2178},
{"f_2174batch-driver.scm",(void*)f_2174},
{"f_1823batch-driver.scm",(void*)f_1823},
{"f_2135batch-driver.scm",(void*)f_2135},
{"f_2142batch-driver.scm",(void*)f_2142},
{"f_2145batch-driver.scm",(void*)f_2145},
{"f_2148batch-driver.scm",(void*)f_2148},
{"f_2154batch-driver.scm",(void*)f_2154},
{"f_2157batch-driver.scm",(void*)f_2157},
{"f_2160batch-driver.scm",(void*)f_2160},
{"f_1826batch-driver.scm",(void*)f_1826},
{"f_2113batch-driver.scm",(void*)f_2113},
{"f_2116batch-driver.scm",(void*)f_2116},
{"f_2119batch-driver.scm",(void*)f_2119},
{"f_2125batch-driver.scm",(void*)f_2125},
{"f_2128batch-driver.scm",(void*)f_2128},
{"f_2131batch-driver.scm",(void*)f_2131},
{"f_1829batch-driver.scm",(void*)f_1829},
{"f_2102batch-driver.scm",(void*)f_2102},
{"f_2101batch-driver.scm",(void*)f_2101},
{"f_1835batch-driver.scm",(void*)f_1835},
{"f_1841batch-driver.scm",(void*)f_1841},
{"f_1844batch-driver.scm",(void*)f_1844},
{"f_1847batch-driver.scm",(void*)f_1847},
{"f_1852batch-driver.scm",(void*)f_1852},
{"f_1859batch-driver.scm",(void*)f_1859},
{"f_1862batch-driver.scm",(void*)f_1862},
{"f_1866batch-driver.scm",(void*)f_1866},
{"f_1869batch-driver.scm",(void*)f_1869},
{"f_1872batch-driver.scm",(void*)f_1872},
{"f_1964batch-driver.scm",(void*)f_1964},
{"f_1970batch-driver.scm",(void*)f_1970},
{"f_1973batch-driver.scm",(void*)f_1973},
{"f_1976batch-driver.scm",(void*)f_1976},
{"f_2061batch-driver.scm",(void*)f_2061},
{"f_1979batch-driver.scm",(void*)f_1979},
{"f_1982batch-driver.scm",(void*)f_1982},
{"f_1985batch-driver.scm",(void*)f_1985},
{"f_1999batch-driver.scm",(void*)f_1999},
{"f_2003batch-driver.scm",(void*)f_2003},
{"f_2009batch-driver.scm",(void*)f_2009},
{"f_2012batch-driver.scm",(void*)f_2012},
{"f_2015batch-driver.scm",(void*)f_2015},
{"f_2018batch-driver.scm",(void*)f_2018},
{"f_2021batch-driver.scm",(void*)f_2021},
{"f_2043batch-driver.scm",(void*)f_2043},
{"f_2024batch-driver.scm",(void*)f_2024},
{"f_2027batch-driver.scm",(void*)f_2027},
{"f_1993batch-driver.scm",(void*)f_1993},
{"f_1878batch-driver.scm",(void*)f_1878},
{"f_1892batch-driver.scm",(void*)f_1892},
{"f_1896batch-driver.scm",(void*)f_1896},
{"f_1899batch-driver.scm",(void*)f_1899},
{"f_1918batch-driver.scm",(void*)f_1918},
{"f_1935batch-driver.scm",(void*)f_1935},
{"f_1938batch-driver.scm",(void*)f_1938},
{"f_1944batch-driver.scm",(void*)f_1944},
{"f_1947batch-driver.scm",(void*)f_1947},
{"f_1886batch-driver.scm",(void*)f_1886},
{"f_1701batch-driver.scm",(void*)f_1701},
{"f_1694batch-driver.scm",(void*)f_1694},
{"f_1670batch-driver.scm",(void*)f_1670},
{"f_1592batch-driver.scm",(void*)f_1592},
{"f_1614batch-driver.scm",(void*)f_1614},
{"f_1606batch-driver.scm",(void*)f_1606},
{"f_1604batch-driver.scm",(void*)f_1604},
{"f_1600batch-driver.scm",(void*)f_1600},
{"f_1372batch-driver.scm",(void*)f_1372},
{"f_1402batch-driver.scm",(void*)f_1402},
{"f_1397batch-driver.scm",(void*)f_1397},
{"f_1374batch-driver.scm",(void*)f_1374},
{"f_1378batch-driver.scm",(void*)f_1378},
{"f_1392batch-driver.scm",(void*)f_1392},
{"f_1386batch-driver.scm",(void*)f_1386},
{"f_1381batch-driver.scm",(void*)f_1381},
{"f_1366batch-driver.scm",(void*)f_1366},
{"f_1349batch-driver.scm",(void*)f_1349},
{"f_1339batch-driver.scm",(void*)f_1339},
{"f_1309batch-driver.scm",(void*)f_1309},
{"f_1315batch-driver.scm",(void*)f_1315},
{"f_1329batch-driver.scm",(void*)f_1329},
{"f_1333batch-driver.scm",(void*)f_1333},
{"f_1229batch-driver.scm",(void*)f_1229},
{"f_1298batch-driver.scm",(void*)f_1298},
{"f_1294batch-driver.scm",(void*)f_1294},
{"f_1278batch-driver.scm",(void*)f_1278},
{"f_1270batch-driver.scm",(void*)f_1270},
{"f_1239batch-driver.scm",(void*)f_1239},
{"f_1180batch-driver.scm",(void*)f_1180},
{"f_1226batch-driver.scm",(void*)f_1226},
{"f_1184batch-driver.scm",(void*)f_1184},
{"f_1190batch-driver.scm",(void*)f_1190},
{"f_1205batch-driver.scm",(void*)f_1205},
{"f_1201batch-driver.scm",(void*)f_1201},
{"f_1187batch-driver.scm",(void*)f_1187},
{"f_1168batch-driver.scm",(void*)f_1168},
{"f_1175batch-driver.scm",(void*)f_1175},
{"f_1153batch-driver.scm",(void*)f_1153},
{"f_1160batch-driver.scm",(void*)f_1160},
{"f_1163batch-driver.scm",(void*)f_1163},
{"f_1131batch-driver.scm",(void*)f_1131},
{"f_1138batch-driver.scm",(void*)f_1138},
{"f_1151batch-driver.scm",(void*)f_1151},
{"f_1113batch-driver.scm",(void*)f_1113},
{"f_1117batch-driver.scm",(void*)f_1117},
{"f_1126batch-driver.scm",(void*)f_1126},
{"f_1107batch-driver.scm",(void*)f_1107},
{"f_1005batch-driver.scm",(void*)f_1005},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
