/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-17 11:09
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[356];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_fcall f_3227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_fcall f_1120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_fcall f_1508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_fcall f_1511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_fcall f_1526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_fcall f_1532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_fcall f_1541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_fcall f_1544(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_fcall f_1547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_fcall f_1554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_fcall f_1557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_fcall f_1560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_fcall f_1563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_fcall f_1566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_fcall f_1569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_fcall f_1572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_fcall f_1575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_fcall f_1578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_fcall f_1584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_fcall f_1590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_fcall f_1615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_fcall f_1650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_fcall f_1681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_fcall f_1715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_fcall f_1742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_fcall f_1821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_fcall f_1830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_fcall f_2382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_fcall f_1892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_fcall f_1895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_fcall f_2130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_fcall f_1652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_fcall f_1429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1459)
static void C_fcall f_1459(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_fcall f_1454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1431)
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_fcall f_1423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1406)
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1396)
static C_word C_fcall f_1396(C_word t0);
C_noret_decl(f_1366)
static void C_fcall f_1366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1372)
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_fcall f_1286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_fcall f_1247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1262)
static void C_ccall f_1262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_fcall f_1225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_fcall f_1210(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1170)
static void C_fcall f_1170(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static C_word C_fcall f_1164();
C_noret_decl(f_1062)
static void C_fcall f_1062(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3227)
static void C_fcall trf_3227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3227(t0,t1);}

C_noret_decl(trf_1120)
static void C_fcall trf_1120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1120(t0,t1);}

C_noret_decl(trf_1508)
static void C_fcall trf_1508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1508(t0,t1);}

C_noret_decl(trf_1511)
static void C_fcall trf_1511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1511(t0,t1);}

C_noret_decl(trf_1526)
static void C_fcall trf_1526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1526(t0,t1);}

C_noret_decl(trf_1532)
static void C_fcall trf_1532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1532(t0,t1);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1538(t0,t1);}

C_noret_decl(trf_1541)
static void C_fcall trf_1541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1541(t0,t1);}

C_noret_decl(trf_1544)
static void C_fcall trf_1544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1544(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1544(t0,t1);}

C_noret_decl(trf_1547)
static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1547(t0,t1);}

C_noret_decl(trf_1554)
static void C_fcall trf_1554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1554(t0,t1);}

C_noret_decl(trf_1557)
static void C_fcall trf_1557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1557(t0,t1);}

C_noret_decl(trf_1560)
static void C_fcall trf_1560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1560(t0,t1);}

C_noret_decl(trf_1563)
static void C_fcall trf_1563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1563(t0,t1);}

C_noret_decl(trf_1566)
static void C_fcall trf_1566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1566(t0,t1);}

C_noret_decl(trf_1569)
static void C_fcall trf_1569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1569(t0,t1);}

C_noret_decl(trf_1572)
static void C_fcall trf_1572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1572(t0,t1);}

C_noret_decl(trf_1575)
static void C_fcall trf_1575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1575(t0,t1);}

C_noret_decl(trf_1578)
static void C_fcall trf_1578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1578(t0,t1);}

C_noret_decl(trf_1584)
static void C_fcall trf_1584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1584(t0,t1);}

C_noret_decl(trf_1590)
static void C_fcall trf_1590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1590(t0,t1);}

C_noret_decl(trf_1615)
static void C_fcall trf_1615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1615(t0,t1);}

C_noret_decl(trf_1650)
static void C_fcall trf_1650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1650(t0,t1);}

C_noret_decl(trf_1681)
static void C_fcall trf_1681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1681(t0,t1);}

C_noret_decl(trf_1715)
static void C_fcall trf_1715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1715(t0,t1);}

C_noret_decl(trf_1742)
static void C_fcall trf_1742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1742(t0,t1);}

C_noret_decl(trf_2584)
static void C_fcall trf_2584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2584(t0,t1,t2);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2639(t0,t1,t2);}

C_noret_decl(trf_1821)
static void C_fcall trf_1821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1821(t0,t1);}

C_noret_decl(trf_1830)
static void C_fcall trf_1830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1830(t0,t1);}

C_noret_decl(trf_2382)
static void C_fcall trf_2382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2382(t0,t1);}

C_noret_decl(trf_1892)
static void C_fcall trf_1892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1892(t0,t1);}

C_noret_decl(trf_1895)
static void C_fcall trf_1895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1895(t0,t1);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1918(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2130)
static void C_fcall trf_2130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2130(t0,t1);}

C_noret_decl(trf_1652)
static void C_fcall trf_1652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1652(t0,t1,t2);}

C_noret_decl(trf_1429)
static void C_fcall trf_1429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1429(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1429(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1459)
static void C_fcall trf_1459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1459(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1459(t0,t1);}

C_noret_decl(trf_1454)
static void C_fcall trf_1454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1454(t0,t1,t2);}

C_noret_decl(trf_1431)
static void C_fcall trf_1431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1431(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1431(t0,t1,t2,t3);}

C_noret_decl(trf_1423)
static void C_fcall trf_1423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1423(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1423(t0,t1,t2);}

C_noret_decl(trf_1406)
static void C_fcall trf_1406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1406(t0,t1,t2);}

C_noret_decl(trf_1366)
static void C_fcall trf_1366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1366(t0,t1,t2);}

C_noret_decl(trf_1372)
static void C_fcall trf_1372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1372(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1372(t0,t1,t2);}

C_noret_decl(trf_1286)
static void C_fcall trf_1286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1286(t0,t1);}

C_noret_decl(trf_1247)
static void C_fcall trf_1247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1247(t0,t1);}

C_noret_decl(trf_1225)
static void C_fcall trf_1225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1225(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1225(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1210)
static void C_fcall trf_1210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1210(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1210(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1188)
static void C_fcall trf_1188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1188(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1188(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1170)
static void C_fcall trf_1170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1170(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1170(t0,t1,t2,t3);}

C_noret_decl(trf_1062)
static void C_fcall trf_1062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1062(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2720)){
C_save(t1);
C_rereclaim2(2720*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,356);
lf[0]=C_h_intern(&lf[0],17,"user-options-pass");
lf[1]=C_h_intern(&lf[1],14,"user-read-pass");
lf[2]=C_h_intern(&lf[2],22,"user-preprocessor-pass");
lf[3]=C_h_intern(&lf[3],9,"user-pass");
lf[4]=C_h_intern(&lf[4],11,"user-pass-2");
lf[5]=C_h_intern(&lf[5],23,"user-post-analysis-pass");
lf[6]=C_h_intern(&lf[6],19,"compile-source-file");
lf[7]=C_h_intern(&lf[7],4,"quit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[10]=C_h_intern(&lf[10],12,"explicit-use");
lf[11]=C_h_intern(&lf[11],26,"\010compilerexplicit-use-flag");
lf[12]=C_h_intern(&lf[12],12,"\004coredeclare");
lf[13]=C_h_intern(&lf[13],7,"verbose");
lf[14]=C_h_intern(&lf[14],11,"output-file");
lf[15]=C_h_intern(&lf[15],36,"\010compilerdefault-optimization-passes");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[17]=C_h_intern(&lf[17],7,"profile");
lf[18]=C_h_intern(&lf[18],12,"profile-name");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[20]=C_h_intern(&lf[20],9,"heap-size");
lf[21]=C_h_intern(&lf[21],17,"heap-initial-size");
lf[22]=C_h_intern(&lf[22],11,"heap-growth");
lf[23]=C_h_intern(&lf[23],14,"heap-shrinkage");
lf[24]=C_h_intern(&lf[24],13,"keyword-style");
lf[25]=C_h_intern(&lf[25],4,"unit");
lf[26]=C_h_intern(&lf[26],12,"analyze-only");
lf[27]=C_h_intern(&lf[27],7,"dynamic");
lf[28]=C_h_intern(&lf[28],5,"quiet");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],10,"stack-size");
lf[31]=C_h_intern(&lf[31],26,"\010compilerdebugging-chicken");
lf[32]=C_h_intern(&lf[32],6,"printf");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[35]=C_h_intern(&lf[35],19,"\010compilerdump-nodes");
lf[36]=C_h_intern(&lf[36],12,"pretty-print");
lf[37]=C_h_intern(&lf[37],30,"\010compilerbuild-expression-tree");
lf[38]=C_h_intern(&lf[38],34,"\010compilerdisplay-analysis-database");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[40]=C_h_intern(&lf[40],12,"\003sysfor-each");
lf[41]=C_h_intern(&lf[41],19,"\003syshash-table-set!");
lf[42]=C_h_intern(&lf[42],24,"\003sysline-number-database");
lf[43]=C_h_intern(&lf[43],10,"alist-cons");
lf[44]=C_h_intern(&lf[44],18,"\003syshash-table-ref");
lf[45]=C_h_intern(&lf[45],9,"list-info");
lf[46]=C_h_intern(&lf[46],26,"\003sysdefault-read-info-hook");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[50]=C_h_intern(&lf[50],8,"\003sysread");
lf[51]=C_h_intern(&lf[51],12,"\010compilerget");
lf[52]=C_h_intern(&lf[52],13,"\010compilerput!");
lf[53]=C_h_intern(&lf[53],27,"\010compileranalyze-expression");
lf[54]=C_h_intern(&lf[54],9,"\003syserror");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],15,"lset-difference");
lf[68]=C_h_intern(&lf[68],3,"eq\077");
lf[69]=C_h_intern(&lf[69],7,"\003sysmap");
lf[70]=C_h_intern(&lf[70],14,"string->symbol");
lf[71]=C_h_intern(&lf[71],12,"string-split");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[73]=C_h_intern(&lf[73],10,"append-map");
lf[74]=C_h_intern(&lf[74],25,"\010compilertarget-heap-size");
lf[75]=C_h_intern(&lf[75],33,"\010compilertarget-initial-heap-size");
lf[76]=C_h_intern(&lf[76],27,"\010compilertarget-heap-growth");
lf[77]=C_h_intern(&lf[77],30,"\010compilertarget-heap-shrinkage");
lf[78]=C_h_intern(&lf[78],26,"\010compilertarget-stack-size");
lf[79]=C_h_intern(&lf[79],8,"no-trace");
lf[80]=C_h_intern(&lf[80],24,"\010compileremit-trace-info");
lf[81]=C_h_intern(&lf[81],29,"disable-stack-overflow-checks");
lf[82]=C_h_intern(&lf[82],40,"\010compilerdisable-stack-overflow-checking");
lf[83]=C_h_intern(&lf[83],7,"version");
lf[84]=C_h_intern(&lf[84],7,"newline");
lf[85]=C_h_intern(&lf[85],22,"\010compilerprint-version");
lf[86]=C_h_intern(&lf[86],4,"help");
lf[87]=C_h_intern(&lf[87],20,"\010compilerprint-usage");
lf[88]=C_h_intern(&lf[88],7,"release");
lf[89]=C_h_intern(&lf[89],7,"display");
lf[90]=C_h_intern(&lf[90],15,"chicken-version");
lf[91]=C_h_intern(&lf[91],24,"\010compilersource-filename");
lf[92]=C_h_intern(&lf[92],28,"\010compilerprofile-lambda-list");
lf[93]=C_h_intern(&lf[93],31,"\010compilerline-number-database-2");
lf[94]=C_h_intern(&lf[94],23,"\010compilerconstant-table");
lf[95]=C_h_intern(&lf[95],21,"\010compilerinline-table");
lf[96]=C_h_intern(&lf[96],23,"\010compilerfirst-analysis");
lf[97]=C_h_intern(&lf[97],41,"\010compilerperform-high-level-optimizations");
lf[98]=C_h_intern(&lf[98],37,"\010compilerinline-substitutions-enabled");
lf[99]=C_h_intern(&lf[99],22,"optimize-leaf-routines");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[101]=C_h_intern(&lf[101],34,"\010compilertransform-direct-lambdas!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[103]=C_h_intern(&lf[103],4,"leaf");
lf[104]=C_h_intern(&lf[104],18,"\010compilerdebugging");
lf[105]=C_h_intern(&lf[105],1,"p");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[108]=C_h_intern(&lf[108],1,"5");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[111]=C_h_intern(&lf[111],36,"\010compilerprepare-for-code-generation");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[113]=C_h_intern(&lf[113],30,"\010compilercompiler-cleanup-hook");
lf[114]=C_h_intern(&lf[114],1,"t");
lf[115]=C_h_intern(&lf[115],17,"\003sysdisplay-times");
lf[116]=C_h_intern(&lf[116],14,"\003sysstop-timer");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[118]=C_h_intern(&lf[118],17,"close-output-port");
lf[119]=C_h_intern(&lf[119],22,"\010compilergenerate-code");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[121]=C_h_intern(&lf[121],16,"open-output-file");
lf[122]=C_h_intern(&lf[122],19,"current-output-port");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[125]=C_h_intern(&lf[125],1,"9");
lf[126]=C_h_intern(&lf[126],4,"exit");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[128]=C_h_intern(&lf[128],20,"\003syswarnings-enabled");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[130]=C_h_intern(&lf[130],1,"8");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[132]=C_h_intern(&lf[132],35,"\010compilerperform-closure-conversion");
lf[133]=C_h_intern(&lf[133],24,"\010compilerinline-globally");
lf[134]=C_h_intern(&lf[134],25,"\010compileremit-inline-file");
lf[135]=C_h_intern(&lf[135],32,"\010compileremit-global-inline-file");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000(Generating global inline file `~a\047 ...~%");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[138]=C_h_intern(&lf[138],1,"7");
lf[139]=C_h_intern(&lf[139],1,"s");
lf[140]=C_h_intern(&lf[140],33,"\010compilerprint-program-statistics");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[142]=C_h_intern(&lf[142],1,"4");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[144]=C_h_intern(&lf[144],1,"u");
lf[145]=C_h_intern(&lf[145],31,"\010compilerdump-undefined-globals");
lf[146]=C_h_intern(&lf[146],3,"opt");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[148]=C_h_intern(&lf[148],1,"3");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[150]=C_h_intern(&lf[150],31,"\010compilerperform-cps-conversion");
lf[151]=C_h_intern(&lf[151],6,"unsafe");
lf[152]=C_h_intern(&lf[152],34,"\010compilerscan-toplevel-assignments");
lf[153]=C_h_intern(&lf[153],26,"\010compilerdo-lambda-lifting");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[155]=C_h_intern(&lf[155],1,"L");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[157]=C_h_intern(&lf[157],32,"\010compilerperform-lambda-lifting!");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[160]=C_h_intern(&lf[160],1,"0");
lf[161]=C_h_intern(&lf[161],4,"lift");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[163]=C_h_intern(&lf[163],1,"U");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[167]=C_h_intern(&lf[167],4,"user");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[169]=C_h_intern(&lf[169],4,"node");
lf[170]=C_h_intern(&lf[170],6,"lambda");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[172]=C_h_intern(&lf[172],25,"\010compilerbuild-node-graph");
lf[173]=C_h_intern(&lf[173],32,"\010compilercanonicalize-begin-body");
lf[174]=C_h_intern(&lf[174],25,"\010compilerload-inline-file");
lf[175]=C_h_intern(&lf[175],5,"print");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\024Loading inline file ");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[178]=C_h_intern(&lf[178],12,"file-exists\077");
lf[179]=C_h_intern(&lf[179],28,"\003sysresolve-include-filename");
lf[180]=C_h_intern(&lf[180],13,"make-pathname");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[182]=C_h_intern(&lf[182],14,"symbol->string");
lf[183]=C_h_intern(&lf[183],11,"concatenate");
lf[184]=C_h_intern(&lf[184],3,"cdr");
lf[185]=C_h_intern(&lf[185],2,"pp");
lf[186]=C_h_intern(&lf[186],1,"M");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[188]=C_h_intern(&lf[188],12,"vector->list");
lf[189]=C_h_intern(&lf[189],26,"\010compilerfile-requirements");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[192]=C_h_intern(&lf[192],12,"check-syntax");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[194]=C_h_intern(&lf[194],1,"2");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[196]=C_h_intern(&lf[196],25,"\010compilercompiler-warning");
lf[197]=C_h_intern(&lf[197],5,"style");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[199]=C_h_intern(&lf[199],8,"feature\077");
lf[200]=C_h_intern(&lf[200],19,"compiling-extension");
lf[201]=C_h_intern(&lf[201],18,"\010compilerunit-name");
lf[202]=C_h_intern(&lf[202],5,"usage");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[204]=C_h_intern(&lf[204],26,"\010compilerblock-compilation");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[206]=C_h_intern(&lf[206],37,"\010compilerdisplay-line-number-database");
lf[207]=C_h_intern(&lf[207],1,"n");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[209]=C_h_intern(&lf[209],32,"\010compilerdisplay-real-name-table");
lf[210]=C_h_intern(&lf[210],1,"N");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[212]=C_h_intern(&lf[212],6,"append");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[214]=C_h_intern(&lf[214],5,"quote");
lf[215]=C_h_intern(&lf[215],33,"\010compilerprofile-info-vector-name");
lf[216]=C_h_intern(&lf[216],28,"\003sysset-profile-info-vector!");
lf[217]=C_h_intern(&lf[217],21,"\010compileremit-profile");
lf[218]=C_h_intern(&lf[218],25,"\003sysregister-profile-info");
lf[219]=C_h_intern(&lf[219],4,"set!");
lf[220]=C_h_intern(&lf[220],13,"\004corecallunit");
lf[221]=C_h_intern(&lf[221],19,"\010compilerused-units");
lf[222]=C_h_intern(&lf[222],28,"\010compilerimmutable-constants");
lf[223]=C_h_intern(&lf[223],6,"gensym");
lf[224]=C_h_intern(&lf[224],32,"\010compilercanonicalize-expression");
lf[225]=C_h_intern(&lf[225],28,"\003sysexplicit-library-modules");
lf[226]=C_h_intern(&lf[226],4,"uses");
lf[227]=C_h_intern(&lf[227],7,"declare");
lf[228]=C_h_intern(&lf[228],10,"\003sysappend");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[230]=C_h_intern(&lf[230],1,"1");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[233]=C_h_intern(&lf[233],21,"\010compilerstring->expr");
lf[234]=C_h_intern(&lf[234],7,"reverse");
lf[235]=C_h_intern(&lf[235],27,"\003syscurrent-source-filename");
lf[236]=C_h_intern(&lf[236],33,"\010compilerclose-checked-input-file");
lf[237]=C_h_intern(&lf[237],16,"\003sysdynamic-wind");
lf[238]=C_h_intern(&lf[238],34,"\010compilercheck-and-open-input-file");
lf[239]=C_h_intern(&lf[239],8,"epilogue");
lf[240]=C_h_intern(&lf[240],8,"prologue");
lf[241]=C_h_intern(&lf[241],8,"postlude");
lf[242]=C_h_intern(&lf[242],7,"prelude");
lf[243]=C_h_intern(&lf[243],11,"make-vector");
lf[244]=C_h_intern(&lf[244],34,"\010compilerline-number-database-size");
lf[245]=C_h_intern(&lf[245],1,"r");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[252]=C_h_intern(&lf[252],5,"-help");
lf[253]=C_h_intern(&lf[253],1,"h");
lf[254]=C_h_intern(&lf[254],2,"-h");
lf[255]=C_h_intern(&lf[255],18,"accumulate-profile");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[259]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[260]=C_h_intern(&lf[260],39,"\010compilerdefault-profiling-declarations");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[264]=C_h_intern(&lf[264],21,"no-usual-integrations");
lf[265]=C_h_intern(&lf[265],17,"standard-bindings");
lf[266]=C_h_intern(&lf[266],34,"\010compilerdefault-standard-bindings");
lf[267]=C_h_intern(&lf[267],17,"extended-bindings");
lf[268]=C_h_intern(&lf[268],34,"\010compilerdefault-extended-bindings");
lf[269]=C_h_intern(&lf[269],1,"m");
lf[270]=C_h_intern(&lf[270],14,"set-gc-report!");
lf[271]=C_h_intern(&lf[271],42,"\010compilerdefault-default-target-stack-size");
lf[272]=C_h_intern(&lf[272],41,"\010compilerdefault-default-target-heap-size");
lf[273]=C_h_intern(&lf[273],14,"compile-syntax");
lf[274]=C_h_intern(&lf[274],25,"\003sysenable-runtime-macros");
lf[275]=C_h_intern(&lf[275],22,"\004corerequire-extension");
lf[276]=C_h_intern(&lf[276],17,"require-extension");
lf[277]=C_h_intern(&lf[277],9,"extension");
lf[278]=C_h_intern(&lf[278],16,"define-extension");
lf[279]=C_h_intern(&lf[279],13,"pathname-file");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[281]=C_h_intern(&lf[281],28,"\010compilerpostponed-initforms");
lf[282]=C_h_intern(&lf[282],6,"delete");
lf[283]=C_h_intern(&lf[283],4,"load");
lf[284]=C_h_intern(&lf[284],12,"load-verbose");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[286]=C_h_intern(&lf[286],6,"extend");
lf[287]=C_h_intern(&lf[287],17,"register-feature!");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[289]=C_h_intern(&lf[289],7,"feature");
lf[290]=C_h_intern(&lf[290],20,"keep-shadowed-macros");
lf[291]=C_h_intern(&lf[291],33,"\010compilerundefine-shadowed-macros");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[294]=C_h_intern(&lf[294],23,"\010compilerchop-separator");
lf[295]=C_h_intern(&lf[295],12,"include-path");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[297]=C_h_intern(&lf[297],7,"\000prefix");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[299]=C_h_intern(&lf[299],5,"\000none");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[301]=C_h_intern(&lf[301],7,"\000suffix");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[303]=C_h_intern(&lf[303],17,"compress-literals");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[305]=C_h_intern(&lf[305],16,"case-insensitive");
lf[306]=C_h_intern(&lf[306],14,"case-sensitive");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[308]=C_h_intern(&lf[308],24,"\010compilerinline-max-size");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[310]=C_h_intern(&lf[310],6,"inline");
lf[311]=C_h_intern(&lf[311],23,"\010compilerinline-locally");
lf[312]=C_h_intern(&lf[312],30,"emit-external-prototypes-first");
lf[313]=C_h_intern(&lf[313],30,"\010compilerexternal-protos-first");
lf[314]=C_h_intern(&lf[314],5,"block");
lf[315]=C_h_intern(&lf[315],17,"fixnum-arithmetic");
lf[316]=C_h_intern(&lf[316],11,"number-type");
lf[317]=C_h_intern(&lf[317],6,"fixnum");
lf[318]=C_h_intern(&lf[318],18,"disable-interrupts");
lf[319]=C_h_intern(&lf[319],28,"\010compilerinsert-timer-checks");
lf[320]=C_h_intern(&lf[320],16,"unsafe-libraries");
lf[321]=C_h_intern(&lf[321],27,"\010compileremit-unsafe-marker");
lf[322]=C_h_intern(&lf[322],11,"no-warnings");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[324]=C_h_intern(&lf[324],15,"disable-warning");
lf[325]=C_h_intern(&lf[325],13,"inline-global");
lf[326]=C_h_intern(&lf[326],5,"local");
lf[327]=C_h_intern(&lf[327],26,"\010compilerlocal-definitions");
lf[328]=C_h_intern(&lf[328],14,"no-lambda-info");
lf[329]=C_h_intern(&lf[329],26,"\010compileremit-closure-info");
lf[330]=C_h_intern(&lf[330],3,"raw");
lf[331]=C_h_intern(&lf[331],12,"emit-exports");
lf[332]=C_h_intern(&lf[332],7,"warning");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[334]=C_h_intern(&lf[334],1,"b");
lf[335]=C_h_intern(&lf[335],15,"\003sysstart-timer");
lf[336]=C_h_intern(&lf[336],11,"lambda-lift");
lf[337]=C_h_intern(&lf[337],13,"string-append");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[339]=C_h_intern(&lf[339],19,"emit-import-library");
lf[340]=C_h_intern(&lf[340],16,"\003sysstring->list");
lf[341]=C_h_intern(&lf[341],5,"debug");
lf[342]=C_h_intern(&lf[342],30,"\010compilerstandalone-executable");
lf[343]=C_h_intern(&lf[343],29,"\010compilerstring->c-identifier");
lf[344]=C_h_intern(&lf[344],18,"\010compilerstringify");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[347]=C_h_intern(&lf[347],6,"getenv");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[349]=C_h_intern(&lf[349],9,"to-stdout");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[352]=C_h_intern(&lf[352],29,"\010compilerdefault-declarations");
lf[353]=C_h_intern(&lf[353],30,"\010compilerunits-used-by-default");
lf[354]=C_h_intern(&lf[354],28,"\010compilerinitialize-compiler");
lf[355]=C_h_intern(&lf[355],14,"make-parameter");
C_register_lf2(lf,356,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1015 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1018 in k1015 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1021 in k1018 in k1015 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 81   make-parameter */
t3=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_FALSE);}

/* k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1053,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 86   make-parameter */
t4=C_retrieve(lf[355]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[6]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1059,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1059r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1059r(t0,t1,t2,t3);}}

static void C_ccall f_1059r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1062,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1095,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 99   initialize-compiler */
t6=C_retrieve(lf[354]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(C_word)C_i_memq(lf[10],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[11]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[11]))){
t7=t6;
f_3227(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[353]),C_SCHEME_END_OF_LIST);}}

/* k3236 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[226],t1);
t3=((C_word*)t0)[2];
f_3227(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3225 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_3227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 102  append */
t2=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[352]),t1);}

/* k3221 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3219,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[12],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[13],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 110  option-arg */
f_1062(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[5]))){
t9=t8;
f_1111(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3208,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 115  pathname-file */
t10=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3208(2,t10,lf[351]);}}}}

/* k3206 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 115  make-pathname */
t2=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[350]);}

/* k3184 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 112  symbol->string */
t2=*((C_word*)lf[182]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1111(2,t2,t1);}}

/* k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1114,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 116  getenv */
t5=C_retrieve(lf[347]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[348]);}

/* k3178 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[345]);
/* batch-driver.scm: 116  string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[346]);}

/* k3174 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[294]),t1);}

/* k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=C_retrieve(lf[15]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[16];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[17],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1120,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1120(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[255],((C_word*)t0)[8]);
t14=t12;
f_1120(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[18],((C_word*)t0)[8])));}}

/* k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1120,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[18],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[19]);
t5=(C_word)C_i_memq(lf[20],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[30],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1164,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1170,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1188,a[2]=t25,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1210,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1225,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1237,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1286,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1423,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t30,a[11]=t23,a[12]=t1,a[13]=t34,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t28,a[18]=t27,a[19]=t13,a[20]=t17,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t26,a[24]=t35,a[25]=t33,a[26]=t32,a[27]=t19,a[28]=t24,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=t31,a[32]=((C_word*)t0)[8],a[33]=t21,a[34]=t11,a[35]=((C_word*)t0)[12],a[36]=((C_word*)t0)[13],a[37]=t16,tmp=(C_word)a,a+=38,tmp);
if(C_truep(t12)){
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3149,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3153,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 211  option-arg */
f_1062(t39,t12);}
else{
t37=t36;
f_1508(t37,C_SCHEME_UNDEFINED);}}

/* k3155 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 211  stringify */
t2=C_retrieve(lf[344]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3151 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 211  string->c-identifier */
t2=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3147 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[201]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1508(t3,t2);}

/* k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1508,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=C_retrieve(lf[201]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[342] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1511(t6,t5);}
else{
t5=t2;
f_1511(t5,C_SCHEME_UNDEFINED);}}

/* k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1511,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3119,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 219  collect-options */
t5=((C_word*)t0)[31];
f_1366(t5,t4,lf[341]);}

/* k3139 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 215  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3118 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3125,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3137,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[340]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3135 in a3118 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3124 in a3118 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3125,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 217  string->symbol */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[31]));
t4=C_mutate(((C_word *)((C_word*)t0)[37])+1,t3);
t5=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3101,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3117,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 225  collect-options */
t8=((C_word*)t0)[31];
f_1366(t8,t7,lf[339]);}

/* k3115 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3100 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3101,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 223  string->symbol */
t4=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3107 in a3100 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 224  string-append */
t3=*((C_word*)lf[337]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[338]);}

/* k3111 in k3107 in a3100 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3113,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[336],((C_word*)t0)[36]))){
t4=C_set_block_item(lf[153] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1526(t5,t4);}
else{
t4=t3;
f_1526(t4,C_SCHEME_UNDEFINED);}}

/* k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1526,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[114],C_retrieve(lf[31])))){
/* batch-driver.scm: 227  ##sys#start-timer */
t3=*((C_word*)lf[335]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1529(2,t3,C_SCHEME_UNDEFINED);}}

/* k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[334],C_retrieve(lf[31])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1532(t4,t3);}
else{
t3=t2;
f_1532(t3,C_SCHEME_UNDEFINED);}}

/* k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1532,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[331],((C_word*)t0)[35]))){
/* batch-driver.scm: 230  warning */
t3=C_retrieve(lf[332]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[333]);}
else{
t3=t2;
f_1535(2,t3,C_SCHEME_UNDEFINED);}}

/* k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[11] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[31],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1538(t6,t5);}
else{
t3=t2;
f_1538(t3,C_SCHEME_UNDEFINED);}}

/* k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[328],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[329] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1541(t4,t3);}
else{
t3=t2;
f_1541(t3,C_SCHEME_UNDEFINED);}}

/* k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1541,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[326],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[327] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1544(t4,t3);}
else{
t3=t2;
f_1544(t3,C_SCHEME_UNDEFINED);}}

/* k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1544(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1544,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[325],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[133] /* inline-globally */,0,C_SCHEME_TRUE);
t4=t2;
f_1547(t4,t3);}
else{
t3=t2;
f_1547(t3,C_SCHEME_UNDEFINED);}}

/* k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 241  collect-options */
t4=((C_word*)t0)[30];
f_1366(t4,t3,lf[324]);}

/* k3059 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[35]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 243  printf */
t5=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[323]);}
else{
t5=t4;
f_3053(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1554(t4,C_SCHEME_UNDEFINED);}}

/* k3051 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[128] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1554(t3,t2);}

/* k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1554,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[99],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[99] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1557(t4,t3);}
else{
t3=t2;
f_1557(t3,C_SCHEME_UNDEFINED);}}

/* k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1557,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[151],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[151] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1560(t4,t3);}
else{
t3=t2;
f_1560(t3,C_SCHEME_UNDEFINED);}}

/* k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1560,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[320],((C_word*)t0)[35]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[321] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1563(t5,t4);}
else{
t4=t2;
f_1563(t4,C_SCHEME_UNDEFINED);}}

/* k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1563,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[318],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[319] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1566(t4,t3);}
else{
t3=t2;
f_1566(t3,C_SCHEME_UNDEFINED);}}

/* k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1566,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[315],((C_word*)t0)[35]))){
t3=C_mutate((C_word*)lf[316]+1 /* (set! number-type ...) */,lf[317]);
t4=t2;
f_1569(t4,t3);}
else{
t3=t2;
f_1569(t3,C_SCHEME_UNDEFINED);}}

/* k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1569,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[314],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[204] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1572(t4,t3);}
else{
t3=t2;
f_1572(t3,C_SCHEME_UNDEFINED);}}

/* k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1572,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[313] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1575(t4,t3);}
else{
t3=t2;
f_1575(t3,C_SCHEME_UNDEFINED);}}

/* k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1575,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[310],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[311] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1578(t4,t3);}
else{
t3=t2;
f_1578(t3,C_SCHEME_UNDEFINED);}}

/* k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1578,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 257  option-arg */
f_1062(t4,t2);}
else{
t4=t3;
f_1584(t4,C_SCHEME_FALSE);}}

/* k3010 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[134]+1 /* (set! emit-inline-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1584(t3,t2);}

/* k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1584,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[35],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 260  option-arg */
f_1062(t4,t2);}
else{
t4=t3;
f_1590(t4,C_SCHEME_FALSE);}}

/* k2997 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3002,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 261  string->number */
C_string_to_number(3,0,t2,t1);}

/* k3000 in k2997 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3005(2,t3,t1);}
else{
/* batch-driver.scm: 262  quit */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[309],((C_word*)t0)[2]);}}

/* k3003 in k3000 in k2997 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[308]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1590(t3,t2);}

/* k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1590,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[305],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[35])){
/* batch-driver.scm: 264  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[307]);}
else{
t4=t3;
f_2986(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1593(2,t3,C_SCHEME_UNDEFINED);}}

/* k2984 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 265  register-feature! */
t3=C_retrieve(lf[287]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[305]);}

/* k2987 in k2984 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 266  case-sensitive */
t2=C_retrieve(lf[306]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[303],((C_word*)t0)[30]))){
/* batch-driver.scm: 268  compiler-warning */
t3=C_retrieve(lf[196]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[202],lf[304]);}
else{
t3=t2;
f_1596(2,t3,C_SCHEME_UNDEFINED);}}

/* k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 270  option-arg */
f_1062(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1599(2,t3,C_SCHEME_UNDEFINED);}}

/* k2942 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[296],t1))){
/* batch-driver.scm: 271  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[297]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[298],t1))){
/* batch-driver.scm: 272  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[299]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[300],t1))){
/* batch-driver.scm: 273  keyword-style */
t2=C_retrieve(lf[24]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}
else{
/* batch-driver.scm: 274  quit */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[302]);}}}}

/* k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[34]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[34],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2941,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 278  collect-options */
t7=((C_word*)t0)[30];
f_1366(t7,t6,lf[295]);}

/* k2939 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[294]),t1);}

/* k2935 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 278  append */
t2=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t4=(C_truep(((C_word*)t0)[19])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[19],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 282  quit */
t5=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[293]);}
else{
t5=t3;
f_1608(2,t5,C_SCHEME_UNDEFINED);}}

/* k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2913,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2921,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 287  collect-options */
t6=((C_word*)t0)[30];
f_1366(t6,t5,lf[226]);}

/* k2919 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 285  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2912 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2913,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[292]);}

/* k2909 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[290],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[291] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1615(t5,t4);}
else{
t4=t3;
f_1615(t4,C_SCHEME_UNDEFINED);}}

/* k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1615,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2895,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 294  collect-options */
t6=((C_word*)t0)[30];
f_1366(t6,t5,lf[289]);}

/* k2901 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 294  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2894 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2895,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[288]);}

/* k2891 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[287]),t1);}

/* k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 298  collect-options */
t5=((C_word*)t0)[30];
f_1366(t5,t4,lf[286]);}

/* k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1628,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[20])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 300  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[285]);}
else{
t3=t2;
f_1628(2,t3,C_SCHEME_UNDEFINED);}}

/* k2884 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 301  load-verbose */
t2=C_retrieve(lf[284]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2875,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2874 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2875,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 302  ##sys#resolve-include-filename */
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2881 in a2874 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 302  load */
t2=C_retrieve(lf[283]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 303  delete */
t3=C_retrieve(lf[282]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[68]+1));}

/* k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 306  user-post-analysis-pass */
t6=C_retrieve(lf[5]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 309  append */
t4=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[32])[1],C_retrieve(lf[281]));}

/* k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[277],((C_word*)t0)[29]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=t3,a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[32],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2861,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[19])){
/* batch-driver.scm: 318  pathname-file */
t7=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[19]);}
else{
if(C_truep(((C_word*)t0)[27])){
/* batch-driver.scm: 319  pathname-file */
t7=C_retrieve(lf[279]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[27]);}
else{
/* batch-driver.scm: 320  quit */
t7=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[280]);}}}
else{
t4=t3;
f_1650(t4,C_SCHEME_UNDEFINED);}}

/* k2859 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 317  string->symbol */
t2=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2855 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[278],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 314  append */
t5=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}

/* k2839 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1650(t3,t2);}

/* k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1650,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[31],a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[31],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],tmp=(C_word)a,a+=33,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[30],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2814,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2834,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 336  ids */
t7=t2;
f_1652(t7,t6,lf[276]);}

/* k2832 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2813 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2814,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[275],t5));}

/* k2810 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 333  append */
t2=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[32],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[273],((C_word*)t0)[31]))){
t4=C_set_block_item(lf[274] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1681(t5,t4);}
else{
t4=t3;
f_1681(t4,C_SCHEME_UNDEFINED);}}

/* k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1681,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 342  option-arg */
f_1062(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[272]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1685(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1685(2,t4,C_SCHEME_FALSE);}}}

/* k2789 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 342  arg-val */
f_1286(((C_word*)t0)[2],t1);}

/* k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 346  option-arg */
f_1062(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1689(2,t4,C_SCHEME_FALSE);}}

/* k2782 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 346  arg-val */
f_1286(((C_word*)t0)[2],t1);}

/* k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 347  option-arg */
f_1062(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1693(2,t4,C_SCHEME_FALSE);}}

/* k2775 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 347  arg-val */
f_1286(((C_word*)t0)[2],t1);}

/* k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 348  option-arg */
f_1062(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1697(2,t4,C_SCHEME_FALSE);}}

/* k2768 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 348  arg-val */
f_1286(((C_word*)t0)[2],t1);}

/* k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1697,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2750,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 351  option-arg */
f_1062(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[271]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1701(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1701(2,t5,C_SCHEME_FALSE);}}}

/* k2748 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 351  arg-val */
f_1286(((C_word*)t0)[2],t1);}

/* k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1701,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[79],((C_word*)t0)[25]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[80]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[81],((C_word*)t0)[25]);
t7=C_mutate((C_word*)lf[82]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[269],C_retrieve(lf[31])))){
/* batch-driver.scm: 357  set-gc-report! */
t9=C_retrieve(lf[270]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1712(2,t9,C_SCHEME_UNDEFINED);}}

/* k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[264],((C_word*)t0)[25]))){
t3=t2;
f_1715(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[265]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[266]));
t4=C_mutate((C_word*)lf[267]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[268]));
t5=t2;
f_1715(t5,t4);}}

/* k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1715,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[80]))?lf[261]:lf[262]);
/* batch-driver.scm: 362  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[263],t3);}
else{
t3=t2;
f_1718(2,t3,C_SCHEME_UNDEFINED);}}

/* k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[255],t3);
t5=C_set_block_item(lf[217] /* emit-profile */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2703,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t7=(C_truep(t4)?lf[259]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 370  append */
t8=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[260]),t7);}
else{
t3=t2;
f_1721(2,t3,C_SCHEME_UNDEFINED);}}

/* k2701 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[256]:lf[257]);
/* batch-driver.scm: 377  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[258],t3);}
else{
t3=((C_word*)t0)[2];
f_1721(2,t3,C_SCHEME_UNDEFINED);}}

/* k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[83],((C_word*)t0)[24]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 380  print-version */
t3=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[86],((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(t2)){
t4=t3;
f_1742(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[252],((C_word*)t0)[24]);
if(C_truep(t4)){
t5=t3;
f_1742(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[253],((C_word*)t0)[24]);
t6=t3;
f_1742(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[254],((C_word*)t0)[24])));}}}}

/* k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1742,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 383  print-usage */
t2=C_retrieve(lf[87]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[24]);}
else{
if(C_truep((C_word)C_i_memq(lf[88],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 385  chicken-version */
t4=C_retrieve(lf[90]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[22];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1779(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 395  printf */
t4=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[250],((C_word*)t0)[22]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 389  print-version */
t4=C_retrieve(lf[85]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1771 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 390  display */
t2=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[251]);}

/* k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! source-filename ...) */,((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[24],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 397  debugging */
t4=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[245],lf[249],((C_word*)t0)[10]);}

/* k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 398  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[245],lf[248],C_retrieve(lf[31]));}

/* k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 399  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[245],lf[247],C_retrieve(lf[74]));}

/* k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 400  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[245],lf[246],C_retrieve(lf[78]));}

/* k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=f_1164();
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 404  make-vector */
t5=*((C_word*)lf[243]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[244]),C_SCHEME_END_OF_LIST);}

/* k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 405  collect-options */
t4=((C_word*)t0)[2];
f_1366(t4,t3,lf[242]);}

/* k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 406  collect-options */
t3=((C_word*)t0)[2];
f_1366(t3,t2,lf[241]);}

/* k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 408  collect-options */
t4=((C_word*)t0)[2];
f_1366(t4,t3,lf[240]);}

/* k2667 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2677,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 410  collect-options */
t4=((C_word*)t0)[2];
f_1366(t4,t3,lf[239]);}

/* k2675 in k2667 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 407  append */
t2=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm: 412  user-read-pass */
t3=C_retrieve(lf[1]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],a[22]=((C_word*)t0)[26],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[22])){
/* batch-driver.scm: 414  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[232]);}
else{
t4=t3;
f_2572(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2584(t6,t2,((C_word*)t0)[4]);}}

/* doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2584,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2595,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[233]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 424  check-and-open-input-file */
t5=C_retrieve(lf[238]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2662,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[237]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2661 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[235]));
t3=C_mutate((C_word*)lf[235]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2629 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2634,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 426  read-form */
t3=((C_word*)t0)[2];
f_1423(t3,t2,((C_word*)t0)[5]);}

/* k2632 in a2629 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2639(t5,((C_word*)t0)[2],t1);}

/* doloop629 in k2632 in a2629 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 429  close-checked-input-file */
t3=C_retrieve(lf[236]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 427  read-form */
t6=((C_word*)t0)[2];
f_1423(t6,t5,((C_word*)t0)[6]);}}

/* k2658 in doloop629 in k2632 in a2629 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2639(t2,((C_word*)t0)[2],t1);}

/* a2624 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[235]));
t3=C_mutate((C_word*)lf[235]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2614 in k2611 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2584(t3,((C_word*)t0)[2],t2);}

/* k2597 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 421  reverse */
t3=*((C_word*)lf[234]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2601 in k2597 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[233]),((C_word*)t0)[2]);}

/* k2605 in k2601 in k2597 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 420  append */
t2=*((C_word*)lf[212]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2593 in doloop600 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2570 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 415  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2574 in k2570 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1815(2,t3,t2);}

/* k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 433  user-preprocessor-pass */
t3=C_retrieve(lf[2]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2562,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[18])){
/* batch-driver.scm: 435  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[231]);}
else{
t4=t3;
f_2562(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1821(t3,C_SCHEME_UNDEFINED);}}

/* k2560 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2564 in k2560 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1821(t3,t2);}

/* k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1821,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 438  print-expr */
t3=((C_word*)t0)[7];
f_1225(t3,t2,lf[229],lf[230],((C_word*)((C_word*)t0)[3])[1]);}

/* k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1824,2,t0,t1);}
t2=f_1396(((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1830(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 441  append */
t5=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[225]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2537 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
t2=C_mutate((C_word*)lf[225]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[228]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2557 in k2537 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[226],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[227],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1830(t7,t6);}

/* k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1830,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 443  append */
t4=*((C_word*)lf[212]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2530 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[224]),t1);}

/* k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 444  gensym */
t3=C_retrieve(lf[223]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[92]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2500,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[222]));}

/* a2499 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2500,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[214],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[219],t8));}

/* k2372 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2490,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[221]));}

/* a2489 in k2372 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2490,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[220],t3));}

/* k2376 in k2372 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[217]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[214],t3);
t5=(C_truep(C_retrieve(lf[201]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[214],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[218],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[215]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[219],t12);
t14=t2;
f_2382(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2382(t3,C_SCHEME_END_OF_LIST);}}

/* k2380 in k2376 in k2372 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_2382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2382,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2401,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[92]));}

/* a2400 in k2380 in k2376 in k2372 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2401,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[214],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[214],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[215]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[216],t11));}

/* k2384 in k2380 in k2376 in k2372 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[201]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 446  append */
t5=*((C_word*)lf[212]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[213]);}

/* k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2367,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 467  debugging */
t6=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[210],lf[211]);}

/* k2365 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 468  display-real-name-table */
t2=C_retrieve(lf[209]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1845(2,t2,C_SCHEME_UNDEFINED);}}

/* k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 469  debugging */
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[207],lf[208]);}

/* k2359 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 470  display-line-number-database */
t2=C_retrieve(lf[206]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1848(2,t2,C_SCHEME_UNDEFINED);}}

/* k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[204]))?C_retrieve(lf[201]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 473  compiler-warning */
t4=C_retrieve(lf[196]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[202],lf[205],C_retrieve(lf[201]));}
else{
t4=t2;
f_1851(2,t4,C_SCHEME_UNDEFINED);}}

/* k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[201]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 479  compiler-warning */
t4=C_retrieve(lf[196]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[202],lf[203],C_retrieve(lf[201]));}
else{
t4=t2;
f_1854(2,t4,C_SCHEME_UNDEFINED);}}

/* k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[151]))){
/* batch-driver.scm: 481  feature? */
t4=C_retrieve(lf[199]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[200]);}
else{
t4=t3;
f_2340(2,t4,C_SCHEME_FALSE);}}

/* k2338 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 482  compiler-warning */
t2=C_retrieve(lf[196]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[197],lf[198]);}
else{
t2=((C_word*)t0)[2];
f_1857(2,t2,C_SCHEME_UNDEFINED);}}

/* k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! line-number-database ...) */,C_retrieve(lf[93]));
t3=C_set_block_item(lf[93] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 489  end-time */
t5=((C_word*)t0)[17];
f_1406(t5,t4,lf[195]);}

/* k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 490  print-expr */
t3=((C_word*)t0)[2];
f_1225(t3,t2,lf[193],lf[194],((C_word*)((C_word*)t0)[4])[1]);}

/* k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[192],((C_word*)t0)[2]))){
/* batch-driver.scm: 492  exit */
t3=C_retrieve(lf[126]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1868(2,t3,C_SCHEME_UNDEFINED);}}

/* k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 494  user-pass */
t3=C_retrieve(lf[3]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2318,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[12])){
/* batch-driver.scm: 496  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[191]);}
else{
t4=t3;
f_2318(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1874(2,t3,C_SCHEME_UNDEFINED);}}

/* k2316 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=f_1396(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2323 in k2316 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 499  end-time */
t3=((C_word*)t0)[3];
f_1406(t3,((C_word*)t0)[2],lf[190]);}

/* k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 501  vector->list */
t4=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[189]));}

/* k2313 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 501  concatenate */
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1880,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2308,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 502  debugging */
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[186],lf[187]);}

/* k2306 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 503  pp */
t2=C_retrieve(lf[185]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1880(2,t2,C_SCHEME_UNDEFINED);}}

/* k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[133]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[184]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1883(2,t3,C_SCHEME_UNDEFINED);}}

/* k2303 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 514  concatenate */
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2299 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2266 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2267,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2293,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 508  symbol->string */
t6=*((C_word*)lf[182]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2295 in a2266 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 508  make-pathname */
t2=C_retrieve(lf[180]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[181]);}

/* k2291 in a2266 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 507  ##sys#resolve-include-filename */
t2=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2269 in a2266 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 510  file-exists? */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2278 in k2269 in a2266 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 512  print */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[176],((C_word*)t0)[3],lf[177]);}
else{
t3=t2;
f_2283(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2281 in k2278 in k2269 in a2266 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 513  load-inline-file */
t2=C_retrieve(lf[174]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 519  canonicalize-begin-body */
t5=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2260 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 518  build-node-graph */
t2=C_retrieve(lf[172]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2256 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2250,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[170],lf[171],t2);}

/* f_2250 in k2256 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2250,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[169],t2,t3,t4));}

/* k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1889,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 520  user-pass-2 */
t3=C_retrieve(lf[4]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[13],a[8]=t2,a[9]=((C_word*)t0)[16],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[12])){
/* batch-driver.scm: 522  printf */
t4=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[168]);}
else{
t4=t3;
f_2216(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1892(t3,C_SCHEME_UNDEFINED);}}

/* k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=f_1396(((C_word*)t0)[9]);
t3=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 525  analyze */
t5=((C_word*)t0)[2];
f_1429(t5,t4,lf[167],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2221 in k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 526  print-db */
t3=((C_word*)t0)[2];
f_1210(t3,t2,lf[166],lf[160],t1,C_fix(0));}

/* k2224 in k2221 in k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 527  end-time */
t3=((C_word*)t0)[3];
f_1406(t3,t2,lf[165]);}

/* k2227 in k2224 in k2221 in k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=f_1396(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 529  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2233 in k2227 in k2224 in k2221 in k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 530  end-time */
t3=((C_word*)t0)[2];
f_1406(t3,t2,lf[164]);}

/* k2236 in k2233 in k2227 in k2224 in k2221 in k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 531  print-node */
t3=((C_word*)t0)[3];
f_1188(t3,t2,lf[162],lf[163],((C_word*)t0)[2]);}

/* k2239 in k2236 in k2233 in k2227 in k2224 in k2221 in k2214 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1892(t3,t2);}

/* k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1892,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[153]))){
t3=f_1396(((C_word*)t0)[16]);
t4=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 537  analyze */
t6=((C_word*)t0)[14];
f_1429(t6,t5,lf[161],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1895(t3,C_SCHEME_UNDEFINED);}}

/* k2192 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2197,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 538  print-db */
t3=((C_word*)t0)[2];
f_1210(t3,t2,lf[159],lf[160],t1,C_fix(0));}

/* k2195 in k2192 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 539  end-time */
t3=((C_word*)t0)[3];
f_1406(t3,t2,lf[158]);}

/* k2198 in k2195 in k2192 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=f_1396(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 541  perform-lambda-lifting! */
t4=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2204 in k2198 in k2195 in k2192 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 542  end-time */
t3=((C_word*)t0)[2];
f_1406(t3,t2,lf[156]);}

/* k2207 in k2204 in k2198 in k2195 in k2192 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 543  print-node */
t3=((C_word*)t0)[3];
f_1188(t3,t2,lf[154],lf[155],((C_word*)t0)[2]);}

/* k2210 in k2207 in k2204 in k2198 in k2195 in k2192 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1895(t3,t2);}

/* k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1895,NULL,2,t0,t1);}
t2=C_set_block_item(lf[42] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[94] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[95] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[151]))){
t6=t5;
f_1901(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2183,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2183 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2183,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2180 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* batch-driver.scm: 550  scan-toplevel-assignments */
t3=C_retrieve(lf[152]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=f_1396(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 553  perform-cps-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1910,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 554  end-time */
t3=((C_word*)t0)[14];
f_1406(t3,t2,lf[149]);}

/* k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 555  print-node */
t3=((C_word*)t0)[13];
f_1188(t3,t2,lf[147],lf[148],((C_word*)t0)[2]);}

/* k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1918(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1918(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1396(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[15],a[19]=t4,tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 561  analyze */
t7=((C_word*)t0)[12];
f_1429(t7,t6,lf[146],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep(C_retrieve(lf[96]))){
if(C_truep((C_word)C_i_memq(lf[144],C_retrieve(lf[31])))){
/* batch-driver.scm: 564  dump-undefined-globals */
t3=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t3=t2;
f_1928(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1928(2,t3,C_SCHEME_UNDEFINED);}}

/* k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=C_set_block_item(lf[96] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 566  end-time */
t4=((C_word*)t0)[14];
f_1406(t4,t3,lf[143]);}

/* k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 567  print-db */
t3=((C_word*)t0)[2];
f_1210(t3,t2,lf[141],lf[142],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_memq(lf[139],C_retrieve(lf[31])))){
/* batch-driver.scm: 569  print-program-statistics */
t3=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1938(2,t3,C_SCHEME_UNDEFINED);}}

/* k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
if(C_truep(((C_word*)t0)[20])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 572  debugging */
t3=C_retrieve(lf[104]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[105],lf[110],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[18],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 596  print-node */
t3=((C_word*)t0)[12];
f_1188(t3,t2,lf[137],lf[138],((C_word*)t0)[18]);}}

/* k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[133]))?C_retrieve(lf[134]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_retrieve(lf[134]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[16],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[15])){
/* batch-driver.scm: 601  printf */
t6=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[136],t4);}
else{
t6=t5;
f_2150(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t2;
f_2033(2,t4,C_SCHEME_UNDEFINED);}}

/* k2148 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 602  emit-global-inline-file */
t2=C_retrieve(lf[135]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=f_1396(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 605  perform-closure-conversion */
t4=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 606  end-time */
t3=((C_word*)t0)[13];
f_1406(t3,t2,lf[131]);}

/* k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 607  print-db */
t3=((C_word*)t0)[3];
f_1210(t3,t2,lf[129],lf[130],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[128]))){
t4=f_1164();
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2130(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2130(t4,C_SCHEME_FALSE);}}

/* k2128 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_2130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 609  display */
t2=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[127]);}
else{
t2=((C_word*)t0)[2];
f_2048(2,t2,C_SCHEME_UNDEFINED);}}

/* k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 610  exit */
t3=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_2051(2,t3,C_SCHEME_UNDEFINED);}}

/* k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 611  print-node */
t3=((C_word*)t0)[2];
f_1188(t3,t2,lf[124],lf[125],((C_word*)t0)[11]);}

/* k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=f_1396(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2068,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 616  end-time */
t7=((C_word*)t0)[7];
f_1406(t7,t6,lf[123]);}

/* k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
t2=f_1396(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 619  open-output-file */
t4=*((C_word*)lf[121]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 619  current-output-port */
t4=*((C_word*)lf[122]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2081(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 621  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[120],((C_word*)t0)[9]);}}

/* k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 622  generate-code */
t3=C_retrieve(lf[119]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2082 in k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 623  close-output-port */
t3=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2087(2,t3,C_SCHEME_UNDEFINED);}}

/* k2085 in k2082 in k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 624  end-time */
t3=((C_word*)t0)[2];
f_1406(t3,t2,lf[117]);}

/* k2088 in k2085 in k2082 in k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[114],C_retrieve(lf[31])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 625  ##sys#stop-timer */
t4=*((C_word*)lf[116]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2093(2,t3,C_SCHEME_UNDEFINED);}}

/* k2110 in k2088 in k2085 in k2082 in k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 625  ##sys#display-times */
t2=C_retrieve(lf[115]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2091 in k2088 in k2085 in k2082 in k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 626  compiler-cleanup-hook */
t3=C_retrieve(lf[113]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2094 in k2091 in k2088 in k2085 in k2082 in k2079 in k2076 in k2070 in a2067 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 628  printf */
t2=C_retrieve(lf[32]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[112]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2061 in k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2031 in k2028 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
/* batch-driver.scm: 615  prepare-for-code-generation */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=f_1396(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1958,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 577  end-time */
t5=((C_word*)t0)[4];
f_1406(t5,t4,lf[109]);}

/* k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 578  print-node */
t3=((C_word*)t0)[2];
f_1188(t3,t2,lf[107],lf[108],((C_word*)t0)[6]);}

/* k1963 in k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 580  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1918(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[98]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[99]))){
t3=f_1396(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 587  analyze */
t5=((C_word*)t0)[2];
f_1429(t5,t4,lf[103],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 593  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1918(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 582  debugging */
t4=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[105],lf[106]);}}}

/* k1982 in k1963 in k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[98] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 584  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1918(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1999 in k1963 in k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2004,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 588  end-time */
t3=((C_word*)t0)[2];
f_1406(t3,t2,lf[102]);}

/* k2002 in k1999 in k1963 in k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=f_1396(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 590  transform-direct-lambdas! */
t4=C_retrieve(lf[101]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2008 in k2002 in k1999 in k1963 in k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2013,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 591  end-time */
t3=((C_word*)t0)[2];
f_1406(t3,t2,lf[100]);}

/* k2011 in k2008 in k2002 in k1999 in k1963 in k1960 in a1957 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 592  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1918(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1951 in k1942 in k1936 in k1933 in k1930 in k1926 in k1923 in loop in k1911 in k1908 in k1905 in k1899 in k1893 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 in k1869 in k1866 in k1863 in k1860 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1834 in k1831 in k1828 in k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in k1798 in k1790 in k1787 in k1784 in k1781 in k1777 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
/* batch-driver.scm: 576  perform-high-level-optimizations */
t2=C_retrieve(lf[97]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1759 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 385  display */
t2=*((C_word*)lf[89]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1752 in k1740 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 386  newline */
t2=*((C_word*)lf[84]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1728 in k1719 in k1716 in k1713 in k1710 in k1699 in k1695 in k1691 in k1687 in k1683 in k1679 in k1676 in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 381  newline */
t2=*((C_word*)lf[84]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ids in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1652,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1666,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1674,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 330  collect-options */
t7=((C_word*)t0)[2];
f_1366(t7,t6,t2);}

/* k1672 in ids in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 328  append-map */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1665 in ids in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1666,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[71]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[72]);}

/* k1662 in ids in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[70]+1),t1);}

/* k1658 in ids in k1648 in k1645 in k1641 in k1633 in k1629 in k1626 in k1623 in k1616 in k1613 in k1610 in k1606 in k1603 in k1597 in k1594 in k1591 in k1588 in k1582 in k1576 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1545 in k1542 in k1539 in k1536 in k1533 in k1530 in k1527 in k1524 in k1521 in k1513 in k1509 in k1506 in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 325  lset-difference */
t2=C_retrieve(lf[67]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[68]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1429,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1431,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no302350 */
t8=t7;
f_1459(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf303346 */
t10=t6;
f_1454(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body300309 */
t12=t5;
f_1431(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[55],t11);}}}}

/* def-no302 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1459(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1459,NULL,2,t0,t1);}
/* def-contf303346 */
t2=((C_word*)t0)[2];
f_1454(t2,t1,C_fix(0));}

/* def-contf303 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1454,NULL,3,t0,t1,t2);}
/* body300309 */
t3=((C_word*)t0)[2];
f_1431(t3,t1,t2,C_SCHEME_TRUE);}

/* body300 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1431,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1435,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 202  analyze-expression */
t5=C_retrieve(lf[53]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1433 in body300 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1438,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1449,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 204  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1438(2,t3,C_SCHEME_UNDEFINED);}}

/* a1448 in k1433 in body300 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1449,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[52]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1442 in k1433 in body300 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1443,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[51]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k1436 in k1433 in body300 in analyze in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1423,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 198  ##sys#read */
t3=C_retrieve(lf[50]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1406,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_1164();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 195  printf */
t5=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[49],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static C_word C_fcall f_1396(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_1164();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1366,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1372(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1372,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 187  option-arg */
f_1062(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1384 in loop in collect-options in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1390,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 187  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1372(t4,t2,t3);}

/* k1388 in k1384 in loop in collect-options in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1286(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1286,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1296,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 178  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 180  substring */
t11=*((C_word*)lf[48]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1351,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 181  substring */
t13=*((C_word*)lf[48]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1353 in arg-val in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 181  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1349 in arg-val in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1296(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1333 in arg-val in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 180  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1325 in arg-val in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1296(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1294 in arg-val in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 183  quit */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1237,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1241,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[46]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1283,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1283 in infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1283,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1239 in infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1244,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[45],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1247(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1247(t5,C_SCHEME_FALSE);}}

/* k1245 in k1239 in infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1247,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 170  ##sys#hash-table-ref */
t6=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[42]),t5);}
else{
t2=((C_word*)t0)[3];
f_1244(2,t2,C_SCHEME_UNDEFINED);}}

/* k1260 in k1245 in k1239 in infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 169  alist-cons */
t3=C_retrieve(lf[43]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1256 in k1245 in k1239 in infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 166  ##sys#hash-table-set! */
t2=C_retrieve(lf[41]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[42]),((C_word*)t0)[2],t1);}

/* k1242 in k1239 in infohook in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1225,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 160  print-header */
t6=((C_word*)t0)[2];
f_1170(t6,t5,t2,t3);}

/* k1230 in print-expr in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[36]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1210(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1210,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1217,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 155  print-header */
t7=((C_word*)t0)[2];
f_1170(t7,t6,t2,t3);}

/* k1215 in print-db in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 156  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[39],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1218 in k1215 in print-db in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 157  display-analysis-database */
t2=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1188,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1195,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 149  print-header */
t6=((C_word*)t0)[2];
f_1170(t6,t5,t2,t3);}

/* k1193 in print-node in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 151  dump-nodes */
t2=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 152  build-expression-tree */
t3=C_retrieve(lf[37]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1206 in k1193 in print-node in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 152  pretty-print */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1170(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1170,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1174,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 142  printf */
t5=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[34],t2);}
else{
t5=t4;
f_1174(2,t5,C_SCHEME_UNDEFINED);}}

/* k1172 in print-header in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[31])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 145  printf */
t3=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[33],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1181 in k1172 in print-header in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k1118 in k1112 in k1109 in k3217 in k1093 in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static C_word C_fcall f_1164(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file in k1055 in k1051 in k1047 in k1043 in k1039 in k1035 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 */
static void C_fcall f_1062(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1062,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 94   quit */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[8],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 97   quit */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[9],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[309] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_1017batch-driver.scm",(void*)f_1017},
{"f_1020batch-driver.scm",(void*)f_1020},
{"f_1023batch-driver.scm",(void*)f_1023},
{"f_1026batch-driver.scm",(void*)f_1026},
{"f_1029batch-driver.scm",(void*)f_1029},
{"f_1032batch-driver.scm",(void*)f_1032},
{"f_1037batch-driver.scm",(void*)f_1037},
{"f_1041batch-driver.scm",(void*)f_1041},
{"f_1045batch-driver.scm",(void*)f_1045},
{"f_1049batch-driver.scm",(void*)f_1049},
{"f_1053batch-driver.scm",(void*)f_1053},
{"f_1057batch-driver.scm",(void*)f_1057},
{"f_1059batch-driver.scm",(void*)f_1059},
{"f_1095batch-driver.scm",(void*)f_1095},
{"f_3238batch-driver.scm",(void*)f_3238},
{"f_3227batch-driver.scm",(void*)f_3227},
{"f_3223batch-driver.scm",(void*)f_3223},
{"f_3219batch-driver.scm",(void*)f_3219},
{"f_3208batch-driver.scm",(void*)f_3208},
{"f_3186batch-driver.scm",(void*)f_3186},
{"f_1111batch-driver.scm",(void*)f_1111},
{"f_3180batch-driver.scm",(void*)f_3180},
{"f_3176batch-driver.scm",(void*)f_3176},
{"f_1114batch-driver.scm",(void*)f_1114},
{"f_1120batch-driver.scm",(void*)f_1120},
{"f_3157batch-driver.scm",(void*)f_3157},
{"f_3153batch-driver.scm",(void*)f_3153},
{"f_3149batch-driver.scm",(void*)f_3149},
{"f_1508batch-driver.scm",(void*)f_1508},
{"f_1511batch-driver.scm",(void*)f_1511},
{"f_3141batch-driver.scm",(void*)f_3141},
{"f_3119batch-driver.scm",(void*)f_3119},
{"f_3137batch-driver.scm",(void*)f_3137},
{"f_3125batch-driver.scm",(void*)f_3125},
{"f_1515batch-driver.scm",(void*)f_1515},
{"f_3117batch-driver.scm",(void*)f_3117},
{"f_3101batch-driver.scm",(void*)f_3101},
{"f_3109batch-driver.scm",(void*)f_3109},
{"f_3113batch-driver.scm",(void*)f_3113},
{"f_1523batch-driver.scm",(void*)f_1523},
{"f_1526batch-driver.scm",(void*)f_1526},
{"f_1529batch-driver.scm",(void*)f_1529},
{"f_1532batch-driver.scm",(void*)f_1532},
{"f_1535batch-driver.scm",(void*)f_1535},
{"f_1538batch-driver.scm",(void*)f_1538},
{"f_1541batch-driver.scm",(void*)f_1541},
{"f_1544batch-driver.scm",(void*)f_1544},
{"f_1547batch-driver.scm",(void*)f_1547},
{"f_3061batch-driver.scm",(void*)f_3061},
{"f_1551batch-driver.scm",(void*)f_1551},
{"f_3053batch-driver.scm",(void*)f_3053},
{"f_1554batch-driver.scm",(void*)f_1554},
{"f_1557batch-driver.scm",(void*)f_1557},
{"f_1560batch-driver.scm",(void*)f_1560},
{"f_1563batch-driver.scm",(void*)f_1563},
{"f_1566batch-driver.scm",(void*)f_1566},
{"f_1569batch-driver.scm",(void*)f_1569},
{"f_1572batch-driver.scm",(void*)f_1572},
{"f_1575batch-driver.scm",(void*)f_1575},
{"f_1578batch-driver.scm",(void*)f_1578},
{"f_3012batch-driver.scm",(void*)f_3012},
{"f_1584batch-driver.scm",(void*)f_1584},
{"f_2999batch-driver.scm",(void*)f_2999},
{"f_3002batch-driver.scm",(void*)f_3002},
{"f_3005batch-driver.scm",(void*)f_3005},
{"f_1590batch-driver.scm",(void*)f_1590},
{"f_2986batch-driver.scm",(void*)f_2986},
{"f_2989batch-driver.scm",(void*)f_2989},
{"f_1593batch-driver.scm",(void*)f_1593},
{"f_1596batch-driver.scm",(void*)f_1596},
{"f_2944batch-driver.scm",(void*)f_2944},
{"f_1599batch-driver.scm",(void*)f_1599},
{"f_2941batch-driver.scm",(void*)f_2941},
{"f_2937batch-driver.scm",(void*)f_2937},
{"f_1605batch-driver.scm",(void*)f_1605},
{"f_1608batch-driver.scm",(void*)f_1608},
{"f_2921batch-driver.scm",(void*)f_2921},
{"f_2913batch-driver.scm",(void*)f_2913},
{"f_2911batch-driver.scm",(void*)f_2911},
{"f_1612batch-driver.scm",(void*)f_1612},
{"f_1615batch-driver.scm",(void*)f_1615},
{"f_2903batch-driver.scm",(void*)f_2903},
{"f_2895batch-driver.scm",(void*)f_2895},
{"f_2893batch-driver.scm",(void*)f_2893},
{"f_1618batch-driver.scm",(void*)f_1618},
{"f_1625batch-driver.scm",(void*)f_1625},
{"f_2886batch-driver.scm",(void*)f_2886},
{"f_1628batch-driver.scm",(void*)f_1628},
{"f_2875batch-driver.scm",(void*)f_2875},
{"f_2883batch-driver.scm",(void*)f_2883},
{"f_1631batch-driver.scm",(void*)f_1631},
{"f_1635batch-driver.scm",(void*)f_1635},
{"f_1643batch-driver.scm",(void*)f_1643},
{"f_1647batch-driver.scm",(void*)f_1647},
{"f_2861batch-driver.scm",(void*)f_2861},
{"f_2857batch-driver.scm",(void*)f_2857},
{"f_2841batch-driver.scm",(void*)f_2841},
{"f_1650batch-driver.scm",(void*)f_1650},
{"f_2834batch-driver.scm",(void*)f_2834},
{"f_2814batch-driver.scm",(void*)f_2814},
{"f_2812batch-driver.scm",(void*)f_2812},
{"f_1678batch-driver.scm",(void*)f_1678},
{"f_1681batch-driver.scm",(void*)f_1681},
{"f_2791batch-driver.scm",(void*)f_2791},
{"f_1685batch-driver.scm",(void*)f_1685},
{"f_2784batch-driver.scm",(void*)f_2784},
{"f_1689batch-driver.scm",(void*)f_1689},
{"f_2777batch-driver.scm",(void*)f_2777},
{"f_1693batch-driver.scm",(void*)f_1693},
{"f_2770batch-driver.scm",(void*)f_2770},
{"f_1697batch-driver.scm",(void*)f_1697},
{"f_2750batch-driver.scm",(void*)f_2750},
{"f_1701batch-driver.scm",(void*)f_1701},
{"f_1712batch-driver.scm",(void*)f_1712},
{"f_1715batch-driver.scm",(void*)f_1715},
{"f_1718batch-driver.scm",(void*)f_1718},
{"f_2703batch-driver.scm",(void*)f_2703},
{"f_1721batch-driver.scm",(void*)f_1721},
{"f_1742batch-driver.scm",(void*)f_1742},
{"f_1773batch-driver.scm",(void*)f_1773},
{"f_1779batch-driver.scm",(void*)f_1779},
{"f_1783batch-driver.scm",(void*)f_1783},
{"f_1786batch-driver.scm",(void*)f_1786},
{"f_1789batch-driver.scm",(void*)f_1789},
{"f_1792batch-driver.scm",(void*)f_1792},
{"f_1800batch-driver.scm",(void*)f_1800},
{"f_1803batch-driver.scm",(void*)f_1803},
{"f_1806batch-driver.scm",(void*)f_1806},
{"f_2669batch-driver.scm",(void*)f_2669},
{"f_2677batch-driver.scm",(void*)f_2677},
{"f_1809batch-driver.scm",(void*)f_1809},
{"f_1812batch-driver.scm",(void*)f_1812},
{"f_2584batch-driver.scm",(void*)f_2584},
{"f_2613batch-driver.scm",(void*)f_2613},
{"f_2662batch-driver.scm",(void*)f_2662},
{"f_2630batch-driver.scm",(void*)f_2630},
{"f_2634batch-driver.scm",(void*)f_2634},
{"f_2639batch-driver.scm",(void*)f_2639},
{"f_2660batch-driver.scm",(void*)f_2660},
{"f_2625batch-driver.scm",(void*)f_2625},
{"f_2616batch-driver.scm",(void*)f_2616},
{"f_2599batch-driver.scm",(void*)f_2599},
{"f_2603batch-driver.scm",(void*)f_2603},
{"f_2607batch-driver.scm",(void*)f_2607},
{"f_2595batch-driver.scm",(void*)f_2595},
{"f_2572batch-driver.scm",(void*)f_2572},
{"f_2576batch-driver.scm",(void*)f_2576},
{"f_1815batch-driver.scm",(void*)f_1815},
{"f_1818batch-driver.scm",(void*)f_1818},
{"f_2562batch-driver.scm",(void*)f_2562},
{"f_2566batch-driver.scm",(void*)f_2566},
{"f_1821batch-driver.scm",(void*)f_1821},
{"f_1824batch-driver.scm",(void*)f_1824},
{"f_2539batch-driver.scm",(void*)f_2539},
{"f_2559batch-driver.scm",(void*)f_2559},
{"f_1830batch-driver.scm",(void*)f_1830},
{"f_2532batch-driver.scm",(void*)f_2532},
{"f_1833batch-driver.scm",(void*)f_1833},
{"f_1836batch-driver.scm",(void*)f_1836},
{"f_2500batch-driver.scm",(void*)f_2500},
{"f_2374batch-driver.scm",(void*)f_2374},
{"f_2490batch-driver.scm",(void*)f_2490},
{"f_2378batch-driver.scm",(void*)f_2378},
{"f_2382batch-driver.scm",(void*)f_2382},
{"f_2401batch-driver.scm",(void*)f_2401},
{"f_2386batch-driver.scm",(void*)f_2386},
{"f_1842batch-driver.scm",(void*)f_1842},
{"f_2367batch-driver.scm",(void*)f_2367},
{"f_1845batch-driver.scm",(void*)f_1845},
{"f_2361batch-driver.scm",(void*)f_2361},
{"f_1848batch-driver.scm",(void*)f_1848},
{"f_1851batch-driver.scm",(void*)f_1851},
{"f_1854batch-driver.scm",(void*)f_1854},
{"f_2340batch-driver.scm",(void*)f_2340},
{"f_1857batch-driver.scm",(void*)f_1857},
{"f_1862batch-driver.scm",(void*)f_1862},
{"f_1865batch-driver.scm",(void*)f_1865},
{"f_1868batch-driver.scm",(void*)f_1868},
{"f_1871batch-driver.scm",(void*)f_1871},
{"f_2318batch-driver.scm",(void*)f_2318},
{"f_2325batch-driver.scm",(void*)f_2325},
{"f_1874batch-driver.scm",(void*)f_1874},
{"f_2315batch-driver.scm",(void*)f_2315},
{"f_1877batch-driver.scm",(void*)f_1877},
{"f_2308batch-driver.scm",(void*)f_2308},
{"f_1880batch-driver.scm",(void*)f_1880},
{"f_2305batch-driver.scm",(void*)f_2305},
{"f_2301batch-driver.scm",(void*)f_2301},
{"f_2267batch-driver.scm",(void*)f_2267},
{"f_2297batch-driver.scm",(void*)f_2297},
{"f_2293batch-driver.scm",(void*)f_2293},
{"f_2271batch-driver.scm",(void*)f_2271},
{"f_2280batch-driver.scm",(void*)f_2280},
{"f_2283batch-driver.scm",(void*)f_2283},
{"f_1883batch-driver.scm",(void*)f_1883},
{"f_2262batch-driver.scm",(void*)f_2262},
{"f_2258batch-driver.scm",(void*)f_2258},
{"f_2250batch-driver.scm",(void*)f_2250},
{"f_1886batch-driver.scm",(void*)f_1886},
{"f_1889batch-driver.scm",(void*)f_1889},
{"f_2216batch-driver.scm",(void*)f_2216},
{"f_2223batch-driver.scm",(void*)f_2223},
{"f_2226batch-driver.scm",(void*)f_2226},
{"f_2229batch-driver.scm",(void*)f_2229},
{"f_2235batch-driver.scm",(void*)f_2235},
{"f_2238batch-driver.scm",(void*)f_2238},
{"f_2241batch-driver.scm",(void*)f_2241},
{"f_1892batch-driver.scm",(void*)f_1892},
{"f_2194batch-driver.scm",(void*)f_2194},
{"f_2197batch-driver.scm",(void*)f_2197},
{"f_2200batch-driver.scm",(void*)f_2200},
{"f_2206batch-driver.scm",(void*)f_2206},
{"f_2209batch-driver.scm",(void*)f_2209},
{"f_2212batch-driver.scm",(void*)f_2212},
{"f_1895batch-driver.scm",(void*)f_1895},
{"f_2183batch-driver.scm",(void*)f_2183},
{"f_2182batch-driver.scm",(void*)f_2182},
{"f_1901batch-driver.scm",(void*)f_1901},
{"f_1907batch-driver.scm",(void*)f_1907},
{"f_1910batch-driver.scm",(void*)f_1910},
{"f_1913batch-driver.scm",(void*)f_1913},
{"f_1918batch-driver.scm",(void*)f_1918},
{"f_1925batch-driver.scm",(void*)f_1925},
{"f_1928batch-driver.scm",(void*)f_1928},
{"f_1932batch-driver.scm",(void*)f_1932},
{"f_1935batch-driver.scm",(void*)f_1935},
{"f_1938batch-driver.scm",(void*)f_1938},
{"f_2030batch-driver.scm",(void*)f_2030},
{"f_2150batch-driver.scm",(void*)f_2150},
{"f_2033batch-driver.scm",(void*)f_2033},
{"f_2039batch-driver.scm",(void*)f_2039},
{"f_2042batch-driver.scm",(void*)f_2042},
{"f_2045batch-driver.scm",(void*)f_2045},
{"f_2130batch-driver.scm",(void*)f_2130},
{"f_2048batch-driver.scm",(void*)f_2048},
{"f_2051batch-driver.scm",(void*)f_2051},
{"f_2054batch-driver.scm",(void*)f_2054},
{"f_2068batch-driver.scm",(void*)f_2068},
{"f_2072batch-driver.scm",(void*)f_2072},
{"f_2078batch-driver.scm",(void*)f_2078},
{"f_2081batch-driver.scm",(void*)f_2081},
{"f_2084batch-driver.scm",(void*)f_2084},
{"f_2087batch-driver.scm",(void*)f_2087},
{"f_2090batch-driver.scm",(void*)f_2090},
{"f_2112batch-driver.scm",(void*)f_2112},
{"f_2093batch-driver.scm",(void*)f_2093},
{"f_2096batch-driver.scm",(void*)f_2096},
{"f_2062batch-driver.scm",(void*)f_2062},
{"f_1944batch-driver.scm",(void*)f_1944},
{"f_1958batch-driver.scm",(void*)f_1958},
{"f_1962batch-driver.scm",(void*)f_1962},
{"f_1965batch-driver.scm",(void*)f_1965},
{"f_1984batch-driver.scm",(void*)f_1984},
{"f_2001batch-driver.scm",(void*)f_2001},
{"f_2004batch-driver.scm",(void*)f_2004},
{"f_2010batch-driver.scm",(void*)f_2010},
{"f_2013batch-driver.scm",(void*)f_2013},
{"f_1952batch-driver.scm",(void*)f_1952},
{"f_1761batch-driver.scm",(void*)f_1761},
{"f_1754batch-driver.scm",(void*)f_1754},
{"f_1730batch-driver.scm",(void*)f_1730},
{"f_1652batch-driver.scm",(void*)f_1652},
{"f_1674batch-driver.scm",(void*)f_1674},
{"f_1666batch-driver.scm",(void*)f_1666},
{"f_1664batch-driver.scm",(void*)f_1664},
{"f_1660batch-driver.scm",(void*)f_1660},
{"f_1429batch-driver.scm",(void*)f_1429},
{"f_1459batch-driver.scm",(void*)f_1459},
{"f_1454batch-driver.scm",(void*)f_1454},
{"f_1431batch-driver.scm",(void*)f_1431},
{"f_1435batch-driver.scm",(void*)f_1435},
{"f_1449batch-driver.scm",(void*)f_1449},
{"f_1443batch-driver.scm",(void*)f_1443},
{"f_1438batch-driver.scm",(void*)f_1438},
{"f_1423batch-driver.scm",(void*)f_1423},
{"f_1406batch-driver.scm",(void*)f_1406},
{"f_1396batch-driver.scm",(void*)f_1396},
{"f_1366batch-driver.scm",(void*)f_1366},
{"f_1372batch-driver.scm",(void*)f_1372},
{"f_1386batch-driver.scm",(void*)f_1386},
{"f_1390batch-driver.scm",(void*)f_1390},
{"f_1286batch-driver.scm",(void*)f_1286},
{"f_1355batch-driver.scm",(void*)f_1355},
{"f_1351batch-driver.scm",(void*)f_1351},
{"f_1335batch-driver.scm",(void*)f_1335},
{"f_1327batch-driver.scm",(void*)f_1327},
{"f_1296batch-driver.scm",(void*)f_1296},
{"f_1237batch-driver.scm",(void*)f_1237},
{"f_1283batch-driver.scm",(void*)f_1283},
{"f_1241batch-driver.scm",(void*)f_1241},
{"f_1247batch-driver.scm",(void*)f_1247},
{"f_1262batch-driver.scm",(void*)f_1262},
{"f_1258batch-driver.scm",(void*)f_1258},
{"f_1244batch-driver.scm",(void*)f_1244},
{"f_1225batch-driver.scm",(void*)f_1225},
{"f_1232batch-driver.scm",(void*)f_1232},
{"f_1210batch-driver.scm",(void*)f_1210},
{"f_1217batch-driver.scm",(void*)f_1217},
{"f_1220batch-driver.scm",(void*)f_1220},
{"f_1188batch-driver.scm",(void*)f_1188},
{"f_1195batch-driver.scm",(void*)f_1195},
{"f_1208batch-driver.scm",(void*)f_1208},
{"f_1170batch-driver.scm",(void*)f_1170},
{"f_1174batch-driver.scm",(void*)f_1174},
{"f_1183batch-driver.scm",(void*)f_1183},
{"f_1164batch-driver.scm",(void*)f_1164},
{"f_1062batch-driver.scm",(void*)f_1062},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
