/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-01 13:56
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: batch-driver.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[349];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_fcall f_3166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_fcall f_1103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_fcall f_1494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_fcall f_1509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_fcall f_1515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_fcall f_1537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_fcall f_1540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_fcall f_1546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_fcall f_1552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_fcall f_1558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_fcall f_1567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_fcall f_1592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_fcall f_1627(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_fcall f_1658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_fcall f_1692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_fcall f_1719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_fcall f_2522(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_fcall f_1798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_fcall f_1807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_fcall f_2320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_fcall f_1863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_fcall f_1866(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_fcall f_1889(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_fcall f_2104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_fcall f_1629(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_fcall f_1412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1442)
static void C_fcall f_1442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_fcall f_1437(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1414)
static void C_fcall f_1414(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1389)
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1379)
static C_word C_fcall f_1379(C_word t0);
C_noret_decl(f_1349)
static void C_fcall f_1349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1355)
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_fcall f_1269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_fcall f_1230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_fcall f_1193(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_fcall f_1171(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static C_word C_fcall f_1147();
C_noret_decl(f_1045)
static void C_fcall f_1045(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3166)
static void C_fcall trf_3166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3166(t0,t1);}

C_noret_decl(trf_1103)
static void C_fcall trf_1103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1103(t0,t1);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1491(t0,t1);}

C_noret_decl(trf_1494)
static void C_fcall trf_1494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1494(t0,t1);}

C_noret_decl(trf_1509)
static void C_fcall trf_1509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1509(t0,t1);}

C_noret_decl(trf_1515)
static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1515(t0,t1);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1521(t0,t1);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1524(t0,t1);}

C_noret_decl(trf_1537)
static void C_fcall trf_1537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1537(t0,t1);}

C_noret_decl(trf_1540)
static void C_fcall trf_1540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1540(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1546)
static void C_fcall trf_1546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1546(t0,t1);}

C_noret_decl(trf_1549)
static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1549(t0,t1);}

C_noret_decl(trf_1552)
static void C_fcall trf_1552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1552(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1555(t0,t1);}

C_noret_decl(trf_1558)
static void C_fcall trf_1558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1558(t0,t1);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1567)
static void C_fcall trf_1567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1567(t0,t1);}

C_noret_decl(trf_1592)
static void C_fcall trf_1592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1592(t0,t1);}

C_noret_decl(trf_1627)
static void C_fcall trf_1627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1627(t0,t1);}

C_noret_decl(trf_1658)
static void C_fcall trf_1658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1658(t0,t1);}

C_noret_decl(trf_1692)
static void C_fcall trf_1692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1692(t0,t1);}

C_noret_decl(trf_1719)
static void C_fcall trf_1719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1719(t0,t1);}

C_noret_decl(trf_2522)
static void C_fcall trf_2522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2522(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2522(t0,t1,t2);}

C_noret_decl(trf_2577)
static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2577(t0,t1,t2);}

C_noret_decl(trf_1798)
static void C_fcall trf_1798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1798(t0,t1);}

C_noret_decl(trf_1807)
static void C_fcall trf_1807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1807(t0,t1);}

C_noret_decl(trf_2320)
static void C_fcall trf_2320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2320(t0,t1);}

C_noret_decl(trf_1863)
static void C_fcall trf_1863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1863(t0,t1);}

C_noret_decl(trf_1866)
static void C_fcall trf_1866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1866(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1866(t0,t1);}

C_noret_decl(trf_1889)
static void C_fcall trf_1889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1889(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1889(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2104)
static void C_fcall trf_2104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2104(t0,t1);}

C_noret_decl(trf_1629)
static void C_fcall trf_1629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1629(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1629(t0,t1,t2);}

C_noret_decl(trf_1412)
static void C_fcall trf_1412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1412(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1412(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1442)
static void C_fcall trf_1442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1442(t0,t1);}

C_noret_decl(trf_1437)
static void C_fcall trf_1437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1437(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1437(t0,t1,t2);}

C_noret_decl(trf_1414)
static void C_fcall trf_1414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1414(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1414(t0,t1,t2,t3);}

C_noret_decl(trf_1406)
static void C_fcall trf_1406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1406(t0,t1,t2);}

C_noret_decl(trf_1389)
static void C_fcall trf_1389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1389(t0,t1,t2);}

C_noret_decl(trf_1349)
static void C_fcall trf_1349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1349(t0,t1,t2);}

C_noret_decl(trf_1355)
static void C_fcall trf_1355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1355(t0,t1,t2);}

C_noret_decl(trf_1269)
static void C_fcall trf_1269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1269(t0,t1);}

C_noret_decl(trf_1230)
static void C_fcall trf_1230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1230(t0,t1);}

C_noret_decl(trf_1208)
static void C_fcall trf_1208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1208(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1208(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1193)
static void C_fcall trf_1193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1193(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1193(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1171)
static void C_fcall trf_1171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1171(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1171(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1153)
static void C_fcall trf_1153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1153(t0,t1,t2,t3);}

C_noret_decl(trf_1045)
static void C_fcall trf_1045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1045(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2630)){
C_save(t1);
C_rereclaim2(2630*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,349);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[4]=C_h_intern(&lf[4],17,"user-options-pass");
lf[5]=C_h_intern(&lf[5],14,"user-read-pass");
lf[6]=C_h_intern(&lf[6],22,"user-preprocessor-pass");
lf[7]=C_h_intern(&lf[7],9,"user-pass");
lf[8]=C_h_intern(&lf[8],11,"user-pass-2");
lf[9]=C_h_intern(&lf[9],23,"user-post-analysis-pass");
lf[10]=C_h_intern(&lf[10],27,"user-post-optimization-pass");
lf[11]=C_h_intern(&lf[11],19,"compile-source-file");
lf[12]=C_h_intern(&lf[12],4,"quit");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[15]=C_h_intern(&lf[15],12,"explicit-use");
lf[16]=C_h_intern(&lf[16],26,"\010compilerexplicit-use-flag");
lf[17]=C_h_intern(&lf[17],12,"\004coredeclare");
lf[18]=C_h_intern(&lf[18],7,"verbose");
lf[19]=C_h_intern(&lf[19],11,"output-file");
lf[20]=C_h_intern(&lf[20],36,"\010compilerdefault-optimization-passes");
lf[21]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[22]=C_h_intern(&lf[22],7,"profile");
lf[23]=C_h_intern(&lf[23],12,"profile-name");
lf[24]=C_h_intern(&lf[24],9,"heap-size");
lf[25]=C_h_intern(&lf[25],17,"heap-initial-size");
lf[26]=C_h_intern(&lf[26],11,"heap-growth");
lf[27]=C_h_intern(&lf[27],14,"heap-shrinkage");
lf[28]=C_h_intern(&lf[28],13,"keyword-style");
lf[29]=C_h_intern(&lf[29],4,"unit");
lf[30]=C_h_intern(&lf[30],12,"analyze-only");
lf[31]=C_h_intern(&lf[31],7,"dynamic");
lf[32]=C_h_intern(&lf[32],5,"quiet");
lf[33]=C_h_intern(&lf[33],7,"nursery");
lf[34]=C_h_intern(&lf[34],10,"stack-size");
lf[35]=C_h_intern(&lf[35],26,"\010compilerdebugging-chicken");
lf[36]=C_h_intern(&lf[36],6,"printf");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\014pass: ~a~%~!");
lf[39]=C_h_intern(&lf[39],19,"\010compilerdump-nodes");
lf[40]=C_h_intern(&lf[40],12,"pretty-print");
lf[41]=C_h_intern(&lf[41],30,"\010compilerbuild-expression-tree");
lf[42]=C_h_intern(&lf[42],34,"\010compilerdisplay-analysis-database");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[44]=C_h_intern(&lf[44],12,"\003sysfor-each");
lf[45]=C_h_intern(&lf[45],19,"\003syshash-table-set!");
lf[46]=C_h_intern(&lf[46],24,"\003sysline-number-database");
lf[47]=C_h_intern(&lf[47],10,"alist-cons");
lf[48]=C_h_intern(&lf[48],18,"\003syshash-table-ref");
lf[49]=C_h_intern(&lf[49],9,"list-info");
lf[50]=C_h_intern(&lf[50],26,"\003sysdefault-read-info-hook");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[52]=C_h_intern(&lf[52],9,"substring");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[54]=C_h_intern(&lf[54],8,"\003sysread");
lf[55]=C_h_intern(&lf[55],12,"\010compilerget");
lf[56]=C_h_intern(&lf[56],13,"\010compilerput!");
lf[57]=C_h_intern(&lf[57],27,"\010compileranalyze-expression");
lf[58]=C_h_intern(&lf[58],9,"\003syserror");
lf[59]=C_h_intern(&lf[59],1,"D");
lf[60]=C_h_intern(&lf[60],25,"\010compilerimport-libraries");
lf[61]=C_h_intern(&lf[61],26,"\010compilerdisabled-warnings");
lf[62]=C_h_intern(&lf[62],12,"inline-limit");
lf[63]=C_h_intern(&lf[63],21,"\010compilerverbose-mode");
lf[64]=C_h_intern(&lf[64],31,"\003sysread-error-with-line-number");
lf[65]=C_h_intern(&lf[65],21,"\003sysinclude-pathnames");
lf[66]=C_h_intern(&lf[66],19,"\000compiler-extension");
lf[67]=C_h_intern(&lf[67],12,"\003sysfeatures");
lf[68]=C_h_intern(&lf[68],10,"\000compiling");
lf[69]=C_h_intern(&lf[69],15,"lset-difference");
lf[70]=C_h_intern(&lf[70],3,"eq\077");
lf[71]=C_h_intern(&lf[71],7,"\003sysmap");
lf[72]=C_h_intern(&lf[72],14,"string->symbol");
lf[73]=C_h_intern(&lf[73],12,"string-split");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[75]=C_h_intern(&lf[75],10,"append-map");
lf[76]=C_h_intern(&lf[76],25,"\010compilertarget-heap-size");
lf[77]=C_h_intern(&lf[77],33,"\010compilertarget-initial-heap-size");
lf[78]=C_h_intern(&lf[78],27,"\010compilertarget-heap-growth");
lf[79]=C_h_intern(&lf[79],30,"\010compilertarget-heap-shrinkage");
lf[80]=C_h_intern(&lf[80],26,"\010compilertarget-stack-size");
lf[81]=C_h_intern(&lf[81],8,"no-trace");
lf[82]=C_h_intern(&lf[82],24,"\010compileremit-trace-info");
lf[83]=C_h_intern(&lf[83],29,"disable-stack-overflow-checks");
lf[84]=C_h_intern(&lf[84],40,"\010compilerdisable-stack-overflow-checking");
lf[85]=C_h_intern(&lf[85],7,"version");
lf[86]=C_h_intern(&lf[86],7,"newline");
lf[87]=C_h_intern(&lf[87],22,"\010compilerprint-version");
lf[88]=C_h_intern(&lf[88],4,"help");
lf[89]=C_h_intern(&lf[89],20,"\010compilerprint-usage");
lf[90]=C_h_intern(&lf[90],7,"release");
lf[91]=C_h_intern(&lf[91],7,"display");
lf[92]=C_h_intern(&lf[92],15,"chicken-version");
lf[93]=C_h_intern(&lf[93],24,"\010compilersource-filename");
lf[94]=C_h_intern(&lf[94],28,"\010compilerprofile-lambda-list");
lf[95]=C_h_intern(&lf[95],31,"\010compilerline-number-database-2");
lf[96]=C_h_intern(&lf[96],23,"\010compilerconstant-table");
lf[97]=C_h_intern(&lf[97],21,"\010compilerinline-table");
lf[98]=C_h_intern(&lf[98],23,"\010compilerfirst-analysis");
lf[99]=C_h_intern(&lf[99],41,"\010compilerperform-high-level-optimizations");
lf[100]=C_h_intern(&lf[100],37,"\010compilerinline-substitutions-enabled");
lf[101]=C_h_intern(&lf[101],22,"optimize-leaf-routines");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[103]=C_h_intern(&lf[103],34,"\010compilertransform-direct-lambdas!");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[105]=C_h_intern(&lf[105],4,"leaf");
lf[106]=C_h_intern(&lf[106],18,"\010compilerdebugging");
lf[107]=C_h_intern(&lf[107],1,"p");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[110]=C_h_intern(&lf[110],1,"5");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[113]=C_h_intern(&lf[113],36,"\010compilerprepare-for-code-generation");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\031compilation finished.~%~!");
lf[115]=C_h_intern(&lf[115],30,"\010compilercompiler-cleanup-hook");
lf[116]=C_h_intern(&lf[116],1,"t");
lf[117]=C_h_intern(&lf[117],17,"\003sysdisplay-times");
lf[118]=C_h_intern(&lf[118],14,"\003sysstop-timer");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[120]=C_h_intern(&lf[120],17,"close-output-port");
lf[121]=C_h_intern(&lf[121],22,"\010compilergenerate-code");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\025generating `~A\047 ...~%");
lf[123]=C_h_intern(&lf[123],16,"open-output-file");
lf[124]=C_h_intern(&lf[124],19,"current-output-port");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[127]=C_h_intern(&lf[127],1,"9");
lf[128]=C_h_intern(&lf[128],4,"exit");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[130]=C_h_intern(&lf[130],20,"\003syswarnings-enabled");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[132]=C_h_intern(&lf[132],1,"8");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[134]=C_h_intern(&lf[134],35,"\010compilerperform-closure-conversion");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\033post-optimization user pass");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000 post-optimization user pass...~%");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[138]=C_h_intern(&lf[138],1,"7");
lf[139]=C_h_intern(&lf[139],1,"s");
lf[140]=C_h_intern(&lf[140],33,"\010compilerprint-program-statistics");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[142]=C_h_intern(&lf[142],1,"4");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[144]=C_h_intern(&lf[144],1,"u");
lf[145]=C_h_intern(&lf[145],31,"\010compilerdump-undefined-globals");
lf[146]=C_h_intern(&lf[146],3,"opt");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[148]=C_h_intern(&lf[148],1,"3");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[150]=C_h_intern(&lf[150],31,"\010compilerperform-cps-conversion");
lf[151]=C_h_intern(&lf[151],6,"unsafe");
lf[152]=C_h_intern(&lf[152],34,"\010compilerscan-toplevel-assignments");
lf[153]=C_h_intern(&lf[153],26,"\010compilerdo-lambda-lifting");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[155]=C_h_intern(&lf[155],1,"L");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[157]=C_h_intern(&lf[157],32,"\010compilerperform-lambda-lifting!");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[160]=C_h_intern(&lf[160],1,"0");
lf[161]=C_h_intern(&lf[161],4,"lift");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[163]=C_h_intern(&lf[163],1,"U");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\023secondary user pass");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\020pre-analysis (u)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\014analysis (u)");
lf[167]=C_h_intern(&lf[167],4,"user");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\030Secondary user pass...~%");
lf[169]=C_h_intern(&lf[169],11,"concatenate");
lf[170]=C_h_intern(&lf[170],12,"vector->list");
lf[171]=C_h_intern(&lf[171],26,"\010compilerfile-requirements");
lf[172]=C_h_intern(&lf[172],1,"M");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[174]=C_h_intern(&lf[174],4,"node");
lf[175]=C_h_intern(&lf[175],6,"lambda");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[177]=C_h_intern(&lf[177],25,"\010compilerbuild-node-graph");
lf[178]=C_h_intern(&lf[178],32,"\010compilercanonicalize-begin-body");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\020User pass...~%~!");
lf[181]=C_h_intern(&lf[181],12,"check-syntax");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[183]=C_h_intern(&lf[183],1,"2");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[185]=C_h_intern(&lf[185],25,"\010compilercompiler-warning");
lf[186]=C_h_intern(&lf[186],5,"style");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000ycompiling extensions in unsafe mode is bad practice and should be avoided a"
"s it may be surprising to an unsuspecting user");
lf[188]=C_h_intern(&lf[188],8,"feature\077");
lf[189]=C_h_intern(&lf[189],19,"compiling-extension");
lf[190]=C_h_intern(&lf[190],18,"\010compilerunit-name");
lf[191]=C_h_intern(&lf[191],5,"usage");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[193]=C_h_intern(&lf[193],26,"\010compilerblock-compilation");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000`compilation of library unit `~a\047 in block-mode - globals may not be accessi"
"ble outside this unit");
lf[195]=C_h_intern(&lf[195],37,"\010compilerdisplay-line-number-database");
lf[196]=C_h_intern(&lf[196],1,"n");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[198]=C_h_intern(&lf[198],32,"\010compilerdisplay-real-name-table");
lf[199]=C_h_intern(&lf[199],1,"N");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[201]=C_h_intern(&lf[201],6,"append");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[203]=C_h_intern(&lf[203],5,"quote");
lf[204]=C_h_intern(&lf[204],33,"\010compilerprofile-info-vector-name");
lf[205]=C_h_intern(&lf[205],28,"\003sysset-profile-info-vector!");
lf[206]=C_h_intern(&lf[206],21,"\010compileremit-profile");
lf[207]=C_h_intern(&lf[207],25,"\003sysregister-profile-info");
lf[208]=C_h_intern(&lf[208],4,"set!");
lf[209]=C_h_intern(&lf[209],13,"\004corecallunit");
lf[210]=C_h_intern(&lf[210],19,"\010compilerused-units");
lf[211]=C_h_intern(&lf[211],28,"\010compilerimmutable-constants");
lf[212]=C_h_intern(&lf[212],6,"gensym");
lf[213]=C_h_intern(&lf[213],32,"\010compilercanonicalize-expression");
lf[214]=C_h_intern(&lf[214],28,"\003sysexplicit-library-modules");
lf[215]=C_h_intern(&lf[215],4,"uses");
lf[216]=C_h_intern(&lf[216],7,"declare");
lf[217]=C_h_intern(&lf[217],10,"\003sysappend");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[219]=C_h_intern(&lf[219],1,"1");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036User preprocessing pass...~%~!");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\025User read pass...~%~!");
lf[222]=C_h_intern(&lf[222],21,"\010compilerstring->expr");
lf[223]=C_h_intern(&lf[223],7,"reverse");
lf[224]=C_h_intern(&lf[224],27,"\003syscurrent-source-filename");
lf[225]=C_h_intern(&lf[225],33,"\010compilerclose-checked-input-file");
lf[226]=C_h_intern(&lf[226],16,"\003sysdynamic-wind");
lf[227]=C_h_intern(&lf[227],34,"\010compilercheck-and-open-input-file");
lf[228]=C_h_intern(&lf[228],8,"epilogue");
lf[229]=C_h_intern(&lf[229],8,"prologue");
lf[230]=C_h_intern(&lf[230],8,"postlude");
lf[231]=C_h_intern(&lf[231],7,"prelude");
lf[232]=C_h_intern(&lf[232],11,"make-vector");
lf[233]=C_h_intern(&lf[233],34,"\010compilerline-number-database-size");
lf[234]=C_h_intern(&lf[234],1,"r");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\024compiling `~a\047 ...~%");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[241]=C_h_intern(&lf[241],5,"-help");
lf[242]=C_h_intern(&lf[242],1,"h");
lf[243]=C_h_intern(&lf[243],2,"-h");
lf[244]=C_h_intern(&lf[244],18,"accumulate-profile");
lf[245]=C_h_intern(&lf[245],28,"\010compilerprofiled-procedures");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\030Generating ~aprofile~%~!");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[250]=C_h_intern(&lf[250],39,"\010compilerdefault-profiling-declarations");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\012stacktrace");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\026debugging info: ~A~%~!");
lf[254]=C_h_intern(&lf[254],21,"no-usual-integrations");
lf[255]=C_h_intern(&lf[255],17,"standard-bindings");
lf[256]=C_h_intern(&lf[256],34,"\010compilerdefault-standard-bindings");
lf[257]=C_h_intern(&lf[257],17,"extended-bindings");
lf[258]=C_h_intern(&lf[258],34,"\010compilerdefault-extended-bindings");
lf[259]=C_h_intern(&lf[259],1,"m");
lf[260]=C_h_intern(&lf[260],14,"set-gc-report!");
lf[261]=C_h_intern(&lf[261],42,"\010compilerdefault-default-target-stack-size");
lf[262]=C_h_intern(&lf[262],41,"\010compilerdefault-default-target-heap-size");
lf[263]=C_h_intern(&lf[263],14,"compile-syntax");
lf[264]=C_h_intern(&lf[264],25,"\003sysenable-runtime-macros");
lf[265]=C_h_intern(&lf[265],22,"\004corerequire-extension");
lf[266]=C_h_intern(&lf[266],17,"require-extension");
lf[267]=C_h_intern(&lf[267],9,"extension");
lf[268]=C_h_intern(&lf[268],16,"define-extension");
lf[269]=C_h_intern(&lf[269],13,"pathname-file");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000-no filename available for `-extension\047 option");
lf[271]=C_h_intern(&lf[271],28,"\010compilerpostponed-initforms");
lf[272]=C_h_intern(&lf[272],6,"delete");
lf[273]=C_h_intern(&lf[273],4,"load");
lf[274]=C_h_intern(&lf[274],28,"\003sysresolve-include-filename");
lf[275]=C_h_intern(&lf[275],12,"load-verbose");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\042Loading compiler extensions...~%~!");
lf[277]=C_h_intern(&lf[277],6,"extend");
lf[278]=C_h_intern(&lf[278],17,"register-feature!");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[280]=C_h_intern(&lf[280],7,"feature");
lf[281]=C_h_intern(&lf[281],20,"keep-shadowed-macros");
lf[282]=C_h_intern(&lf[282],33,"\010compilerundefine-shadowed-macros");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[285]=C_h_intern(&lf[285],23,"\010compilerchop-separator");
lf[286]=C_h_intern(&lf[286],12,"include-path");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[288]=C_h_intern(&lf[288],7,"\000prefix");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[290]=C_h_intern(&lf[290],5,"\000none");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[292]=C_h_intern(&lf[292],7,"\000suffix");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[294]=C_h_intern(&lf[294],17,"compress-literals");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[296]=C_h_intern(&lf[296],16,"case-insensitive");
lf[297]=C_h_intern(&lf[297],14,"case-sensitive");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\0000Identifiers and symbols are case insensitive~%~!");
lf[299]=C_h_intern(&lf[299],24,"\010compilerinline-max-size");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[301]=C_h_intern(&lf[301],6,"inline");
lf[302]=C_h_intern(&lf[302],30,"emit-external-prototypes-first");
lf[303]=C_h_intern(&lf[303],30,"\010compilerexternal-protos-first");
lf[304]=C_h_intern(&lf[304],5,"block");
lf[305]=C_h_intern(&lf[305],17,"fixnum-arithmetic");
lf[306]=C_h_intern(&lf[306],11,"number-type");
lf[307]=C_h_intern(&lf[307],6,"fixnum");
lf[308]=C_h_intern(&lf[308],18,"disable-interrupts");
lf[309]=C_h_intern(&lf[309],28,"\010compilerinsert-timer-checks");
lf[310]=C_h_intern(&lf[310],16,"unsafe-libraries");
lf[311]=C_h_intern(&lf[311],27,"\010compileremit-unsafe-marker");
lf[312]=C_h_intern(&lf[312],11,"no-warnings");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\031Warnings are disabled~%~!");
lf[314]=C_h_intern(&lf[314],15,"disable-warning");
lf[315]=C_h_intern(&lf[315],6,"import");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000#deprecated compiler option: -import");
lf[317]=C_h_intern(&lf[317],13,"check-imports");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000*deprecated compiler option: -check-imports");
lf[319]=C_h_intern(&lf[319],14,"no-lambda-info");
lf[320]=C_h_intern(&lf[320],26,"\010compileremit-closure-info");
lf[321]=C_h_intern(&lf[321],3,"raw");
lf[322]=C_h_intern(&lf[322],12,"emit-exports");
lf[323]=C_h_intern(&lf[323],7,"warning");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[325]=C_h_intern(&lf[325],1,"b");
lf[326]=C_h_intern(&lf[326],15,"\003sysstart-timer");
lf[327]=C_h_intern(&lf[327],11,"lambda-lift");
lf[328]=C_h_intern(&lf[328],13,"string-append");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[330]=C_h_intern(&lf[330],19,"emit-import-library");
lf[331]=C_h_intern(&lf[331],16,"\003sysstring->list");
lf[332]=C_h_intern(&lf[332],5,"debug");
lf[333]=C_h_intern(&lf[333],30,"\010compilerstandalone-executable");
lf[334]=C_h_intern(&lf[334],29,"\010compilerstring->c-identifier");
lf[335]=C_h_intern(&lf[335],18,"\010compilerstringify");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[338]=C_h_intern(&lf[338],6,"getenv");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[340]=C_h_intern(&lf[340],14,"symbol->string");
lf[341]=C_h_intern(&lf[341],9,"to-stdout");
lf[342]=C_h_intern(&lf[342],13,"make-pathname");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[345]=C_h_intern(&lf[345],29,"\010compilerdefault-declarations");
lf[346]=C_h_intern(&lf[346],30,"\010compilerunits-used-by-default");
lf[347]=C_h_intern(&lf[347],28,"\010compilerinitialize-compiler");
lf[348]=C_h_intern(&lf[348],14,"make-parameter");
C_register_lf2(lf,349,create_ptable());
t2=C_mutate(&lf[0] /* (set! c358 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k994 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k997 in k994 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1000 in k997 in k994 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1003 in k1000 in k997 in k994 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant49 ...) */,lf[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 86   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! user-pass-2 ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 87   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 88   make-parameter */
t4=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1 /* (set! user-post-optimization-pass ...) */,t1);
t3=C_mutate((C_word*)lf[11]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1042,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1042r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1042r(t0,t1,t2,t3);}}

static void C_ccall f_1042r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1045,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1078,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 101  initialize-compiler */
t6=C_retrieve(lf[347]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(C_word)C_i_memq(lf[15],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[16]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3166,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[16]))){
t7=t6;
f_3166(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[217]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[346]),C_SCHEME_END_OF_LIST);}}

/* k3175 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[215],t1);
t3=((C_word*)t0)[2];
f_3166(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3164 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_3166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 104  append */
t2=*((C_word*)lf[201]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve(lf[345]),t1);}

/* k3160 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[217]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[18],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[19],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 112  option-arg */
f_1045(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[341],((C_word*)t0)[5]))){
t9=t8;
f_1094(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3147,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 117  pathname-file */
t10=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3147(2,t10,lf[344]);}}}}

/* k3145 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 117  make-pathname */
t2=C_retrieve(lf[342]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[343]);}

/* k3123 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 114  symbol->string */
t2=*((C_word*)lf[340]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1094(2,t2,t1);}}

/* k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1097,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3115,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 118  getenv */
t5=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[339]);}

/* k3117 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[336]);
/* batch-driver.scm: 118  string-split */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[337]);}

/* k3113 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[285]),t1);}

/* k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=C_retrieve(lf[20]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[21];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[22],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1103,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1103(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[244],((C_word*)t0)[8]);
t14=t12;
f_1103(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[23],((C_word*)t0)[8])));}}

/* k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[94],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1103,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[3]);
t5=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[30],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[31],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(C_word)C_i_memq(lf[32],((C_word*)t0)[13]);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(C_word)C_i_memq(lf[33],((C_word*)t0)[13]);
t23=(C_truep(t22)?t22:(C_word)C_i_memq(lf[34],((C_word*)t0)[13]));
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1147,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1171,a[2]=t25,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1193,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1220,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1269,tmp=(C_word)a,a+=2,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[9],a[3]=t24,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t30,a[11]=t23,a[12]=t1,a[13]=t34,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t28,a[18]=t27,a[19]=t13,a[20]=t17,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t26,a[24]=t35,a[25]=t33,a[26]=t32,a[27]=t19,a[28]=t24,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=t31,a[32]=((C_word*)t0)[8],a[33]=t21,a[34]=t11,a[35]=((C_word*)t0)[12],a[36]=((C_word*)t0)[13],a[37]=t16,tmp=(C_word)a,a+=38,tmp);
if(C_truep(t12)){
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3092,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=t38,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 213  option-arg */
f_1045(t39,t12);}
else{
t37=t36;
f_1491(t37,C_SCHEME_UNDEFINED);}}

/* k3094 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 213  stringify */
t2=C_retrieve(lf[335]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3090 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 213  string->c-identifier */
t2=C_retrieve(lf[334]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3086 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[190]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1491(t3,t2);}

/* k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=C_retrieve(lf[190]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[333] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1494(t6,t5);}
else{
t5=t2;
f_1494(t5,C_SCHEME_UNDEFINED);}}

/* k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1494,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|37,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],tmp=(C_word)a,a+=38,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3058,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3080,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 221  collect-options */
t5=((C_word*)t0)[31];
f_1349(t5,t4,lf[332]);}

/* k3078 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 217  append-map */
t2=C_retrieve(lf[75]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3057 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3064,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3076,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[331]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3074 in a3057 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3063 in a3057 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3064,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 219  string->symbol */
t4=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[59],C_retrieve(lf[35]));
t4=C_mutate(((C_word *)((C_word*)t0)[37])+1,t3);
t5=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3040,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 227  collect-options */
t8=((C_word*)t0)[31];
f_1349(t8,t7,lf[330]);}

/* k3054 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3039 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3040,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 225  string->symbol */
t4=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3046 in a3039 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3052,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 226  string-append */
t3=*((C_word*)lf[328]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[329]);}

/* k3050 in k3046 in a3039 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[327],((C_word*)t0)[36]))){
t4=C_set_block_item(lf[153] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1509(t5,t4);}
else{
t4=t3;
f_1509(t4,C_SCHEME_UNDEFINED);}}

/* k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[116],C_retrieve(lf[35])))){
/* batch-driver.scm: 229  ##sys#start-timer */
t3=*((C_word*)lf[326]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1512(2,t3,C_SCHEME_UNDEFINED);}}

/* k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[325],C_retrieve(lf[35])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1515(t4,t3);}
else{
t3=t2;
f_1515(t3,C_SCHEME_UNDEFINED);}}

/* k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1515,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[322],((C_word*)t0)[35]))){
/* batch-driver.scm: 232  warning */
t3=C_retrieve(lf[323]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[324]);}
else{
t3=t2;
f_1518(2,t3,C_SCHEME_UNDEFINED);}}

/* k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[321],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[16] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[31],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1521(t6,t5);}
else{
t3=t2;
f_1521(t3,C_SCHEME_UNDEFINED);}}

/* k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1521,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[319],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[320] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1524(t4,t3);}
else{
t3=t2;
f_1524(t3,C_SCHEME_UNDEFINED);}}

/* k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[35]))){
/* batch-driver.scm: 240  compiler-warning */
t3=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[191],lf[318]);}
else{
t3=t2;
f_1527(2,t3,C_SCHEME_UNDEFINED);}}

/* k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[315],((C_word*)t0)[35]))){
/* batch-driver.scm: 242  compiler-warning */
t3=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[191],lf[316]);}
else{
t3=t2;
f_1530(2,t3,C_SCHEME_UNDEFINED);}}

/* k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 243  collect-options */
t4=((C_word*)t0)[30];
f_1349(t4,t3,lf[314]);}

/* k2994 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[72]+1),t1);}

/* k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1534,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[35]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[34])){
/* batch-driver.scm: 245  printf */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[313]);}
else{
t5=t4;
f_2988(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1537(t4,C_SCHEME_UNDEFINED);}}

/* k2986 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[130] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1537(t3,t2);}

/* k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1537,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[101],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[101] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1540(t4,t3);}
else{
t3=t2;
f_1540(t3,C_SCHEME_UNDEFINED);}}

/* k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1540,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[151],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[151] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1543(t4,t3);}
else{
t3=t2;
f_1543(t3,C_SCHEME_UNDEFINED);}}

/* k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[310],((C_word*)t0)[35]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[311] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1546(t5,t4);}
else{
t4=t2;
f_1546(t4,C_SCHEME_UNDEFINED);}}

/* k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1546,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[308],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[309] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1549(t4,t3);}
else{
t3=t2;
f_1549(t3,C_SCHEME_UNDEFINED);}}

/* k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[305],((C_word*)t0)[35]))){
t3=C_mutate((C_word*)lf[306]+1 /* (set! number-type ...) */,lf[307]);
t4=t2;
f_1552(t4,t3);}
else{
t3=t2;
f_1552(t3,C_SCHEME_UNDEFINED);}}

/* k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1552,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[304],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[193] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1555(t4,t3);}
else{
t3=t2;
f_1555(t3,C_SCHEME_UNDEFINED);}}

/* k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[302],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[303] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1558(t4,t3);}
else{
t3=t2;
f_1558(t3,C_SCHEME_UNDEFINED);}}

/* k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[301],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[299] /* inline-max-size */,0,C_fix(10));
t4=t2;
f_1561(t4,t3);}
else{
t3=t2;
f_1561(t3,C_SCHEME_UNDEFINED);}}

/* k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[62],((C_word*)t0)[35]);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[35],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],tmp=(C_word)a,a+=36,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 259  option-arg */
f_1045(t4,t2);}
else{
t4=t3;
f_1567(t4,C_SCHEME_FALSE);}}

/* k2936 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2941,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 260  string->number */
C_string_to_number(3,0,t2,t1);}

/* k2939 in k2936 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_2944(2,t3,t1);}
else{
/* batch-driver.scm: 261  quit */
t3=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[300],((C_word*)t0)[2]);}}

/* k2942 in k2939 in k2936 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[299]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1567(t3,t2);}

/* k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1567,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[296],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[35])){
/* batch-driver.scm: 263  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[298]);}
else{
t4=t3;
f_2925(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1570(2,t3,C_SCHEME_UNDEFINED);}}

/* k2923 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 264  register-feature! */
t3=C_retrieve(lf[278]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[296]);}

/* k2926 in k2923 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 265  case-sensitive */
t2=C_retrieve(lf[297]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[294],((C_word*)t0)[30]))){
/* batch-driver.scm: 267  compiler-warning */
t3=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[191],lf[295]);}
else{
t3=t2;
f_1573(2,t3,C_SCHEME_UNDEFINED);}}

/* k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 269  option-arg */
f_1045(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1576(2,t3,C_SCHEME_UNDEFINED);}}

/* k2881 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[287],t1))){
/* batch-driver.scm: 270  keyword-style */
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[288]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[289],t1))){
/* batch-driver.scm: 271  keyword-style */
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[290]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[291],t1))){
/* batch-driver.scm: 272  keyword-style */
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[292]);}
else{
/* batch-driver.scm: 273  quit */
t2=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[293]);}}}}

/* k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[34]);
t3=C_set_block_item(lf[64] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[34],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 277  collect-options */
t7=((C_word*)t0)[30];
f_1349(t7,t6,lf[286]);}

/* k2878 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[285]),t1);}

/* k2874 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 277  append */
t2=*((C_word*)lf[201]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,C_retrieve(lf[65]),((C_word*)t0)[2]);}

/* k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t4=(C_truep(((C_word*)t0)[19])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[19],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 281  quit */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,lf[284]);}
else{
t5=t3;
f_1585(2,t5,C_SCHEME_UNDEFINED);}}

/* k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2850,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2852,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2860,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 286  collect-options */
t6=((C_word*)t0)[30];
f_1349(t6,t5,lf[215]);}

/* k2858 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 284  append-map */
t2=C_retrieve(lf[75]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2851 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2852,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[283]);}

/* k2848 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[72]+1),t1);}

/* k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[281],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[282] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1592(t5,t4);}
else{
t4=t3;
f_1592(t4,C_SCHEME_UNDEFINED);}}

/* k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1592,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2834,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2842,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 293  collect-options */
t6=((C_word*)t0)[30];
f_1349(t6,t5,lf[280]);}

/* k2840 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 293  append-map */
t2=C_retrieve(lf[75]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2833 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2834,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[279]);}

/* k2830 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[278]),t1);}

/* k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[67]));
t3=C_mutate((C_word*)lf[67]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 297  collect-options */
t5=((C_word*)t0)[30];
f_1349(t5,t4,lf[277]);}

/* k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1605,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[20])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2825,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 299  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[276]);}
else{
t3=t2;
f_1605(2,t3,C_SCHEME_UNDEFINED);}}

/* k2823 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 300  load-verbose */
t2=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2814,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2813 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2814,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 301  ##sys#resolve-include-filename */
t4=C_retrieve(lf[274]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2820 in a2813 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 301  load */
t2=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 302  delete */
t3=C_retrieve(lf[272]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[66],C_retrieve(lf[67]),*((C_word*)lf[70]+1));}

/* k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[68],C_retrieve(lf[67]));
t4=C_mutate((C_word*)lf[67]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 305  user-post-analysis-pass */
t6=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[33])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 308  append */
t4=*((C_word*)lf[201]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[32])[1],C_retrieve(lf[271]));}

/* k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[267],((C_word*)t0)[29]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t3,a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[32],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[19])){
/* batch-driver.scm: 317  pathname-file */
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[19]);}
else{
if(C_truep(((C_word*)t0)[27])){
/* batch-driver.scm: 318  pathname-file */
t7=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[27]);}
else{
/* batch-driver.scm: 319  quit */
t7=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[270]);}}}
else{
t4=t3;
f_1627(t4,C_SCHEME_UNDEFINED);}}

/* k2798 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 316  string->symbol */
t2=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2794 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[268],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 313  append */
t5=*((C_word*)lf[201]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t4);}

/* k2778 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1627(t3,t2);}

/* k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1627(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1627,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[31],a[3]=((C_word*)t0)[32],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[31],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],tmp=(C_word)a,a+=33,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[30],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2753,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 335  ids */
t7=t2;
f_1629(t7,t6,lf[266]);}

/* k2771 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2752 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2753,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[265],t5));}

/* k2749 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 332  append */
t2=*((C_word*)lf[201]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[32],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[263],((C_word*)t0)[31]))){
t4=C_set_block_item(lf[264] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1658(t5,t4);}
else{
t4=t3;
f_1658(t4,C_SCHEME_UNDEFINED);}}

/* k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1658,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2730,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 341  option-arg */
f_1045(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[262]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1662(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1662(2,t4,C_SCHEME_FALSE);}}}

/* k2728 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 341  arg-val */
f_1269(((C_word*)t0)[2],t1);}

/* k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],tmp=(C_word)a,a+=31,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2723,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 345  option-arg */
f_1045(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1666(2,t4,C_SCHEME_FALSE);}}

/* k2721 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 345  arg-val */
f_1269(((C_word*)t0)[2],t1);}

/* k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 346  option-arg */
f_1045(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1670(2,t4,C_SCHEME_FALSE);}}

/* k2714 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 346  arg-val */
f_1269(((C_word*)t0)[2],t1);}

/* k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2709,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 347  option-arg */
f_1045(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1674(2,t4,C_SCHEME_FALSE);}}

/* k2707 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 347  arg-val */
f_1269(((C_word*)t0)[2],t1);}

/* k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1674,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2689,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 350  option-arg */
f_1045(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[261]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1678(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1678(2,t5,C_SCHEME_FALSE);}}}

/* k2687 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 350  arg-val */
f_1269(((C_word*)t0)[2],t1);}

/* k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[81],((C_word*)t0)[25]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[82]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[83],((C_word*)t0)[25]);
t7=C_mutate((C_word*)lf[84]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[259],C_retrieve(lf[35])))){
/* batch-driver.scm: 356  set-gc-report! */
t9=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1689(2,t9,C_SCHEME_UNDEFINED);}}

/* k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep((C_word)C_i_memq(lf[254],((C_word*)t0)[25]))){
t3=t2;
f_1692(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[255]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[256]));
t4=C_mutate((C_word*)lf[257]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[258]));
t5=t2;
f_1692(t5,t4);}}

/* k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1692(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1692,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_truep(C_retrieve(lf[82]))?lf[251]:lf[252]);
/* batch-driver.scm: 361  printf */
t4=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[253],t3);}
else{
t3=t2;
f_1695(2,t3,C_SCHEME_UNDEFINED);}}

/* k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[244],t3);
t5=C_set_block_item(lf[206] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_set_block_item(lf[245] /* profiled-procedures */,0,C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[249]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 370  append */
t9=*((C_word*)lf[201]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)((C_word*)t0)[7])[1],C_retrieve(lf[250]),t8);}
else{
t3=t2;
f_1698(2,t3,C_SCHEME_UNDEFINED);}}

/* k2640 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
t3=(C_truep(((C_word*)t0)[3])?lf[246]:lf[247]);
/* batch-driver.scm: 377  printf */
t4=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[248],t3);}
else{
t3=((C_word*)t0)[2];
f_1698(2,t3,C_SCHEME_UNDEFINED);}}

/* k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[85],((C_word*)t0)[24]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1707,a[2]=((C_word*)t0)[23],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 380  print-version */
t3=C_retrieve(lf[87]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[88],((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(t2)){
t4=t3;
f_1719(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[241],((C_word*)t0)[24]);
if(C_truep(t4)){
t5=t3;
f_1719(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[242],((C_word*)t0)[24]);
t6=t3;
f_1719(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[243],((C_word*)t0)[24])));}}}}

/* k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1719,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 383  print-usage */
t2=C_retrieve(lf[89]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[24]);}
else{
if(C_truep((C_word)C_i_memq(lf[90],((C_word*)t0)[23]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1738,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 385  chicken-version */
t4=C_retrieve(lf[92]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=((C_word*)t0)[22];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[12])){
t4=t3;
f_1756(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 395  printf */
t4=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[239],((C_word*)t0)[22]);}}
else{
if(C_truep(((C_word*)t0)[12])){
t3=((C_word*)t0)[24];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[24],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 389  print-version */
t4=C_retrieve(lf[87]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}}}}

/* k1748 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 390  display */
t2=*((C_word*)lf[91]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[240]);}

/* k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! source-filename ...) */,((C_word*)t0)[24]);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[24],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 397  debugging */
t4=C_retrieve(lf[106]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[234],lf[238],((C_word*)t0)[10]);}

/* k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 398  debugging */
t3=C_retrieve(lf[106]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[234],lf[237],C_retrieve(lf[35]));}

/* k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 399  debugging */
t3=C_retrieve(lf[106]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[234],lf[236],C_retrieve(lf[76]));}

/* k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 400  debugging */
t3=C_retrieve(lf[106]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[234],lf[235],C_retrieve(lf[80]));}

/* k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=f_1147();
t3=C_mutate(((C_word *)((C_word*)t0)[23])+1,t2);
t4=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 404  make-vector */
t5=*((C_word*)lf[232]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[233]),C_SCHEME_END_OF_LIST);}

/* k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* batch-driver.scm: 405  collect-options */
t4=((C_word*)t0)[2];
f_1349(t4,t3,lf[231]);}

/* k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 406  collect-options */
t3=((C_word*)t0)[2];
f_1349(t3,t2,lf[230]);}

/* k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[19],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 408  collect-options */
t4=((C_word*)t0)[2];
f_1349(t4,t3,lf[229]);}

/* k2605 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2615,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 410  collect-options */
t4=((C_word*)t0)[2];
f_1349(t4,t3,lf[228]);}

/* k2613 in k2605 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 407  append */
t2=*((C_word*)lf[201]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
/* batch-driver.scm: 412  user-read-pass */
t3=C_retrieve(lf[5]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],a[22]=((C_word*)t0)[26],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[22])){
/* batch-driver.scm: 414  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[221]);}
else{
t4=t3;
f_2510(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2522(t6,t2,((C_word*)t0)[4]);}}

/* doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_2522(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2522,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2533,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[222]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 424  check-and-open-input-file */
t5=C_retrieve(lf[227]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2563,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2599 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[224]));
t3=C_mutate((C_word*)lf[224]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2567 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2572,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 426  read-form */
t3=((C_word*)t0)[2];
f_1406(t3,t2,((C_word*)t0)[5]);}

/* k2570 in a2567 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2577(t5,((C_word*)t0)[2],t1);}

/* doloop623 in k2570 in a2567 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 429  close-checked-input-file */
t3=C_retrieve(lf[225]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2598,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 427  read-form */
t6=((C_word*)t0)[2];
f_1406(t6,t5,((C_word*)t0)[6]);}}

/* k2596 in doloop623 in k2570 in a2567 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2577(t2,((C_word*)t0)[2],t1);}

/* a2562 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2563,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[224]));
t3=C_mutate((C_word*)lf[224]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2552 in k2549 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2522(t3,((C_word*)t0)[2],t2);}

/* k2535 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 421  reverse */
t3=*((C_word*)lf[223]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2539 in k2535 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2545,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[222]),((C_word*)t0)[2]);}

/* k2543 in k2539 in k2535 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 420  append */
t2=*((C_word*)lf[201]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2531 in doloop594 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2508 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 415  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2512 in k2508 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1792(2,t3,t2);}

/* k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 433  user-preprocessor-pass */
t3=C_retrieve(lf[6]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2500,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[18])){
/* batch-driver.scm: 435  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[220]);}
else{
t4=t3;
f_2500(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1798(t3,C_SCHEME_UNDEFINED);}}

/* k2498 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2502 in k2498 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1798(t3,t2);}

/* k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1798,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 438  print-expr */
t3=((C_word*)t0)[7];
f_1208(t3,t2,lf[218],lf[219],((C_word*)((C_word*)t0)[3])[1]);}

/* k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=f_1379(((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],tmp=(C_word)a,a+=22,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1807(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 441  append */
t5=*((C_word*)lf[201]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[214]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2475 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=C_mutate((C_word*)lf[214]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[217]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2495 in k2475 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[215],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[216],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1807(t7,t6);}

/* k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1807,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 443  append */
t4=*((C_word*)lf[201]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2468 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[213]),t1);}

/* k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 444  gensym */
t3=C_retrieve(lf[212]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[94]));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],tmp=(C_word)a,a+=18,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2438,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[211]));}

/* a2437 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2438,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[203],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[208],t8));}

/* k2310 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2428,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[210]));}

/* a2427 in k2310 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2428,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[209],t3));}

/* k2314 in k2310 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[203],t3);
t5=(C_truep(C_retrieve(lf[190]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[203],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[207],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[204]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[208],t12);
t14=t2;
f_2320(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2320(t3,C_SCHEME_END_OF_LIST);}}

/* k2318 in k2314 in k2310 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_2320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2320,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2339,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[94]));}

/* a2338 in k2318 in k2314 in k2310 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2339,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[203],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[203],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[204]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[205],t11));}

/* k2322 in k2318 in k2314 in k2310 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[190]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 446  append */
t5=*((C_word*)lf[201]+1);
((C_proc9)C_retrieve_proc(t5))(9,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[202]);}

/* k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 467  debugging */
t6=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[199],lf[200]);}

/* k2303 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 468  display-real-name-table */
t2=C_retrieve(lf[198]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1822(2,t2,C_SCHEME_UNDEFINED);}}

/* k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 469  debugging */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[196],lf[197]);}

/* k2297 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 470  display-line-number-database */
t2=C_retrieve(lf[195]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1825(2,t2,C_SCHEME_UNDEFINED);}}

/* k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[193]))?C_retrieve(lf[190]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 473  compiler-warning */
t4=C_retrieve(lf[185]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[191],lf[194],C_retrieve(lf[190]));}
else{
t4=t2;
f_1828(2,t4,C_SCHEME_UNDEFINED);}}

/* k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(C_truep(C_retrieve(lf[190]))?((C_word*)t0)[11]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 479  compiler-warning */
t4=C_retrieve(lf[185]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[191],lf[192],C_retrieve(lf[190]));}
else{
t4=t2;
f_1831(2,t4,C_SCHEME_UNDEFINED);}}

/* k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[151]))){
/* batch-driver.scm: 481  feature? */
t4=C_retrieve(lf[188]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[189]);}
else{
t4=t3;
f_2278(2,t4,C_SCHEME_FALSE);}}

/* k2276 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 482  compiler-warning */
t2=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[186],lf[187]);}
else{
t2=((C_word*)t0)[2];
f_1834(2,t2,C_SCHEME_UNDEFINED);}}

/* k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! line-number-database ...) */,C_retrieve(lf[95]));
t3=C_set_block_item(lf[95] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 489  end-time */
t5=((C_word*)t0)[17];
f_1389(t5,t4,lf[184]);}

/* k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 490  print-expr */
t3=((C_word*)t0)[2];
f_1208(t3,t2,lf[182],lf[183],((C_word*)((C_word*)t0)[4])[1]);}

/* k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[181],((C_word*)t0)[2]))){
/* batch-driver.scm: 492  exit */
t3=C_retrieve(lf[128]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t3=t2;
f_1845(2,t3,C_SCHEME_UNDEFINED);}}

/* k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 494  user-pass */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2256,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[12])){
/* batch-driver.scm: 496  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[180]);}
else{
t4=t3;
f_2256(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1851(2,t3,C_SCHEME_UNDEFINED);}}

/* k2254 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=f_1379(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2261 in k2254 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 499  end-time */
t3=((C_word*)t0)[3];
f_1389(t3,((C_word*)t0)[2],lf[179]);}

/* k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2249,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 504  canonicalize-begin-body */
t5=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2251 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 503  build-node-graph */
t2=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2247 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2241,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[175],lf[176],t2);}

/* f_2241 in k2247 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2241,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[174],t2,t3,t4));}

/* k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1857,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 505  user-pass-2 */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1860,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2225,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 506  debugging */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[172],lf[173]);}

/* k2223 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 507  vector->list */
t4=*((C_word*)lf[170]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_retrieve(lf[171]));}
else{
t2=((C_word*)t0)[2];
f_1860(2,t2,C_SCHEME_UNDEFINED);}}

/* k2234 in k2223 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 507  concatenate */
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2230 in k2223 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 507  pretty-print */
t2=C_retrieve(lf[40]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],a[8]=t2,a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[13])){
/* batch-driver.scm: 509  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[168]);}
else{
t4=t3;
f_2193(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1863(t3,C_SCHEME_UNDEFINED);}}

/* k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=f_1379(((C_word*)t0)[9]);
t3=C_set_block_item(lf[98] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 512  analyze */
t5=((C_word*)t0)[2];
f_1412(t5,t4,lf[167],((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2198 in k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 513  print-db */
t3=((C_word*)t0)[2];
f_1193(t3,t2,lf[166],lf[160],t1,C_fix(0));}

/* k2201 in k2198 in k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 514  end-time */
t3=((C_word*)t0)[3];
f_1389(t3,t2,lf[165]);}

/* k2204 in k2201 in k2198 in k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=f_1379(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 516  proc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k2210 in k2204 in k2201 in k2198 in k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 517  end-time */
t3=((C_word*)t0)[2];
f_1389(t3,t2,lf[164]);}

/* k2213 in k2210 in k2204 in k2201 in k2198 in k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 518  print-node */
t3=((C_word*)t0)[3];
f_1171(t3,t2,lf[162],lf[163],((C_word*)t0)[2]);}

/* k2216 in k2213 in k2210 in k2204 in k2201 in k2198 in k2191 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[98] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1863(t3,t2);}

/* k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1863,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[153]))){
t3=f_1379(((C_word*)t0)[16]);
t4=C_set_block_item(lf[98] /* first-analysis */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 524  analyze */
t6=((C_word*)t0)[14];
f_1412(t6,t5,lf[161],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1866(t3,C_SCHEME_UNDEFINED);}}

/* k2169 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2174,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 525  print-db */
t3=((C_word*)t0)[2];
f_1193(t3,t2,lf[159],lf[160],t1,C_fix(0));}

/* k2172 in k2169 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 526  end-time */
t3=((C_word*)t0)[3];
f_1389(t3,t2,lf[158]);}

/* k2175 in k2172 in k2169 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=f_1379(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 528  perform-lambda-lifting! */
t4=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2181 in k2175 in k2172 in k2169 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 529  end-time */
t3=((C_word*)t0)[2];
f_1389(t3,t2,lf[156]);}

/* k2184 in k2181 in k2175 in k2172 in k2169 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 530  print-node */
t3=((C_word*)t0)[3];
f_1171(t3,t2,lf[154],lf[155],((C_word*)t0)[2]);}

/* k2187 in k2184 in k2181 in k2175 in k2172 in k2169 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[98] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1866(t3,t2);}

/* k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1866,NULL,2,t0,t1);}
t2=C_set_block_item(lf[46] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[96] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[97] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[151]))){
t6=t5;
f_1872(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2160,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* f_2160 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2160,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2157 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* batch-driver.scm: 537  scan-toplevel-assignments */
t3=C_retrieve(lf[152]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=f_1379(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 540  perform-cps-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1881,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 541  end-time */
t3=((C_word*)t0)[14];
f_1389(t3,t2,lf[149]);}

/* k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 542  print-node */
t3=((C_word*)t0)[13];
f_1171(t3,t2,lf[147],lf[148],((C_word*)t0)[2]);}

/* k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t3,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_1889(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1889(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1889,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1379(((C_word*)t0)[15]);
t6=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=t3,a[18]=((C_word*)t0)[15],a[19]=t4,tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 548  analyze */
t7=((C_word*)t0)[12];
f_1412(t7,t6,lf[146],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep(C_retrieve(lf[98]))){
if(C_truep((C_word)C_i_memq(lf[144],C_retrieve(lf[35])))){
/* batch-driver.scm: 551  dump-undefined-globals */
t3=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t3=t2;
f_1899(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1899(2,t3,C_SCHEME_UNDEFINED);}}

/* k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=C_set_block_item(lf[98] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 553  end-time */
t4=((C_word*)t0)[14];
f_1389(t4,t3,lf[143]);}

/* k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
/* batch-driver.scm: 554  print-db */
t3=((C_word*)t0)[2];
f_1193(t3,t2,lf[141],lf[142],((C_word*)t0)[17],((C_word*)t0)[16]);}

/* k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_memq(lf[139],C_retrieve(lf[35])))){
/* batch-driver.scm: 556  print-program-statistics */
t3=C_retrieve(lf[140]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[17]);}
else{
t3=t2;
f_1909(2,t3,C_SCHEME_UNDEFINED);}}

/* k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
if(C_truep(((C_word*)t0)[20])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 559  debugging */
t3=C_retrieve(lf[106]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[107],lf[112],((C_word*)t0)[16]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[18],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[19],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 582  print-node */
t3=((C_word*)t0)[12];
f_1171(t3,t2,lf[137],lf[138],((C_word*)t0)[18]);}}

/* k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 584  user-post-optimization-pass */
t3=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[17],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[15])){
/* batch-driver.scm: 587  printf */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[136]);}
else{
t4=t3;
f_2121(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2007(2,t3,C_SCHEME_UNDEFINED);}}

/* k2119 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=f_1379(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 589  proc */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2125 in k2119 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 590  end-time */
t2=((C_word*)t0)[3];
f_1389(t2,((C_word*)t0)[2],lf[135]);}

/* k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2007,2,t0,t1);}
t2=f_1379(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 593  perform-closure-conversion */
t4=C_retrieve(lf[134]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[16]);}

/* k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 594  end-time */
t3=((C_word*)t0)[13];
f_1389(t3,t2,lf[133]);}

/* k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 595  print-db */
t3=((C_word*)t0)[3];
f_1193(t3,t2,lf[131],lf[132],((C_word*)t0)[15],((C_word*)t0)[2]);}

/* k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2104,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[130]))){
t4=f_1147();
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2104(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2104(t4,C_SCHEME_FALSE);}}

/* k2102 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_2104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 597  display */
t2=*((C_word*)lf[91]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[129]);}
else{
t2=((C_word*)t0)[2];
f_2022(2,t2,C_SCHEME_UNDEFINED);}}

/* k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 598  exit */
t3=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(0));}
else{
t3=t2;
f_2025(2,t3,C_SCHEME_UNDEFINED);}}

/* k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* batch-driver.scm: 599  print-node */
t3=((C_word*)t0)[2];
f_1171(t3,t2,lf[126],lf[127],((C_word*)t0)[11]);}

/* k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=f_1379(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2042,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t1,a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 604  end-time */
t7=((C_word*)t0)[7];
f_1389(t7,t6,lf[125]);}

/* k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=f_1379(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[9])){
/* batch-driver.scm: 607  open-output-file */
t4=*((C_word*)lf[123]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
/* batch-driver.scm: 607  current-output-port */
t4=*((C_word*)lf[124]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2055(2,t3,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 609  printf */
t3=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[122],((C_word*)t0)[9]);}}

/* k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 610  generate-code */
t3=C_retrieve(lf[121]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2056 in k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 611  close-output-port */
t3=*((C_word*)lf[120]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2061(2,t3,C_SCHEME_UNDEFINED);}}

/* k2059 in k2056 in k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 612  end-time */
t3=((C_word*)t0)[2];
f_1389(t3,t2,lf[119]);}

/* k2062 in k2059 in k2056 in k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[116],C_retrieve(lf[35])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2086,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 613  ##sys#stop-timer */
t4=*((C_word*)lf[118]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2067(2,t3,C_SCHEME_UNDEFINED);}}

/* k2084 in k2062 in k2059 in k2056 in k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 613  ##sys#display-times */
t2=C_retrieve(lf[117]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2065 in k2062 in k2059 in k2056 in k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 614  compiler-cleanup-hook */
t3=C_retrieve(lf[115]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2068 in k2065 in k2062 in k2059 in k2056 in k2053 in k2050 in k2044 in a2041 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 616  printf */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[114]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2035 in k2026 in k2023 in k2020 in k2017 in k2014 in k2011 in k2005 in k2002 in k1999 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
/* batch-driver.scm: 603  prepare-for-code-generation */
t2=C_retrieve(lf[113]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=f_1379(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1929,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 563  end-time */
t5=((C_word*)t0)[4];
f_1389(t5,t4,lf[111]);}

/* k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 564  print-node */
t3=((C_word*)t0)[2];
f_1171(t3,t2,lf[109],lf[110],((C_word*)t0)[6]);}

/* k1934 in k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 566  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1889(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[100]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[101]))){
t3=f_1379(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 573  analyze */
t5=((C_word*)t0)[2];
f_1412(t5,t4,lf[105],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 579  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1889(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 568  debugging */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[107],lf[108]);}}}

/* k1953 in k1934 in k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[100] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 570  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1889(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1970 in k1934 in k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1975,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 574  end-time */
t3=((C_word*)t0)[2];
f_1389(t3,t2,lf[104]);}

/* k1973 in k1970 in k1934 in k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
t2=f_1379(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 576  transform-direct-lambdas! */
t4=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1979 in k1973 in k1970 in k1934 in k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1984,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 577  end-time */
t3=((C_word*)t0)[2];
f_1389(t3,t2,lf[102]);}

/* k1982 in k1979 in k1973 in k1970 in k1934 in k1931 in a1928 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 578  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1889(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1922 in k1913 in k1907 in k1904 in k1901 in k1897 in k1894 in loop in k1882 in k1879 in k1876 in k1870 in k1864 in k1861 in k1858 in k1855 in k1852 in k1849 in k1846 in k1843 in k1840 in k1837 in k1832 in k1829 in k1826 in k1823 in k1820 in k1817 in k1811 in k1808 in k1805 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1767 in k1764 in k1761 in k1758 in k1754 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
/* batch-driver.scm: 562  perform-high-level-optimizations */
t2=C_retrieve(lf[99]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1736 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 385  display */
t2=*((C_word*)lf[91]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1729 in k1717 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 386  newline */
t2=*((C_word*)lf[86]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1705 in k1696 in k1693 in k1690 in k1687 in k1676 in k1672 in k1668 in k1664 in k1660 in k1656 in k1653 in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 381  newline */
t2=*((C_word*)lf[86]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ids in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1629(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1629,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1641,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1643,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1651,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 329  collect-options */
t7=((C_word*)t0)[2];
f_1349(t7,t6,t2);}

/* k1649 in ids in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 327  append-map */
t2=C_retrieve(lf[75]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1642 in ids in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1643,3,t0,t1,t2);}
/* string-split */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[74]);}

/* k1639 in ids in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[72]+1),t1);}

/* k1635 in ids in k1625 in k1622 in k1618 in k1610 in k1606 in k1603 in k1600 in k1593 in k1590 in k1587 in k1583 in k1580 in k1574 in k1571 in k1568 in k1565 in k1559 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in k1538 in k1535 in k1532 in k1528 in k1525 in k1522 in k1519 in k1516 in k1513 in k1510 in k1507 in k1504 in k1496 in k1492 in k1489 in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 324  lset-difference */
t2=C_retrieve(lf[69]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[70]+1),t1,((C_word*)((C_word*)t0)[2])[1]);}

/* analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1412,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1414,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no300348 */
t8=t7;
f_1442(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf301344 */
t10=t6;
f_1437(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body298307 */
t12=t5;
f_1414(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[1],t11);}}}}

/* def-no300 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1442,NULL,2,t0,t1);}
/* def-contf301344 */
t2=((C_word*)t0)[2];
f_1437(t2,t1,C_fix(0));}

/* def-contf301 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1437(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1437,NULL,3,t0,t1,t2);}
/* body298307 */
t3=((C_word*)t0)[2];
f_1414(t3,t1,t2,C_SCHEME_TRUE);}

/* body298 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1414(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1414,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1418,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 204  analyze-expression */
t5=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1416 in body298 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1421,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 206  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1421(2,t3,C_SCHEME_UNDEFINED);}}

/* a1431 in k1416 in body298 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1432,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
t5=C_retrieve(lf[56]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1425 in k1416 in body298 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1426,4,t0,t1,t2,t3);}
/* ##compiler#get */
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* k1419 in k1416 in body298 in analyze in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1406,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 200  ##sys#read */
t3=C_retrieve(lf[54]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* end-time in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1389,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=f_1147();
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 197  printf */
t5=C_retrieve(lf[36]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,lf[53],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static C_word C_fcall f_1379(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t1=f_1147();
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1349,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1355(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1355,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 189  option-arg */
f_1045(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1367 in loop in collect-options in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1373,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 189  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1355(t4,t2,t3);}

/* k1371 in k1367 in loop in collect-options in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1269(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1269,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1279,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 180  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 182  substring */
t11=*((C_word*)lf[52]+1);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 183  substring */
t13=*((C_word*)lf[52]+1);
((C_proc5)C_retrieve_proc(t13))(5,t13,t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 184  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1336 in arg-val in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 183  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1332 in arg-val in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1279(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1316 in arg-val in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1308 in arg-val in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1279(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1277 in arg-val in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 185  quit */
t2=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[51],((C_word*)t0)[2]);}}

/* infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1220,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1224,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[50]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1266,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1266 in infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1266,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1222 in infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[49],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1230(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1230(t5,C_SCHEME_FALSE);}}

/* k1228 in k1222 in infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1230,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 172  ##sys#hash-table-ref */
t6=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve(lf[46]),t5);}
else{
t2=((C_word*)t0)[3];
f_1227(2,t2,C_SCHEME_UNDEFINED);}}

/* k1243 in k1228 in k1222 in infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 171  alist-cons */
t3=C_retrieve(lf[47]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1239 in k1228 in k1222 in infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 168  ##sys#hash-table-set! */
t2=C_retrieve(lf[45]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[46]),((C_word*)t0)[2],t1);}

/* k1225 in k1222 in infohook in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1208,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1215,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 162  print-header */
t6=((C_word*)t0)[2];
f_1153(t6,t5,t2,t3);}

/* k1213 in print-expr in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[40]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1193(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1193,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1200,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 157  print-header */
t7=((C_word*)t0)[2];
f_1153(t7,t6,t2,t3);}

/* k1198 in print-db in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 158  printf */
t3=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[43],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1201 in k1198 in print-db in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 159  display-analysis-database */
t2=C_retrieve(lf[42]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1171(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1171,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1178,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 151  print-header */
t6=((C_word*)t0)[2];
f_1153(t6,t5,t2,t3);}

/* k1176 in print-node in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 153  dump-nodes */
t2=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 154  build-expression-tree */
t3=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1189 in k1176 in print-node in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 154  pretty-print */
t2=C_retrieve(lf[40]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* print-header in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1153,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1157,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 144  printf */
t5=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[38],t2);}
else{
t5=t4;
f_1157(2,t5,C_SCHEME_UNDEFINED);}}

/* k1155 in print-header in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1157,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[35])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 147  printf */
t3=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[37],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1164 in k1155 in print-header in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* cputime in k1101 in k1095 in k1092 in k3156 in k1076 in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static C_word C_fcall f_1147(){
C_word tmp;
C_word t1;
C_stack_check;
return((C_word)C_fudge(C_fix(6)));}

/* option-arg in compile-source-file in k1038 in k1034 in k1030 in k1026 in k1022 in k1018 in k1014 in k1009 in k1006 in k1003 in k1000 in k997 in k994 */
static void C_fcall f_1045(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1045,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 96   quit */
t5=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[13],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 99   quit */
t5=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[14],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[301] = {
{"toplevelbatch-driver.scm",(void*)C_driver_toplevel},
{"f_996batch-driver.scm",(void*)f_996},
{"f_999batch-driver.scm",(void*)f_999},
{"f_1002batch-driver.scm",(void*)f_1002},
{"f_1005batch-driver.scm",(void*)f_1005},
{"f_1008batch-driver.scm",(void*)f_1008},
{"f_1011batch-driver.scm",(void*)f_1011},
{"f_1016batch-driver.scm",(void*)f_1016},
{"f_1020batch-driver.scm",(void*)f_1020},
{"f_1024batch-driver.scm",(void*)f_1024},
{"f_1028batch-driver.scm",(void*)f_1028},
{"f_1032batch-driver.scm",(void*)f_1032},
{"f_1036batch-driver.scm",(void*)f_1036},
{"f_1040batch-driver.scm",(void*)f_1040},
{"f_1042batch-driver.scm",(void*)f_1042},
{"f_1078batch-driver.scm",(void*)f_1078},
{"f_3177batch-driver.scm",(void*)f_3177},
{"f_3166batch-driver.scm",(void*)f_3166},
{"f_3162batch-driver.scm",(void*)f_3162},
{"f_3158batch-driver.scm",(void*)f_3158},
{"f_3147batch-driver.scm",(void*)f_3147},
{"f_3125batch-driver.scm",(void*)f_3125},
{"f_1094batch-driver.scm",(void*)f_1094},
{"f_3119batch-driver.scm",(void*)f_3119},
{"f_3115batch-driver.scm",(void*)f_3115},
{"f_1097batch-driver.scm",(void*)f_1097},
{"f_1103batch-driver.scm",(void*)f_1103},
{"f_3096batch-driver.scm",(void*)f_3096},
{"f_3092batch-driver.scm",(void*)f_3092},
{"f_3088batch-driver.scm",(void*)f_3088},
{"f_1491batch-driver.scm",(void*)f_1491},
{"f_1494batch-driver.scm",(void*)f_1494},
{"f_3080batch-driver.scm",(void*)f_3080},
{"f_3058batch-driver.scm",(void*)f_3058},
{"f_3076batch-driver.scm",(void*)f_3076},
{"f_3064batch-driver.scm",(void*)f_3064},
{"f_1498batch-driver.scm",(void*)f_1498},
{"f_3056batch-driver.scm",(void*)f_3056},
{"f_3040batch-driver.scm",(void*)f_3040},
{"f_3048batch-driver.scm",(void*)f_3048},
{"f_3052batch-driver.scm",(void*)f_3052},
{"f_1506batch-driver.scm",(void*)f_1506},
{"f_1509batch-driver.scm",(void*)f_1509},
{"f_1512batch-driver.scm",(void*)f_1512},
{"f_1515batch-driver.scm",(void*)f_1515},
{"f_1518batch-driver.scm",(void*)f_1518},
{"f_1521batch-driver.scm",(void*)f_1521},
{"f_1524batch-driver.scm",(void*)f_1524},
{"f_1527batch-driver.scm",(void*)f_1527},
{"f_1530batch-driver.scm",(void*)f_1530},
{"f_2996batch-driver.scm",(void*)f_2996},
{"f_1534batch-driver.scm",(void*)f_1534},
{"f_2988batch-driver.scm",(void*)f_2988},
{"f_1537batch-driver.scm",(void*)f_1537},
{"f_1540batch-driver.scm",(void*)f_1540},
{"f_1543batch-driver.scm",(void*)f_1543},
{"f_1546batch-driver.scm",(void*)f_1546},
{"f_1549batch-driver.scm",(void*)f_1549},
{"f_1552batch-driver.scm",(void*)f_1552},
{"f_1555batch-driver.scm",(void*)f_1555},
{"f_1558batch-driver.scm",(void*)f_1558},
{"f_1561batch-driver.scm",(void*)f_1561},
{"f_2938batch-driver.scm",(void*)f_2938},
{"f_2941batch-driver.scm",(void*)f_2941},
{"f_2944batch-driver.scm",(void*)f_2944},
{"f_1567batch-driver.scm",(void*)f_1567},
{"f_2925batch-driver.scm",(void*)f_2925},
{"f_2928batch-driver.scm",(void*)f_2928},
{"f_1570batch-driver.scm",(void*)f_1570},
{"f_1573batch-driver.scm",(void*)f_1573},
{"f_2883batch-driver.scm",(void*)f_2883},
{"f_1576batch-driver.scm",(void*)f_1576},
{"f_2880batch-driver.scm",(void*)f_2880},
{"f_2876batch-driver.scm",(void*)f_2876},
{"f_1582batch-driver.scm",(void*)f_1582},
{"f_1585batch-driver.scm",(void*)f_1585},
{"f_2860batch-driver.scm",(void*)f_2860},
{"f_2852batch-driver.scm",(void*)f_2852},
{"f_2850batch-driver.scm",(void*)f_2850},
{"f_1589batch-driver.scm",(void*)f_1589},
{"f_1592batch-driver.scm",(void*)f_1592},
{"f_2842batch-driver.scm",(void*)f_2842},
{"f_2834batch-driver.scm",(void*)f_2834},
{"f_2832batch-driver.scm",(void*)f_2832},
{"f_1595batch-driver.scm",(void*)f_1595},
{"f_1602batch-driver.scm",(void*)f_1602},
{"f_2825batch-driver.scm",(void*)f_2825},
{"f_1605batch-driver.scm",(void*)f_1605},
{"f_2814batch-driver.scm",(void*)f_2814},
{"f_2822batch-driver.scm",(void*)f_2822},
{"f_1608batch-driver.scm",(void*)f_1608},
{"f_1612batch-driver.scm",(void*)f_1612},
{"f_1620batch-driver.scm",(void*)f_1620},
{"f_1624batch-driver.scm",(void*)f_1624},
{"f_2800batch-driver.scm",(void*)f_2800},
{"f_2796batch-driver.scm",(void*)f_2796},
{"f_2780batch-driver.scm",(void*)f_2780},
{"f_1627batch-driver.scm",(void*)f_1627},
{"f_2773batch-driver.scm",(void*)f_2773},
{"f_2753batch-driver.scm",(void*)f_2753},
{"f_2751batch-driver.scm",(void*)f_2751},
{"f_1655batch-driver.scm",(void*)f_1655},
{"f_1658batch-driver.scm",(void*)f_1658},
{"f_2730batch-driver.scm",(void*)f_2730},
{"f_1662batch-driver.scm",(void*)f_1662},
{"f_2723batch-driver.scm",(void*)f_2723},
{"f_1666batch-driver.scm",(void*)f_1666},
{"f_2716batch-driver.scm",(void*)f_2716},
{"f_1670batch-driver.scm",(void*)f_1670},
{"f_2709batch-driver.scm",(void*)f_2709},
{"f_1674batch-driver.scm",(void*)f_1674},
{"f_2689batch-driver.scm",(void*)f_2689},
{"f_1678batch-driver.scm",(void*)f_1678},
{"f_1689batch-driver.scm",(void*)f_1689},
{"f_1692batch-driver.scm",(void*)f_1692},
{"f_1695batch-driver.scm",(void*)f_1695},
{"f_2642batch-driver.scm",(void*)f_2642},
{"f_1698batch-driver.scm",(void*)f_1698},
{"f_1719batch-driver.scm",(void*)f_1719},
{"f_1750batch-driver.scm",(void*)f_1750},
{"f_1756batch-driver.scm",(void*)f_1756},
{"f_1760batch-driver.scm",(void*)f_1760},
{"f_1763batch-driver.scm",(void*)f_1763},
{"f_1766batch-driver.scm",(void*)f_1766},
{"f_1769batch-driver.scm",(void*)f_1769},
{"f_1777batch-driver.scm",(void*)f_1777},
{"f_1780batch-driver.scm",(void*)f_1780},
{"f_1783batch-driver.scm",(void*)f_1783},
{"f_2607batch-driver.scm",(void*)f_2607},
{"f_2615batch-driver.scm",(void*)f_2615},
{"f_1786batch-driver.scm",(void*)f_1786},
{"f_1789batch-driver.scm",(void*)f_1789},
{"f_2522batch-driver.scm",(void*)f_2522},
{"f_2551batch-driver.scm",(void*)f_2551},
{"f_2600batch-driver.scm",(void*)f_2600},
{"f_2568batch-driver.scm",(void*)f_2568},
{"f_2572batch-driver.scm",(void*)f_2572},
{"f_2577batch-driver.scm",(void*)f_2577},
{"f_2598batch-driver.scm",(void*)f_2598},
{"f_2563batch-driver.scm",(void*)f_2563},
{"f_2554batch-driver.scm",(void*)f_2554},
{"f_2537batch-driver.scm",(void*)f_2537},
{"f_2541batch-driver.scm",(void*)f_2541},
{"f_2545batch-driver.scm",(void*)f_2545},
{"f_2533batch-driver.scm",(void*)f_2533},
{"f_2510batch-driver.scm",(void*)f_2510},
{"f_2514batch-driver.scm",(void*)f_2514},
{"f_1792batch-driver.scm",(void*)f_1792},
{"f_1795batch-driver.scm",(void*)f_1795},
{"f_2500batch-driver.scm",(void*)f_2500},
{"f_2504batch-driver.scm",(void*)f_2504},
{"f_1798batch-driver.scm",(void*)f_1798},
{"f_1801batch-driver.scm",(void*)f_1801},
{"f_2477batch-driver.scm",(void*)f_2477},
{"f_2497batch-driver.scm",(void*)f_2497},
{"f_1807batch-driver.scm",(void*)f_1807},
{"f_2470batch-driver.scm",(void*)f_2470},
{"f_1810batch-driver.scm",(void*)f_1810},
{"f_1813batch-driver.scm",(void*)f_1813},
{"f_2438batch-driver.scm",(void*)f_2438},
{"f_2312batch-driver.scm",(void*)f_2312},
{"f_2428batch-driver.scm",(void*)f_2428},
{"f_2316batch-driver.scm",(void*)f_2316},
{"f_2320batch-driver.scm",(void*)f_2320},
{"f_2339batch-driver.scm",(void*)f_2339},
{"f_2324batch-driver.scm",(void*)f_2324},
{"f_1819batch-driver.scm",(void*)f_1819},
{"f_2305batch-driver.scm",(void*)f_2305},
{"f_1822batch-driver.scm",(void*)f_1822},
{"f_2299batch-driver.scm",(void*)f_2299},
{"f_1825batch-driver.scm",(void*)f_1825},
{"f_1828batch-driver.scm",(void*)f_1828},
{"f_1831batch-driver.scm",(void*)f_1831},
{"f_2278batch-driver.scm",(void*)f_2278},
{"f_1834batch-driver.scm",(void*)f_1834},
{"f_1839batch-driver.scm",(void*)f_1839},
{"f_1842batch-driver.scm",(void*)f_1842},
{"f_1845batch-driver.scm",(void*)f_1845},
{"f_1848batch-driver.scm",(void*)f_1848},
{"f_2256batch-driver.scm",(void*)f_2256},
{"f_2263batch-driver.scm",(void*)f_2263},
{"f_1851batch-driver.scm",(void*)f_1851},
{"f_2253batch-driver.scm",(void*)f_2253},
{"f_2249batch-driver.scm",(void*)f_2249},
{"f_2241batch-driver.scm",(void*)f_2241},
{"f_1854batch-driver.scm",(void*)f_1854},
{"f_1857batch-driver.scm",(void*)f_1857},
{"f_2225batch-driver.scm",(void*)f_2225},
{"f_2236batch-driver.scm",(void*)f_2236},
{"f_2232batch-driver.scm",(void*)f_2232},
{"f_1860batch-driver.scm",(void*)f_1860},
{"f_2193batch-driver.scm",(void*)f_2193},
{"f_2200batch-driver.scm",(void*)f_2200},
{"f_2203batch-driver.scm",(void*)f_2203},
{"f_2206batch-driver.scm",(void*)f_2206},
{"f_2212batch-driver.scm",(void*)f_2212},
{"f_2215batch-driver.scm",(void*)f_2215},
{"f_2218batch-driver.scm",(void*)f_2218},
{"f_1863batch-driver.scm",(void*)f_1863},
{"f_2171batch-driver.scm",(void*)f_2171},
{"f_2174batch-driver.scm",(void*)f_2174},
{"f_2177batch-driver.scm",(void*)f_2177},
{"f_2183batch-driver.scm",(void*)f_2183},
{"f_2186batch-driver.scm",(void*)f_2186},
{"f_2189batch-driver.scm",(void*)f_2189},
{"f_1866batch-driver.scm",(void*)f_1866},
{"f_2160batch-driver.scm",(void*)f_2160},
{"f_2159batch-driver.scm",(void*)f_2159},
{"f_1872batch-driver.scm",(void*)f_1872},
{"f_1878batch-driver.scm",(void*)f_1878},
{"f_1881batch-driver.scm",(void*)f_1881},
{"f_1884batch-driver.scm",(void*)f_1884},
{"f_1889batch-driver.scm",(void*)f_1889},
{"f_1896batch-driver.scm",(void*)f_1896},
{"f_1899batch-driver.scm",(void*)f_1899},
{"f_1903batch-driver.scm",(void*)f_1903},
{"f_1906batch-driver.scm",(void*)f_1906},
{"f_1909batch-driver.scm",(void*)f_1909},
{"f_2001batch-driver.scm",(void*)f_2001},
{"f_2004batch-driver.scm",(void*)f_2004},
{"f_2121batch-driver.scm",(void*)f_2121},
{"f_2127batch-driver.scm",(void*)f_2127},
{"f_2007batch-driver.scm",(void*)f_2007},
{"f_2013batch-driver.scm",(void*)f_2013},
{"f_2016batch-driver.scm",(void*)f_2016},
{"f_2019batch-driver.scm",(void*)f_2019},
{"f_2104batch-driver.scm",(void*)f_2104},
{"f_2022batch-driver.scm",(void*)f_2022},
{"f_2025batch-driver.scm",(void*)f_2025},
{"f_2028batch-driver.scm",(void*)f_2028},
{"f_2042batch-driver.scm",(void*)f_2042},
{"f_2046batch-driver.scm",(void*)f_2046},
{"f_2052batch-driver.scm",(void*)f_2052},
{"f_2055batch-driver.scm",(void*)f_2055},
{"f_2058batch-driver.scm",(void*)f_2058},
{"f_2061batch-driver.scm",(void*)f_2061},
{"f_2064batch-driver.scm",(void*)f_2064},
{"f_2086batch-driver.scm",(void*)f_2086},
{"f_2067batch-driver.scm",(void*)f_2067},
{"f_2070batch-driver.scm",(void*)f_2070},
{"f_2036batch-driver.scm",(void*)f_2036},
{"f_1915batch-driver.scm",(void*)f_1915},
{"f_1929batch-driver.scm",(void*)f_1929},
{"f_1933batch-driver.scm",(void*)f_1933},
{"f_1936batch-driver.scm",(void*)f_1936},
{"f_1955batch-driver.scm",(void*)f_1955},
{"f_1972batch-driver.scm",(void*)f_1972},
{"f_1975batch-driver.scm",(void*)f_1975},
{"f_1981batch-driver.scm",(void*)f_1981},
{"f_1984batch-driver.scm",(void*)f_1984},
{"f_1923batch-driver.scm",(void*)f_1923},
{"f_1738batch-driver.scm",(void*)f_1738},
{"f_1731batch-driver.scm",(void*)f_1731},
{"f_1707batch-driver.scm",(void*)f_1707},
{"f_1629batch-driver.scm",(void*)f_1629},
{"f_1651batch-driver.scm",(void*)f_1651},
{"f_1643batch-driver.scm",(void*)f_1643},
{"f_1641batch-driver.scm",(void*)f_1641},
{"f_1637batch-driver.scm",(void*)f_1637},
{"f_1412batch-driver.scm",(void*)f_1412},
{"f_1442batch-driver.scm",(void*)f_1442},
{"f_1437batch-driver.scm",(void*)f_1437},
{"f_1414batch-driver.scm",(void*)f_1414},
{"f_1418batch-driver.scm",(void*)f_1418},
{"f_1432batch-driver.scm",(void*)f_1432},
{"f_1426batch-driver.scm",(void*)f_1426},
{"f_1421batch-driver.scm",(void*)f_1421},
{"f_1406batch-driver.scm",(void*)f_1406},
{"f_1389batch-driver.scm",(void*)f_1389},
{"f_1379batch-driver.scm",(void*)f_1379},
{"f_1349batch-driver.scm",(void*)f_1349},
{"f_1355batch-driver.scm",(void*)f_1355},
{"f_1369batch-driver.scm",(void*)f_1369},
{"f_1373batch-driver.scm",(void*)f_1373},
{"f_1269batch-driver.scm",(void*)f_1269},
{"f_1338batch-driver.scm",(void*)f_1338},
{"f_1334batch-driver.scm",(void*)f_1334},
{"f_1318batch-driver.scm",(void*)f_1318},
{"f_1310batch-driver.scm",(void*)f_1310},
{"f_1279batch-driver.scm",(void*)f_1279},
{"f_1220batch-driver.scm",(void*)f_1220},
{"f_1266batch-driver.scm",(void*)f_1266},
{"f_1224batch-driver.scm",(void*)f_1224},
{"f_1230batch-driver.scm",(void*)f_1230},
{"f_1245batch-driver.scm",(void*)f_1245},
{"f_1241batch-driver.scm",(void*)f_1241},
{"f_1227batch-driver.scm",(void*)f_1227},
{"f_1208batch-driver.scm",(void*)f_1208},
{"f_1215batch-driver.scm",(void*)f_1215},
{"f_1193batch-driver.scm",(void*)f_1193},
{"f_1200batch-driver.scm",(void*)f_1200},
{"f_1203batch-driver.scm",(void*)f_1203},
{"f_1171batch-driver.scm",(void*)f_1171},
{"f_1178batch-driver.scm",(void*)f_1178},
{"f_1191batch-driver.scm",(void*)f_1191},
{"f_1153batch-driver.scm",(void*)f_1153},
{"f_1157batch-driver.scm",(void*)f_1157},
{"f_1166batch-driver.scm",(void*)f_1166},
{"f_1147batch-driver.scm",(void*)f_1147},
{"f_1045batch-driver.scm",(void*)f_1045},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
