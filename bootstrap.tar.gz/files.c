/* Generated from files.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-07 10:47
   Version 3.3.4 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   compiled 2008-07-29 on pequod (Linux)
   command line: files.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -explicit-use -output-file files.c -extend private-namespace.scm
   unit: files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[83];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,20),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,51,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,53,50,48,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,12),40,97,53,49,52,32,103,53,48,53,53,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,6),40,97,53,53,53,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,6),40,97,53,54,55,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,14),40,97,53,54,49,32,46,32,103,53,51,54,48,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,97,53,52,57,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,12),40,97,53,48,56,32,103,53,50,53,52,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,100,52,54,32,108,52,55,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,97,53,56,56,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,97,53,56,50,32,103,51,53,52,48,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,6),40,97,54,49,51,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,54,50,53,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,14),40,97,54,49,57,32,46,32,103,51,56,52,51,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,97,54,48,55,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,12),40,97,53,55,54,32,103,51,55,51,57,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,6),40,97,54,52,54,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,12),40,97,54,52,48,32,103,50,53,51,48,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,6),40,97,54,55,49,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,97,54,56,51,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,97,54,55,55,32,46,32,103,50,56,51,51,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,97,54,54,53,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,12),40,97,54,51,52,32,103,50,55,50,57,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,49,48,32,99,108,111,98,98,101,114,49,54,32,98,108,111,99,107,115,105,122,101,49,55,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,98,108,111,99,107,115,105,122,101,49,51,32,37,99,108,111,98,98,101,114,56,55,48,41,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,99,108,111,98,98,101,114,49,50,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,53,32,110,101,119,102,105,108,101,54,32,46,32,103,52,55,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,97,56,53,54,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,14),40,97,56,53,48,32,103,49,50,49,49,50,54,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,6),40,97,56,56,49,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,6),40,97,56,57,51,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,16),40,97,56,56,55,32,46,32,103,49,50,52,49,50,57,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,6),40,97,56,55,53,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,14),40,97,56,52,52,32,103,49,50,51,49,50,53,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,6),40,97,57,50,56,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,14),40,97,57,50,50,32,103,49,51,51,49,51,56,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,6),40,97,57,54,51,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,97,57,55,53,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,16),40,97,57,54,57,32,46,32,103,49,51,54,49,52,51,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,6),40,97,57,53,55,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,14),40,97,57,49,54,32,103,49,51,53,49,51,55,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,49,57,32,108,49,50,48,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,6),40,97,57,57,54,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,14),40,97,57,57,48,32,103,49,48,56,49,49,51,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,48,50,49,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,48,51,51,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,17),40,97,49,48,50,55,32,46,32,103,49,49,49,49,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,48,49,53,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,14),40,97,57,56,52,32,103,49,49,48,49,49,50,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,49,48,53,52,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,14),40,97,49,48,52,56,32,103,57,56,49,48,51,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,49,48,55,57,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,49,48,57,49,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,97,49,48,56,53,32,46,32,103,49,48,49,49,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,49,48,55,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,15),40,97,49,48,52,50,32,103,49,48,48,49,48,50,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,56,51,32,99,108,111,98,98,101,114,56,57,32,98,108,111,99,107,115,105,122,101,57,48,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,98,108,111,99,107,115,105,122,101,56,54,32,37,99,108,111,98,98,101,114,56,49,49,53,51,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,99,108,111,98,98,101,114,56,53,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,55,56,32,110,101,119,102,105,108,101,55,57,32,46,32,103,55,55,56,48,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,49,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,99,104,111,112,45,112,100,115,32,115,116,114,49,54,55,32,112,100,115,49,54,56,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,49,56,48,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,26),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,49,55,55,32,112,100,115,49,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,34),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,49,56,54,32,112,100,115,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,52),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,49,57,48,32,100,105,114,49,57,49,32,102,105,108,101,49,57,50,32,101,120,116,49,57,51,32,112,100,115,49,57,52,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,49,50,32,101,120,116,50,49,56,32,112,100,115,50,49,57,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,50,49,53,32,37,101,120,116,50,49,48,50,50,49,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,50,49,52,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,48,55,32,102,105,108,101,50,48,56,32,46,32,103,50,48,54,50,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,51,51,32,101,120,116,50,51,57,32,112,100,115,50,52,48,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,112,100,115,50,51,54,32,37,101,120,116,50,51,49,50,52,53,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,120,116,50,51,53,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,50),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,50,56,32,102,105,108,101,50,50,57,32,46,32,103,50,50,55,50,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,50,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,50,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,49,55,49,48,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,38),40,97,49,55,49,54,32,100,105,114,50,55,48,50,55,51,32,102,105,108,101,50,55,49,50,55,52,32,101,120,116,50,55,50,50,55,53,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,50,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,7),40,97,49,55,50,53,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,38),40,97,49,55,51,49,32,100,105,114,50,56,48,50,56,51,32,102,105,108,101,50,56,49,50,56,52,32,101,120,116,50,56,50,50,56,53,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,50,55,57,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,97,49,55,52,48,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,38),40,97,49,55,52,54,32,100,105,114,50,57,48,50,57,51,32,102,105,108,101,50,57,49,50,57,52,32,101,120,116,50,57,50,50,57,53,41,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,50,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,7),40,97,49,55,53,53,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,38),40,97,49,55,54,49,32,100,105,114,51,48,48,51,48,51,32,102,105,108,101,51,48,49,51,48,52,32,101,120,116,51,48,50,51,48,53,41,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,50,57,57,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,7),40,97,49,55,55,51,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,38),40,97,49,55,55,57,32,100,105,114,51,49,48,51,49,51,32,102,105,108,101,51,49,49,51,49,52,32,101,120,116,51,49,50,51,49,53,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,51,48,57,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,49,55,57,49,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,36),40,97,49,55,57,55,32,95,51,50,49,51,50,52,32,102,105,108,101,51,50,50,51,50,53,32,101,120,116,51,50,51,51,50,54,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,49,57,32,100,105,114,51,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,7),40,97,49,56,48,57,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,35),40,97,49,56,49,53,32,100,105,114,51,51,50,51,51,53,32,95,51,51,51,51,51,54,32,101,120,116,51,51,52,51,51,55,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,51,51,48,32,102,105,108,101,51,51,49,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,97,49,56,50,55,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,36),40,97,49,56,51,51,32,100,105,114,51,52,51,51,52,54,32,102,105,108,101,51,52,52,51,52,55,32,95,51,52,53,51,52,56,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,51,52,49,32,101,120,116,51,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,12),40,97,49,56,55,56,32,112,51,55,51,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,101,120,116,51,54,51,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,51,55,54,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_files_toplevel)
C_externexport void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static C_word C_fcall f_1915(C_word t0);
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_fcall f_1858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_fcall f_1583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1529)
static void C_fcall f_1529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1502)
static void C_fcall f_1502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1452)
static void C_fcall f_1452(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1438)
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_fcall f_1391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_fcall f_1324(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1263)
static void C_fcall f_1263(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1272)
static void C_fcall f_1272(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_fcall f_1209(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1225)
static void C_fcall f_1225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1139)
static void C_fcall f_1139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_fcall f_1134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_781)
static void C_fcall f_781(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_794)
static void C_fcall f_794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1116)
static void C_ccall f_1116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_fcall f_824(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_432)
static void C_ccall f_432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_432)
static void C_ccall f_432r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_731)
static void C_fcall f_731(C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_fcall f_726(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_434)
static void C_fcall f_434(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_447)
static void C_fcall f_447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_450)
static void C_ccall f_450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_ccall f_456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_666)
static void C_ccall f_666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_684)
static void C_ccall f_684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_658)
static void C_ccall f_658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_633)
static void C_ccall f_633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_620)
static void C_ccall f_620r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_626)
static void C_ccall f_626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_614)
static void C_ccall f_614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_589)
static void C_ccall f_589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_475)
static void C_ccall f_475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_fcall f_477(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_509)
static void C_ccall f_509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_515)
static void C_ccall f_515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_521)
static void C_ccall f_521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_531)
static void C_ccall f_531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_538)
static void C_ccall f_538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_493)
static void C_ccall f_493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_ccall f_500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_487)
static void C_ccall f_487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1858)
static void C_fcall trf_1858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1858(t0,t1);}

C_noret_decl(trf_1583)
static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1583(t0,t1);}

C_noret_decl(trf_1529)
static void C_fcall trf_1529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1529(t0,t1);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1524(t0,t1,t2);}

C_noret_decl(trf_1502)
static void C_fcall trf_1502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1502(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1502(t0,t1,t2,t3);}

C_noret_decl(trf_1452)
static void C_fcall trf_1452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1452(t0,t1);}

C_noret_decl(trf_1447)
static void C_fcall trf_1447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1447(t0,t1,t2);}

C_noret_decl(trf_1438)
static void C_fcall trf_1438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1438(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1438(t0,t1,t2,t3);}

C_noret_decl(trf_1355)
static void C_fcall trf_1355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1355(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1355(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1391)
static void C_fcall trf_1391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1391(t0,t1);}

C_noret_decl(trf_1324)
static void C_fcall trf_1324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1324(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1324(t0,t1,t2,t3);}

C_noret_decl(trf_1263)
static void C_fcall trf_1263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1263(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1263(t0,t1,t2,t3);}

C_noret_decl(trf_1272)
static void C_fcall trf_1272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1272(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1272(t0,t1,t2);}

C_noret_decl(trf_1209)
static void C_fcall trf_1209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1209(t0,t1,t2);}

C_noret_decl(trf_1225)
static void C_fcall trf_1225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1225(t0,t1);}

C_noret_decl(trf_1139)
static void C_fcall trf_1139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1139(t0,t1);}

C_noret_decl(trf_1134)
static void C_fcall trf_1134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1134(t0,t1,t2);}

C_noret_decl(trf_781)
static void C_fcall trf_781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_781(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_781(t0,t1,t2,t3);}

C_noret_decl(trf_794)
static void C_fcall trf_794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_794(t0,t1);}

C_noret_decl(trf_824)
static void C_fcall trf_824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_824(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_824(t0,t1,t2,t3);}

C_noret_decl(trf_731)
static void C_fcall trf_731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_731(t0,t1);}

C_noret_decl(trf_726)
static void C_fcall trf_726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_726(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_726(t0,t1,t2);}

C_noret_decl(trf_434)
static void C_fcall trf_434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_434(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_434(t0,t1,t2,t3);}

C_noret_decl(trf_447)
static void C_fcall trf_447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_447(t0,t1);}

C_noret_decl(trf_477)
static void C_fcall trf_477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_477(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_477(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_files_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("files_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(442)){
C_save(t1);
C_rereclaim2(442*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,83);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"file-exists\077");
lf[3]=C_h_intern(&lf[3],11,"delete-file");
lf[4]=C_h_intern(&lf[4],12,"delete-file*");
lf[5]=C_h_intern(&lf[5],9,"file-copy");
lf[6]=C_h_intern(&lf[6],17,"close-output-port");
lf[7]=C_h_intern(&lf[7],16,"close-input-port");
lf[8]=C_h_intern(&lf[8],12,"read-string!");
lf[9]=C_h_intern(&lf[9],9,"condition");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_h_intern(&lf[11],13,"string-append");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[13]=C_h_intern(&lf[13],12,"write-string");
lf[14]=C_h_intern(&lf[14],22,"with-exception-handler");
lf[15]=C_h_intern(&lf[15],30,"call-with-current-continuation");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[18]=C_h_intern(&lf[18],16,"open-output-file");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[20]=C_h_intern(&lf[20],15,"open-input-file");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[24]=C_h_intern(&lf[24],9,"file-move");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\034could not remove origfile - ");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[32]=C_h_intern(&lf[32],12,"string-match");
lf[33]=C_h_intern(&lf[33],6,"regexp");
lf[34]=C_h_intern(&lf[34],20,"\003syswindows-platform");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\014([A-Za-z]:)\077");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_h_intern(&lf[37],18,"absolute-pathname\077");
lf[39]=C_h_intern(&lf[39],13,"\003syssubstring");
lf[40]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000/\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[41]=C_h_intern(&lf[41],19,"\003sysundefined-value");
lf[42]=C_h_intern(&lf[42],13,"make-pathname");
lf[43]=C_h_intern(&lf[43],22,"make-absolute-pathname");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[52]=C_h_intern(&lf[52],17,"\003sysstring-append");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[55]=C_h_intern(&lf[55],18,"decompose-pathname");
lf[56]=C_h_intern(&lf[56],18,"pathname-directory");
lf[57]=C_h_intern(&lf[57],13,"pathname-file");
lf[58]=C_h_intern(&lf[58],18,"pathname-extension");
lf[59]=C_h_intern(&lf[59],24,"pathname-strip-directory");
lf[60]=C_h_intern(&lf[60],24,"pathname-strip-extension");
lf[61]=C_h_intern(&lf[61],26,"pathname-replace-directory");
lf[62]=C_h_intern(&lf[62],21,"pathname-replace-file");
lf[63]=C_h_intern(&lf[63],26,"pathname-replace-extension");
lf[64]=C_h_intern(&lf[64],6,"getenv");
lf[65]=C_h_intern(&lf[65],21,"call-with-output-file");
lf[66]=C_h_intern(&lf[66],21,"create-temporary-file");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[72]=C_h_intern(&lf[72],15,"directory-null\077");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[75]=C_h_intern(&lf[75],12,"string-split");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[79]=C_h_intern(&lf[79],21,"make-anchored-pattern");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\010[\134/\134\134].*");
lf[81]=C_h_intern(&lf[81],17,"register-feature!");
lf[82]=C_h_intern(&lf[82],5,"files");
C_register_lf2(lf,83,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k410 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 78   register-feature! */
t3=*((C_word*)lf[81]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[82]);}

/* k413 in k410 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_417,a[2]=t2,a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_432,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[32]+1);
t8=*((C_word*)lf[33]+1);
t9=*((C_word*)lf[11]+1);
t10=(C_truep(*((C_word*)lf[34]+1))?lf[35]:lf[36]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1192,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 188  string-append */
t13=t9;
((C_proc4)C_retrieve_proc(t13))(4,t13,t12,t10,lf[80]);}

/* k1950 in k413 in k410 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 188  make-anchored-pattern */
t2=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1190 in k413 in k410 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 189  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1193 in k1190 in k413 in k410 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate(&lf[38],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[41]+1);
t5=C_mutate((C_word*)lf[42]+1,t4);
t6=*((C_word*)lf[41]+1);
t7=C_mutate((C_word*)lf[43]+1,t6);
t8=*((C_word*)lf[11]+1);
t9=*((C_word*)lf[37]+1);
t10=lf[44];
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1263,a[2]=t8,a[3]=t10,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1324,a[2]=t11,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1355,a[2]=t8,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t14=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1436,a[2]=t12,a[3]=t13,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1500,a[2]=t12,a[3]=t9,a[4]=t10,a[5]=t13,a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t16=*((C_word*)lf[32]+1);
t17=*((C_word*)lf[33]+1);
t18=*((C_word*)lf[11]+1);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1579,a[2]=t17,a[3]=((C_word*)t0)[2],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 272  regexp */
t20=t17;
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[78]);}

/* k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 273  regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[77]);}

/* k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1583,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li75),tmp=(C_word)a,a+=7,tmp));
t4=*((C_word*)lf[41]+1);
t5=C_mutate((C_word*)lf[56]+1,t4);
t6=*((C_word*)lf[41]+1);
t7=C_mutate((C_word*)lf[57]+1,t6);
t8=*((C_word*)lf[41]+1);
t9=C_mutate((C_word*)lf[58]+1,t8);
t10=*((C_word*)lf[41]+1);
t11=C_mutate((C_word*)lf[59]+1,t10);
t12=*((C_word*)lf[41]+1);
t13=C_mutate((C_word*)lf[60]+1,t12);
t14=*((C_word*)lf[41]+1);
t15=C_mutate((C_word*)lf[61]+1,t14);
t16=*((C_word*)lf[41]+1);
t17=C_mutate((C_word*)lf[62]+1,t16);
t18=*((C_word*)lf[41]+1);
t19=C_mutate((C_word*)lf[63]+1,t18);
t20=*((C_word*)lf[55]+1);
t21=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1705,a[2]=t20,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1720,a[2]=t20,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1735,a[2]=t20,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1750,a[2]=t20,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1768,a[2]=t20,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=t20,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1804,a[2]=t20,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1822,a[2]=t20,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t29=*((C_word*)lf[64]+1);
t30=*((C_word*)lf[42]+1);
t31=*((C_word*)lf[2]+1);
t32=*((C_word*)lf[65]+1);
t33=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1840,a[2]=t29,a[3]=t30,a[4]=t31,a[5]=t32,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t34=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t35=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t35+1)))(2,t35,C_SCHEME_UNDEFINED);}

/* directory-null? in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1905,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_1913(2,t4,t2);}
else{
t4=(C_word)C_i_check_string_2(t2,lf[72]);
/* files.scm: 367  string-split */
t5=*((C_word*)lf[75]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t2,lf[76],C_SCHEME_TRUE);}}

/* k1911 in directory-null? in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1915(t1));}

/* loop in k1911 in directory-null? in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static C_word C_fcall f_1915(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[73]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[74]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1840r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1840r(t0,t1,t2);}}

static void C_ccall f_1840r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* files.scm: 348  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[71]);}

/* k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1847(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm: 348  getenv */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[70]);}}

/* k1895 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1847(2,t2,t1);}
else{
/* files.scm: 348  getenv */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[69]);}}

/* k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[6],C_fix(0)):lf[67]);
t4=(C_word)C_i_check_string_2(t3,lf[66]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1858,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=((C_word)li101),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_1858(t8,((C_word*)t0)[2]);}

/* loop in k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1858,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 353  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k1886 in loop in k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 353  ##sys#string-append */
t2=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k1882 in loop in k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 353  make-pathname */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1863 in loop in k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1871,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 354  file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1869 in k1863 in loop in k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1871,2,t0,t1);}
if(C_truep(t1)){
/* files.scm: 355  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1858(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[3],a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 356  call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a1878 in k1869 in k1863 in loop in k1845 in k1842 in create-temporary-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1879,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* pathname-replace-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1822,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1828,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li97),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1834,a[2]=t3,a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1833 in pathname-replace-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1834,5,t0,t1,t2,t3,t4);}
/* files.scm: 340  make-pathname */
t5=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a1827 in pathname-replace-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
/* files.scm: 339  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1804,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1810,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1816,a[2]=t3,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1815 in pathname-replace-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1816,5,t0,t1,t2,t3,t4);}
/* files.scm: 335  make-pathname */
t5=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a1809 in pathname-replace-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
/* files.scm: 334  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1786,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1792,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1798,a[2]=t3,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1797 in pathname-replace-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1798,5,t0,t1,t2,t3,t4);}
/* files.scm: 330  make-pathname */
t5=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a1791 in pathname-replace-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
/* files.scm: 329  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1768,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1774,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1779 in pathname-strip-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1780,5,t0,t1,t2,t3,t4);}
/* files.scm: 325  make-pathname */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a1773 in pathname-strip-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
/* files.scm: 324  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1750,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1756,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1761 in pathname-strip-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1762,5,t0,t1,t2,t3,t4);}
/* files.scm: 320  make-pathname */
t5=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a1755 in pathname-strip-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
/* files.scm: 319  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1735,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li82),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1746 in pathname-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1747,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a1740 in pathname-extension in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
/* files.scm: 314  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1720,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1726,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1731 in pathname-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1732,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a1725 in pathname-file in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
/* files.scm: 309  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1705,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1711,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1717,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1716 in pathname-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1717,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a1710 in pathname-directory in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
/* files.scm: 304  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1597,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[55]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* files.scm: 283  values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1613,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* files.scm: 284  string-match */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t2);}}

/* k1611 in decompose-pathname in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* files.scm: 286  strip-pds */
f_1583(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 287  string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k1640 in k1611 in decompose-pathname in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(t1);
/* files.scm: 289  strip-pds */
f_1583(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 290  strip-pds */
f_1583(t2,((C_word*)t0)[2]);}}

/* k1665 in k1640 in k1611 in decompose-pathname in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 290  values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k1650 in k1640 in k1611 in decompose-pathname in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* files.scm: 289  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k1621 in k1611 in decompose-pathname in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[3]);
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=(C_word)C_i_car(t3);
/* files.scm: 286  values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k1580 in k1577 in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1583(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1583,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[53]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[54]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* files.scm: 279  chop-pds */
f_1209(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_1500r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1500r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1500r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1502,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word)li70),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=t5,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1529,a[2]=t6,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext235246 */
t8=t7;
f_1529(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds236244 */
t10=t6;
f_1524(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body233238 */
t12=t5;
f_1502(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext235 in make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1529,NULL,2,t0,t1);}
/* def-pds236244 */
t2=((C_word*)t0)[2];
f_1524(t2,t1,C_SCHEME_FALSE);}

/* def-pds236 in make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,3,t0,t1,t2);}
/* body233238 */
t3=((C_word*)t0)[2];
f_1502(t3,t1,t2,C_SCHEME_FALSE);}

/* body233 in make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1502(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1502,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* files.scm: 260  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1324(t5,t4,((C_word*)t0)[2],t3);}

/* k1508 in body233 in make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 261  absolute-pathname? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1514 in k1508 in body233 in make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_1513(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
/* files.scm: 263  ##sys#string-append */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}}

/* k1511 in k1508 in body233 in make-absolute-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 258  _make-pathname */
t2=((C_word*)t0)[6];
f_1355(t2,((C_word*)t0)[5],lf[43],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1436r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1436r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1436r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1438,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1447,a[2]=t5,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1452,a[2]=t6,a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-ext214222 */
t8=t7;
f_1452(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-pds215220 */
t10=t6;
f_1447(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body212217 */
t12=t5;
f_1438(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-ext214 in make-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1452,NULL,2,t0,t1);}
/* def-pds215220 */
t2=((C_word*)t0)[2];
f_1447(t2,t1,C_SCHEME_FALSE);}

/* def-pds215 in make-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1447,NULL,3,t0,t1,t2);}
/* body212217 */
t3=((C_word*)t0)[2];
f_1438(t3,t1,t2,C_SCHEME_FALSE);}

/* body212 in make-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1438(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1438,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1446,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 254  canonicalize-dirs */
t5=((C_word*)t0)[3];
f_1324(t5,t4,((C_word*)t0)[2],t3);}

/* k1444 in body212 in make-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 254  _make-pathname */
t2=((C_word*)t0)[6];
f_1355(t2,((C_word*)t0)[5],lf[42],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1355,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[47]);
t8=(C_truep(t4)?t4:lf[48]);
t9=(C_truep(t6)?(C_word)C_block_size(t6):C_fix(1));
t10=(C_word)C_i_check_string_2(t3,t2);
t11=(C_word)C_i_check_string_2(t8,t2);
t12=(C_word)C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?(C_word)C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1384,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_block_size(t8);
t16=(C_word)C_fixnum_greater_or_equal_p(t15,t9);
t17=(C_truep(t16)?(C_truep(t6)?(C_word)C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9):(C_word)C_i_memq((C_word)C_subchar(t8,C_fix(0)),lf[51])):C_SCHEME_FALSE);
if(C_truep(t17)){
t18=(C_word)C_block_size(t8);
/* files.scm: 244  ##sys#substring */
t19=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t14,t8,t9,t18);}
else{
t18=t14;
f_1384(2,t18,t8);}}

/* k1382 in _make-pathname in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1391(t5,(C_word)C_i_not(t4));}
else{
t4=t2;
f_1391(t4,C_SCHEME_FALSE);}}

/* k1389 in k1382 in _make-pathname in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[49]:lf[50]);
/* files.scm: 238  string-append */
t3=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* canonicalize-dirs in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1324(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1324,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[46]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
/* files.scm: 227  conc-dirs */
t7=((C_word*)t0)[2];
f_1263(t7,t1,t6,t3);}
else{
/* files.scm: 228  conc-dirs */
t6=((C_word*)t0)[2];
f_1263(t6,t1,t2,t3);}}}

/* conc-dirs in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1263(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1263,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t2,lf[42]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1272(t8,t1,t2);}

/* loop in conc-dirs in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1272(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1272,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[45]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* files.scm: 219  loop */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_i_car(t2);
/* files.scm: 221  chop-pds */
f_1209(t6,t7,((C_word*)t0)[4]);}}}

/* k1300 in loop in conc-dirs in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1310,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* files.scm: 223  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1272(t6,t4,t5);}

/* k1308 in k1300 in loop in conc-dirs in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 220  string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1209(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1209,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_block_size(t2);
t5=(C_truep(t3)?(C_word)C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1225,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=(C_word)C_fixnum_difference(t4,t5);
t8=t6;
f_1225(t8,(C_word)C_substring_compare(t2,t3,t7,C_fix(0),t5));}
else{
t7=(C_word)C_fixnum_difference(t4,t5);
t8=(C_word)C_subchar(t2,t7);
t9=t6;
f_1225(t9,(C_word)C_i_memq(t8,lf[40]));}}
else{
t7=t6;
f_1225(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1223 in chop-pds in k1193 in k1190 in k413 in k410 */
static void C_fcall f_1225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 203  ##sys#substring */
t3=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1196,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[37]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 192  string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k1205 in absolute-pathname? in k1193 in k1190 in k413 in k410 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_pairp(t1));}

/* file-move in k413 in k410 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_779r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_779r(t0,t1,t2,t3,t4);}}

static void C_ccall f_779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_781,a[2]=t3,a[3]=t2,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1134,a[2]=t5,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1139,a[2]=t6,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber85154 */
t8=t7;
f_1139(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize86152 */
t10=t6;
f_1134(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body8388 */
t12=t5;
f_781(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber85 in file-move in k413 in k410 */
static void C_fcall f_1139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1139,NULL,2,t0,t1);}
/* def-blocksize86152 */
t2=((C_word*)t0)[2];
f_1134(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize86 in file-move in k413 in k410 */
static void C_fcall f_1134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1134,NULL,3,t0,t1,t2);}
/* body8388 */
t3=((C_word*)t0)[2];
f_781(t3,t1,t2,C_fix(1024));}

/* body83 in file-move in k413 in k410 */
static void C_fcall f_781(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_781,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[24]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[24]);
t6=(C_word)C_i_check_number_2(t3,lf[24]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_794,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_794(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_794(t8,C_SCHEME_FALSE);}}

/* k792 in body83 in file-move in k413 in k410 */
static void C_fcall f_794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_794,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_797(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 140  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[5]);}}

/* k1125 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 138  string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[31],t1);}

/* k1121 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 138  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 141  file-exists? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_803(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1116,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 142  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[30],((C_word*)t0)[6]);}}

/* k1114 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 142  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 143  file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1097 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_806(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1109,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 145  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[29],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_806(2,t2,C_SCHEME_FALSE);}}

/* k1107 in k1097 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 145  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[5],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 148  call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1043,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1049,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1074,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 148  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1073 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[3],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 148  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1085 in a1073 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1086r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1086r(t0,t1,t2);}}

static void C_ccall f_1086r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1092,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 148  g100 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1091 in a1085 in a1073 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1079 in a1073 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
/* files.scm: 148  open-input-file */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1048 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1049,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 148  g100 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1054 in a1048 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 150  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[28],((C_word*)t0)[2]);}

/* k1064 in a1054 in a1048 in a1042 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 150  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1039 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 153  call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 153  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1015 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[3],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 153  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1027 in a1015 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1028r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1028r(t0,t1,t2);}}

static void C_ccall f_1028r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1034,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 153  g110 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1033 in a1027 in a1015 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1021 in a1015 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
/* files.scm: 153  open-output-file */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a990 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_991,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 153  g110 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a996 in a990 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 155  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[27],((C_word*)t0)[2]);}

/* k1006 in a996 in a990 in a984 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 155  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k981 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 158  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* files.scm: 159  read-string! */
t3=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li41),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_824(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_fcall f_824(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_824,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 163  close-input-port */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_915,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_917,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li40),tmp=(C_word)a,a+=8,tmp);
/* files.scm: 172  call-with-current-continuation */
t9=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_917,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_923,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_958,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp);
/* files.scm: 172  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a957 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_970,a[2]=((C_word*)t0)[2],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 172  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a969 in a957 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_970(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_970r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_970r(t0,t1,t2);}}

static void C_ccall f_970r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_976,a[2]=t2,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 172  g135 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a975 in a969 in a957 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a963 in a957 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
/* files.scm: 172  write-string */
t2=*((C_word*)lf[13]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a922 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_923,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
/* files.scm: 172  g135 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a928 in a922 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_929,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 174  close-input-port */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k934 in a928 in a922 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 175  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k937 in k934 in a928 in a922 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 178  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k948 in k937 in k934 in a928 in a922 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 176  string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k944 in k937 in k934 in a928 in a922 in a916 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 176  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k913 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k899 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 179  read-string! */
t3=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k906 in k899 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 179  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_824(t3,((C_word*)t0)[2],t1,t2);}

/* k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 164  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[2],a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 165  call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_845,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_851,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_876,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 165  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a875 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_882,a[2]=((C_word*)t0)[3],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_888,a[2]=((C_word*)t0)[2],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 165  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a887 in a875 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_888(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_888r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_888r(t0,t1,t2);}}

static void C_ccall f_888r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_894,a[2]=t2,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 165  g123 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a893 in a887 in a875 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a881 in a875 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
/* files.scm: 165  delete-file */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a850 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_851,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 165  g123 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a856 in a850 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_868,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 167  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[25],((C_word*)t0)[2]);}

/* k866 in a856 in a850 in a844 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 167  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k841 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k838 in k835 in k832 in loop in k820 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in body83 in file-move in k413 in k410 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-copy in k413 in k410 */
static void C_ccall f_432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_432r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_432r(t0,t1,t2,t3,t4);}}

static void C_ccall f_432r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_434,a[2]=t3,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_726,a[2]=t5,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_731,a[2]=t6,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-clobber1271 */
t8=t7;
f_731(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-blocksize1369 */
t10=t6;
f_726(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body1015 */
t12=t5;
f_434(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber12 in file-copy in k413 in k410 */
static void C_fcall f_731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_731,NULL,2,t0,t1);}
/* def-blocksize1369 */
t2=((C_word*)t0)[2];
f_726(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize13 in file-copy in k413 in k410 */
static void C_fcall f_726(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_726,NULL,3,t0,t1,t2);}
/* body1015 */
t3=((C_word*)t0)[2];
f_434(t3,t1,t2,C_fix(1024));}

/* body10 in file-copy in k413 in k410 */
static void C_fcall f_434(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_434,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[5]);
t5=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[5]);
t6=(C_word)C_i_check_number_2(t3,lf[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_447,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_integerp(t3))){
t8=t3;
t9=t7;
f_447(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}
else{
t8=t7;
f_447(t8,C_SCHEME_FALSE);}}

/* k445 in body10 in file-copy in k413 in k410 */
static void C_fcall f_447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_447,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_450(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_719,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 97   number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[6]);}}

/* k717 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 95   string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[23],t1);}

/* k713 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 95   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 98   file-exists? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_456(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 99   string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[22],((C_word*)t0)[3]);}}

/* k706 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 99   ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_691,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm: 100  file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k689 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_691,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_459(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 102  string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[21],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_459(2,t2,C_SCHEME_FALSE);}}

/* k699 in k689 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 102  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_635,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 105  call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_635,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_641,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_666,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 105  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a665 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_672,a[2]=((C_word*)t0)[3],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_678,a[2]=((C_word*)t0)[2],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 105  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a677 in a665 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_678(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_678r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_678r(t0,t1,t2);}}

static void C_ccall f_678r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_684,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 105  g27 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a683 in a677 in a665 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_684,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a671 in a665 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_672,2,t0,t1);}
/* files.scm: 105  open-input-file */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a640 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_641,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_647,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 105  g27 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a646 in a640 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_647,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_658,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 107  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[19],((C_word*)t0)[2]);}

/* k656 in a646 in a640 in a634 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 107  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k631 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_577,a[2]=((C_word*)t0)[2],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 110  call-with-current-continuation */
t5=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_577,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_583,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_608,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 110  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a607 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_614,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_620,a[2]=((C_word*)t0)[2],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 110  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a619 in a607 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_620(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_620r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_620r(t0,t1,t2);}}

static void C_ccall f_620r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_626,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 110  g37 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a625 in a619 in a607 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_626,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a613 in a607 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_614,2,t0,t1);}
/* files.scm: 110  open-output-file */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a582 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_583,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_589,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* files.scm: 110  g37 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a588 in a582 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_589,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[3],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_600,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 112  string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[17],((C_word*)t0)[2]);}

/* k598 in a588 in a582 in a576 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 112  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k573 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm: 115  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_475,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm: 116  read-string! */
t3=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_475,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li8),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_477(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_fcall f_477(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_477,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_487,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 120  close-input-port */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_493,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_507,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_509,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li7),tmp=(C_word)a,a+=8,tmp);
/* files.scm: 124  call-with-current-continuation */
t9=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_509,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_515,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_550,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li6),tmp=(C_word)a,a+=7,tmp);
/* files.scm: 124  with-exception-handler */
t5=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a549 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_562,a[2]=((C_word*)t0)[2],a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 124  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a561 in a549 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_562(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_562r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_562r(t0,t1,t2);}}

static void C_ccall f_562r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_568,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
/* files.scm: 124  g52 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a567 in a561 in a549 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_568,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a555 in a549 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
/* files.scm: 124  write-string */
t2=*((C_word*)lf[13]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a514 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_515,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li1),tmp=(C_word)a,a+=7,tmp);
/* files.scm: 124  g52 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a520 in a514 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_521,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[5],lf[9]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 126  close-input-port */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k526 in a520 in a514 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 127  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k529 in k526 in a520 in a514 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_538,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm: 130  number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k540 in k529 in k526 in a520 in a514 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 128  string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[12],t1);}

/* k536 in k529 in k526 in a520 in a514 in a508 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm: 128  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k505 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k491 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_500,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm: 131  read-string! */
t3=*((C_word*)lf[8]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k498 in k491 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm: 131  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_477(t3,((C_word*)t0)[2],t1,t2);}

/* k485 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm: 121  close-output-port */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k488 in k485 in loop in k473 in k466 in k463 in k460 in k457 in k454 in k451 in k448 in k445 in body10 in file-copy in k413 in k410 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* delete-file* in k413 in k410 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_417,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_424,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm: 87   file-exists? */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k422 in delete-file* in k413 in k410 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_424,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm: 87   delete-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k428 in k422 in delete-file* in k413 in k410 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[196] = {
{"toplevelfiles.scm",(void*)C_files_toplevel},
{"f_412files.scm",(void*)f_412},
{"f_415files.scm",(void*)f_415},
{"f_1952files.scm",(void*)f_1952},
{"f_1192files.scm",(void*)f_1192},
{"f_1195files.scm",(void*)f_1195},
{"f_1579files.scm",(void*)f_1579},
{"f_1582files.scm",(void*)f_1582},
{"f_1905files.scm",(void*)f_1905},
{"f_1913files.scm",(void*)f_1913},
{"f_1915files.scm",(void*)f_1915},
{"f_1840files.scm",(void*)f_1840},
{"f_1844files.scm",(void*)f_1844},
{"f_1897files.scm",(void*)f_1897},
{"f_1847files.scm",(void*)f_1847},
{"f_1858files.scm",(void*)f_1858},
{"f_1888files.scm",(void*)f_1888},
{"f_1884files.scm",(void*)f_1884},
{"f_1865files.scm",(void*)f_1865},
{"f_1871files.scm",(void*)f_1871},
{"f_1879files.scm",(void*)f_1879},
{"f_1822files.scm",(void*)f_1822},
{"f_1834files.scm",(void*)f_1834},
{"f_1828files.scm",(void*)f_1828},
{"f_1804files.scm",(void*)f_1804},
{"f_1816files.scm",(void*)f_1816},
{"f_1810files.scm",(void*)f_1810},
{"f_1786files.scm",(void*)f_1786},
{"f_1798files.scm",(void*)f_1798},
{"f_1792files.scm",(void*)f_1792},
{"f_1768files.scm",(void*)f_1768},
{"f_1780files.scm",(void*)f_1780},
{"f_1774files.scm",(void*)f_1774},
{"f_1750files.scm",(void*)f_1750},
{"f_1762files.scm",(void*)f_1762},
{"f_1756files.scm",(void*)f_1756},
{"f_1735files.scm",(void*)f_1735},
{"f_1747files.scm",(void*)f_1747},
{"f_1741files.scm",(void*)f_1741},
{"f_1720files.scm",(void*)f_1720},
{"f_1732files.scm",(void*)f_1732},
{"f_1726files.scm",(void*)f_1726},
{"f_1705files.scm",(void*)f_1705},
{"f_1717files.scm",(void*)f_1717},
{"f_1711files.scm",(void*)f_1711},
{"f_1597files.scm",(void*)f_1597},
{"f_1613files.scm",(void*)f_1613},
{"f_1642files.scm",(void*)f_1642},
{"f_1667files.scm",(void*)f_1667},
{"f_1652files.scm",(void*)f_1652},
{"f_1623files.scm",(void*)f_1623},
{"f_1583files.scm",(void*)f_1583},
{"f_1500files.scm",(void*)f_1500},
{"f_1529files.scm",(void*)f_1529},
{"f_1524files.scm",(void*)f_1524},
{"f_1502files.scm",(void*)f_1502},
{"f_1510files.scm",(void*)f_1510},
{"f_1516files.scm",(void*)f_1516},
{"f_1513files.scm",(void*)f_1513},
{"f_1436files.scm",(void*)f_1436},
{"f_1452files.scm",(void*)f_1452},
{"f_1447files.scm",(void*)f_1447},
{"f_1438files.scm",(void*)f_1438},
{"f_1446files.scm",(void*)f_1446},
{"f_1355files.scm",(void*)f_1355},
{"f_1384files.scm",(void*)f_1384},
{"f_1391files.scm",(void*)f_1391},
{"f_1324files.scm",(void*)f_1324},
{"f_1263files.scm",(void*)f_1263},
{"f_1272files.scm",(void*)f_1272},
{"f_1302files.scm",(void*)f_1302},
{"f_1310files.scm",(void*)f_1310},
{"f_1209files.scm",(void*)f_1209},
{"f_1225files.scm",(void*)f_1225},
{"f_1196files.scm",(void*)f_1196},
{"f_1207files.scm",(void*)f_1207},
{"f_779files.scm",(void*)f_779},
{"f_1139files.scm",(void*)f_1139},
{"f_1134files.scm",(void*)f_1134},
{"f_781files.scm",(void*)f_781},
{"f_794files.scm",(void*)f_794},
{"f_1127files.scm",(void*)f_1127},
{"f_1123files.scm",(void*)f_1123},
{"f_797files.scm",(void*)f_797},
{"f_800files.scm",(void*)f_800},
{"f_1116files.scm",(void*)f_1116},
{"f_803files.scm",(void*)f_803},
{"f_1099files.scm",(void*)f_1099},
{"f_1109files.scm",(void*)f_1109},
{"f_806files.scm",(void*)f_806},
{"f_1043files.scm",(void*)f_1043},
{"f_1074files.scm",(void*)f_1074},
{"f_1086files.scm",(void*)f_1086},
{"f_1092files.scm",(void*)f_1092},
{"f_1080files.scm",(void*)f_1080},
{"f_1049files.scm",(void*)f_1049},
{"f_1055files.scm",(void*)f_1055},
{"f_1066files.scm",(void*)f_1066},
{"f_1041files.scm",(void*)f_1041},
{"f_809files.scm",(void*)f_809},
{"f_985files.scm",(void*)f_985},
{"f_1016files.scm",(void*)f_1016},
{"f_1028files.scm",(void*)f_1028},
{"f_1034files.scm",(void*)f_1034},
{"f_1022files.scm",(void*)f_1022},
{"f_991files.scm",(void*)f_991},
{"f_997files.scm",(void*)f_997},
{"f_1008files.scm",(void*)f_1008},
{"f_983files.scm",(void*)f_983},
{"f_812files.scm",(void*)f_812},
{"f_815files.scm",(void*)f_815},
{"f_822files.scm",(void*)f_822},
{"f_824files.scm",(void*)f_824},
{"f_917files.scm",(void*)f_917},
{"f_958files.scm",(void*)f_958},
{"f_970files.scm",(void*)f_970},
{"f_976files.scm",(void*)f_976},
{"f_964files.scm",(void*)f_964},
{"f_923files.scm",(void*)f_923},
{"f_929files.scm",(void*)f_929},
{"f_936files.scm",(void*)f_936},
{"f_939files.scm",(void*)f_939},
{"f_950files.scm",(void*)f_950},
{"f_946files.scm",(void*)f_946},
{"f_915files.scm",(void*)f_915},
{"f_901files.scm",(void*)f_901},
{"f_908files.scm",(void*)f_908},
{"f_834files.scm",(void*)f_834},
{"f_837files.scm",(void*)f_837},
{"f_845files.scm",(void*)f_845},
{"f_876files.scm",(void*)f_876},
{"f_888files.scm",(void*)f_888},
{"f_894files.scm",(void*)f_894},
{"f_882files.scm",(void*)f_882},
{"f_851files.scm",(void*)f_851},
{"f_857files.scm",(void*)f_857},
{"f_868files.scm",(void*)f_868},
{"f_843files.scm",(void*)f_843},
{"f_840files.scm",(void*)f_840},
{"f_432files.scm",(void*)f_432},
{"f_731files.scm",(void*)f_731},
{"f_726files.scm",(void*)f_726},
{"f_434files.scm",(void*)f_434},
{"f_447files.scm",(void*)f_447},
{"f_719files.scm",(void*)f_719},
{"f_715files.scm",(void*)f_715},
{"f_450files.scm",(void*)f_450},
{"f_453files.scm",(void*)f_453},
{"f_708files.scm",(void*)f_708},
{"f_456files.scm",(void*)f_456},
{"f_691files.scm",(void*)f_691},
{"f_701files.scm",(void*)f_701},
{"f_459files.scm",(void*)f_459},
{"f_635files.scm",(void*)f_635},
{"f_666files.scm",(void*)f_666},
{"f_678files.scm",(void*)f_678},
{"f_684files.scm",(void*)f_684},
{"f_672files.scm",(void*)f_672},
{"f_641files.scm",(void*)f_641},
{"f_647files.scm",(void*)f_647},
{"f_658files.scm",(void*)f_658},
{"f_633files.scm",(void*)f_633},
{"f_462files.scm",(void*)f_462},
{"f_577files.scm",(void*)f_577},
{"f_608files.scm",(void*)f_608},
{"f_620files.scm",(void*)f_620},
{"f_626files.scm",(void*)f_626},
{"f_614files.scm",(void*)f_614},
{"f_583files.scm",(void*)f_583},
{"f_589files.scm",(void*)f_589},
{"f_600files.scm",(void*)f_600},
{"f_575files.scm",(void*)f_575},
{"f_465files.scm",(void*)f_465},
{"f_468files.scm",(void*)f_468},
{"f_475files.scm",(void*)f_475},
{"f_477files.scm",(void*)f_477},
{"f_509files.scm",(void*)f_509},
{"f_550files.scm",(void*)f_550},
{"f_562files.scm",(void*)f_562},
{"f_568files.scm",(void*)f_568},
{"f_556files.scm",(void*)f_556},
{"f_515files.scm",(void*)f_515},
{"f_521files.scm",(void*)f_521},
{"f_528files.scm",(void*)f_528},
{"f_531files.scm",(void*)f_531},
{"f_542files.scm",(void*)f_542},
{"f_538files.scm",(void*)f_538},
{"f_507files.scm",(void*)f_507},
{"f_493files.scm",(void*)f_493},
{"f_500files.scm",(void*)f_500},
{"f_487files.scm",(void*)f_487},
{"f_490files.scm",(void*)f_490},
{"f_417files.scm",(void*)f_417},
{"f_424files.scm",(void*)f_424},
{"f_430files.scm",(void*)f_430},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
