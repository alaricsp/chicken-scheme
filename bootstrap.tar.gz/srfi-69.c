/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-13 07:34
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: srfi-69.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file srfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[115];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,49,49,51,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,102,95,49,57,49,56,32,102,120,110,49,52,57,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,22),40,102,95,49,57,48,53,32,104,115,104,49,52,51,32,108,105,109,49,52,52,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,51,57,32,98,121,116,118,101,99,49,57,55,32,105,49,57,56,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,52,49,32,98,121,116,118,101,99,49,57,52,32,105,49,57,53,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,52,51,32,98,121,116,118,101,99,49,57,49,32,105,49,57,50,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,52,53,32,98,121,116,118,101,99,49,56,56,32,105,49,56,57,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,52,55,32,98,121,116,118,101,99,49,56,53,32,105,49,56,54,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,52,57,32,98,121,116,118,101,99,49,56,50,32,105,49,56,51,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,53,49,32,98,121,116,118,101,99,49,55,57,32,105,49,56,48,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,53,51,32,98,121,116,118,101,99,49,55,54,32,105,49,55,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,102,95,50,48,54,50,32,119,114,100,50,48,48,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,15),40,102,95,49,57,52,48,32,111,98,106,49,54,50,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,15),40,102,95,49,57,50,57,32,111,98,106,49,53,51,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,49,50,55,32,46,32,116,109,112,49,50,54,49,50,56,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,37,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,50,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,15),40,102,95,50,49,50,52,32,102,120,110,50,51,53,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,22),40,102,95,50,49,49,49,32,104,115,104,50,50,57,32,108,105,109,50,51,48,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,50,49,54,32,46,32,116,109,112,50,49,53,50,49,55,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,15),40,102,95,50,49,56,54,32,102,120,110,50,54,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,22),40,102,95,50,49,55,51,32,104,115,104,50,54,51,32,108,105,109,50,54,52,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,15),40,102,95,50,50,48,54,32,115,116,114,50,55,53,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,15),40,102,95,50,49,57,55,32,111,98,106,50,55,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,50,53,48,32,46,32,116,109,112,50,52,57,50,53,49,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,50,56,49,32,46,32,121,50,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,102,95,50,50,56,53,32,102,120,110,51,49,55,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,22),40,102,95,50,50,55,50,32,104,115,104,51,49,49,32,108,105,109,51,49,50,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,15),40,102,95,50,51,48,53,32,115,116,114,51,50,51,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,102,95,50,50,57,54,32,111,98,106,51,50,49,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,50,57,56,32,46,32,116,109,112,50,57,55,50,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,15),40,102,95,50,52,51,55,32,102,120,110,51,55,53,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,22),40,102,95,50,52,50,52,32,104,115,104,51,54,57,32,108,105,109,51,55,48,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,102,95,50,51,56,54,32,115,116,114,51,52,50,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,15),40,102,95,50,51,55,55,32,111,98,106,51,52,48,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,102,95,50,52,48,54,32,111,98,106,51,52,54,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,102,95,50,51,57,55,32,111,98,106,51,52,52,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,51,53,54,32,46,32,116,109,112,51,53,53,51,53,55,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,102,95,50,55,49,50,32,102,120,110,52,54,57,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,22),40,102,95,50,54,57,57,32,104,115,104,52,54,51,32,108,105,109,52,54,52,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,15),40,102,95,50,53,50,56,32,115,116,114,51,57,54,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,102,95,50,53,49,57,32,111,98,106,51,57,52,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,51,56,32,98,121,116,118,101,99,52,51,51,32,105,52,51,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,52,48,32,98,121,116,118,101,99,52,51,48,32,105,52,51,49,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,52,50,32,98,121,116,118,101,99,52,50,55,32,105,52,50,56,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,52,52,32,98,121,116,118,101,99,52,50,52,32,105,52,50,53,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,52,54,32,98,121,116,118,101,99,52,50,49,32,105,52,50,50,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,52,56,32,98,121,116,118,101,99,52,49,56,32,105,52,49,57,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,53,48,32,98,121,116,118,101,99,52,49,53,32,105,52,49,54,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,53,50,32,98,121,116,118,101,99,52,49,50,32,105,52,49,51,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,15),40,102,95,50,54,54,49,32,119,114,100,52,51,54,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,15),40,102,95,50,53,51,57,32,111,98,106,51,57,56,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,15),40,102,95,50,54,56,49,32,111,98,106,52,52,48,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,15),40,102,95,50,54,55,50,32,111,98,106,52,51,56,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,52,53,48,32,46,32,116,109,112,52,52,57,52,53,49,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,53,48,50,32,105,53,48,51,32,108,101,110,53,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,46),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,52,57,51,32,115,101,101,100,52,57,52,32,100,101,112,116,104,52,57,53,32,115,116,97,114,116,52,57,54,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,15),40,102,95,50,56,51,50,32,111,98,106,53,51,55,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,15),40,102,95,50,56,54,53,32,111,98,106,53,51,50,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,102,95,50,56,53,54,32,111,98,106,53,51,48,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,15),40,102,95,50,56,52,53,32,111,98,106,53,50,51,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,15),40,102,95,50,56,51,52,32,111,98,106,53,49,54,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,97,116,111,109,105,99,45,104,97,115,104,32,111,98,106,53,48,56,32,100,101,112,116,104,53,48,57,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,15),40,102,95,50,57,51,51,32,115,116,114,53,53,49,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,15),40,102,95,50,57,50,52,32,111,98,106,53,52,57,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,52,51,32,98,121,116,118,101,99,53,56,56,32,105,53,56,57,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,52,53,32,98,121,116,118,101,99,53,56,53,32,105,53,56,54,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,52,55,32,98,121,116,118,101,99,53,56,50,32,105,53,56,51,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,52,57,32,98,121,116,118,101,99,53,55,57,32,105,53,56,48,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,53,49,32,98,121,116,118,101,99,53,55,54,32,105,53,55,55,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,53,51,32,98,121,116,118,101,99,53,55,51,32,105,53,55,52,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,53,53,32,98,121,116,118,101,99,53,55,48,32,105,53,55,49,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,102,95,51,48,53,55,32,98,121,116,118,101,99,53,54,55,32,105,53,54,56,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,15),40,102,95,51,48,54,54,32,119,114,100,53,57,49,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,15),40,102,95,50,57,52,52,32,111,98,106,53,53,51,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,15),40,102,95,51,48,56,51,32,115,116,114,53,57,57,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,15),40,102,95,51,48,57,52,32,111,98,106,54,48,49,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,15),40,102,95,51,49,50,48,32,111,98,106,54,48,51,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,15),40,102,95,51,49,53,52,32,111,98,106,54,48,55,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,15),40,102,95,51,49,56,51,32,111,98,106,54,49,49,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,15),40,102,95,51,49,57,53,32,111,98,106,54,49,51,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,48,48,32,111,98,106,54,48,57,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,48,50,32,111,98,106,54,48,53,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,48,52,32,111,98,106,53,57,55,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,49,53,32,111,98,106,53,57,53,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,48,54,32,111,98,106,53,57,51,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,32),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,53,51,57,32,100,101,112,116,104,53,52,48,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,21),40,37,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,52,56,56,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,52,57,32,102,120,110,54,52,53,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,102,95,51,50,51,54,32,104,115,104,54,51,57,32,108,105,109,54,52,48,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,54,50,54,32,46,32,116,109,112,54,50,53,54,50,55,41};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,102,95,51,51,49,50,32,102,120,110,54,55,56,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,22),40,102,95,51,50,57,57,32,104,115,104,54,55,50,32,108,105,109,54,55,51,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,102,95,51,51,50,51,32,115,116,114,54,56,50,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,54,53,57,32,46,32,116,109,112,54,53,56,54,54,48,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,102,95,51,51,55,54,32,102,120,110,55,49,51,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,22),40,102,95,51,51,54,51,32,104,115,104,55,48,55,32,108,105,109,55,48,56,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,15),40,102,95,51,51,56,55,32,115,116,114,55,49,55,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,54,57,52,32,46,32,116,109,112,54,57,51,54,57,53,41,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,55,52,52,32,114,101,113,55,52,53,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,116),40,37,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,55,55,49,32,104,97,115,104,55,55,50,32,108,101,110,55,55,51,32,109,105,110,45,108,111,97,100,55,55,52,32,109,97,120,45,108,111,97,100,55,55,53,32,119,101,97,107,45,107,101,121,115,55,55,54,32,119,101,97,107,45,118,97,108,117,101,115,55,55,55,32,105,110,105,116,105,97,108,55,55,56,32,46,32,116,109,112,55,55,48,55,55,57,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,56,57,51,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,8),40,102,95,51,54,55,52,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,56,56,54,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,55,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,57,53,49,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,57,53,53,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,57,54,48,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,57,54,53,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,57,55,48,41,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,57,55,53,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,57,56,48,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,57,56,53,41,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,57,57,48,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,57,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,49,51,32,105,49,48,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,44),40,37,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,49,48,52,53,32,118,101,99,49,48,52,54,32,108,101,110,49,48,52,55,41,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,22),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,49,48,56,52,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,55,50,32,105,49,48,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,25),40,37,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,49,48,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,49,48,57,53,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,26),40,102,95,52,51,50,53,32,104,116,49,49,51,51,32,110,101,119,115,105,122,49,49,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,49,49,56,32,102,117,110,99,49,49,50,56,32,116,104,117,110,107,49,49,50,57,41,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,8),40,102,95,52,51,57,56,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,116,104,117,110,107,49,49,50,49,32,37,102,117,110,99,49,49,49,54,49,49,57,55,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,102,117,110,99,49,49,50,48,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,49),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,49,49,48,55,32,107,101,121,49,49,48,56,32,46,32,116,109,112,49,49,48,54,49,49,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,50,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,50,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,26),40,102,95,52,54,48,49,32,104,116,49,50,50,57,32,110,101,119,115,105,122,49,50,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,61),40,37,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,50,50,50,32,107,101,121,49,50,50,51,32,102,117,110,99,49,50,50,52,32,100,101,102,49,50,50,53,41,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,60),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,50,57,48,32,107,101,121,49,50,57,49,32,102,117,110,99,49,50,57,50,32,100,101,102,49,50,57,51,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,51,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,51,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,26),40,102,95,52,56,49,49,32,104,116,49,51,48,54,32,110,101,119,115,105,122,49,51,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,49,51,48,48,32,107,101,121,49,51,48,49,32,118,97,108,49,51,48,50,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,52,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,47),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,49,52,48,57,32,107,101,121,49,52,49,48,32,100,101,102,49,52,49,49,41,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,52,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,52,52,50,32,107,101,121,49,52,52,51,41,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,53,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,53,50,51,32,98,117,99,107,101,116,49,53,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,52,57,48,32,107,101,121,49,52,57,49,41,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,53,54,48,32,98,117,99,107,101,116,49,53,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,53,52,56,32,105,49,53,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,53,51,56,32,102,117,110,99,49,53,51,57,41,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,53,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,54,48,50,32,108,115,116,49,54,48,57,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,53,57,51,32,105,49,54,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,36),40,37,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,53,56,53,32,104,116,50,49,53,56,54,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,54,50,50,32,104,116,50,49,54,50,51,41,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,54,50,57,32,104,116,50,49,54,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,54,53,49,32,108,115,116,49,54,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,54,52,54,32,108,115,116,49,54,52,55,41,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,54,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,13),40,97,53,53,49,49,32,120,49,54,54,57,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,54,54,52,32,46,32,114,101,115,116,49,54,54,53,41};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,54,57,48,32,108,115,116,49,54,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,54,56,53,32,108,115,116,49,54,56,54,41,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,54,55,53,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,55,49,55,32,108,115,116,49,55,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,55,49,50,32,108,115,116,49,55,49,51,41,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,55,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,18),40,97,53,54,56,54,32,98,117,99,107,101,116,49,55,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,55,51,55,32,105,49,55,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,38),40,37,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,55,50,57,32,112,114,111,99,49,55,51,48,41,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,55,55,49,32,97,99,99,49,55,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,55,54,54,32,97,99,99,49,55,54,55,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,43),40,37,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,55,53,52,32,102,117,110,99,49,55,53,53,32,105,110,105,116,49,55,53,54,41,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,55,56,50,32,102,117,110,99,49,55,56,51,32,105,110,105,116,49,55,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,55,57,48,32,112,114,111,99,49,55,57,49,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,55,57,55,32,112,114,111,99,49,55,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,25),40,97,53,56,49,56,32,107,49,56,48,55,32,118,49,56,48,56,32,97,49,56,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,56,48,52,32,102,117,110,99,49,56,48,53,41};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,51,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,51,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,8),40,102,95,53,57,52,57,41};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,36),40,97,53,56,50,56,32,104,116,49,51,54,52,32,107,101,121,49,51,54,53,32,46,32,116,109,112,49,51,54,51,49,51,54,54,41,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5833)
static void C_ccall f_5833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_fcall f_5866(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_fcall f_5705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5717)
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5733)
static void C_fcall f_5733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_fcall f_5656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5668)
static void C_fcall f_5668(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5606)
static void C_fcall f_5606(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5622)
static void C_fcall f_5622(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5541)
static void C_fcall f_5541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5557)
static void C_fcall f_5557(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5442)
static void C_fcall f_5442(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5458)
static void C_fcall f_5458(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5334)
static void C_fcall f_5334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5346)
static void C_fcall f_5346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5369)
static void C_fcall f_5369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_fcall f_5243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5269)
static void C_fcall f_5269(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_fcall f_5174(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static C_word C_fcall f_5127(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_fcall f_5054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static C_word C_fcall f_5014(C_word t0,C_word t1);
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_fcall f_4947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static C_word C_fcall f_4908(C_word t0,C_word t1);
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_fcall f_4836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_fcall f_4451(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_fcall f_4626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_fcall f_4546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_fcall f_4487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_fcall f_4386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4377)
static void C_ccall f_4377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_fcall f_4350(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_fcall f_4266(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4035)
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_fcall f_4050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4112)
static void C_fcall f_4112(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_fcall f_3942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3965)
static void C_fcall f_3965(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_fcall f_3552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_fcall f_3555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_fcall f_3590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_fcall f_3568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static C_word C_fcall f_3473(C_word t0);
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t11) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_fcall f_3410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3416)
static C_word C_fcall f_3416(C_word t0,C_word t1);
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_fcall f_2743(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2811)
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_fcall f_2746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2763)
static void C_fcall f_2763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_fcall f_2090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5908)
static void C_fcall trf_5908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5908(t0,t1,t2);}

C_noret_decl(trf_5866)
static void C_fcall trf_5866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5866(t0,t1,t2);}

C_noret_decl(trf_5705)
static void C_fcall trf_5705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5705(t0,t1,t2,t3);}

C_noret_decl(trf_5717)
static void C_fcall trf_5717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5717(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5717(t0,t1,t2,t3);}

C_noret_decl(trf_5733)
static void C_fcall trf_5733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5733(t0,t1,t2,t3);}

C_noret_decl(trf_5656)
static void C_fcall trf_5656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5656(t0,t1,t2);}

C_noret_decl(trf_5668)
static void C_fcall trf_5668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5668(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5668(t0,t1,t2);}

C_noret_decl(trf_5606)
static void C_fcall trf_5606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5606(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5606(t0,t1,t2,t3);}

C_noret_decl(trf_5622)
static void C_fcall trf_5622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5622(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5622(t0,t1,t2,t3);}

C_noret_decl(trf_5541)
static void C_fcall trf_5541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5541(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5541(t0,t1,t2,t3);}

C_noret_decl(trf_5557)
static void C_fcall trf_5557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5557(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5557(t0,t1,t2,t3);}

C_noret_decl(trf_5442)
static void C_fcall trf_5442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5442(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5442(t0,t1,t2,t3);}

C_noret_decl(trf_5458)
static void C_fcall trf_5458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5458(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5458(t0,t1,t2,t3);}

C_noret_decl(trf_5334)
static void C_fcall trf_5334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5334(t0,t1,t2);}

C_noret_decl(trf_5346)
static void C_fcall trf_5346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5346(t0,t1,t2);}

C_noret_decl(trf_5369)
static void C_fcall trf_5369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5369(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5369(t0,t1,t2);}

C_noret_decl(trf_5243)
static void C_fcall trf_5243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5243(t0,t1,t2);}

C_noret_decl(trf_5269)
static void C_fcall trf_5269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5269(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5269(t0,t1,t2,t3);}

C_noret_decl(trf_5174)
static void C_fcall trf_5174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5174(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5174(t0,t1,t2,t3);}

C_noret_decl(trf_5054)
static void C_fcall trf_5054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5054(t0,t1,t2);}

C_noret_decl(trf_4947)
static void C_fcall trf_4947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4947(t0,t1,t2);}

C_noret_decl(trf_4836)
static void C_fcall trf_4836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4836(t0,t1);}

C_noret_decl(trf_4766)
static void C_fcall trf_4766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4766(t0,t1,t2);}

C_noret_decl(trf_4717)
static void C_fcall trf_4717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4717(t0,t1,t2);}

C_noret_decl(trf_4451)
static void C_fcall trf_4451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4451(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4451(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4626)
static void C_fcall trf_4626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4626(t0,t1);}

C_noret_decl(trf_4546)
static void C_fcall trf_4546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4546(t0,t1,t2);}

C_noret_decl(trf_4487)
static void C_fcall trf_4487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4487(t0,t1,t2);}

C_noret_decl(trf_4403)
static void C_fcall trf_4403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4403(t0,t1);}

C_noret_decl(trf_4386)
static void C_fcall trf_4386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4386(t0,t1,t2);}

C_noret_decl(trf_4158)
static void C_fcall trf_4158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4158(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4158(t0,t1,t2,t3);}

C_noret_decl(trf_4350)
static void C_fcall trf_4350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4350(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4350(t0,t1);}

C_noret_decl(trf_4266)
static void C_fcall trf_4266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4266(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4266(t0,t1,t2);}

C_noret_decl(trf_4203)
static void C_fcall trf_4203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4203(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4203(t0,t1,t2);}

C_noret_decl(trf_4035)
static void C_fcall trf_4035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4035(t0,t1,t2);}

C_noret_decl(trf_4050)
static void C_fcall trf_4050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4050(t0,t1,t2);}

C_noret_decl(trf_4112)
static void C_fcall trf_4112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4112(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4112(t0,t1,t2);}

C_noret_decl(trf_3942)
static void C_fcall trf_3942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3942(t0,t1,t2);}

C_noret_decl(trf_3965)
static void C_fcall trf_3965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3965(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3965(t0,t1,t2);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3549(t0,t1);}

C_noret_decl(trf_3552)
static void C_fcall trf_3552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3552(t0,t1);}

C_noret_decl(trf_3555)
static void C_fcall trf_3555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3555(t0,t1);}

C_noret_decl(trf_3590)
static void C_fcall trf_3590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3590(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3590(t0,t1,t2);}

C_noret_decl(trf_3601)
static void C_fcall trf_3601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3601(t0,t1,t2);}

C_noret_decl(trf_3568)
static void C_fcall trf_3568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3568(t0,t1);}

C_noret_decl(trf_3410)
static void C_fcall trf_3410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3410(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3410(t0,t1,t2);}

C_noret_decl(trf_2743)
static void C_fcall trf_2743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2743(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2743(t0,t1);}

C_noret_decl(trf_2868)
static void C_fcall trf_2868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2868(t0,t1,t2,t3);}

C_noret_decl(trf_2811)
static void C_fcall trf_2811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2811(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2811(t0,t1,t2,t3);}

C_noret_decl(trf_2746)
static void C_fcall trf_2746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2746(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2746(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2763)
static void C_fcall trf_2763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2763(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2763(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2090)
static void C_fcall trf_2090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2090(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr10r)
static void C_fcall tr10r(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10r(C_proc10 k){
int n;
C_word *a,t10;
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
n=C_rest_count(0);
a=C_alloc(n*3);
t10=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(933)){
C_save(t1);
C_rereclaim2(933*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,115);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysnumber-hash-hook");
lf[4]=C_h_intern(&lf[4],11,"number-hash");
lf[5]=C_h_intern(&lf[5],5,"fxmod");
lf[6]=C_h_intern(&lf[6],4,"\077obj");
lf[7]=C_h_intern(&lf[7],15,"\003syssignal-hook");
lf[8]=C_h_intern(&lf[8],5,"\000type");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[12]=C_h_intern(&lf[12],15,"object-uid-hash");
lf[13]=C_h_intern(&lf[13],11,"symbol-hash");
lf[14]=C_h_intern(&lf[14],17,"\003syscheck-keyword");
lf[15]=C_h_intern(&lf[15],11,"\000type-error");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[17]=C_h_intern(&lf[17],8,"keyword\077");
lf[18]=C_h_intern(&lf[18],12,"keyword-hash");
lf[19]=C_h_intern(&lf[19],8,"eq\077-hash");
lf[20]=C_h_intern(&lf[20],16,"hash-by-identity");
lf[21]=C_h_intern(&lf[21],9,"eqv\077-hash");
lf[22]=C_h_intern(&lf[22],11,"input-port\077");
lf[23]=C_h_intern(&lf[23],11,"equal\077-hash");
lf[24]=C_h_intern(&lf[24],4,"hash");
lf[25]=C_h_intern(&lf[25],11,"string-hash");
lf[26]=C_h_intern(&lf[26],14,"string-ci-hash");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[30]=C_h_intern(&lf[30],11,"make-vector");
lf[31]=C_h_intern(&lf[31],16,"%make-hash-table");
lf[32]=C_h_intern(&lf[32],10,"hash-table");
lf[33]=C_h_intern(&lf[33],3,"eq\077");
lf[34]=C_h_intern(&lf[34],4,"eqv\077");
lf[35]=C_h_intern(&lf[35],6,"equal\077");
lf[36]=C_h_intern(&lf[36],8,"string=\077");
lf[37]=C_h_intern(&lf[37],11,"string-ci=\077");
lf[38]=C_h_intern(&lf[38],1,"=");
lf[39]=C_h_intern(&lf[39],15,"make-hash-table");
lf[40]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[41]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[42]=C_h_intern(&lf[42],7,"warning");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[44]=C_h_intern(&lf[44],5,"error");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[46]=C_h_intern(&lf[46],5,"\000test");
lf[47]=C_h_intern(&lf[47],17,"\003syscheck-closure");
lf[48]=C_h_intern(&lf[48],5,"\000hash");
lf[49]=C_h_intern(&lf[49],5,"\000size");
lf[50]=C_h_intern(&lf[50],19,"hash-table-max-size");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[52]=C_h_intern(&lf[52],8,"\000initial");
lf[53]=C_h_intern(&lf[53],9,"\000min-load");
lf[54]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[55]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[57]=C_h_intern(&lf[57],17,"\003syscheck-inexact");
lf[58]=C_h_intern(&lf[58],9,"\000max-load");
lf[59]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[60]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[62]=C_h_intern(&lf[62],10,"\000weak-keys");
lf[63]=C_h_intern(&lf[63],12,"\000weak-values");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[68]=C_h_intern(&lf[68],11,"hash-table\077");
lf[69]=C_h_intern(&lf[69],15,"hash-table-size");
lf[70]=C_h_intern(&lf[70],31,"hash-table-equivalence-function");
lf[71]=C_h_intern(&lf[71],24,"hash-table-hash-function");
lf[72]=C_h_intern(&lf[72],19,"hash-table-min-load");
lf[73]=C_h_intern(&lf[73],19,"hash-table-max-load");
lf[74]=C_h_intern(&lf[74],20,"hash-table-weak-keys");
lf[75]=C_h_intern(&lf[75],22,"hash-table-weak-values");
lf[76]=C_h_intern(&lf[76],23,"hash-table-has-initial\077");
lf[77]=C_h_intern(&lf[77],18,"hash-table-initial");
lf[78]=C_h_intern(&lf[78],19,"%hash-table-resize!");
lf[80]=C_h_intern(&lf[80],15,"hash-table-copy");
lf[81]=C_h_intern(&lf[81],18,"hash-table-update!");
lf[82]=C_h_intern(&lf[82],5,"floor");
lf[83]=C_h_intern(&lf[83],13,"\000access-error");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[85]=C_h_intern(&lf[85],8,"identity");
lf[87]=C_h_intern(&lf[87],26,"hash-table-update!/default");
lf[88]=C_h_intern(&lf[88],15,"hash-table-set!");
lf[89]=C_h_intern(&lf[89],19,"\003sysundefined-value");
lf[90]=C_h_intern(&lf[90],14,"hash-table-ref");
lf[91]=C_h_intern(&lf[91],22,"hash-table-ref/default");
lf[92]=C_h_intern(&lf[92],18,"hash-table-exists\077");
lf[93]=C_h_intern(&lf[93],18,"hash-table-delete!");
lf[94]=C_h_intern(&lf[94],18,"hash-table-remove!");
lf[95]=C_h_intern(&lf[95],17,"hash-table-clear!");
lf[96]=C_h_intern(&lf[96],12,"vector-fill!");
lf[98]=C_h_intern(&lf[98],17,"hash-table-merge!");
lf[99]=C_h_intern(&lf[99],16,"hash-table-merge");
lf[100]=C_h_intern(&lf[100],17,"hash-table->alist");
lf[101]=C_h_intern(&lf[101],17,"alist->hash-table");
lf[102]=C_h_intern(&lf[102],12,"\003sysfor-each");
lf[103]=C_h_intern(&lf[103],15,"hash-table-keys");
lf[104]=C_h_intern(&lf[104],17,"hash-table-values");
lf[107]=C_h_intern(&lf[107],15,"hash-table-fold");
lf[108]=C_h_intern(&lf[108],19,"hash-table-for-each");
lf[109]=C_h_intern(&lf[109],15,"hash-table-walk");
lf[110]=C_h_intern(&lf[110],14,"hash-table-map");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[112]=C_h_intern(&lf[112],18,"getter-with-setter");
lf[113]=C_h_intern(&lf[113],17,"register-feature!");
lf[114]=C_h_intern(&lf[114],7,"srfi-69");
C_register_lf2(lf,115,create_ptable());
t2=C_mutate(&lf[0] /* (set! c139 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 59   register-feature! */
t4=*((C_word*)lf[113]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[114]);}

/* k1877 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[117],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[11] /* (set! %object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2090,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[12]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2096,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[13]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[14]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[18]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2254,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[19]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2409,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[20]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[19]+1));
t11=C_mutate((C_word*)lf[21]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[3] /* (set! %equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[24]+1 /* (set! hash ...) */,*((C_word*)lf[23]+1));
t15=C_mutate((C_word*)lf[25]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[26]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3345,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[27] /* (set! constant736 ...) */,lf[28]);
t18=C_mutate(&lf[29] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[30]+1);
t20=C_mutate((C_word*)lf[31]+1 /* (set! %make-hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3440,a[2]=t19,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[33]+1);
t22=*((C_word*)lf[34]+1);
t23=*((C_word*)lf[35]+1);
t24=*((C_word*)lf[36]+1);
t25=*((C_word*)lf[37]+1);
t26=*((C_word*)lf[38]+1);
t27=C_mutate((C_word*)lf[39]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3471,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,a[8]=((C_word)li104),tmp=(C_word)a,a+=9,tmp));
t28=C_mutate((C_word*)lf[68]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[69]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3849,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3858,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3867,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3876,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3885,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[76]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3903,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[78]+1 /* (set! %hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t39=*((C_word*)lf[30]+1);
t40=C_mutate(&lf[79] /* (set! %hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4035,a[2]=t39,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[80]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4147,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[33]+1);
t43=C_mutate((C_word*)lf[81]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=t42,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp));
t44=*((C_word*)lf[33]+1);
t45=C_mutate(&lf[86] /* (set! %hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4451,a[2]=t44,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[87]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4663,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t47=*((C_word*)lf[33]+1);
t48=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=t47,a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[33]+1);
t51=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5829,a[2]=t50,a[3]=((C_word)li182),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 800  getter-with-setter */
t52=*((C_word*)lf[112]+1);
((C_proc4)C_retrieve_proc(t52))(4,t52,t49,t51,*((C_word*)lf[88]+1));}

/* a5828 in k1877 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_5829r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5829r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5833,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5833(2,t6,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5949,a[2]=t2,a[3]=t3,a[4]=((C_word)li181),tmp=(C_word)a,a+=5,tmp));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5833(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* f_5949 in a5828 in k1877 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
/* srfi-69.scm: 803  ##sys#signal-hook */
t2=*((C_word*)lf[7]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[83],lf[90],lf[111],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5831 in a5828 in k1877 */
static void C_ccall f_5833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5833,2,t0,t1);}
t2=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[32],lf[90]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 807  ##sys#check-closure */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[90]);}

/* k5837 in k5831 in a5828 in k1877 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5839,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 811  hash */
t7=t4;
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5849 in k5837 in k5831 in a5828 in k1877 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5851,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5866,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li179),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5866(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li180),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5908(t7,((C_word*)t0)[2],t3);}}

/* loop in k5849 in k5837 in k5831 in a5828 in k1877 */
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5908,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 824  def */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 826  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5925 in loop in k5849 in k5837 in k5831 in a5828 in k1877 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 828  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5908(t3,((C_word*)t0)[5],t2);}}

/* loop in k5849 in k5837 in k5831 in a5828 in k1877 */
static void C_fcall f_5866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5866,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 816  def */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 820  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4873 in k1877 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[58],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[33]+1);
t4=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=t3,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[33]+1);
t6=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4983,a[2]=t5,a[3]=((C_word)li144),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[33]+1);
t8=C_mutate((C_word*)lf[93]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5091,a[2]=t7,a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[94]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5222,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5318,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[97] /* (set! %hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5334,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[98]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5399,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5411,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[100]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[39]+1);
t16=C_mutate((C_word*)lf[101]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5500,a[2]=t15,a[3]=((C_word)li161),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[103]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5526,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5591,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[105] /* (set! %hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5656,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[106] /* (set! %hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5705,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[107]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5771,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[108]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5783,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[109]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5795,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[110]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4873 in k1877 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5807,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[110]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5814,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1078 ##sys#check-closure */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[110]);}

/* k5812 in hash-table-map in k4873 in k1877 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[4],a[3]=((C_word)li177),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1079 %hash-table-fold */
f_5705(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5818 in k5812 in hash-table-map in k4873 in k1877 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5819,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5827,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1079 func */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5825 in a5818 in k5812 in hash-table-map in k4873 in k1877 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4873 in k1877 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5795,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[109]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5802,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1073 ##sys#check-closure */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[109]);}

/* k5800 in hash-table-walk in k4873 in k1877 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1074 %hash-table-for-each */
f_5656(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4873 in k1877 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5783,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[108]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5790,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1068 ##sys#check-closure */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[108]);}

/* k5788 in hash-table-for-each in k4873 in k1877 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1069 %hash-table-for-each */
f_5656(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4873 in k1877 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5771,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[32],lf[107]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5778,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1063 ##sys#check-closure */
t7=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[107]);}

/* k5776 in hash-table-fold in k4873 in k1877 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1064 %hash-table-fold */
f_5705(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %hash-table-fold in k4873 in k1877 */
static void C_fcall f_5705(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5705,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5717,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,a[6]=((C_word)li172),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_5717(t10,t1,C_fix(0),t4);}

/* loop in %hash-table-fold in k4873 in k1877 */
static void C_fcall f_5717(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5717,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word)li171),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5733(t8,t1,t4,t3);}}

/* fold2 in loop in %hash-table-fold in k4873 in k1877 */
static void C_fcall f_5733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5733,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1056 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5717(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5761,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1059 func */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k5759 in fold2 in loop in %hash-table-fold in k4873 in k1877 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1058 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5733(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* %hash-table-for-each in k4873 in k1877 */
static void C_fcall f_5656(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5656,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5668,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,a[6]=((C_word)li169),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5668(t9,t1,C_fix(0));}

/* doloop1737 in %hash-table-for-each in k4873 in k1877 */
static void C_fcall f_5668(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5668,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5678,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5687,a[2]=((C_word*)t0)[3],a[3]=((C_word)li168),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* srfi-69.scm: 1043 ##sys#for-each */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a5686 in doloop1737 in %hash-table-for-each in k4873 in k1877 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5687,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1044 proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k5676 in doloop1737 in %hash-table-for-each in k4873 in k1877 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5668(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4873 in k1877 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5591,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[104]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5606,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li166),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5606(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4873 in k1877 */
static void C_fcall f_5606(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5606,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5622,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li165),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5622(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4873 in k1877 */
static void C_fcall f_5622(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5622,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1026 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5606(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1027 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4873 in k1877 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5526,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[103]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5541,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li163),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5541(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4873 in k1877 */
static void C_fcall f_5541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5541,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5557,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li162),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5557(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4873 in k1877 */
static void C_fcall f_5557(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5557,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1011 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5541(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1012 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4873 in k1877 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5500r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5500r(t0,t1,t2,t3);}}

static void C_ccall f_5500r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[101]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k5505 in alist->hash-table in k4873 in k1877 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5510,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5512,a[2]=t1,a[3]=((C_word)li160),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5511 in k5505 in alist->hash-table in k4873 in k1877 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5512,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 995  %hash-table-update!/default */
t5=lf[86];
f_4451(t5,t1,((C_word*)t0)[2],t3,*((C_word*)lf[85]+1),t4);}

/* k5508 in k5505 in alist->hash-table in k4873 in k1877 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4873 in k1877 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5427,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5442,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li158),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5442(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4873 in k1877 */
static void C_fcall f_5442(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5442,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5458,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li157),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5458(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4873 in k1877 */
static void C_fcall f_5458(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5458,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 984  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5442(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 985  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4873 in k1877 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5411,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[99]);
t5=(C_word)C_i_check_structure_2(t3,lf[32],lf[99]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5425,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 970  %hash-table-copy */
t7=lf[79];
f_4035(t7,t6,t2);}

/* k5423 in hash-table-merge in k4873 in k1877 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 970  %hash-table-merge! */
f_5334(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4873 in k1877 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5399,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[98]);
t5=(C_word)C_i_check_structure_2(t3,lf[32],lf[98]);
/* srfi-69.scm: 965  %hash-table-merge! */
f_5334(t1,t2,t3);}

/* %hash-table-merge! in k4873 in k1877 */
static void C_fcall f_5334(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5334,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5346,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=((C_word)li153),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5346(t9,t1,C_fix(0));}

/* doloop1593 in %hash-table-merge! in k4873 in k1877 */
static void C_fcall f_5346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5346,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5356,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5369,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5369(t8,t3,t4);}}

/* doloop1602 in doloop1593 in %hash-table-merge! in k4873 in k1877 */
static void C_fcall f_5369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5369,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5382,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 960  %hash-table-update!/default */
t7=lf[86];
f_4451(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[85]+1),t6);}}

/* k5380 in doloop1602 in doloop1593 in %hash-table-merge! in k4873 in k1877 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5369(t3,((C_word*)t0)[2],t2);}

/* k5354 in doloop1593 in %hash-table-merge! in k4873 in k1877 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5346(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4873 in k1877 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5318,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[95]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5325,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 947  vector-fill! */
t6=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k5323 in hash-table-clear! in k4873 in k1877 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4873 in k1877 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5222,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[94]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5229,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 924  ##sys#check-closure */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[94]);}

/* k5227 in hash-table-remove! in k4873 in k1877 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5229,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word)li149),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_5243(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1548 in k5227 in hash-table-remove! in k4873 in k1877 */
static void C_fcall f_5243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5243,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5256,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word)li148),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5269(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1548 in k5227 in hash-table-remove! in k4873 in k1877 */
static void C_fcall f_5269(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5269,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5288,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 934  func */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k5286 in loop in doloop1548 in k5227 in hash-table-remove! in k4873 in k1877 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 941  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5269(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k5254 in doloop1548 in k5227 in hash-table-remove! in k4873 in k1877 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5243(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4873 in k1877 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5091,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[93]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5107,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 888  hash */
t9=t7;
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t3,t6);}

/* k5105 in hash-table-delete! in k4873 in k1877 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5127,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li145),tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_5127(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word)li146),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_5174(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k5105 in hash-table-delete! in k4873 in k1877 */
static void C_fcall f_5174(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5174,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5193,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 911  test */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k5191 in loop in k5105 in hash-table-delete! in k4873 in k1877 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 918  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5174(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k5105 in hash-table-delete! in k4873 in k1877 */
static C_word C_fcall f_5127(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4873 in k1877 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4983,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[32],lf[92]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4999,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 864  hash */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k4997 in hash-table-exists? in k4873 in k1877 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[3],a[3]=((C_word)li142),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5014(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word)li143),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5054(t7,((C_word*)t0)[2],t3);}}

/* loop in k4997 in hash-table-exists? in k4873 in k1877 */
static void C_fcall f_5054(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5054,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 876  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5065 in loop in k4997 in hash-table-exists? in k4873 in k1877 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 877  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5054(t3,((C_word*)t0)[4],t2);}}

/* loop in k4997 in hash-table-exists? in k4873 in k1877 */
static C_word C_fcall f_5014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4873 in k1877 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4877,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[32],lf[91]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4893,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 838  hash */
t11=t8;
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t3,t10);}

/* k4891 in hash-table-ref/default in k4873 in k1877 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li139),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4908(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li140),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4947(t7,((C_word*)t0)[2],t3);}}

/* loop in k4891 in hash-table-ref/default in k4873 in k1877 */
static void C_fcall f_4947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4947,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 853  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4961 in loop in k4891 in hash-table-ref/default in k4873 in k1877 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 855  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4947(t3,((C_word*)t0)[5],t2);}}

/* loop in k4891 in hash-table-ref/default in k4873 in k1877 */
static C_word C_fcall f_4908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-set! in k1877 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4675,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[32],lf[88]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4685,a[2]=t7,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t2,t7);}

/* f_4811 in hash-table-set! in k1877 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4811,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(5));
t6=(C_word)C_slot(t2,C_fix(6));
t7=(C_word)C_block_size(t4);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4863,a[2]=t6,a[3]=t3,a[4]=t7,a[5]=t4,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_a_i_times(&a,2,t7,t5);
/* srfi-69.scm: 628  floor */
t10=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}

/* k4861 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 629  floor */
t5=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4853 in k4861 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4855,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4836(t5,(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4836(t4,C_SCHEME_FALSE);}}

/* k4834 in k4853 in k4861 */
static void C_fcall f_4836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 632  %hash-table-resize! */
t2=*((C_word*)lf[78]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4683 in hash-table-set! in k1877 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 772  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4698 in k4683 in hash-table-set! in k1877 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4717,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word)li135),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4717(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word)li136),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_4766(t8,t3,t2);}}

/* loop in k4698 in k4683 in hash-table-set! in k1877 */
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4766,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 792  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4794 in loop in k4698 in k4683 in hash-table-set! in k1877 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 794  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4766(t3,((C_word*)t0)[6],t2);}}

/* loop in k4698 in k4683 in hash-table-set! in k1877 */
static void C_fcall f_4717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4717,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 784  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4704 in k4698 in k4683 in hash-table-set! in k1877 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[89]+1));}

/* hash-table-update!/default in k1877 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4663,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[32],lf[87]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4670,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 759  ##sys#check-closure */
t8=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[87]);}

/* k4668 in hash-table-update!/default in k1877 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 760  %hash-table-update!/default */
t2=lf[86];
f_4451(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %hash-table-update!/default in k1877 */
static void C_fcall f_4451(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4451,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4458,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t7,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4601,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t2,t7);}

/* f_4601 in %hash-table-update!/default in k1877 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4601,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(5));
t6=(C_word)C_slot(t2,C_fix(6));
t7=(C_word)C_block_size(t4);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4653,a[2]=t6,a[3]=t3,a[4]=t7,a[5]=t4,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_a_i_times(&a,2,t7,t5);
/* srfi-69.scm: 628  floor */
t10=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}

/* k4651 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 629  floor */
t5=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4643 in k4651 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4626(t5,(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4626(t4,C_SCHEME_FALSE);}}

/* k4624 in k4643 in k4651 */
static void C_fcall f_4626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 632  %hash-table-resize! */
t2=*((C_word*)lf[78]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 727  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4487,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li130),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4487(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li131),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4546(t7,((C_word*)t0)[2],t2);}}

/* loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_fcall f_4546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4546,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4556,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 746  func */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 751  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4577 in loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 752  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 755  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4546(t3,((C_word*)t0)[5],t2);}}

/* k4580 in k4577 in loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4554 in loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_fcall f_4487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4487,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4497,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 733  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 739  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 742  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4521 in loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4495 in loop in k4471 in k4456 in %hash-table-update!/default in k1877 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-update! in k1877 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_4156r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4156r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4158,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li125),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4386,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word)li127),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4403,a[2]=t6,a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func11201209 */
t8=t7;
f_4403(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk11211196 */
t10=t6;
f_4386(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body11181127 */
t12=t5;
f_4158(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-func1120 in hash-table-update! in k1877 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4403,NULL,2,t0,t1);}
/* def-thunk11211196 */
t2=((C_word*)t0)[2];
f_4386(t2,t1,*((C_word*)lf[85]+1));}

/* def-thunk1121 in hash-table-update! in k1877 */
static void C_fcall f_4386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4386,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
/* body11181127 */
t5=((C_word*)t0)[2];
f_4158(t5,t1,t2,t4);}

/* f_4398 in def-thunk1121 in hash-table-update! in k1877 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
/* srfi-69.scm: 676  ##sys#signal-hook */
t2=*((C_word*)lf[7]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[83],lf[81],lf[84],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body1118 in hash-table-update! in k1877 */
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4158,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[32],lf[81]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4165,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 680  ##sys#check-closure */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[81]);}

/* k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 681  ##sys#check-closure */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[81]);}

/* k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4325,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[7],t3);}

/* f_4325 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4325,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(5));
t6=(C_word)C_slot(t2,C_fix(6));
t7=(C_word)C_block_size(t4);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4377,a[2]=t6,a[3]=t3,a[4]=t7,a[5]=t4,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_a_i_times(&a,2,t7,t5);
/* srfi-69.scm: 628  floor */
t10=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}

/* k4375 */
static void C_ccall f_4377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4377,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 629  floor */
t5=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4367 in k4375 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4350(t5,(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4350(t4,C_SCHEME_FALSE);}}

/* k4348 in k4367 in k4375 */
static void C_fcall f_4350(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 632  %hash-table-resize! */
t2=*((C_word*)lf[78]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 688  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4203,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li122),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4203(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li123),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4266(t7,((C_word*)t0)[2],t2);}}

/* loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_fcall f_4266(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4266,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4276,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4294,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 707  thunk */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 712  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4301 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 713  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 716  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4266(t3,((C_word*)t0)[5],t2);}}

/* k4304 in k4301 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4292 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 707  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4274 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_fcall f_4203(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4203,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4213,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4231,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 694  thunk */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 700  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 703  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k4241 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4229 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 694  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4211 in loop in k4187 in k4172 in k4166 in k4163 in body1118 in hash-table-update! in k1877 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-copy in k1877 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4147,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[80]);
/* srfi-69.scm: 661  %hash-table-copy */
t4=lf[79];
f_4035(t4,t1,t2);}

/* %hash-table-copy in k1877 */
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4035,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4045,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 641  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k4043 in %hash-table-copy in k1877 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li119),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_4050(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop1072 in k4043 in %hash-table-copy in k1877 */
static void C_fcall f_4050(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4050,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 644  %make-hash-table */
t11=*((C_word*)lf[31]+1);
((C_proc11)C_retrieve_proc(t11))(11,t11,t1,t3,t4,t5,t6,t7,t8,t9,t10,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4106,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4112,a[2]=t6,a[3]=((C_word)li118),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4112(t8,t3,t4);}}

/* copy-loop in doloop1072 in k4043 in %hash-table-copy in k1877 */
static void C_fcall f_4112(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4112,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4133,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 657  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k4131 in copy-loop in doloop1072 in k4043 in %hash-table-copy in k1877 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4104 in doloop1072 in k4043 in %hash-table-copy in k1877 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4050(t4,((C_word*)t0)[2],t3);}

/* %hash-table-resize! in k1877 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4009,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4016,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 599  hash-table-canonical-length */
f_3410(t7,lf[27],t6);}

/* k4014 in %hash-table-resize! in k1877 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 600  make-vector */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k4017 in k4014 in %hash-table-resize! in k1877 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4022,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3942,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,a[8]=((C_word)li116),tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_3942(t11,t2,C_fix(0));}

/* doloop1013 in k4017 in k4014 in %hash-table-resize! in k1877 */
static void C_fcall f_3942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3942,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3952,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word)li115),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3965(t8,t3,t4);}}

/* loop in doloop1013 in k4017 in k4014 in %hash-table-resize! in k1877 */
static void C_fcall f_3965(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3965,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3981,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 590  hash */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3979 in loop in doloop1013 in k4017 in k4014 in %hash-table-resize! in k1877 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 593  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3965(t8,((C_word*)t0)[2],t7);}

/* k3950 in doloop1013 in k4017 in k4014 in %hash-table-resize! in k1877 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3942(t3,((C_word*)t0)[2],t2);}

/* k4020 in k4017 in k4014 in %hash-table-resize! in k1877 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1877 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3915,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[77]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 577  thunk */
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1877 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3903,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[76]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1877 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3894,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1877 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3885,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1877 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3876,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1877 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3867,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1877 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3858,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1877 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3849,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k1877 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3840,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[32],lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k1877 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3834,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[32]));}

/* make-hash-table in k1877 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+47)){
C_save_and_reclaim((void*)tr2r,(void*)f_3471r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3471r(t0,t1,t2);}}

static void C_ccall f_3471r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a=C_alloc(47);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[35]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[40];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[41];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t22=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3549,a[2]=t4,a[3]=t2,a[4]=t21,a[5]=t12,a[6]=t20,a[7]=t18,a[8]=t16,a[9]=t14,a[10]=t8,a[11]=t6,a[12]=t1,a[13]=t10,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t23=t22;
f_3549(t23,C_SCHEME_UNDEFINED);}
else{
t23=(C_word)C_i_car(((C_word*)t4)[1]);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3824,a[2]=t4,a[3]=t23,a[4]=t6,a[5]=t22,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 456  keyword? */
t25=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,t23);}}

/* k3822 in make-hash-table in k1877 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3549(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 457  ##sys#check-closure */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[39]);}}

/* k3825 in k3822 in make-hash-table in k1877 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3549(t5,t4);}

/* k3547 in make-hash-table in k1877 */
static void C_fcall f_3549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3549,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3552(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 462  keyword? */
t5=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k3802 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3552(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3807,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 463  ##sys#check-closure */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[39]);}}

/* k3805 in k3802 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3552(t5,t4);}

/* k3550 in k3547 in make-hash-table in k1877 */
static void C_fcall f_3552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3552,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3555(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 468  keyword? */
t5=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k3770 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3772,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3555(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[39]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3778(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 471  error */
t4=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[39],lf[67],((C_word*)t0)[4]);}}}

/* k3776 in k3770 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[50]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_3555(t6,t5);}

/* k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_fcall f_3555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3555,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t4,a[11]=((C_word*)t0)[3],a[12]=((C_word)li103),tmp=(C_word)a,a+=13,tmp));
t6=((C_word*)t4)[1];
f_3590(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_fcall f_3590(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3590,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[11],a[3]=t3,a[4]=((C_word)li101),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3611,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[10],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* srfi-69.scm: 481  keyword? */
t6=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}

/* k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3611,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_3617(2,t4,(C_word)C_i_car(t2));}
else{
/* srfi-69.scm: 485  invarg-err */
t4=((C_word*)t0)[2];
f_3601(t4,t3,lf[65]);}}
else{
/* srfi-69.scm: 517  invarg-err */
t2=((C_word*)t0)[2];
f_3601(t2,((C_word*)t0)[12],lf[66]);}}

/* k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[11],lf[46]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3633,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[39]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[11],lf[48]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3643,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 491  ##sys#check-closure */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[39]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],lf[49]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[39]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3656,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3656(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 496  error */
t8=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[39],lf[51],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[11],lf[52]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3674,a[2]=t1,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp));
t8=t2;
f_3620(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[11],lf[53]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3684,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 501  ##sys#check-inexact */
t9=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[39]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[11],lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 506  ##sys#check-inexact */
t10=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[39]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[11],lf[62]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t2;
f_3620(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[11],lf[63]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_mutate(((C_word *)((C_word*)t0)[3])+1,t11);
t13=t2;
f_3620(2,t13,t12);}
else{
/* srfi-69.scm: 515  invarg-err */
t11=((C_word*)t0)[2];
f_3601(t11,t2,lf[64]);}}}}}}}}}

/* k3707 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[59],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[60]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3712(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 508  error */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[39],lf[61],((C_word*)t0)[3]);}}

/* k3710 in k3707 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3620(2,t3,t2);}

/* k3682 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[54],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[55]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3687(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 503  error */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[39],lf[56],((C_word*)t0)[3]);}}

/* k3685 in k3682 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3620(2,t3,t2);}

/* f_3674 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3674,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3654 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[50]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3620(2,t4,t3);}

/* k3641 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3620(2,t3,t2);}

/* k3631 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3620(2,t3,t2);}

/* k3618 in k3615 in k3609 in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 516  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3590(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3601,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 480  error */
t3=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[39],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3556 in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]))){
/* srfi-69.scm: 520  error */
t3=*((C_word*)lf[44]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[39],lf[45],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=t2;
f_3561(2,t3,C_SCHEME_UNDEFINED);}}

/* k3559 in k3556 in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* srfi-69.scm: 522  hash-table-canonical-length */
f_3410(t2,lf[27],((C_word*)((C_word*)t0)[11])[1]);}

/* k3563 in k3559 in k3556 in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_3568(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_3473(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t3;
f_3568(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3581,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 529  warning */
t6=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[39],lf[43]);}}}

/* k3579 in k3563 in k3559 in k3556 in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[23]+1));
t3=((C_word*)t0)[2];
f_3568(t3,t2);}

/* k3566 in k3563 in k3559 in k3556 in k3553 in k3550 in k3547 in make-hash-table in k1877 */
static void C_fcall f_3568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 532  %make-hash-table */
t2=*((C_word*)lf[31]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* hash-for-test in make-hash-table in k1877 */
static C_word C_fcall f_3473(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_check;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[19]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[21]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[23]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[25]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[37]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[26]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[4]+1):C_SCHEME_FALSE));}}}}}}

/* %make-hash-table in k1877 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,...){
C_word tmp;
C_word t10;
va_list v;
C_word *a,c2=c;
C_save_rest(t9,c2,10);
if(c<10) C_bad_min_argc_2(c,10,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr10r,(void*)f_3440r,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
else{
a=C_alloc((c-10)*3);
t10=C_restore_rest(a,C_rest_count(0));
f_3440r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}}

static void C_ccall f_3440r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3444,a[2]=t9,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t10))){
/* srfi-69.scm: 404  make-vector */
t12=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t12))(4,t12,t11,t4,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
t13=t11;
f_3444(2,t13,(C_word)C_i_car(t10));}
else{
/* ##sys#error */
t13=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,lf[0],t10);}}}

/* k3442 in %make-hash-table in k1877 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[32],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1877 */
static void C_fcall f_3410(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3410,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t3,a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3416(t4,t2));}

/* loop in hash-table-canonical-length in k1877 */
static C_word C_fcall f_3416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k1877 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3345r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3345r(t0,t1,t2,t3);}}

static void C_ccall f_3345r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3349,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3349(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3349(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3347 in string-ci-hash in k1877 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[26]);
t3=(C_word)C_i_check_exact_2(t1,lf[26]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3387,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* f_3387 in k3347 in string-ci-hash in k1877 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3387,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string_ci(t2));}

/* k3360 in k3347 in string-ci-hash in k1877 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3363,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_3363 in k3360 in k3347 in string-ci-hash in k1877 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3363,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3376 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3376,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k3373 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* string-hash in k1877 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3281r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3281r(t0,t1,t2,t3);}}

static void C_ccall f_3281r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3285,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3285(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3285(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3283 in string-hash in k1877 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[25]);
t3=(C_word)C_i_check_exact_2(t1,lf[25]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* f_3323 in k3283 in string-hash in k1877 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3323,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* k3296 in k3283 in string-hash in k1877 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_3299 in k3296 in k3283 in string-hash in k1877 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3299,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3312,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3312 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3312,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k3309 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* equal?-hash in k1877 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3221r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3221r(t0,t1,t2,t3);}}

static void C_ccall f_3221r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3225,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3225(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3225(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3223 in equal?-hash in k1877 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[24]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 344  %equal?-hash */
f_2743(t3,((C_word*)t0)[2]);}

/* k3233 in k3223 in equal?-hash in k1877 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_3236 in k3233 in k3223 in equal?-hash in k1877 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3236,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3249 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3249,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k3246 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* %equal?-hash in k1877 */
static void C_fcall f_2743(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2743,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2746,a[2]=t8,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2811,a[2]=t8,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2868,a[2]=t4,a[3]=t6,a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm: 340  recursive-hash */
t12=((C_word*)t8)[1];
f_2868(t12,t1,t2,C_fix(0));}

/* recursive-hash in %equal?-hash in k1877 */
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2868,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2924,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2944,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3206,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}}}}}}}

/* f_3206 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3206,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3215 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3215,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_blockp(t2));}

/* k3212 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(262));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* f_3204 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3204,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_byteblockp(t2));}

/* k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}}}

/* f_3202 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3202,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_portp(t2));}

/* k3148 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3150,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3200,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* f_3200 in k3148 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3200,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_specialp(t2));}

/* k3177 in k3148 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3195,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_3195 in k3177 in k3148 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3195,3,t0,t1,t2);}
/* srfi-69.scm: 292  vector-hash */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2746(t3,t1,t2,C_fix(0),((C_word*)t0)[2],C_fix(0));}

/* f_3183 in k3177 in k3148 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3183,3,t0,t1,t2);}
t3=(C_word)C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm: 289  vector-hash */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2746(t4,t1,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* f_3154 in k3148 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3154,3,t0,t1,t2);}
t3=(C_word)C_peek_fixnum(t2,C_fix(0));
t4=(C_word)C_fixnum_shift_left(t3,C_fix(4));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3169,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 284  input-port? */
t6=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k3167 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[2],t2));}

/* f_3120 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3120,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 279  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2811(t5,t3,t4,((C_word*)t0)[2]);}

/* k3138 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3132,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 280  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2811(t5,t3,t4,((C_word*)t0)[2]);}

/* k3130 in k3138 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* f_3094 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3094,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 276  recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2811(t6,t4,t5,((C_word*)t0)[2]);}

/* k3104 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* f_3083 in k3077 in k3071 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3083,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* f_2944 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2944,3,t0,t1,t2);}
if(C_truep((C_word)C_i_flonump(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2962,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3057,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(7));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 158  ##sys#number-hash-hook */
t4=*((C_word*)lf[2]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k3063 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3066 in k3063 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3066,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix(t2));}

/* f_3057 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3057,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2960 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(6));}

/* f_3055 in k2960 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3055,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2972 in k2960 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(5));}

/* f_3053 in k2972 in k2960 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3053,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2984 in k2972 in k2960 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(4));}

/* f_3051 in k2984 in k2972 in k2960 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3051,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(3));}

/* f_3049 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3049,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3047,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}

/* f_3047 in k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3047,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k3020 in k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3045,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}

/* f_3045 in k3020 in k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3045,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k3032 in k3020 in k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3043,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_3043 in k3032 in k3020 in k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3043,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k3040 in k3032 in k3020 in k3008 in k2996 in k2984 in k2972 in k2960 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
t2=(C_word)C_fixnum_shift_left(t1,C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=(C_word)C_fixnum_shift_left(t3,C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[8],t4);
t6=(C_word)C_fixnum_shift_left(t5,C_fix(1));
t7=(C_word)C_fixnum_plus(((C_word*)t0)[7],t6);
t8=(C_word)C_fixnum_shift_left(t7,C_fix(1));
t9=(C_word)C_fixnum_plus(((C_word*)t0)[6],t8);
t10=(C_word)C_fixnum_shift_left(t9,C_fix(1));
t11=(C_word)C_fixnum_plus(((C_word*)t0)[5],t10);
t12=(C_word)C_fixnum_shift_left(t11,C_fix(1));
t13=(C_word)C_fixnum_plus(((C_word*)t0)[4],t12);
t14=(C_word)C_fixnum_shift_left(t13,C_fix(1));
t15=(C_word)C_fixnum_plus(((C_word*)t0)[3],t14);
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_fixnum_times(C_fix(331804471),t15));}

/* f_2924 in recursive-hash in %equal?-hash in k1877 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2924,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_2933 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2933,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* recursive-atomic-hash in %equal?-hash in k1877 */
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2811,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2818,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_2834 in recursive-atomic-hash in %equal?-hash in k1877 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2834,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2838,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_2845 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2845,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_2856 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2856,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2865,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_2865 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2865,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_blockp(t2));}

/* k2862 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2847 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:(C_word)C_i_symbolp(((C_word*)t0)[2])));}

/* k2836 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:(C_word)C_i_numberp(((C_word*)t0)[2])));}

/* k2816 in recursive-atomic-hash in %equal?-hash in k1877 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_2821(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2832,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* f_2832 in k2816 in recursive-atomic-hash in %equal?-hash in k1877 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2832,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_byteblockp(t2));}

/* k2819 in k2816 in recursive-atomic-hash in %equal?-hash in k1877 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 314  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2868(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in %equal?-hash in k1877 */
static void C_fcall f_2746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2746,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,a[6]=((C_word)li54),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_2763(t13,t1,t7,t5,t9);}

/* loop in vector-hash in %equal?-hash in k1877 */
static void C_fcall f_2763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2763,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2797,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 306  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2868(t10,t7,t8,t9);}}

/* k2795 in loop in vector-hash in %equal?-hash in k1877 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 304  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2763(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1877 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2684r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2684r(t0,t1,t2,t3);}}

static void C_ccall f_2684r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2688,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2688(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2688(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2686 in eqv?-hash in k1877 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[21]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2698,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_2698(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t4))){
t5=t3;
f_2698(2,t5,(C_word)C_fix((C_word)C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2698(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2698(2,t5,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2698(2,t5,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t4))){
t5=t3;
f_2698(2,t5,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
if(C_truep((C_word)C_i_numberp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2668,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}}}}}}}

/* f_2672 in k2686 in eqv?-hash in k1877 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2672,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_2681 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2681,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_blockp(t2));}

/* k2678 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2666 in k2686 in eqv?-hash in k1877 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2698(2,t2,C_fix(262));}
else{
/* srfi-69.scm: 262  %object-uid-hash */
f_2090(((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_2539 in k2686 in eqv?-hash in k1877 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2539,3,t0,t1,t2);}
if(C_truep((C_word)C_i_flonump(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2557,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(7));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2660,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 158  ##sys#number-hash-hook */
t4=*((C_word*)lf[2]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2658 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2661 in k2658 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2661,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix(t2));}

/* f_2652 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2652,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2555 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(6));}

/* f_2650 in k2555 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2650,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2567 in k2555 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2648,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(5));}

/* f_2648 in k2567 in k2555 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2648,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2579 in k2567 in k2555 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(4));}

/* f_2646 in k2579 in k2567 in k2555 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2646,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(3));}

/* f_2644 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2644,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}

/* f_2642 in k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2642,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2615 in k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}

/* f_2640 in k2615 in k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2640,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2627 in k2615 in k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_2638 in k2627 in k2615 in k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2638,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2635 in k2627 in k2615 in k2603 in k2591 in k2579 in k2567 in k2555 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
t2=(C_word)C_fixnum_shift_left(t1,C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=(C_word)C_fixnum_shift_left(t3,C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[8],t4);
t6=(C_word)C_fixnum_shift_left(t5,C_fix(1));
t7=(C_word)C_fixnum_plus(((C_word*)t0)[7],t6);
t8=(C_word)C_fixnum_shift_left(t7,C_fix(1));
t9=(C_word)C_fixnum_plus(((C_word*)t0)[6],t8);
t10=(C_word)C_fixnum_shift_left(t9,C_fix(1));
t11=(C_word)C_fixnum_plus(((C_word*)t0)[5],t10);
t12=(C_word)C_fixnum_shift_left(t11,C_fix(1));
t13=(C_word)C_fixnum_plus(((C_word*)t0)[4],t12);
t14=(C_word)C_fixnum_shift_left(t13,C_fix(1));
t15=(C_word)C_fixnum_plus(((C_word*)t0)[3],t14);
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_fixnum_times(C_fix(331804471),t15));}

/* f_2519 in k2686 in eqv?-hash in k1877 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2519,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2528,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_2528 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2528,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* k2696 in k2686 in eqv?-hash in k1877 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2699,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_2699 in k2696 in k2686 in eqv?-hash in k1877 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2699,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2711,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_2712 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2712,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k2709 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* eq?-hash in k1877 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2409r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2409r(t0,t1,t2,t3);}}

static void C_ccall f_2409r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2413(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2413(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2411 in eq?-hash in k1877 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[19]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_2423(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t4))){
t5=t3;
f_2423(2,t5,(C_word)C_fix((C_word)C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2423(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2423(2,t5,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2423(2,t5,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t4))){
t5=t3;
f_2423(2,t5,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2393,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}}}}}}

/* f_2397 in k2411 in eq?-hash in k1877 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2397,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_2406 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2406,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_blockp(t2));}

/* k2403 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k2391 in k2411 in eq?-hash in k1877 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2423(2,t2,C_fix(262));}
else{
/* srfi-69.scm: 236  %object-uid-hash */
f_2090(((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_2377 in k2411 in eq?-hash in k1877 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2377,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_2386 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2386,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* k2421 in k2411 in eq?-hash in k1877 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_2424 in k2421 in k2411 in eq?-hash in k1877 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2424,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2437,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_2437 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2437,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k2434 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* keyword-hash in k1877 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2254r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2254r(t0,t1,t2,t3);}}

static void C_ccall f_2254r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2258(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2258(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2256 in keyword-hash in k1877 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 213  ##sys#check-keyword */
t3=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[18]);}

/* k2259 in k2256 in keyword-hash in k1877 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[18]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2296,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_2296 in k2259 in k2256 in keyword-hash in k1877 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2296,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_2305 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2305,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* k2269 in k2259 in k2256 in keyword-hash in k1877 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_2272 in k2269 in k2259 in k2256 in keyword-hash in k1877 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2272,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2285,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_2285 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2285,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k2282 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* ##sys#check-keyword in k1877 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2228r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2228r(t0,t1,t2,t3);}}

static void C_ccall f_2228r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2235,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 200  keyword? */
t5=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2233 in ##sys#check-keyword in k1877 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 201  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[15],t3,lf[16],((C_word*)t0)[2]);}}

/* symbol-hash in k1877 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2155r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2155r(t0,t1,t2,t3);}}

static void C_ccall f_2155r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2159,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2159(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2159(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2157 in symbol-hash in k1877 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[13]);
t3=(C_word)C_i_check_exact_2(t1,lf[13]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2172,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* f_2197 in k2157 in symbol-hash in k1877 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2197,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_2206 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2206,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_hash_string(t2));}

/* k2170 in k2157 in symbol-hash in k1877 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_2173 in k2170 in k2157 in symbol-hash in k1877 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2173,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_2186 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2186,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k2183 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* object-uid-hash in k1877 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2096r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2096r(t0,t1,t2,t3);}}

static void C_ccall f_2096r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2100,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2100(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2100(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2098 in object-uid-hash in k1877 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[12]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 181  %object-uid-hash */
f_2090(t3,((C_word*)t0)[2]);}

/* k2108 in k2098 in object-uid-hash in k1877 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_2111 in k2108 in k2098 in object-uid-hash in k1877 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2111,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2123,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_2124 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2124,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k2121 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* %object-uid-hash in k1877 */
static void C_fcall f_2090(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2090,NULL,2,t1,t2);}
/* srfi-69.scm: 177  %equal?-hash */
f_2743(t1,t2);}

/* number-hash in k1877 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1887r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1887r(t0,t1,t2,t3);}}

static void C_ccall f_1887r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1891,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1891(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1891(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1889 in number-hash in k1877 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[2]))){
t3=t2;
f_1894(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 166  ##sys#signal-hook */
t3=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[8],lf[4],lf[9],((C_word*)t0)[2]);}}

/* k1892 in k1889 in number-hash in k1877 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_1929 in k1892 in k1889 in number-hash in k1877 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1929,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[6]+1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1940,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}

/* f_1940 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1940,3,t0,t1,t2);}
if(C_truep((C_word)C_i_flonump(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2053,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(7));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 158  ##sys#number-hash-hook */
t4=*((C_word*)lf[2]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k2059 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2062 in k2059 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2062,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fix(t2));}

/* f_2053 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2053,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k1956 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2051,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(6));}

/* f_2051 in k1956 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2051,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k1968 in k1956 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(5));}

/* f_2049 in k1968 in k1956 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2049,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k1980 in k1968 in k1956 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2047,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(4));}

/* f_2047 in k1980 in k1968 in k1956 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2047,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2045,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(3));}

/* f_2045 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2045,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}

/* f_2043 in k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2043,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2016 in k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2041,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}

/* f_2041 in k2016 in k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2041,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2028 in k2016 in k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_2039 in k2028 in k2016 in k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2039,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_subbyte(t2,t3));}

/* k2036 in k2028 in k2016 in k2004 in k1992 in k1980 in k1968 in k1956 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
t2=(C_word)C_fixnum_shift_left(t1,C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=(C_word)C_fixnum_shift_left(t3,C_fix(1));
t5=(C_word)C_fixnum_plus(((C_word*)t0)[8],t4);
t6=(C_word)C_fixnum_shift_left(t5,C_fix(1));
t7=(C_word)C_fixnum_plus(((C_word*)t0)[7],t6);
t8=(C_word)C_fixnum_shift_left(t7,C_fix(1));
t9=(C_word)C_fixnum_plus(((C_word*)t0)[6],t8);
t10=(C_word)C_fixnum_shift_left(t9,C_fix(1));
t11=(C_word)C_fixnum_plus(((C_word*)t0)[5],t10);
t12=(C_word)C_fixnum_shift_left(t11,C_fix(1));
t13=(C_word)C_fixnum_plus(((C_word*)t0)[4],t12);
t14=(C_word)C_fixnum_shift_left(t13,C_fix(1));
t15=(C_word)C_fixnum_plus(((C_word*)t0)[3],t14);
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_fixnum_times(C_fix(331804471),t15));}

/* k1902 in k1892 in k1889 in number-hash in k1877 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_1905 in k1902 in k1892 in k1889 in number-hash in k1877 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1905,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1917,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_1918 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1918,3,t0,t1,t2);}
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2));}

/* k1915 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t1);
/* srfi-69.scm: 127  fxmod */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* ##sys#number-hash-hook in k1877 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1881,3,t0,t1,t2);}
/* srfi-69.scm: 154  %equal?-hash */
f_2743(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[355] = {
{"toplevelsrfi-69.scm",(void*)C_srfi_69_toplevel},
{"f_1879srfi-69.scm",(void*)f_1879},
{"f_5829srfi-69.scm",(void*)f_5829},
{"f_5949srfi-69.scm",(void*)f_5949},
{"f_5833srfi-69.scm",(void*)f_5833},
{"f_5839srfi-69.scm",(void*)f_5839},
{"f_5851srfi-69.scm",(void*)f_5851},
{"f_5908srfi-69.scm",(void*)f_5908},
{"f_5927srfi-69.scm",(void*)f_5927},
{"f_5866srfi-69.scm",(void*)f_5866},
{"f_4875srfi-69.scm",(void*)f_4875},
{"f_5807srfi-69.scm",(void*)f_5807},
{"f_5814srfi-69.scm",(void*)f_5814},
{"f_5819srfi-69.scm",(void*)f_5819},
{"f_5827srfi-69.scm",(void*)f_5827},
{"f_5795srfi-69.scm",(void*)f_5795},
{"f_5802srfi-69.scm",(void*)f_5802},
{"f_5783srfi-69.scm",(void*)f_5783},
{"f_5790srfi-69.scm",(void*)f_5790},
{"f_5771srfi-69.scm",(void*)f_5771},
{"f_5778srfi-69.scm",(void*)f_5778},
{"f_5705srfi-69.scm",(void*)f_5705},
{"f_5717srfi-69.scm",(void*)f_5717},
{"f_5733srfi-69.scm",(void*)f_5733},
{"f_5761srfi-69.scm",(void*)f_5761},
{"f_5656srfi-69.scm",(void*)f_5656},
{"f_5668srfi-69.scm",(void*)f_5668},
{"f_5687srfi-69.scm",(void*)f_5687},
{"f_5678srfi-69.scm",(void*)f_5678},
{"f_5591srfi-69.scm",(void*)f_5591},
{"f_5606srfi-69.scm",(void*)f_5606},
{"f_5622srfi-69.scm",(void*)f_5622},
{"f_5526srfi-69.scm",(void*)f_5526},
{"f_5541srfi-69.scm",(void*)f_5541},
{"f_5557srfi-69.scm",(void*)f_5557},
{"f_5500srfi-69.scm",(void*)f_5500},
{"f_5507srfi-69.scm",(void*)f_5507},
{"f_5512srfi-69.scm",(void*)f_5512},
{"f_5510srfi-69.scm",(void*)f_5510},
{"f_5427srfi-69.scm",(void*)f_5427},
{"f_5442srfi-69.scm",(void*)f_5442},
{"f_5458srfi-69.scm",(void*)f_5458},
{"f_5411srfi-69.scm",(void*)f_5411},
{"f_5425srfi-69.scm",(void*)f_5425},
{"f_5399srfi-69.scm",(void*)f_5399},
{"f_5334srfi-69.scm",(void*)f_5334},
{"f_5346srfi-69.scm",(void*)f_5346},
{"f_5369srfi-69.scm",(void*)f_5369},
{"f_5382srfi-69.scm",(void*)f_5382},
{"f_5356srfi-69.scm",(void*)f_5356},
{"f_5318srfi-69.scm",(void*)f_5318},
{"f_5325srfi-69.scm",(void*)f_5325},
{"f_5222srfi-69.scm",(void*)f_5222},
{"f_5229srfi-69.scm",(void*)f_5229},
{"f_5243srfi-69.scm",(void*)f_5243},
{"f_5269srfi-69.scm",(void*)f_5269},
{"f_5288srfi-69.scm",(void*)f_5288},
{"f_5256srfi-69.scm",(void*)f_5256},
{"f_5091srfi-69.scm",(void*)f_5091},
{"f_5107srfi-69.scm",(void*)f_5107},
{"f_5174srfi-69.scm",(void*)f_5174},
{"f_5193srfi-69.scm",(void*)f_5193},
{"f_5127srfi-69.scm",(void*)f_5127},
{"f_4983srfi-69.scm",(void*)f_4983},
{"f_4999srfi-69.scm",(void*)f_4999},
{"f_5054srfi-69.scm",(void*)f_5054},
{"f_5067srfi-69.scm",(void*)f_5067},
{"f_5014srfi-69.scm",(void*)f_5014},
{"f_4877srfi-69.scm",(void*)f_4877},
{"f_4893srfi-69.scm",(void*)f_4893},
{"f_4947srfi-69.scm",(void*)f_4947},
{"f_4963srfi-69.scm",(void*)f_4963},
{"f_4908srfi-69.scm",(void*)f_4908},
{"f_4675srfi-69.scm",(void*)f_4675},
{"f_4811srfi-69.scm",(void*)f_4811},
{"f_4863srfi-69.scm",(void*)f_4863},
{"f_4855srfi-69.scm",(void*)f_4855},
{"f_4836srfi-69.scm",(void*)f_4836},
{"f_4685srfi-69.scm",(void*)f_4685},
{"f_4700srfi-69.scm",(void*)f_4700},
{"f_4766srfi-69.scm",(void*)f_4766},
{"f_4796srfi-69.scm",(void*)f_4796},
{"f_4717srfi-69.scm",(void*)f_4717},
{"f_4706srfi-69.scm",(void*)f_4706},
{"f_4663srfi-69.scm",(void*)f_4663},
{"f_4670srfi-69.scm",(void*)f_4670},
{"f_4451srfi-69.scm",(void*)f_4451},
{"f_4601srfi-69.scm",(void*)f_4601},
{"f_4653srfi-69.scm",(void*)f_4653},
{"f_4645srfi-69.scm",(void*)f_4645},
{"f_4626srfi-69.scm",(void*)f_4626},
{"f_4458srfi-69.scm",(void*)f_4458},
{"f_4473srfi-69.scm",(void*)f_4473},
{"f_4546srfi-69.scm",(void*)f_4546},
{"f_4579srfi-69.scm",(void*)f_4579},
{"f_4582srfi-69.scm",(void*)f_4582},
{"f_4556srfi-69.scm",(void*)f_4556},
{"f_4487srfi-69.scm",(void*)f_4487},
{"f_4523srfi-69.scm",(void*)f_4523},
{"f_4497srfi-69.scm",(void*)f_4497},
{"f_4156srfi-69.scm",(void*)f_4156},
{"f_4403srfi-69.scm",(void*)f_4403},
{"f_4386srfi-69.scm",(void*)f_4386},
{"f_4398srfi-69.scm",(void*)f_4398},
{"f_4158srfi-69.scm",(void*)f_4158},
{"f_4165srfi-69.scm",(void*)f_4165},
{"f_4168srfi-69.scm",(void*)f_4168},
{"f_4325srfi-69.scm",(void*)f_4325},
{"f_4377srfi-69.scm",(void*)f_4377},
{"f_4369srfi-69.scm",(void*)f_4369},
{"f_4350srfi-69.scm",(void*)f_4350},
{"f_4174srfi-69.scm",(void*)f_4174},
{"f_4189srfi-69.scm",(void*)f_4189},
{"f_4266srfi-69.scm",(void*)f_4266},
{"f_4303srfi-69.scm",(void*)f_4303},
{"f_4306srfi-69.scm",(void*)f_4306},
{"f_4294srfi-69.scm",(void*)f_4294},
{"f_4276srfi-69.scm",(void*)f_4276},
{"f_4203srfi-69.scm",(void*)f_4203},
{"f_4243srfi-69.scm",(void*)f_4243},
{"f_4231srfi-69.scm",(void*)f_4231},
{"f_4213srfi-69.scm",(void*)f_4213},
{"f_4147srfi-69.scm",(void*)f_4147},
{"f_4035srfi-69.scm",(void*)f_4035},
{"f_4045srfi-69.scm",(void*)f_4045},
{"f_4050srfi-69.scm",(void*)f_4050},
{"f_4112srfi-69.scm",(void*)f_4112},
{"f_4133srfi-69.scm",(void*)f_4133},
{"f_4106srfi-69.scm",(void*)f_4106},
{"f_4009srfi-69.scm",(void*)f_4009},
{"f_4016srfi-69.scm",(void*)f_4016},
{"f_4019srfi-69.scm",(void*)f_4019},
{"f_3942srfi-69.scm",(void*)f_3942},
{"f_3965srfi-69.scm",(void*)f_3965},
{"f_3981srfi-69.scm",(void*)f_3981},
{"f_3952srfi-69.scm",(void*)f_3952},
{"f_4022srfi-69.scm",(void*)f_4022},
{"f_3915srfi-69.scm",(void*)f_3915},
{"f_3903srfi-69.scm",(void*)f_3903},
{"f_3894srfi-69.scm",(void*)f_3894},
{"f_3885srfi-69.scm",(void*)f_3885},
{"f_3876srfi-69.scm",(void*)f_3876},
{"f_3867srfi-69.scm",(void*)f_3867},
{"f_3858srfi-69.scm",(void*)f_3858},
{"f_3849srfi-69.scm",(void*)f_3849},
{"f_3840srfi-69.scm",(void*)f_3840},
{"f_3834srfi-69.scm",(void*)f_3834},
{"f_3471srfi-69.scm",(void*)f_3471},
{"f_3824srfi-69.scm",(void*)f_3824},
{"f_3827srfi-69.scm",(void*)f_3827},
{"f_3549srfi-69.scm",(void*)f_3549},
{"f_3804srfi-69.scm",(void*)f_3804},
{"f_3807srfi-69.scm",(void*)f_3807},
{"f_3552srfi-69.scm",(void*)f_3552},
{"f_3772srfi-69.scm",(void*)f_3772},
{"f_3778srfi-69.scm",(void*)f_3778},
{"f_3555srfi-69.scm",(void*)f_3555},
{"f_3590srfi-69.scm",(void*)f_3590},
{"f_3611srfi-69.scm",(void*)f_3611},
{"f_3617srfi-69.scm",(void*)f_3617},
{"f_3709srfi-69.scm",(void*)f_3709},
{"f_3712srfi-69.scm",(void*)f_3712},
{"f_3684srfi-69.scm",(void*)f_3684},
{"f_3687srfi-69.scm",(void*)f_3687},
{"f_3674srfi-69.scm",(void*)f_3674},
{"f_3656srfi-69.scm",(void*)f_3656},
{"f_3643srfi-69.scm",(void*)f_3643},
{"f_3633srfi-69.scm",(void*)f_3633},
{"f_3620srfi-69.scm",(void*)f_3620},
{"f_3601srfi-69.scm",(void*)f_3601},
{"f_3558srfi-69.scm",(void*)f_3558},
{"f_3561srfi-69.scm",(void*)f_3561},
{"f_3565srfi-69.scm",(void*)f_3565},
{"f_3581srfi-69.scm",(void*)f_3581},
{"f_3568srfi-69.scm",(void*)f_3568},
{"f_3473srfi-69.scm",(void*)f_3473},
{"f_3440srfi-69.scm",(void*)f_3440},
{"f_3444srfi-69.scm",(void*)f_3444},
{"f_3410srfi-69.scm",(void*)f_3410},
{"f_3416srfi-69.scm",(void*)f_3416},
{"f_3345srfi-69.scm",(void*)f_3345},
{"f_3349srfi-69.scm",(void*)f_3349},
{"f_3387srfi-69.scm",(void*)f_3387},
{"f_3362srfi-69.scm",(void*)f_3362},
{"f_3363srfi-69.scm",(void*)f_3363},
{"f_3376srfi-69.scm",(void*)f_3376},
{"f_3375srfi-69.scm",(void*)f_3375},
{"f_3281srfi-69.scm",(void*)f_3281},
{"f_3285srfi-69.scm",(void*)f_3285},
{"f_3323srfi-69.scm",(void*)f_3323},
{"f_3298srfi-69.scm",(void*)f_3298},
{"f_3299srfi-69.scm",(void*)f_3299},
{"f_3312srfi-69.scm",(void*)f_3312},
{"f_3311srfi-69.scm",(void*)f_3311},
{"f_3221srfi-69.scm",(void*)f_3221},
{"f_3225srfi-69.scm",(void*)f_3225},
{"f_3235srfi-69.scm",(void*)f_3235},
{"f_3236srfi-69.scm",(void*)f_3236},
{"f_3249srfi-69.scm",(void*)f_3249},
{"f_3248srfi-69.scm",(void*)f_3248},
{"f_2743srfi-69.scm",(void*)f_2743},
{"f_2868srfi-69.scm",(void*)f_2868},
{"f_3206srfi-69.scm",(void*)f_3206},
{"f_3215srfi-69.scm",(void*)f_3215},
{"f_3214srfi-69.scm",(void*)f_3214},
{"f_3073srfi-69.scm",(void*)f_3073},
{"f_3204srfi-69.scm",(void*)f_3204},
{"f_3079srfi-69.scm",(void*)f_3079},
{"f_3202srfi-69.scm",(void*)f_3202},
{"f_3150srfi-69.scm",(void*)f_3150},
{"f_3200srfi-69.scm",(void*)f_3200},
{"f_3179srfi-69.scm",(void*)f_3179},
{"f_3195srfi-69.scm",(void*)f_3195},
{"f_3183srfi-69.scm",(void*)f_3183},
{"f_3154srfi-69.scm",(void*)f_3154},
{"f_3169srfi-69.scm",(void*)f_3169},
{"f_3120srfi-69.scm",(void*)f_3120},
{"f_3140srfi-69.scm",(void*)f_3140},
{"f_3132srfi-69.scm",(void*)f_3132},
{"f_3094srfi-69.scm",(void*)f_3094},
{"f_3106srfi-69.scm",(void*)f_3106},
{"f_3083srfi-69.scm",(void*)f_3083},
{"f_2944srfi-69.scm",(void*)f_2944},
{"f_3065srfi-69.scm",(void*)f_3065},
{"f_3066srfi-69.scm",(void*)f_3066},
{"f_3057srfi-69.scm",(void*)f_3057},
{"f_2962srfi-69.scm",(void*)f_2962},
{"f_3055srfi-69.scm",(void*)f_3055},
{"f_2974srfi-69.scm",(void*)f_2974},
{"f_3053srfi-69.scm",(void*)f_3053},
{"f_2986srfi-69.scm",(void*)f_2986},
{"f_3051srfi-69.scm",(void*)f_3051},
{"f_2998srfi-69.scm",(void*)f_2998},
{"f_3049srfi-69.scm",(void*)f_3049},
{"f_3010srfi-69.scm",(void*)f_3010},
{"f_3047srfi-69.scm",(void*)f_3047},
{"f_3022srfi-69.scm",(void*)f_3022},
{"f_3045srfi-69.scm",(void*)f_3045},
{"f_3034srfi-69.scm",(void*)f_3034},
{"f_3043srfi-69.scm",(void*)f_3043},
{"f_3042srfi-69.scm",(void*)f_3042},
{"f_2924srfi-69.scm",(void*)f_2924},
{"f_2933srfi-69.scm",(void*)f_2933},
{"f_2811srfi-69.scm",(void*)f_2811},
{"f_2834srfi-69.scm",(void*)f_2834},
{"f_2845srfi-69.scm",(void*)f_2845},
{"f_2856srfi-69.scm",(void*)f_2856},
{"f_2865srfi-69.scm",(void*)f_2865},
{"f_2864srfi-69.scm",(void*)f_2864},
{"f_2849srfi-69.scm",(void*)f_2849},
{"f_2838srfi-69.scm",(void*)f_2838},
{"f_2818srfi-69.scm",(void*)f_2818},
{"f_2832srfi-69.scm",(void*)f_2832},
{"f_2821srfi-69.scm",(void*)f_2821},
{"f_2746srfi-69.scm",(void*)f_2746},
{"f_2763srfi-69.scm",(void*)f_2763},
{"f_2797srfi-69.scm",(void*)f_2797},
{"f_2684srfi-69.scm",(void*)f_2684},
{"f_2688srfi-69.scm",(void*)f_2688},
{"f_2672srfi-69.scm",(void*)f_2672},
{"f_2681srfi-69.scm",(void*)f_2681},
{"f_2680srfi-69.scm",(void*)f_2680},
{"f_2668srfi-69.scm",(void*)f_2668},
{"f_2539srfi-69.scm",(void*)f_2539},
{"f_2660srfi-69.scm",(void*)f_2660},
{"f_2661srfi-69.scm",(void*)f_2661},
{"f_2652srfi-69.scm",(void*)f_2652},
{"f_2557srfi-69.scm",(void*)f_2557},
{"f_2650srfi-69.scm",(void*)f_2650},
{"f_2569srfi-69.scm",(void*)f_2569},
{"f_2648srfi-69.scm",(void*)f_2648},
{"f_2581srfi-69.scm",(void*)f_2581},
{"f_2646srfi-69.scm",(void*)f_2646},
{"f_2593srfi-69.scm",(void*)f_2593},
{"f_2644srfi-69.scm",(void*)f_2644},
{"f_2605srfi-69.scm",(void*)f_2605},
{"f_2642srfi-69.scm",(void*)f_2642},
{"f_2617srfi-69.scm",(void*)f_2617},
{"f_2640srfi-69.scm",(void*)f_2640},
{"f_2629srfi-69.scm",(void*)f_2629},
{"f_2638srfi-69.scm",(void*)f_2638},
{"f_2637srfi-69.scm",(void*)f_2637},
{"f_2519srfi-69.scm",(void*)f_2519},
{"f_2528srfi-69.scm",(void*)f_2528},
{"f_2698srfi-69.scm",(void*)f_2698},
{"f_2699srfi-69.scm",(void*)f_2699},
{"f_2712srfi-69.scm",(void*)f_2712},
{"f_2711srfi-69.scm",(void*)f_2711},
{"f_2409srfi-69.scm",(void*)f_2409},
{"f_2413srfi-69.scm",(void*)f_2413},
{"f_2397srfi-69.scm",(void*)f_2397},
{"f_2406srfi-69.scm",(void*)f_2406},
{"f_2405srfi-69.scm",(void*)f_2405},
{"f_2393srfi-69.scm",(void*)f_2393},
{"f_2377srfi-69.scm",(void*)f_2377},
{"f_2386srfi-69.scm",(void*)f_2386},
{"f_2423srfi-69.scm",(void*)f_2423},
{"f_2424srfi-69.scm",(void*)f_2424},
{"f_2437srfi-69.scm",(void*)f_2437},
{"f_2436srfi-69.scm",(void*)f_2436},
{"f_2254srfi-69.scm",(void*)f_2254},
{"f_2258srfi-69.scm",(void*)f_2258},
{"f_2261srfi-69.scm",(void*)f_2261},
{"f_2296srfi-69.scm",(void*)f_2296},
{"f_2305srfi-69.scm",(void*)f_2305},
{"f_2271srfi-69.scm",(void*)f_2271},
{"f_2272srfi-69.scm",(void*)f_2272},
{"f_2285srfi-69.scm",(void*)f_2285},
{"f_2284srfi-69.scm",(void*)f_2284},
{"f_2228srfi-69.scm",(void*)f_2228},
{"f_2235srfi-69.scm",(void*)f_2235},
{"f_2155srfi-69.scm",(void*)f_2155},
{"f_2159srfi-69.scm",(void*)f_2159},
{"f_2197srfi-69.scm",(void*)f_2197},
{"f_2206srfi-69.scm",(void*)f_2206},
{"f_2172srfi-69.scm",(void*)f_2172},
{"f_2173srfi-69.scm",(void*)f_2173},
{"f_2186srfi-69.scm",(void*)f_2186},
{"f_2185srfi-69.scm",(void*)f_2185},
{"f_2096srfi-69.scm",(void*)f_2096},
{"f_2100srfi-69.scm",(void*)f_2100},
{"f_2110srfi-69.scm",(void*)f_2110},
{"f_2111srfi-69.scm",(void*)f_2111},
{"f_2124srfi-69.scm",(void*)f_2124},
{"f_2123srfi-69.scm",(void*)f_2123},
{"f_2090srfi-69.scm",(void*)f_2090},
{"f_1887srfi-69.scm",(void*)f_1887},
{"f_1891srfi-69.scm",(void*)f_1891},
{"f_1894srfi-69.scm",(void*)f_1894},
{"f_1929srfi-69.scm",(void*)f_1929},
{"f_1940srfi-69.scm",(void*)f_1940},
{"f_2061srfi-69.scm",(void*)f_2061},
{"f_2062srfi-69.scm",(void*)f_2062},
{"f_2053srfi-69.scm",(void*)f_2053},
{"f_1958srfi-69.scm",(void*)f_1958},
{"f_2051srfi-69.scm",(void*)f_2051},
{"f_1970srfi-69.scm",(void*)f_1970},
{"f_2049srfi-69.scm",(void*)f_2049},
{"f_1982srfi-69.scm",(void*)f_1982},
{"f_2047srfi-69.scm",(void*)f_2047},
{"f_1994srfi-69.scm",(void*)f_1994},
{"f_2045srfi-69.scm",(void*)f_2045},
{"f_2006srfi-69.scm",(void*)f_2006},
{"f_2043srfi-69.scm",(void*)f_2043},
{"f_2018srfi-69.scm",(void*)f_2018},
{"f_2041srfi-69.scm",(void*)f_2041},
{"f_2030srfi-69.scm",(void*)f_2030},
{"f_2039srfi-69.scm",(void*)f_2039},
{"f_2038srfi-69.scm",(void*)f_2038},
{"f_1904srfi-69.scm",(void*)f_1904},
{"f_1905srfi-69.scm",(void*)f_1905},
{"f_1918srfi-69.scm",(void*)f_1918},
{"f_1917srfi-69.scm",(void*)f_1917},
{"f_1881srfi-69.scm",(void*)f_1881},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
