/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-30 23:12
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: srfi-4.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file srfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[176];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,48,32,102,114,111,109,49,32,116,111,50,32,108,111,99,51,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,49),40,35,35,115,121,115,35,99,104,101,99,107,45,105,110,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,55,32,102,114,111,109,56,32,116,111,57,32,108,111,99,49,48,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,114,101,102,32,118,49,52,32,105,49,53,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,114,101,102,32,118,49,54,32,105,49,55,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,114,101,102,32,118,49,56,32,105,49,57,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,114,101,102,32,118,50,48,32,105,50,49,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,114,101,102,32,118,50,50,32,105,50,51,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,114,101,102,32,118,50,52,32,105,50,53,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,114,101,102,32,118,50,54,32,105,50,55,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,114,101,102,32,118,50,57,32,105,51,48,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,117,56,118,101,99,116,111,114,45,115,101,116,33,32,118,51,50,32,105,51,51,32,120,51,52,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,115,56,118,101,99,116,111,114,45,115,101,116,33,32,118,51,53,32,105,51,54,32,120,51,55,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,51,56,32,105,51,57,32,120,52,48,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,118,52,49,32,105,52,50,32,120,52,51,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,105,52,53,32,120,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,105,52,56,32,120,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,118,53,48,32,105,53,49,32,120,53,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,118,53,51,32,105,53,52,32,120,53,53,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,11),40,102,95,57,50,52,32,118,54,48,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,108,101,110,32,116,97,103,53,55,32,115,104,105,102,116,53,56,32,108,111,99,53,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,15),40,102,95,57,54,55,32,118,56,48,32,105,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,26),40,103,101,116,32,108,101,110,103,116,104,55,55,32,97,99,99,55,56,32,108,111,99,55,57,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,19),40,102,95,57,56,49,32,118,56,55,32,105,56,56,32,120,56,57,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,26),40,115,101,116,32,108,101,110,103,116,104,56,52,32,117,112,100,56,53,32,108,111,99,56,54,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,19),40,102,95,57,57,56,32,118,57,54,32,105,57,55,32,120,57,56,41,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,32,108,101,110,103,116,104,57,51,32,117,112,100,57,52,32,108,111,99,57,53,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,23),40,102,95,49,48,56,55,32,118,49,50,52,32,105,49,50,53,32,120,49,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,115,101,116,102,32,108,101,110,103,116,104,49,50,49,32,117,112,100,49,50,50,32,108,111,99,49,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,102,95,49,48,53,49,32,118,49,49,53,32,105,49,49,54,32,120,49,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,102,95,49,48,50,52,32,118,49,48,54,32,105,49,48,55,32,120,49,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,101,120,116,45,102,114,101,101,32,97,49,53,55,49,54,48,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,49,54,51,32,108,101,110,49,54,52,32,101,120,116,63,49,54,53,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,49,55,49,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,100,111,49,56,57,32,105,49,57,49,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,49,55,56,32,105,110,105,116,49,56,53,32,101,120,116,63,49,56,54,32,102,105,110,63,49,56,55,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,102,105,110,63,49,56,50,32,37,105,110,105,116,49,55,53,49,57,56,32,37,101,120,116,63,49,55,54,49,57,57,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,49,56,49,32,37,105,110,105,116,49,55,53,50,48,49,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,49,56,48,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,49,55,51,32,46,32,103,49,55,50,49,55,52,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,100,111,50,50,55,32,105,50,50,57,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,49,54,32,105,110,105,116,50,50,51,32,101,120,116,63,50,50,52,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,50,48,32,37,105,110,105,116,50,49,51,50,51,54,32,37,101,120,116,63,50,49,52,50,51,55,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,49,57,32,37,105,110,105,116,50,49,51,50,51,57,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,49,56,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,50,49,49,32,46,32,103,50,49,48,50,49,50,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,100,111,50,54,52,32,105,50,54,54,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,53,51,32,105,110,105,116,50,54,48,32,101,120,116,63,50,54,49,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,53,55,32,37,105,110,105,116,50,53,48,50,55,51,32,37,101,120,116,63,50,53,49,50,55,52,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,53,54,32,37,105,110,105,116,50,53,48,50,55,54,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,53,53,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,50,52,56,32,46,32,103,50,52,55,50,52,57,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,100,111,51,48,49,32,105,51,48,51,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,50,57,48,32,105,110,105,116,50,57,55,32,101,120,116,63,50,57,56,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,50,57,52,32,37,105,110,105,116,50,56,55,51,49,48,32,37,101,120,116,63,50,56,56,51,49,49,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,50,57,51,32,37,105,110,105,116,50,56,55,51,49,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,50,57,50,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,50,56,53,32,46,32,103,50,56,52,50,56,54,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,100,111,51,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,50,55,32,105,110,105,116,51,51,52,32,101,120,116,63,51,51,53,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,51,49,32,37,105,110,105,116,51,50,52,51,52,55,32,37,101,120,116,63,51,50,53,51,52,56,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,51,48,32,37,105,110,105,116,51,50,52,51,53,48,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,50,57,41,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,51,50,50,32,46,32,103,51,50,49,51,50,51,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,100,111,51,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,51,54,52,32,105,110,105,116,51,55,49,32,101,120,116,63,51,55,50,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,51,54,56,32,37,105,110,105,116,51,54,49,51,56,52,32,37,101,120,116,63,51,54,50,51,56,53,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,54,55,32,37,105,110,105,116,51,54,49,51,56,55,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,54,54,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,51,53,57,32,46,32,103,51,53,56,51,54,48,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,100,111,52,49,50,32,105,52,49,52,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,48,49,32,105,110,105,116,52,48,56,32,101,120,116,63,52,48,57,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,48,53,32,37,105,110,105,116,51,57,56,52,50,50,32,37,101,120,116,63,51,57,57,52,50,51,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,48,52,32,37,105,110,105,116,51,57,56,52,50,53,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,48,51,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,51,57,54,32,46,32,103,51,57,53,51,57,55,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,100,111,52,53,48,32,105,52,53,50,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,51,57,32,105,110,105,116,52,52,54,32,101,120,116,63,52,52,55,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,52,51,32,37,105,110,105,116,52,51,54,52,54,48,32,37,101,120,116,63,52,51,55,52,54,49,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,52,50,32,37,105,110,105,116,52,51,54,52,54,51,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,52,49,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,52,51,52,32,46,32,103,52,51,51,52,51,53,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,17),40,100,111,52,56,54,32,112,52,56,56,32,105,52,56,57,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,15),40,102,95,50,49,57,57,32,108,115,116,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,28),40,105,110,105,116,32,109,97,107,101,52,56,48,32,115,101,116,52,56,49,32,108,111,99,52,56,50,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,53,48,50,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,53,48,52,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,53,48,54,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,53,48,56,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,53,49,48,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,53,49,50,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,53,49,52,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,53,49,54,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,53,50,52,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,13),40,102,95,50,51,49,55,32,118,53,50,49,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,23),40,105,110,105,116,32,108,101,110,103,116,104,53,49,57,32,114,101,102,53,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,117,56,118,101,99,116,111,114,63,32,120,53,51,52,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,16),40,115,56,118,101,99,116,111,114,63,32,120,53,51,53,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,17),40,117,49,54,118,101,99,116,111,114,63,32,120,53,51,54,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,17),40,115,49,54,118,101,99,116,111,114,63,32,120,53,51,55,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,17),40,117,51,50,118,101,99,116,111,114,63,32,120,53,51,56,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,17),40,115,51,50,118,101,99,116,111,114,63,32,120,53,51,57,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,17),40,102,51,50,118,101,99,116,111,114,63,32,120,53,52,48,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,102,54,52,118,101,99,116,111,114,63,32,120,53,52,49,41,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,13),40,102,95,50,52,51,50,32,118,53,52,56,41,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,20),40,112,97,99,107,32,116,97,103,53,52,54,32,108,111,99,53,52,55,41,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,13),40,102,95,50,52,52,51,32,118,53,53,50,41,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,25),40,112,97,99,107,45,99,111,112,121,32,116,97,103,53,53,48,32,108,111,99,53,53,49,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,15),40,102,95,50,52,54,49,32,115,116,114,53,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,28),40,117,110,112,97,99,107,32,116,97,103,53,53,54,32,115,122,53,53,55,32,108,111,99,53,53,56,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,15),40,102,95,50,52,57,48,32,115,116,114,53,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,33),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,53,54,52,32,115,122,53,54,53,32,108,111,99,53,54,54,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,54,49,49,32,112,111,114,116,54,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,54,50,49,32,114,101,97,100,97,98,108,101,54,50,50,32,112,111,114,116,54,50,51,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,48),40,115,117,98,118,101,99,116,111,114,32,118,54,50,55,32,116,54,50,56,32,101,115,54,50,57,32,102,114,111,109,54,51,48,32,116,111,54,51,49,32,108,111,99,54,51,50,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,32),40,115,117,98,117,56,118,101,99,116,111,114,32,118,54,52,52,32,102,114,111,109,54,52,53,32,116,111,54,52,54,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,54,52,55,32,102,114,111,109,54,52,56,32,116,111,54,52,57,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,33),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,54,53,48,32,102,114,111,109,54,53,49,32,116,111,54,53,50,41,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,32),40,115,117,98,115,56,118,101,99,116,111,114,32,118,54,53,51,32,102,114,111,109,54,53,52,32,116,111,54,53,53,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,54,53,54,32,102,114,111,109,54,53,55,32,116,111,54,53,56,41,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,33),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,54,53,57,32,102,114,111,109,54,54,48,32,116,111,54,54,49,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,54,54,50,32,102,114,111,109,54,54,51,32,116,111,54,54,52,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,54,54,53,32,102,114,111,109,54,54,54,32,116,111,54,54,55,41,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,12),40,100,111,54,56,53,32,105,54,56,55,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,31),40,98,111,100,121,54,55,52,32,112,111,114,116,54,56,49,32,102,114,111,109,54,56,50,32,116,111,54,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,116,111,54,55,56,32,37,112,111,114,116,54,55,49,54,57,51,32,37,102,114,111,109,54,55,50,54,57,52,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,114,111,109,54,55,55,32,37,112,111,114,116,54,55,49,54,57,54,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,54,55,54,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,31),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,54,54,57,32,46,32,103,54,54,56,54,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,55,49,48,32,112,111,114,116,55,49,54,32,115,116,97,114,116,55,49,55,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,55,49,51,32,37,112,111,114,116,55,48,56,55,50,53,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,55,49,50,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,39),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,55,48,53,32,100,101,115,116,55,48,54,32,46,32,103,55,48,52,55,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,18),40,119,114,97,112,32,115,116,114,55,51,52,32,110,55,51,53,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,19),40,98,111,100,121,55,52,51,32,110,55,52,57,32,112,55,53,48,41,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,19),40,100,101,102,45,112,55,52,54,32,37,110,55,52,49,55,54,52,41,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,55,52,53,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,25),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,103,55,51,57,55,52,48,41,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


/* from ext-free in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from k1175 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3161)
static void C_fcall f_3161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3094)
static void C_fcall f_3094(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_fcall f_3130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_fcall f_3083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3034)
static void C_fcall f_3034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2984)
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_fcall f_3000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2919)
static void C_fcall f_2919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_fcall f_2914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2905)
static void C_fcall f_2905(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_fcall f_2883(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_ccall f_2707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_fcall f_2488(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_fcall f_2459(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2441)
static void C_fcall f_2441(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2315)
static void C_fcall f_2315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_fcall f_2326(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2197)
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_fcall f_2214(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2134)
static void C_fcall f_2134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_fcall f_2129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2124)
static void C_fcall f_2124(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2072)
static void C_fcall f_2072(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_fcall f_2094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_fcall f_2099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2007)
static void C_fcall f_2007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_fcall f_2002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1997)
static void C_fcall f_1997(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1945)
static void C_fcall f_1945(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_fcall f_1967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_fcall f_1972(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1880)
static void C_fcall f_1880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_fcall f_1875(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1870)
static void C_fcall f_1870(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1825)
static void C_fcall f_1825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static C_word C_fcall f_1849(C_word t0,C_word t1);
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1760)
static void C_fcall f_1760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1750)
static void C_fcall f_1750(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1705)
static void C_fcall f_1705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static C_word C_fcall f_1729(C_word t0,C_word t1);
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1640)
static void C_fcall f_1640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_fcall f_1635(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1630)
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1585)
static void C_fcall f_1585(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_fcall f_1609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1520)
static void C_fcall f_1520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_fcall f_1515(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1465)
static void C_fcall f_1465(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_fcall f_1489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1400)
static void C_fcall f_1400(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_fcall f_1395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1390)
static void C_fcall f_1390(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1345)
static void C_fcall f_1345(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1280)
static void C_fcall f_1280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_fcall f_1275(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1270)
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1225)
static void C_fcall f_1225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_fcall f_1180(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_fcall f_1085(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_fcall f_996(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_fcall f_979(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_fcall f_965(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_922)
static void C_fcall f_922(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_913)
static C_word C_fcall f_913(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_910)
static C_word C_fcall f_910(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_907)
static void C_ccall f_907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_904)
static void C_ccall f_904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_880)
static void C_ccall f_880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3161)
static void C_fcall trf_3161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3161(t0,t1);}

C_noret_decl(trf_3156)
static void C_fcall trf_3156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3156(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3156(t0,t1,t2);}

C_noret_decl(trf_3094)
static void C_fcall trf_3094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3094(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3094(t0,t1,t2,t3);}

C_noret_decl(trf_3130)
static void C_fcall trf_3130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3130(t0,t1);}

C_noret_decl(trf_3083)
static void C_fcall trf_3083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3083(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3083(t0,t1,t2);}

C_noret_decl(trf_3034)
static void C_fcall trf_3034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3034(t0,t1);}

C_noret_decl(trf_3029)
static void C_fcall trf_3029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3029(t0,t1,t2);}

C_noret_decl(trf_2984)
static void C_fcall trf_2984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2984(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2984(t0,t1,t2,t3);}

C_noret_decl(trf_3000)
static void C_fcall trf_3000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3000(t0,t1);}

C_noret_decl(trf_2919)
static void C_fcall trf_2919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2919(t0,t1);}

C_noret_decl(trf_2914)
static void C_fcall trf_2914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2914(t0,t1,t2);}

C_noret_decl(trf_2905)
static void C_fcall trf_2905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2905(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2905(t0,t1,t2,t3);}

C_noret_decl(trf_2868)
static void C_fcall trf_2868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2868(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2868(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2883)
static void C_fcall trf_2883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2883(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2883(t0,t1,t2);}

C_noret_decl(trf_2775)
static void C_fcall trf_2775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2775(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2775(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2488)
static void C_fcall trf_2488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2488(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2488(t0,t1,t2,t3);}

C_noret_decl(trf_2459)
static void C_fcall trf_2459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2459(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2459(t0,t1,t2,t3);}

C_noret_decl(trf_2441)
static void C_fcall trf_2441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2441(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2441(t0,t1,t2);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2430(t0,t1,t2);}

C_noret_decl(trf_2315)
static void C_fcall trf_2315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2315(t0,t1,t2);}

C_noret_decl(trf_2326)
static void C_fcall trf_2326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2326(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2326(t0,t1,t2);}

C_noret_decl(trf_2197)
static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2197(t0,t1,t2,t3);}

C_noret_decl(trf_2214)
static void C_fcall trf_2214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2214(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2214(t0,t1,t2,t3);}

C_noret_decl(trf_2134)
static void C_fcall trf_2134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2134(t0,t1);}

C_noret_decl(trf_2129)
static void C_fcall trf_2129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2129(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2129(t0,t1,t2);}

C_noret_decl(trf_2124)
static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2124(t0,t1,t2,t3);}

C_noret_decl(trf_2072)
static void C_fcall trf_2072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2072(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2072(t0,t1,t2,t3);}

C_noret_decl(trf_2094)
static void C_fcall trf_2094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2094(t0,t1);}

C_noret_decl(trf_2099)
static void C_fcall trf_2099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2099(t0,t1,t2);}

C_noret_decl(trf_2007)
static void C_fcall trf_2007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2007(t0,t1);}

C_noret_decl(trf_2002)
static void C_fcall trf_2002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2002(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2002(t0,t1,t2);}

C_noret_decl(trf_1997)
static void C_fcall trf_1997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1997(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1997(t0,t1,t2,t3);}

C_noret_decl(trf_1945)
static void C_fcall trf_1945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1945(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1945(t0,t1,t2,t3);}

C_noret_decl(trf_1967)
static void C_fcall trf_1967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1967(t0,t1);}

C_noret_decl(trf_1972)
static void C_fcall trf_1972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1972(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1972(t0,t1,t2);}

C_noret_decl(trf_1880)
static void C_fcall trf_1880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1880(t0,t1);}

C_noret_decl(trf_1875)
static void C_fcall trf_1875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1875(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1875(t0,t1,t2);}

C_noret_decl(trf_1870)
static void C_fcall trf_1870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1870(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1870(t0,t1,t2,t3);}

C_noret_decl(trf_1825)
static void C_fcall trf_1825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1825(t0,t1,t2,t3);}

C_noret_decl(trf_1760)
static void C_fcall trf_1760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1760(t0,t1);}

C_noret_decl(trf_1755)
static void C_fcall trf_1755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1755(t0,t1,t2);}

C_noret_decl(trf_1750)
static void C_fcall trf_1750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1750(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1750(t0,t1,t2,t3);}

C_noret_decl(trf_1705)
static void C_fcall trf_1705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1705(t0,t1,t2,t3);}

C_noret_decl(trf_1640)
static void C_fcall trf_1640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1640(t0,t1);}

C_noret_decl(trf_1635)
static void C_fcall trf_1635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1635(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1635(t0,t1,t2);}

C_noret_decl(trf_1630)
static void C_fcall trf_1630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1630(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1630(t0,t1,t2,t3);}

C_noret_decl(trf_1585)
static void C_fcall trf_1585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1585(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1585(t0,t1,t2,t3);}

C_noret_decl(trf_1609)
static void C_fcall trf_1609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1609(t0,t1,t2);}

C_noret_decl(trf_1520)
static void C_fcall trf_1520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1520(t0,t1);}

C_noret_decl(trf_1515)
static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1515(t0,t1,t2);}

C_noret_decl(trf_1510)
static void C_fcall trf_1510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1510(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1510(t0,t1,t2,t3);}

C_noret_decl(trf_1465)
static void C_fcall trf_1465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1465(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1465(t0,t1,t2,t3);}

C_noret_decl(trf_1489)
static void C_fcall trf_1489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1489(t0,t1,t2);}

C_noret_decl(trf_1400)
static void C_fcall trf_1400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1400(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1400(t0,t1);}

C_noret_decl(trf_1395)
static void C_fcall trf_1395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1395(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1395(t0,t1,t2);}

C_noret_decl(trf_1390)
static void C_fcall trf_1390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1390(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1390(t0,t1,t2,t3);}

C_noret_decl(trf_1345)
static void C_fcall trf_1345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1345(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1345(t0,t1,t2,t3);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1369(t0,t1,t2);}

C_noret_decl(trf_1280)
static void C_fcall trf_1280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1280(t0,t1);}

C_noret_decl(trf_1275)
static void C_fcall trf_1275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1275(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1275(t0,t1,t2);}

C_noret_decl(trf_1270)
static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1270(t0,t1,t2,t3);}

C_noret_decl(trf_1225)
static void C_fcall trf_1225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1225(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1225(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1249(t0,t1,t2);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1205(t0,t1);}

C_noret_decl(trf_1180)
static void C_fcall trf_1180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1180(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1180(t0,t1,t2,t3);}

C_noret_decl(trf_1085)
static void C_fcall trf_1085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1085(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1085(t0,t1,t2,t3);}

C_noret_decl(trf_996)
static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_996(t0,t1,t2,t3);}

C_noret_decl(trf_979)
static void C_fcall trf_979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_979(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_979(t0,t1,t2,t3);}

C_noret_decl(trf_965)
static void C_fcall trf_965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_965(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_965(t0,t1,t2,t3);}

C_noret_decl(trf_922)
static void C_fcall trf_922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_922(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_922(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(61);
if(!C_demand(61)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1554)){
C_save(t1);
C_rereclaim2(1554*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(61);
C_initialize_lf(lf,176);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscheck-exact-interval");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],26,"\003syscheck-inexact-interval");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[14]=C_h_intern(&lf[14],15,"\003syscons-flonum");
lf[24]=C_h_intern(&lf[24],15,"u8vector-length");
lf[25]=C_h_intern(&lf[25],15,"s8vector-length");
lf[26]=C_h_intern(&lf[26],16,"u16vector-length");
lf[27]=C_h_intern(&lf[27],16,"s16vector-length");
lf[28]=C_h_intern(&lf[28],16,"u32vector-length");
lf[29]=C_h_intern(&lf[29],16,"s32vector-length");
lf[30]=C_h_intern(&lf[30],16,"f32vector-length");
lf[31]=C_h_intern(&lf[31],16,"f64vector-length");
lf[32]=C_h_intern(&lf[32],15,"\003syscheck-range");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[34]=C_h_intern(&lf[34],13,"u8vector-set!");
lf[35]=C_h_intern(&lf[35],13,"s8vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u16vector-set!");
lf[37]=C_h_intern(&lf[37],14,"s16vector-set!");
lf[38]=C_h_intern(&lf[38],14,"u32vector-set!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"s32vector-set!");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[43]=C_h_intern(&lf[43],14,"f32vector-set!");
lf[44]=C_h_intern(&lf[44],14,"f64vector-set!");
lf[45]=C_h_intern(&lf[45],12,"u8vector-ref");
lf[46]=C_h_intern(&lf[46],12,"s8vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u16vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s16vector-ref");
lf[49]=C_h_intern(&lf[49],13,"u32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"s32vector-ref");
lf[51]=C_h_intern(&lf[51],13,"f32vector-ref");
lf[52]=C_h_intern(&lf[52],13,"f64vector-ref");
lf[53]=C_h_intern(&lf[53],14,"set-finalizer!");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000;not enough memory - can not allocate external number vector");
lf[55]=C_h_intern(&lf[55],19,"\003sysallocate-vector");
lf[56]=C_h_intern(&lf[56],21,"release-number-vector");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[59]=C_h_intern(&lf[59],13,"make-u8vector");
lf[60]=C_h_intern(&lf[60],8,"u8vector");
lf[61]=C_h_intern(&lf[61],13,"make-s8vector");
lf[62]=C_h_intern(&lf[62],8,"s8vector");
lf[63]=C_h_intern(&lf[63],4,"fin\077");
lf[64]=C_h_intern(&lf[64],14,"make-u16vector");
lf[65]=C_h_intern(&lf[65],9,"u16vector");
lf[66]=C_h_intern(&lf[66],14,"make-s16vector");
lf[67]=C_h_intern(&lf[67],9,"s16vector");
lf[68]=C_h_intern(&lf[68],14,"make-u32vector");
lf[69]=C_h_intern(&lf[69],9,"u32vector");
lf[70]=C_h_intern(&lf[70],14,"make-s32vector");
lf[71]=C_h_intern(&lf[71],9,"s32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f32vector");
lf[73]=C_h_intern(&lf[73],9,"f32vector");
lf[74]=C_h_intern(&lf[74],14,"make-f64vector");
lf[75]=C_h_intern(&lf[75],9,"f64vector");
lf[76]=C_h_intern(&lf[76],27,"\003sysnot-a-proper-list-error");
lf[77]=C_h_intern(&lf[77],14,"list->u8vector");
lf[78]=C_h_intern(&lf[78],14,"list->s8vector");
lf[79]=C_h_intern(&lf[79],15,"list->u16vector");
lf[80]=C_h_intern(&lf[80],15,"list->s16vector");
lf[81]=C_h_intern(&lf[81],15,"list->u32vector");
lf[82]=C_h_intern(&lf[82],15,"list->s32vector");
lf[83]=C_h_intern(&lf[83],15,"list->f32vector");
lf[84]=C_h_intern(&lf[84],15,"list->f64vector");
lf[85]=C_h_intern(&lf[85],14,"u8vector->list");
lf[86]=C_h_intern(&lf[86],14,"s8vector->list");
lf[87]=C_h_intern(&lf[87],15,"u16vector->list");
lf[88]=C_h_intern(&lf[88],15,"s16vector->list");
lf[89]=C_h_intern(&lf[89],15,"u32vector->list");
lf[90]=C_h_intern(&lf[90],15,"s32vector->list");
lf[91]=C_h_intern(&lf[91],15,"f32vector->list");
lf[92]=C_h_intern(&lf[92],15,"f64vector->list");
lf[93]=C_h_intern(&lf[93],9,"u8vector\077");
lf[94]=C_h_intern(&lf[94],9,"s8vector\077");
lf[95]=C_h_intern(&lf[95],10,"u16vector\077");
lf[96]=C_h_intern(&lf[96],10,"s16vector\077");
lf[97]=C_h_intern(&lf[97],10,"u32vector\077");
lf[98]=C_h_intern(&lf[98],10,"s32vector\077");
lf[99]=C_h_intern(&lf[99],10,"f32vector\077");
lf[100]=C_h_intern(&lf[100],10,"f64vector\077");
lf[101]=C_h_intern(&lf[101],13,"\003sysmake-blob");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[104]=C_h_intern(&lf[104],21,"u8vector->blob/shared");
lf[105]=C_h_intern(&lf[105],21,"s8vector->blob/shared");
lf[106]=C_h_intern(&lf[106],22,"u16vector->blob/shared");
lf[107]=C_h_intern(&lf[107],22,"s16vector->blob/shared");
lf[108]=C_h_intern(&lf[108],22,"u32vector->blob/shared");
lf[109]=C_h_intern(&lf[109],22,"s32vector->blob/shared");
lf[110]=C_h_intern(&lf[110],22,"f32vector->blob/shared");
lf[111]=C_h_intern(&lf[111],22,"f64vector->blob/shared");
lf[112]=C_h_intern(&lf[112],14,"u8vector->blob");
lf[113]=C_h_intern(&lf[113],14,"s8vector->blob");
lf[114]=C_h_intern(&lf[114],15,"u16vector->blob");
lf[115]=C_h_intern(&lf[115],15,"s16vector->blob");
lf[116]=C_h_intern(&lf[116],15,"u32vector->blob");
lf[117]=C_h_intern(&lf[117],15,"s32vector->blob");
lf[118]=C_h_intern(&lf[118],15,"f32vector->blob");
lf[119]=C_h_intern(&lf[119],15,"f64vector->blob");
lf[120]=C_h_intern(&lf[120],21,"blob->u8vector/shared");
lf[121]=C_h_intern(&lf[121],21,"blob->s8vector/shared");
lf[122]=C_h_intern(&lf[122],22,"blob->u16vector/shared");
lf[123]=C_h_intern(&lf[123],22,"blob->s16vector/shared");
lf[124]=C_h_intern(&lf[124],22,"blob->u32vector/shared");
lf[125]=C_h_intern(&lf[125],22,"blob->s32vector/shared");
lf[126]=C_h_intern(&lf[126],22,"blob->f32vector/shared");
lf[127]=C_h_intern(&lf[127],22,"blob->f64vector/shared");
lf[128]=C_h_intern(&lf[128],14,"blob->u8vector");
lf[129]=C_h_intern(&lf[129],14,"blob->s8vector");
lf[130]=C_h_intern(&lf[130],15,"blob->u16vector");
lf[131]=C_h_intern(&lf[131],15,"blob->s16vector");
lf[132]=C_h_intern(&lf[132],15,"blob->u32vector");
lf[133]=C_h_intern(&lf[133],15,"blob->s32vector");
lf[134]=C_h_intern(&lf[134],15,"blob->f32vector");
lf[135]=C_h_intern(&lf[135],15,"blob->f64vector");
lf[136]=C_h_intern(&lf[136],18,"\003sysuser-read-hook");
lf[137]=C_h_intern(&lf[137],4,"read");
lf[138]=C_h_intern(&lf[138],2,"u8");
lf[139]=C_h_intern(&lf[139],2,"s8");
lf[140]=C_h_intern(&lf[140],3,"u16");
lf[141]=C_h_intern(&lf[141],3,"s16");
lf[142]=C_h_intern(&lf[142],3,"u32");
lf[143]=C_h_intern(&lf[143],3,"s32");
lf[144]=C_h_intern(&lf[144],3,"f32");
lf[145]=C_h_intern(&lf[145],3,"f64");
lf[146]=C_h_intern(&lf[146],1,"f");
lf[147]=C_h_intern(&lf[147],1,"F");
lf[148]=C_h_intern(&lf[148],14,"\003sysread-error");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[150]=C_h_intern(&lf[150],19,"\003sysuser-print-hook");
lf[151]=C_h_intern(&lf[151],9,"\003sysprint");
lf[153]=C_h_intern(&lf[153],11,"subu8vector");
lf[154]=C_h_intern(&lf[154],12,"subu16vector");
lf[155]=C_h_intern(&lf[155],12,"subu32vector");
lf[156]=C_h_intern(&lf[156],11,"subs8vector");
lf[157]=C_h_intern(&lf[157],12,"subs16vector");
lf[158]=C_h_intern(&lf[158],12,"subs32vector");
lf[159]=C_h_intern(&lf[159],12,"subf32vector");
lf[160]=C_h_intern(&lf[160],12,"subf64vector");
lf[161]=C_h_intern(&lf[161],14,"write-u8vector");
lf[162]=C_h_intern(&lf[162],16,"\003syswrite-char-0");
lf[163]=C_h_intern(&lf[163],14,"\003syscheck-port");
lf[164]=C_h_intern(&lf[164],19,"\003sysstandard-output");
lf[165]=C_h_intern(&lf[165],14,"read-u8vector!");
lf[166]=C_h_intern(&lf[166],16,"\003sysread-string!");
lf[167]=C_h_intern(&lf[167],18,"\003sysstandard-input");
lf[168]=C_h_intern(&lf[168],18,"open-output-string");
lf[169]=C_h_intern(&lf[169],17,"get-output-string");
lf[170]=C_h_intern(&lf[170],13,"read-u8vector");
lf[171]=C_h_intern(&lf[171],19,"\003syswrite-char/port");
lf[172]=C_h_intern(&lf[172],15,"\003sysread-char-0");
lf[173]=C_h_intern(&lf[173],17,"register-feature!");
lf[174]=C_h_intern(&lf[174],6,"srfi-4");
lf[175]=C_h_intern(&lf[175],18,"getter-with-setter");
C_register_lf2(lf,176,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_832,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_847,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_868,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_871,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_874,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[10],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_877,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_880,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_898,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_904,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_907,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[20],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_910,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_913,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[22],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_916,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[23],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_919,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_922,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_935,a[2]=t21,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 140  len */
f_922(t22,lf[60],C_SCHEME_FALSE,lf[24]);}

/* k933 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 141  len */
f_922(t3,lf[62],C_SCHEME_FALSE,lf[25]);}

/* k937 in k933 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 142  len */
f_922(t3,lf[65],C_fix(1),lf[26]);}

/* k941 in k937 in k933 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_943,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 143  len */
f_922(t3,lf[67],C_fix(1),lf[27]);}

/* k945 in k941 in k937 in k933 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 144  len */
f_922(t3,lf[69],C_fix(2),lf[28]);}

/* k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 145  len */
f_922(t3,lf[71],C_fix(2),lf[29]);}

/* k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 146  len */
f_922(t3,lf[73],C_fix(2),lf[30]);}

/* k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 147  len */
f_922(t3,lf[75],C_fix(3),lf[31]);}

/* k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1111,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 203  setu */
f_996(t7,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 204  set */
f_979(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1115,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 205  setu */
f_996(t3,*((C_word*)lf[26]+1),lf[18],lf[36]);}

/* k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 206  set */
f_979(t3,*((C_word*)lf[27]+1),lf[19],lf[37]);}

/* k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=*((C_word*)lf[28]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1051,a[2]=t3,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t5=C_mutate((C_word*)lf[38]+1,t4);
t6=*((C_word*)lf[29]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1024,a[2]=t6,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t8=C_mutate((C_word*)lf[41]+1,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 209  setf */
f_1085(t9,*((C_word*)lf[30]+1),lf[22],lf[43]);}

/* k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 210  setf */
f_1085(t3,*((C_word*)lf[31]+1),lf[23],lf[44]);}

/* k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3242,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 213  get */
f_965(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k3240 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 213  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 216  get */
f_965(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k3236 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 216  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 219  get */
f_965(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k3232 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 219  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1151,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 222  get */
f_965(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k3228 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 222  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[37]+1));}

/* k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 226  get */
f_965(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k3224 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 225  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 230  get */
f_965(t4,*((C_word*)lf[29]+1),lf[12],lf[50]);}

/* k3220 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 229  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 234  get */
f_965(t4,*((C_word*)lf[30]+1),lf[13],lf[51]);}

/* k3216 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 233  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[43]+1));}

/* k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1167,2,t0,t1);}
t2=C_mutate((C_word*)lf[51]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 238  get */
f_965(t4,*((C_word*)lf[31]+1),lf[15],lf[52]);}

/* k3212 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 237  getter-with-setter */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[44]+1));}

/* k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[53]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1180,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=t3,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1223,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1343,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t9=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1463,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1583,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1703,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1823,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t13=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1943,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t14=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2070,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 397  init */
f_2197(t16,*((C_word*)lf[59]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 398  init */
f_2197(t3,*((C_word*)lf[61]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 399  init */
f_2197(t3,*((C_word*)lf[64]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 400  init */
f_2197(t3,*((C_word*)lf[66]+1),*((C_word*)lf[37]+1),lf[80]);}

/* k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 401  init */
f_2197(t3,*((C_word*)lf[68]+1),*((C_word*)lf[38]+1),lf[81]);}

/* k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 402  init */
f_2197(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[82]);}

/* k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 403  init */
f_2197(t3,*((C_word*)lf[72]+1),*((C_word*)lf[43]+1),lf[83]);}

/* k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 404  init */
f_2197(t3,*((C_word*)lf[74]+1),*((C_word*)lf[44]+1),lf[84]);}

/* k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1,t1);
t3=*((C_word*)lf[77]+1);
t4=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2267,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[78]+1);
t6=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2273,a[2]=t5,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[79]+1);
t8=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2279,a[2]=t7,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t9=*((C_word*)lf[80]+1);
t10=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2285,a[2]=t9,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[81]+1);
t12=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t11,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[82]+1);
t14=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t13,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[83]+1);
t16=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t15,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t17=*((C_word*)lf[84]+1);
t18=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=t17,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2352,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 455  init */
f_2315(t20,*((C_word*)lf[24]+1),lf[7]);}

/* k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 456  init */
f_2315(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 457  init */
f_2315(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 458  init */
f_2315(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2364,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 459  init */
f_2315(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 460  init */
f_2315(t3,*((C_word*)lf[29]+1),lf[12]);}

/* k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 461  init */
f_2315(t3,*((C_word*)lf[30]+1),lf[13]);}

/* k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 462  init */
f_2315(t3,*((C_word*)lf[31]+1),lf[15]);}

/* k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1,t1);
t3=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2412,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2418,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2424,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2441,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2488,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2522,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 514  pack */
f_2430(t15,lf[60],lf[104]);}

/* k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2522,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 515  pack */
f_2430(t3,lf[62],lf[105]);}

/* k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 516  pack */
f_2430(t3,lf[65],lf[106]);}

/* k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 517  pack */
f_2430(t3,lf[67],lf[107]);}

/* k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 518  pack */
f_2430(t3,lf[69],lf[108]);}

/* k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 519  pack */
f_2430(t3,lf[71],lf[109]);}

/* k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 520  pack */
f_2430(t3,lf[73],lf[110]);}

/* k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 521  pack */
f_2430(t3,lf[75],lf[111]);}

/* k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 523  pack-copy */
f_2441(t3,lf[60],lf[112]);}

/* k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 524  pack-copy */
f_2441(t3,lf[62],lf[113]);}

/* k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 525  pack-copy */
f_2441(t3,lf[65],lf[114]);}

/* k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 526  pack-copy */
f_2441(t3,lf[67],lf[115]);}

/* k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 527  pack-copy */
f_2441(t3,lf[69],lf[116]);}

/* k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 528  pack-copy */
f_2441(t3,lf[71],lf[117]);}

/* k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 529  pack-copy */
f_2441(t3,lf[73],lf[118]);}

/* k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 530  pack-copy */
f_2441(t3,lf[75],lf[119]);}

/* k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 532  unpack */
f_2459(t3,lf[60],C_SCHEME_TRUE,lf[120]);}

/* k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 533  unpack */
f_2459(t3,lf[62],C_SCHEME_TRUE,lf[121]);}

/* k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 534  unpack */
f_2459(t3,lf[65],C_fix(2),lf[122]);}

/* k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 535  unpack */
f_2459(t3,lf[67],C_fix(2),lf[123]);}

/* k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 536  unpack */
f_2459(t3,lf[69],C_fix(4),lf[124]);}

/* k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 537  unpack */
f_2459(t3,lf[71],C_fix(4),lf[125]);}

/* k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 538  unpack */
f_2459(t3,lf[73],C_fix(4),lf[126]);}

/* k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 539  unpack */
f_2459(t3,lf[75],C_fix(8),lf[127]);}

/* k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2614,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 541  unpack-copy */
f_2488(t3,lf[60],C_SCHEME_TRUE,lf[128]);}

/* k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 542  unpack-copy */
f_2488(t3,lf[62],C_SCHEME_TRUE,lf[129]);}

/* k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 543  unpack-copy */
f_2488(t3,lf[65],C_fix(2),lf[130]);}

/* k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 544  unpack-copy */
f_2488(t3,lf[67],C_fix(2),lf[131]);}

/* k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 545  unpack-copy */
f_2488(t3,lf[69],C_fix(4),lf[132]);}

/* k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 546  unpack-copy */
f_2488(t3,lf[71],C_fix(4),lf[133]);}

/* k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 547  unpack-copy */
f_2488(t3,lf[73],C_fix(4),lf[134]);}

/* k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 548  unpack-copy */
f_2488(t3,lf[75],C_fix(8),lf[135]);}

/* k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[103],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1,t1);
t3=*((C_word*)lf[136]+1);
t4=*((C_word*)lf[137]+1);
t5=(C_word)C_a_i_list(&a,16,lf[138],*((C_word*)lf[77]+1),lf[139],*((C_word*)lf[78]+1),lf[140],*((C_word*)lf[79]+1),lf[141],*((C_word*)lf[80]+1),lf[142],*((C_word*)lf[81]+1),lf[143],*((C_word*)lf[82]+1),lf[144],*((C_word*)lf[83]+1),lf[145],*((C_word*)lf[84]+1));
t6=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2651,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[150]+1);
t8=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2707,a[2]=t7,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[152],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[156]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2836,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[161]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[168]+1);
t21=*((C_word*)lf[169]+1);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3092,a[2]=t20,a[3]=t21,a[4]=t22,a[5]=((C_word)li137),tmp=(C_word)a,a+=6,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 670  register-feature! */
t25=*((C_word*)lf[173]+1);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,lf[174]);}

/* k3208 in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_3092r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3092r(t0,t1,t2);}}

static void C_ccall f_3092r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li134),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3156,a[2]=t3,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t4,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n745765 */
t6=t5;
f_3161(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p746763 */
t8=t4;
f_3156(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body743748 */
t10=t3;
f_3094(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n745 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3161,NULL,2,t0,t1);}
/* def-p746763 */
t2=((C_word*)t0)[2];
f_3156(t2,t1,C_SCHEME_FALSE);}

/* def-p746 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3156,NULL,3,t0,t1,t2);}
/* body743748 */
t3=((C_word*)t0)[2];
f_3094(t3,t1,t2,*((C_word*)lf[167]+1));}

/* body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3094(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3094,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 650  ##sys#check-port */
t5=*((C_word*)lf[163]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[170]);}

/* k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[170]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 652  ##sys#allocate-vector */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 659  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k3123 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li133),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3130(t5,((C_word*)t0)[2]);}

/* loop in k3123 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3130,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 661  ##sys#read-char-0 */
t3=*((C_word*)lf[172]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3132 in loop in k3123 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 663  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 667  ##sys#write-char/port */
t3=*((C_word*)lf[171]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k3150 in k3132 in loop in k3123 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 668  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3130(t2,((C_word*)t0)[2]);}

/* k3141 in k3132 in loop in k3123 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 665  wrap */
f_3083(((C_word*)t0)[2],t1,t2);}

/* k3105 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  ##sys#read-string! */
t3=*((C_word*)lf[166]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3108 in k3105 in k3096 in body743 in read-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 657  wrap */
f_3083(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3083(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3083,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3091,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 645  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3089 in wrap in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[60],t1));}

/* read-u8vector! in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_2982r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2982r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2982r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2984,a[2]=t5,a[3]=t3,a[4]=((C_word)li128),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3029,a[2]=t6,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3034,a[2]=t7,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port712726 */
t9=t8;
f_3034(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start713724 */
t11=t7;
f_3029(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body710715 */
t13=t6;
f_2984(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port712 in read-u8vector! in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3034,NULL,2,t0,t1);}
/* def-start713724 */
t2=((C_word*)t0)[2];
f_3029(t2,t1,*((C_word*)lf[167]+1));}

/* def-start713 in read-u8vector! in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3029,NULL,3,t0,t1,t2);}
/* body710715 */
t3=((C_word*)t0)[2];
f_2984(t3,t1,t2,C_fix(0));}

/* body710 in read-u8vector! in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2984,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2988,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 629  ##sys#check-port */
t5=*((C_word*)lf[163]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[165]);}

/* k2986 in body710 in read-u8vector! in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[165]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[60],lf[165]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[165]);
t7=(C_word)C_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3000(t12,t11);}
else{
t9=t5;
f_3000(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3000(t6,C_SCHEME_UNDEFINED);}}

/* k2998 in k2986 in body710 in read-u8vector! in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_3000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 637  ##sys#read-string! */
t2=*((C_word*)lf[166]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2866r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2866r(t0,t1,t2,t3);}}

static void C_ccall f_2866r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2868,a[2]=t2,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2905,a[2]=t2,a[3]=t4,a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=t5,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=t6,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port676697 */
t8=t7;
f_2919(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from677695 */
t10=t6;
f_2914(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to678692 */
t12=t5;
f_2905(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body674680 */
t14=t4;
f_2868(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-port676 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2919,NULL,2,t0,t1);}
/* def-from677695 */
t2=((C_word*)t0)[2];
f_2914(t2,t1,*((C_word*)lf[164]+1));}

/* def-from677 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2914,NULL,3,t0,t1,t2);}
/* def-to678692 */
t3=((C_word*)t0)[2];
f_2905(t3,t1,t2,C_fix(0));}

/* def-to678 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2905(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2905,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2913,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 620  u8vector-length */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k2911 in def-to678 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body674680 */
t2=((C_word*)t0)[5];
f_2868(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body674 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2868,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[60],lf[161]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2875,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 622  ##sys#check-port */
t7=*((C_word*)lf[163]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[161]);}

/* k2873 in body674 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2883(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do685 in k2873 in body674 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2883(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2883,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2893,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 626  ##sys#write-char-0 */
t5=*((C_word*)lf[162]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* k2891 in do685 in k2873 in body674 in write-u8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2883(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2860,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 618  subvector */
f_2775(t1,t2,lf[75],C_fix(8),t3,t4,lf[160]);}

/* subf32vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2854,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 617  subvector */
f_2775(t1,t2,lf[73],C_fix(4),t3,t4,lf[159]);}

/* subs32vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2848,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 616  subvector */
f_2775(t1,t2,lf[71],C_fix(4),t3,t4,lf[158]);}

/* subs16vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2842,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 615  subvector */
f_2775(t1,t2,lf[67],C_fix(2),t3,t4,lf[157]);}

/* subs8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2836,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 614  subvector */
f_2775(t1,t2,lf[62],C_fix(1),t3,t4,lf[156]);}

/* subu32vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2830,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 613  subvector */
f_2775(t1,t2,lf[69],C_fix(4),t3,t4,lf[155]);}

/* subu16vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2824,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 612  subvector */
f_2775(t1,t2,lf[65],C_fix(2),t3,t4,lf[154]);}

/* subu8vector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2818,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 611  subvector */
f_2775(t1,t2,lf[60],C_fix(1),t3,t4,lf[153]);}

/* subvector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2775(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2775,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2788,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 602  ##sys#check-range */
t14=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k2786 in subvector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 603  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k2789 in k2786 in subvector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 605  ##sys#allocate-vector */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2795 in k2789 in k2786 in subvector in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2707,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,3,lf[60],lf[138],*((C_word*)lf[85]+1));
t6=(C_word)C_a_i_list(&a,3,lf[62],lf[139],*((C_word*)lf[86]+1));
t7=(C_word)C_a_i_list(&a,3,lf[65],lf[140],*((C_word*)lf[87]+1));
t8=(C_word)C_a_i_list(&a,3,lf[67],lf[141],*((C_word*)lf[88]+1));
t9=(C_word)C_a_i_list(&a,3,lf[69],lf[142],*((C_word*)lf[89]+1));
t10=(C_word)C_a_i_list(&a,3,lf[71],lf[143],*((C_word*)lf[90]+1));
t11=(C_word)C_a_i_list(&a,3,lf[73],lf[144],*((C_word*)lf[91]+1));
t12=(C_word)C_a_i_list(&a,3,lf[75],lf[145],*((C_word*)lf[92]+1));
t13=(C_word)C_a_i_list(&a,8,t5,t6,t7,t8,t9,t10,t11,t12);
t14=(C_word)C_i_assq((C_word)C_slot(t2,C_fix(0)),t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2717,a[2]=t2,a[3]=t14,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 589  ##sys#print */
t16=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 592  old-hook */
t15=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t15))(5,t15,t1,t2,t3,t4);}}

/* k2715 in ##sys#user-print-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 590  ##sys#print */
t4=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k2718 in k2715 in ##sys#user-print-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,((C_word*)t0)[2]);}

/* k2725 in k2718 in k2715 in ##sys#user-print-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 591  ##sys#print */
t2=*((C_word*)lf[151]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2651,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2661,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 566  read */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 571  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2659 in ##sys#user-read-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[146]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[147]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 569  read */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 570  ##sys#read-error */
t7=*((C_word*)lf[148]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,((C_word*)t0)[5],((C_word*)t0)[2],lf[149],t3);}}}

/* k2684 in k2659 in ##sys#user-read-hook in k2644 in k2640 in k2636 in k2632 in k2628 in k2624 in k2620 in k2616 in k2612 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2576 in k2572 in k2568 in k2564 in k2560 in k2556 in k2552 in k2548 in k2544 in k2540 in k2536 in k2532 in k2528 in k2524 in k2520 in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2488(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2488,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2490,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));}

/* f_2490 in unpack-copy in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2490,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 506  ##sys#make-blob */
t6=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2498 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 512  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[103],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2459(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2459,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2461,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp));}

/* f_2461 in unpack in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2461,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 500  ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[102],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2441(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2441,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2443,a[2]=t3,a[3]=t2,a[4]=((C_word)li105),tmp=(C_word)a,a+=5,tmp));}

/* f_2443 in pack-copy in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2443,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2453,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 490  ##sys#make-blob */
t7=*((C_word*)lf[101]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k2451 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2430(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2430,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2432,a[2]=t3,a[3]=t2,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));}

/* f_2432 in pack in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2432,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2424,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[75]));}

/* f32vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2418,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* s32vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2412,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* u32vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2406,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* s16vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2400,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* u16vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2394,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* s8vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2388,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[62]));}

/* u8vector? in k2378 in k2374 in k2370 in k2366 in k2362 in k2358 in k2354 in k2350 in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2382,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* init in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2315(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2315,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t2,a[3]=t3,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));}

/* f_2317 in init in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2317,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2321,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 448  length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2319 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2326(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2319 */
static void C_fcall f_2326(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2326,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 452  ref */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2338 in loop in k2319 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 453  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2326(t4,t2,t3);}

/* k2342 in k2338 in loop in k2319 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2309r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2309r(t0,t1,t2);}}

static void C_ccall f_2309r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 439  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* f32vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2303r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2303r(t0,t1,t2);}}

static void C_ccall f_2303r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 435  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s32vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2297r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2297r(t0,t1,t2);}}

static void C_ccall f_2297r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 431  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u32vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2291r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2291r(t0,t1,t2);}}

static void C_ccall f_2291r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 427  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s16vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2285r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2285r(t0,t1,t2);}}

static void C_ccall f_2285r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 423  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u16vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2279r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2279r(t0,t1,t2);}}

static void C_ccall f_2279r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 419  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* s8vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2273r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2273r(t0,t1,t2);}}

static void C_ccall f_2273r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 415  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* u8vector in k2263 in k2259 in k2255 in k2251 in k2247 in k2243 in k2239 in k2235 in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2267r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2267r(t0,t1,t2);}}

static void C_ccall f_2267r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 411  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* init in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2197(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2199,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));}

/* f_2199 in init in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2199,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2209,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 389  make */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2207 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2214(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do486 in k2207 */
static void C_fcall f_2214(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2214,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2221,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 394  set */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 395  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2219 in do486 in k2207 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2214(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_2070r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2070r(t0,t1,t2,t3);}}

static void C_ccall f_2070r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li76),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2124,a[2]=t4,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2129,a[2]=t5,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2134,a[2]=t6,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init441464 */
t8=t7;
f_2134(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?442462 */
t10=t6;
f_2129(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin443459 */
t12=t5;
f_2124(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body439445 */
t14=t4;
f_2072(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init441 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2134,NULL,2,t0,t1);}
/* def-ext?442462 */
t2=((C_word*)t0)[2];
f_2129(t2,t1,C_SCHEME_FALSE);}

/* def-ext?442 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2129(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2129,NULL,3,t0,t1,t2);}
/* def-fin443459 */
t3=((C_word*)t0)[2];
f_2124(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin443 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2124(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,4,t0,t1,t2,t3);}
/* body439445 */
t4=((C_word*)t0)[2];
f_2072(t4,t1,t2,t3);}

/* body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2072(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2072,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[74]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 368  alloc */
f_1180(t6,lf[74],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2121 in body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[75],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 369  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2082(2,t5,C_SCHEME_UNDEFINED);}}

/* k2080 in k2121 in body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2082,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[74]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2094(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 375  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2111 in k2080 in k2121 in body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2094(t3,t2);}

/* k2092 in k2080 in k2121 in body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2094,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li75),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2099(t5,((C_word*)t0)[2],C_fix(0));}

/* do450 in k2092 in k2080 in k2121 in body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2099,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2106,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 378  ##sys#f64vector-set! */
t4=lf[23];
f_919(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2104 in do450 in k2092 in k2080 in k2121 in body439 in make-f64vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2099(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1943r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1943r(t0,t1,t2,t3);}}

static void C_ccall f_1943r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=t5,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t6,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init403426 */
t8=t7;
f_2007(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?404424 */
t10=t6;
f_2002(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin405421 */
t12=t5;
f_1997(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body401407 */
t14=t4;
f_1945(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init403 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2007,NULL,2,t0,t1);}
/* def-ext?404424 */
t2=((C_word*)t0)[2];
f_2002(t2,t1,C_SCHEME_FALSE);}

/* def-ext?404 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_2002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2002,NULL,3,t0,t1,t2);}
/* def-fin405421 */
t3=((C_word*)t0)[2];
f_1997(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin405 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1997(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1997,NULL,4,t0,t1,t2,t3);}
/* body401407 */
t4=((C_word*)t0)[2];
f_1945(t4,t1,t2,t3);}

/* body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1945(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1945,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 353  alloc */
f_1180(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1994 in body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 354  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1955(2,t5,C_SCHEME_UNDEFINED);}}

/* k1953 in k1994 in body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_1967(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 360  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1984 in k1953 in k1994 in body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1967(t3,t2);}

/* k1965 in k1953 in k1994 in body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1967,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1972(t5,((C_word*)t0)[2],C_fix(0));}

/* do412 in k1965 in k1953 in k1994 in body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1972(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1972,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1979,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 363  ##sys#f32vector-set! */
t4=lf[22];
f_916(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k1977 in do412 in k1965 in k1953 in k1994 in body401 in make-f32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1972(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1823r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1823r(t0,t1,t2,t3);}}

static void C_ccall f_1823r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=t4,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1875,a[2]=t5,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1880,a[2]=t6,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init366388 */
t8=t7;
f_1880(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?367386 */
t10=t6;
f_1875(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin368383 */
t12=t5;
f_1870(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body364370 */
t14=t4;
f_1825(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init366 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1880,NULL,2,t0,t1);}
/* def-ext?367386 */
t2=((C_word*)t0)[2];
f_1875(t2,t1,C_SCHEME_FALSE);}

/* def-ext?367 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1875(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1875,NULL,3,t0,t1,t2);}
/* def-fin368383 */
t3=((C_word*)t0)[2];
f_1870(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin368 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1870(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1870,NULL,4,t0,t1,t2,t3);}
/* body364370 */
t4=((C_word*)t0)[2];
f_1825(t4,t1,t2,t3);}

/* body364 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1825,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 340  alloc */
f_1180(t5,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1867 in body364 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 341  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1835(2,t5,C_SCHEME_UNDEFINED);}}

/* k1833 in k1867 in body364 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1849(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do375 in k1833 in k1867 in body364 in make-s32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static C_word C_fcall f_1849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_913(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1703r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1703r(t0,t1,t2,t3);}}

static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1750,a[2]=t4,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1755,a[2]=t5,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1760,a[2]=t6,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init329351 */
t8=t7;
f_1760(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?330349 */
t10=t6;
f_1755(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin331346 */
t12=t5;
f_1750(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body327333 */
t14=t4;
f_1705(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init329 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1760,NULL,2,t0,t1);}
/* def-ext?330349 */
t2=((C_word*)t0)[2];
f_1755(t2,t1,C_SCHEME_FALSE);}

/* def-ext?330 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1755,NULL,3,t0,t1,t2);}
/* def-fin331346 */
t3=((C_word*)t0)[2];
f_1750(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin331 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1750(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1750,NULL,4,t0,t1,t2,t3);}
/* body327333 */
t4=((C_word*)t0)[2];
f_1705(t4,t1,t2,t3);}

/* body327 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1705,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 327  alloc */
f_1180(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k1747 in body327 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 328  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1715(2,t5,C_SCHEME_UNDEFINED);}}

/* k1713 in k1747 in body327 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1729(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* do338 in k1713 in k1747 in body327 in make-u32vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static C_word C_fcall f_1729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_910(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1583r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1583r(t0,t1,t2,t3);}}

static void C_ccall f_1583r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li52),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1630,a[2]=t4,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1635,a[2]=t5,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1640,a[2]=t6,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init292314 */
t8=t7;
f_1640(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?293312 */
t10=t6;
f_1635(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin294309 */
t12=t5;
f_1630(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body290296 */
t14=t4;
f_1585(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init292 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1640,NULL,2,t0,t1);}
/* def-ext?293312 */
t2=((C_word*)t0)[2];
f_1635(t2,t1,C_SCHEME_FALSE);}

/* def-ext?293 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1635(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1635,NULL,3,t0,t1,t2);}
/* def-fin294309 */
t3=((C_word*)t0)[2];
f_1630(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin294 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1630,NULL,4,t0,t1,t2,t3);}
/* body290296 */
t4=((C_word*)t0)[2];
f_1585(t4,t1,t2,t3);}

/* body290 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1585(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1585,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 314  alloc */
f_1180(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1627 in body290 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 315  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1595(2,t5,C_SCHEME_UNDEFINED);}}

/* k1593 in k1627 in body290 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 319  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[66]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1602 in k1593 in k1627 in body290 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li51),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1609(t5,((C_word*)t0)[2],C_fix(0));}

/* do301 in k1602 in k1593 in k1627 in body290 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1609,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1616,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 322  ##sys#s16vector-set! */
t4=lf[19];
f_907(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1614 in do301 in k1602 in k1593 in k1627 in body290 in make-s16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1609(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1463r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1463r(t0,t1,t2,t3);}}

static void C_ccall f_1463r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t4,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=t6,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init255277 */
t8=t7;
f_1520(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?256275 */
t10=t6;
f_1515(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin257272 */
t12=t5;
f_1510(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body253259 */
t14=t4;
f_1465(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init255 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1520,NULL,2,t0,t1);}
/* def-ext?256275 */
t2=((C_word*)t0)[2];
f_1515(t2,t1,C_SCHEME_FALSE);}

/* def-ext?256 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1515,NULL,3,t0,t1,t2);}
/* def-fin257272 */
t3=((C_word*)t0)[2];
f_1510(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin257 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1510,NULL,4,t0,t1,t2,t3);}
/* body253259 */
t4=((C_word*)t0)[2];
f_1465(t4,t1,t2,t3);}

/* body253 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1465(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1465,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 301  alloc */
f_1180(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1507 in body253 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 302  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1475(2,t5,C_SCHEME_UNDEFINED);}}

/* k1473 in k1507 in body253 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 306  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1482 in k1473 in k1507 in body253 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1484,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1489(t5,((C_word*)t0)[2],C_fix(0));}

/* do264 in k1482 in k1473 in k1507 in body253 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1489,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 309  ##sys#u16vector-set! */
t4=lf[18];
f_904(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1494 in do264 in k1482 in k1473 in k1507 in body253 in make-u16vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1489(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1343r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1343r(t0,t1,t2,t3);}}

static void C_ccall f_1343r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1390,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1395,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1400,a[2]=t6,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init218240 */
t8=t7;
f_1400(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?219238 */
t10=t6;
f_1395(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin220235 */
t12=t5;
f_1390(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body216222 */
t14=t4;
f_1345(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init218 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1400(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1400,NULL,2,t0,t1);}
/* def-ext?219238 */
t2=((C_word*)t0)[2];
f_1395(t2,t1,C_SCHEME_FALSE);}

/* def-ext?219 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1395,NULL,3,t0,t1,t2);}
/* def-fin220235 */
t3=((C_word*)t0)[2];
f_1390(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin220 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1390(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1390,NULL,4,t0,t1,t2,t3);}
/* body216222 */
t4=((C_word*)t0)[2];
f_1345(t4,t1,t2,t3);}

/* body216 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1345(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1345,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 288  alloc */
f_1180(t5,lf[61],((C_word*)t0)[5],t3);}

/* k1387 in body216 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1389,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[63]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 289  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1355(2,t5,C_SCHEME_UNDEFINED);}}

/* k1353 in k1387 in body216 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 293  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[61]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1362 in k1353 in k1387 in body216 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1364,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1369(t5,((C_word*)t0)[2],C_fix(0));}

/* do227 in k1362 in k1353 in k1387 in body216 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1376,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 296  ##sys#s8vector-set! */
t4=lf[17];
f_901(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1374 in do227 in k1362 in k1353 in k1387 in body216 in make-s8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1369(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_1223r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1223r(t0,t1,t2,t3);}}

static void C_ccall f_1223r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1270,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=t5,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1280,a[2]=t6,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init180202 */
t8=t7;
f_1280(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?181200 */
t10=t6;
f_1275(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?182197 */
t12=t5;
f_1270(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body178184 */
t14=t4;
f_1225(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init180 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1280,NULL,2,t0,t1);}
/* def-ext?181200 */
t2=((C_word*)t0)[2];
f_1275(t2,t1,C_SCHEME_FALSE);}

/* def-ext?181 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1275(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1275,NULL,3,t0,t1,t2);}
/* def-fin?182197 */
t3=((C_word*)t0)[2];
f_1270(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?182 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1270,NULL,4,t0,t1,t2,t3);}
/* body178184 */
t4=((C_word*)t0)[2];
f_1225(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body178 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1225(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1225,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 275  alloc */
f_1180(t6,lf[59],((C_word*)t0)[5],t3);}

/* k1267 in body178 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 276  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1235(2,t5,C_SCHEME_UNDEFINED);}}

/* k1233 in k1267 in body178 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 280  ##sys#check-exact-interval */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1242 in k1233 in k1267 in body178 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1244,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1249(t5,((C_word*)t0)[2],C_fix(0));}

/* do189 in k1242 in k1233 in k1267 in body178 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1249(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1249,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1256,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 283  ##sys#u8vector-set! */
t4=lf[16];
f_898(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1254 in do189 in k1242 in k1233 in k1267 in body178 in make-u8vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1249(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1198,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1205,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1205(t5,(C_word)C_i_memq(t4,lf[58]));}
else{
t4=t3;
f_1205(t4,C_SCHEME_FALSE);}}

/* k1203 in release-number-vector in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-4.scm: 269  ext-free */
t2=((C_word*)t0)[4];
f_1178(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 270  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[56],lf[57],((C_word*)t0)[2]);}}

/* alloc in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1180(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1180,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)C_i_foreign_fixnum_argumentp(t5);
t7=(C_word)stub153(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* srfi-4.scm: 260  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[54],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 261  ##sys#allocate-vector */
t6=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1194 in alloc in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1169 in k1165 in k1161 in k1157 in k1153 in k1149 in k1145 in k1141 in k1137 in k1133 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1178,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub158(C_SCHEME_UNDEFINED,t2));}

/* f_1024 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1024,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1028,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 178  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1026 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1031,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1031(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 180  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[41],lf[42],((C_word*)t0)[2]);}}

/* k1029 in k1026 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 181  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[41]);}

/* k1032 in k1029 in k1026 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 182  upd */
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_913(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_1051 in k1121 in k1117 in k1113 in k1109 in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1051,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1055,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 186  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1053 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1058,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 188  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[39],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1058(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 190  ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[40],((C_word*)t0)[2]);}}}

/* k1056 in k1053 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 191  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[38]);}

/* k1059 in k1056 in k1053 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 192  upd */
t2=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_910(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_1085(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1085,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1087,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));}

/* f_1087 in setf in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1087,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1091,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 196  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1089 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 198  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1095 in k1089 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1104(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 201  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1102 in k1095 in k1089 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 199  upd */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_996(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_996,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_998,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));}

/* f_998 in setu in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_998,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1002,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 169  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1000 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 172  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[33],((C_word*)t0)[7]);}
else{
t4=t3;
f_1008(2,t4,C_SCHEME_UNDEFINED);}}

/* k1006 in k1000 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 173  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1009 in k1006 in k1000 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 174  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_979(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_979,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_981,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));}

/* f_981 in set in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_981,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_985,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 162  length */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k983 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 164  ##sys#check-range */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k989 in k983 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 165  upd */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_fcall f_965(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_965,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_967,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp));}

/* f_967 in get in k961 in k957 in k953 in k949 in k945 in k941 in k937 in k933 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_967,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 156  length */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k969 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 157  ##sys#check-range */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k972 in k969 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 158  acc */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_922(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_922,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_924,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp));}

/* f_924 in len */
static void C_ccall f_924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_924,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_919,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_916,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_913(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_910(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_stack_check;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void C_ccall f_907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_907,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_904,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_901,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_898,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_892,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 116  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_886,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 112  ##sys#cons-flonum */
t5=*((C_word*)lf[14]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_883,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_880,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_877,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_874,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_871,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_868(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_868,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_847,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 98   ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[6],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_832,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 92   ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[295] = {
{"toplevelsrfi-4.scm",(void*)C_srfi_4_toplevel},
{"f_935srfi-4.scm",(void*)f_935},
{"f_939srfi-4.scm",(void*)f_939},
{"f_943srfi-4.scm",(void*)f_943},
{"f_947srfi-4.scm",(void*)f_947},
{"f_951srfi-4.scm",(void*)f_951},
{"f_955srfi-4.scm",(void*)f_955},
{"f_959srfi-4.scm",(void*)f_959},
{"f_963srfi-4.scm",(void*)f_963},
{"f_1111srfi-4.scm",(void*)f_1111},
{"f_1115srfi-4.scm",(void*)f_1115},
{"f_1119srfi-4.scm",(void*)f_1119},
{"f_1123srfi-4.scm",(void*)f_1123},
{"f_1135srfi-4.scm",(void*)f_1135},
{"f_1139srfi-4.scm",(void*)f_1139},
{"f_3242srfi-4.scm",(void*)f_3242},
{"f_1143srfi-4.scm",(void*)f_1143},
{"f_3238srfi-4.scm",(void*)f_3238},
{"f_1147srfi-4.scm",(void*)f_1147},
{"f_3234srfi-4.scm",(void*)f_3234},
{"f_1151srfi-4.scm",(void*)f_1151},
{"f_3230srfi-4.scm",(void*)f_3230},
{"f_1155srfi-4.scm",(void*)f_1155},
{"f_3226srfi-4.scm",(void*)f_3226},
{"f_1159srfi-4.scm",(void*)f_1159},
{"f_3222srfi-4.scm",(void*)f_3222},
{"f_1163srfi-4.scm",(void*)f_1163},
{"f_3218srfi-4.scm",(void*)f_3218},
{"f_1167srfi-4.scm",(void*)f_1167},
{"f_3214srfi-4.scm",(void*)f_3214},
{"f_1171srfi-4.scm",(void*)f_1171},
{"f_2237srfi-4.scm",(void*)f_2237},
{"f_2241srfi-4.scm",(void*)f_2241},
{"f_2245srfi-4.scm",(void*)f_2245},
{"f_2249srfi-4.scm",(void*)f_2249},
{"f_2253srfi-4.scm",(void*)f_2253},
{"f_2257srfi-4.scm",(void*)f_2257},
{"f_2261srfi-4.scm",(void*)f_2261},
{"f_2265srfi-4.scm",(void*)f_2265},
{"f_2352srfi-4.scm",(void*)f_2352},
{"f_2356srfi-4.scm",(void*)f_2356},
{"f_2360srfi-4.scm",(void*)f_2360},
{"f_2364srfi-4.scm",(void*)f_2364},
{"f_2368srfi-4.scm",(void*)f_2368},
{"f_2372srfi-4.scm",(void*)f_2372},
{"f_2376srfi-4.scm",(void*)f_2376},
{"f_2380srfi-4.scm",(void*)f_2380},
{"f_2522srfi-4.scm",(void*)f_2522},
{"f_2526srfi-4.scm",(void*)f_2526},
{"f_2530srfi-4.scm",(void*)f_2530},
{"f_2534srfi-4.scm",(void*)f_2534},
{"f_2538srfi-4.scm",(void*)f_2538},
{"f_2542srfi-4.scm",(void*)f_2542},
{"f_2546srfi-4.scm",(void*)f_2546},
{"f_2550srfi-4.scm",(void*)f_2550},
{"f_2554srfi-4.scm",(void*)f_2554},
{"f_2558srfi-4.scm",(void*)f_2558},
{"f_2562srfi-4.scm",(void*)f_2562},
{"f_2566srfi-4.scm",(void*)f_2566},
{"f_2570srfi-4.scm",(void*)f_2570},
{"f_2574srfi-4.scm",(void*)f_2574},
{"f_2578srfi-4.scm",(void*)f_2578},
{"f_2582srfi-4.scm",(void*)f_2582},
{"f_2586srfi-4.scm",(void*)f_2586},
{"f_2590srfi-4.scm",(void*)f_2590},
{"f_2594srfi-4.scm",(void*)f_2594},
{"f_2598srfi-4.scm",(void*)f_2598},
{"f_2602srfi-4.scm",(void*)f_2602},
{"f_2606srfi-4.scm",(void*)f_2606},
{"f_2610srfi-4.scm",(void*)f_2610},
{"f_2614srfi-4.scm",(void*)f_2614},
{"f_2618srfi-4.scm",(void*)f_2618},
{"f_2622srfi-4.scm",(void*)f_2622},
{"f_2626srfi-4.scm",(void*)f_2626},
{"f_2630srfi-4.scm",(void*)f_2630},
{"f_2634srfi-4.scm",(void*)f_2634},
{"f_2638srfi-4.scm",(void*)f_2638},
{"f_2642srfi-4.scm",(void*)f_2642},
{"f_2646srfi-4.scm",(void*)f_2646},
{"f_3210srfi-4.scm",(void*)f_3210},
{"f_3092srfi-4.scm",(void*)f_3092},
{"f_3161srfi-4.scm",(void*)f_3161},
{"f_3156srfi-4.scm",(void*)f_3156},
{"f_3094srfi-4.scm",(void*)f_3094},
{"f_3098srfi-4.scm",(void*)f_3098},
{"f_3125srfi-4.scm",(void*)f_3125},
{"f_3130srfi-4.scm",(void*)f_3130},
{"f_3134srfi-4.scm",(void*)f_3134},
{"f_3152srfi-4.scm",(void*)f_3152},
{"f_3143srfi-4.scm",(void*)f_3143},
{"f_3107srfi-4.scm",(void*)f_3107},
{"f_3110srfi-4.scm",(void*)f_3110},
{"f_3083srfi-4.scm",(void*)f_3083},
{"f_3091srfi-4.scm",(void*)f_3091},
{"f_2982srfi-4.scm",(void*)f_2982},
{"f_3034srfi-4.scm",(void*)f_3034},
{"f_3029srfi-4.scm",(void*)f_3029},
{"f_2984srfi-4.scm",(void*)f_2984},
{"f_2988srfi-4.scm",(void*)f_2988},
{"f_3000srfi-4.scm",(void*)f_3000},
{"f_2866srfi-4.scm",(void*)f_2866},
{"f_2919srfi-4.scm",(void*)f_2919},
{"f_2914srfi-4.scm",(void*)f_2914},
{"f_2905srfi-4.scm",(void*)f_2905},
{"f_2913srfi-4.scm",(void*)f_2913},
{"f_2868srfi-4.scm",(void*)f_2868},
{"f_2875srfi-4.scm",(void*)f_2875},
{"f_2883srfi-4.scm",(void*)f_2883},
{"f_2893srfi-4.scm",(void*)f_2893},
{"f_2860srfi-4.scm",(void*)f_2860},
{"f_2854srfi-4.scm",(void*)f_2854},
{"f_2848srfi-4.scm",(void*)f_2848},
{"f_2842srfi-4.scm",(void*)f_2842},
{"f_2836srfi-4.scm",(void*)f_2836},
{"f_2830srfi-4.scm",(void*)f_2830},
{"f_2824srfi-4.scm",(void*)f_2824},
{"f_2818srfi-4.scm",(void*)f_2818},
{"f_2775srfi-4.scm",(void*)f_2775},
{"f_2788srfi-4.scm",(void*)f_2788},
{"f_2791srfi-4.scm",(void*)f_2791},
{"f_2797srfi-4.scm",(void*)f_2797},
{"f_2707srfi-4.scm",(void*)f_2707},
{"f_2717srfi-4.scm",(void*)f_2717},
{"f_2720srfi-4.scm",(void*)f_2720},
{"f_2727srfi-4.scm",(void*)f_2727},
{"f_2651srfi-4.scm",(void*)f_2651},
{"f_2661srfi-4.scm",(void*)f_2661},
{"f_2686srfi-4.scm",(void*)f_2686},
{"f_2488srfi-4.scm",(void*)f_2488},
{"f_2490srfi-4.scm",(void*)f_2490},
{"f_2500srfi-4.scm",(void*)f_2500},
{"f_2459srfi-4.scm",(void*)f_2459},
{"f_2461srfi-4.scm",(void*)f_2461},
{"f_2441srfi-4.scm",(void*)f_2441},
{"f_2443srfi-4.scm",(void*)f_2443},
{"f_2453srfi-4.scm",(void*)f_2453},
{"f_2430srfi-4.scm",(void*)f_2430},
{"f_2432srfi-4.scm",(void*)f_2432},
{"f_2424srfi-4.scm",(void*)f_2424},
{"f_2418srfi-4.scm",(void*)f_2418},
{"f_2412srfi-4.scm",(void*)f_2412},
{"f_2406srfi-4.scm",(void*)f_2406},
{"f_2400srfi-4.scm",(void*)f_2400},
{"f_2394srfi-4.scm",(void*)f_2394},
{"f_2388srfi-4.scm",(void*)f_2388},
{"f_2382srfi-4.scm",(void*)f_2382},
{"f_2315srfi-4.scm",(void*)f_2315},
{"f_2317srfi-4.scm",(void*)f_2317},
{"f_2321srfi-4.scm",(void*)f_2321},
{"f_2326srfi-4.scm",(void*)f_2326},
{"f_2340srfi-4.scm",(void*)f_2340},
{"f_2344srfi-4.scm",(void*)f_2344},
{"f_2309srfi-4.scm",(void*)f_2309},
{"f_2303srfi-4.scm",(void*)f_2303},
{"f_2297srfi-4.scm",(void*)f_2297},
{"f_2291srfi-4.scm",(void*)f_2291},
{"f_2285srfi-4.scm",(void*)f_2285},
{"f_2279srfi-4.scm",(void*)f_2279},
{"f_2273srfi-4.scm",(void*)f_2273},
{"f_2267srfi-4.scm",(void*)f_2267},
{"f_2197srfi-4.scm",(void*)f_2197},
{"f_2199srfi-4.scm",(void*)f_2199},
{"f_2209srfi-4.scm",(void*)f_2209},
{"f_2214srfi-4.scm",(void*)f_2214},
{"f_2221srfi-4.scm",(void*)f_2221},
{"f_2070srfi-4.scm",(void*)f_2070},
{"f_2134srfi-4.scm",(void*)f_2134},
{"f_2129srfi-4.scm",(void*)f_2129},
{"f_2124srfi-4.scm",(void*)f_2124},
{"f_2072srfi-4.scm",(void*)f_2072},
{"f_2123srfi-4.scm",(void*)f_2123},
{"f_2082srfi-4.scm",(void*)f_2082},
{"f_2113srfi-4.scm",(void*)f_2113},
{"f_2094srfi-4.scm",(void*)f_2094},
{"f_2099srfi-4.scm",(void*)f_2099},
{"f_2106srfi-4.scm",(void*)f_2106},
{"f_1943srfi-4.scm",(void*)f_1943},
{"f_2007srfi-4.scm",(void*)f_2007},
{"f_2002srfi-4.scm",(void*)f_2002},
{"f_1997srfi-4.scm",(void*)f_1997},
{"f_1945srfi-4.scm",(void*)f_1945},
{"f_1996srfi-4.scm",(void*)f_1996},
{"f_1955srfi-4.scm",(void*)f_1955},
{"f_1986srfi-4.scm",(void*)f_1986},
{"f_1967srfi-4.scm",(void*)f_1967},
{"f_1972srfi-4.scm",(void*)f_1972},
{"f_1979srfi-4.scm",(void*)f_1979},
{"f_1823srfi-4.scm",(void*)f_1823},
{"f_1880srfi-4.scm",(void*)f_1880},
{"f_1875srfi-4.scm",(void*)f_1875},
{"f_1870srfi-4.scm",(void*)f_1870},
{"f_1825srfi-4.scm",(void*)f_1825},
{"f_1869srfi-4.scm",(void*)f_1869},
{"f_1835srfi-4.scm",(void*)f_1835},
{"f_1849srfi-4.scm",(void*)f_1849},
{"f_1703srfi-4.scm",(void*)f_1703},
{"f_1760srfi-4.scm",(void*)f_1760},
{"f_1755srfi-4.scm",(void*)f_1755},
{"f_1750srfi-4.scm",(void*)f_1750},
{"f_1705srfi-4.scm",(void*)f_1705},
{"f_1749srfi-4.scm",(void*)f_1749},
{"f_1715srfi-4.scm",(void*)f_1715},
{"f_1729srfi-4.scm",(void*)f_1729},
{"f_1583srfi-4.scm",(void*)f_1583},
{"f_1640srfi-4.scm",(void*)f_1640},
{"f_1635srfi-4.scm",(void*)f_1635},
{"f_1630srfi-4.scm",(void*)f_1630},
{"f_1585srfi-4.scm",(void*)f_1585},
{"f_1629srfi-4.scm",(void*)f_1629},
{"f_1595srfi-4.scm",(void*)f_1595},
{"f_1604srfi-4.scm",(void*)f_1604},
{"f_1609srfi-4.scm",(void*)f_1609},
{"f_1616srfi-4.scm",(void*)f_1616},
{"f_1463srfi-4.scm",(void*)f_1463},
{"f_1520srfi-4.scm",(void*)f_1520},
{"f_1515srfi-4.scm",(void*)f_1515},
{"f_1510srfi-4.scm",(void*)f_1510},
{"f_1465srfi-4.scm",(void*)f_1465},
{"f_1509srfi-4.scm",(void*)f_1509},
{"f_1475srfi-4.scm",(void*)f_1475},
{"f_1484srfi-4.scm",(void*)f_1484},
{"f_1489srfi-4.scm",(void*)f_1489},
{"f_1496srfi-4.scm",(void*)f_1496},
{"f_1343srfi-4.scm",(void*)f_1343},
{"f_1400srfi-4.scm",(void*)f_1400},
{"f_1395srfi-4.scm",(void*)f_1395},
{"f_1390srfi-4.scm",(void*)f_1390},
{"f_1345srfi-4.scm",(void*)f_1345},
{"f_1389srfi-4.scm",(void*)f_1389},
{"f_1355srfi-4.scm",(void*)f_1355},
{"f_1364srfi-4.scm",(void*)f_1364},
{"f_1369srfi-4.scm",(void*)f_1369},
{"f_1376srfi-4.scm",(void*)f_1376},
{"f_1223srfi-4.scm",(void*)f_1223},
{"f_1280srfi-4.scm",(void*)f_1280},
{"f_1275srfi-4.scm",(void*)f_1275},
{"f_1270srfi-4.scm",(void*)f_1270},
{"f_1225srfi-4.scm",(void*)f_1225},
{"f_1269srfi-4.scm",(void*)f_1269},
{"f_1235srfi-4.scm",(void*)f_1235},
{"f_1244srfi-4.scm",(void*)f_1244},
{"f_1249srfi-4.scm",(void*)f_1249},
{"f_1256srfi-4.scm",(void*)f_1256},
{"f_1198srfi-4.scm",(void*)f_1198},
{"f_1205srfi-4.scm",(void*)f_1205},
{"f_1180srfi-4.scm",(void*)f_1180},
{"f_1196srfi-4.scm",(void*)f_1196},
{"f_1178srfi-4.scm",(void*)f_1178},
{"f_1024srfi-4.scm",(void*)f_1024},
{"f_1028srfi-4.scm",(void*)f_1028},
{"f_1031srfi-4.scm",(void*)f_1031},
{"f_1034srfi-4.scm",(void*)f_1034},
{"f_1051srfi-4.scm",(void*)f_1051},
{"f_1055srfi-4.scm",(void*)f_1055},
{"f_1058srfi-4.scm",(void*)f_1058},
{"f_1061srfi-4.scm",(void*)f_1061},
{"f_1085srfi-4.scm",(void*)f_1085},
{"f_1087srfi-4.scm",(void*)f_1087},
{"f_1091srfi-4.scm",(void*)f_1091},
{"f_1097srfi-4.scm",(void*)f_1097},
{"f_1104srfi-4.scm",(void*)f_1104},
{"f_996srfi-4.scm",(void*)f_996},
{"f_998srfi-4.scm",(void*)f_998},
{"f_1002srfi-4.scm",(void*)f_1002},
{"f_1008srfi-4.scm",(void*)f_1008},
{"f_1011srfi-4.scm",(void*)f_1011},
{"f_979srfi-4.scm",(void*)f_979},
{"f_981srfi-4.scm",(void*)f_981},
{"f_985srfi-4.scm",(void*)f_985},
{"f_991srfi-4.scm",(void*)f_991},
{"f_965srfi-4.scm",(void*)f_965},
{"f_967srfi-4.scm",(void*)f_967},
{"f_971srfi-4.scm",(void*)f_971},
{"f_974srfi-4.scm",(void*)f_974},
{"f_922srfi-4.scm",(void*)f_922},
{"f_924srfi-4.scm",(void*)f_924},
{"f_919srfi-4.scm",(void*)f_919},
{"f_916srfi-4.scm",(void*)f_916},
{"f_913srfi-4.scm",(void*)f_913},
{"f_910srfi-4.scm",(void*)f_910},
{"f_907srfi-4.scm",(void*)f_907},
{"f_904srfi-4.scm",(void*)f_904},
{"f_901srfi-4.scm",(void*)f_901},
{"f_898srfi-4.scm",(void*)f_898},
{"f_892srfi-4.scm",(void*)f_892},
{"f_886srfi-4.scm",(void*)f_886},
{"f_883srfi-4.scm",(void*)f_883},
{"f_880srfi-4.scm",(void*)f_880},
{"f_877srfi-4.scm",(void*)f_877},
{"f_874srfi-4.scm",(void*)f_874},
{"f_871srfi-4.scm",(void*)f_871},
{"f_868srfi-4.scm",(void*)f_868},
{"f_847srfi-4.scm",(void*)f_847},
{"f_832srfi-4.scm",(void*)f_832},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
